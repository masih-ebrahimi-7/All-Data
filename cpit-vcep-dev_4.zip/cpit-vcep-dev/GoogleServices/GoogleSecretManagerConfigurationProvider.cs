﻿using System.ComponentModel;
using Google.Api.Gax;
using Google.Api.Gax.ResourceNames;
using Google.Cloud.SecretManager.V1;
using Microsoft.Extensions.Configuration;

namespace GoogleServices;

public class GoogleSecretManagerConfigurationProvider : ConfigurationProvider
{
    private string? ProjectId { get; set; }
    private SecretManagerServiceClient? Client { get; set; }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="GoogleSecretManagerConfigurationProvider"/> class.
    /// 
    /// This constructor sets the properties <see cref="Client"/> and <see cref="ProjectId"/>.
    /// It first attempts to use the default project ID from <see cref="Platform.Instance()"/>.
    /// If not available, it then uses the provided project ID.
    /// </summary>
    /// <param name="projectId">
    /// The Google Cloud project ID to use if the default from <see cref="Platform.Instance()"/> is not available.
    /// </param>
    public GoogleSecretManagerConfigurationProvider(string? projectId = null)
    {
        try
        {
            Client = SecretManagerServiceClient.Create();
            var platform = Platform.Instance();
            if (platform != null && platform.ProjectId != null)
            {
                ProjectId = platform.ProjectId;
            }
            else if (projectId != null)
            {
                ProjectName project = new ProjectName(projectId);
                ProjectId = project.ProjectId;
            }
        }
        catch (Exception exception)
        {
            throw new WarningException($"Error occured when trying to setup the Secret Manager Service Client. {exception}, {exception.StackTrace}");
        }
    }
    
    public string? GetSecret(string secretId)
    {
        if (ProjectId == null) return null;
        var secretVersionName = new SecretVersionName(ProjectId, secretId, "1");
        try
        {
            return AccessSecretVersion(secretVersionName);
        }
        catch (Exception)
        {
            return null;
        }
    }
    
    public string? GetSecretVersion(string secretId, string secretVersion)
    {
        if (ProjectId == null) return null;
        var secretVersionName = new SecretVersionName(ProjectId, secretId, secretVersion);

        try
        {
            return AccessSecretVersion(secretVersionName);
        }
        catch (Exception)
        {
            return null;
        }
    }

    private string AccessSecretVersion(SecretVersionName secret)
    {
        var result = Client?.AccessSecretVersion(secret);

        // Convert the payload to a string. Payloads are bytes by default.
        return result?.Payload.Data.ToStringUtf8();
    }
}