﻿using System.ComponentModel;

namespace GoogleServices.Enums;

public enum UploadFileType
{
    [Description("Invoice")] Invoice,
    [Description("Claim")] Claim,
    [Description("Grant")] Grant,
    [Description("Contract")] Contract,
    [Description("Archived")] Archived,
}
