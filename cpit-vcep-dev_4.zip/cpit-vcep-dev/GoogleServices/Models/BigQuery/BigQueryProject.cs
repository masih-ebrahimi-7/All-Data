using Google.Cloud.BigQuery.V2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleServices.Models.BigQuery
{
    public class BigQueryProject
    {
        public static string[] ColumnList
        {
            get
            {
                return new string[]
                {
                    "Project",
                    "Project_Description"
                };
            }
        }

        public static string ColumnQuery
        {
            get
            {
                return string.Join(',', ColumnList);
            }
        }

        public BigQueryProject(BigQueryRow row)
        {
            this.Id = row["Project"]?.ToString();
            this.Name = row["Project_Description"]?.ToString();
        }
        public string? Id { get; set; }
        public string? Name { get; set; }
    }
}
