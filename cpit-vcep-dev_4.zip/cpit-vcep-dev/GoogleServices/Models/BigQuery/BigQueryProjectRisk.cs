using Google.Cloud.BigQuery.V2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleServices.Models.BigQuery
{
    public class BigQueryProjectRisk
    {
        public static string[] ColumnList
        {
            get
            {
                return new string[]
                {
                    "Risk_Id",
                    "Risk_URL",
                    "Risk_Title",
                    "Risk_Description",
                    "Risk_Owner_Name",
                    "Creation_Date"

                };
            }
        }

        public static string ColumnQuery
        {
            get
            {
                return string.Join(',', ColumnList);
            }
        }

        public BigQueryProjectRisk(BigQueryRow row)
        {
            this.Id = row["Risk_Id"]?.ToString();
            this.Name = row["Risk_Title"]?.ToString();
            this.Url = row["Risk_URL"]?.ToString();
            this.Description = row["Risk_Description"]?.ToString();
            this.Owner = row["Risk_Owner_Name"]?.ToString();
            this.DateSubmittedString = row["Creation_Date"]?.ToString();

        }
        public string? Id { get; set; }
        public string? Name { get; set; }

        public string? Description { get; set; }
        public string Url { get; }
        public string Owner { get; set; }
        public string? DateSubmittedString { get; set; }
        public System.DateTime? DateSubmitted
        {
            get
            {
                System.DateTime date;
                if (!string.IsNullOrEmpty(this.DateSubmittedString) && System.DateTime.TryParse(this.DateSubmittedString, out date))
                {
                    return System.DateTime.SpecifyKind(date, DateTimeKind.Utc);
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
