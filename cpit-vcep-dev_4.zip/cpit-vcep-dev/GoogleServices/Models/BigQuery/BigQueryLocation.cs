using Google.Cloud.BigQuery.V2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleServices.Models.BigQuery
{
    public class BigQueryLocation
    {
        public static string[] ColumnList
        {
            get
            {
                return new string[]
                {
                    "Location",
                    "Location_Name",
                    "Location_Description",
                    "Location_GUID"
                };
            }
        }

        public static string ColumnQuery
        {
            get
            {
                return string.Join(',', ColumnList);
            }
        }

        public BigQueryLocation(BigQueryRow row)
        {
            this.Id = row["Location"]?.ToString();
            this.Name = row["Location_Name"]?.ToString();
            this.Description = row["Location_Description"]?.ToString();
            this.Guid = row["Location_GUID"]?.ToString();
        }
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Guid { get; set; }
    }
}
