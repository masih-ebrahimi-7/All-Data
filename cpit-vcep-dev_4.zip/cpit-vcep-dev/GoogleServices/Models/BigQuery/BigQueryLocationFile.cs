using Google.Cloud.BigQuery.V2;
using Google.Type;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleServices.Models.BigQuery
{
    public class BigQueryLocationFile
    {
        public static string[] ColumnList
        {
            get
            {
                return new string[]
                {
                    "Id",
                    "Created_At",
                    "Form_Name",
                    "Attachment_Url",
                    "Submitter_Email",
                    "Submitter_Name",
                    "Location_Id"
                };
            }
        }

        public static string ColumnQuery
        {
            get
            {
                return string.Join(',', ColumnList);
            }
        }

        public BigQueryLocationFile(BigQueryRow row)
        {
            this.OneUnopsId = row["Id"]?.ToString();
            this.DateSubmittedString = row["Created_At"]?.ToString();
            this.FormName = row["Form_Name"]?.ToString();
            this.Url = row["Attachment_Url"]?.ToString();
            this.SubmitterEmail = row["Submitter_Email"]?.ToString();
            this.SubmitterName = row["Submitter_Name"]?.ToString();
            this.LocationGuid = row["Location_Id"]?.ToString();
        }

        public string? OneUnopsId { get; set; }
        public string? DateSubmittedString { get; set; }
        public System.DateTime? DateSubmitted
        {
            get
            {
                System.DateTime date;
                if(!string.IsNullOrEmpty(this.DateSubmittedString) && System.DateTime.TryParse(this.DateSubmittedString, out date)){
                    return System.DateTime.SpecifyKind(date, DateTimeKind.Utc);
                }
                else
                {
                    return null;
                }
            }
        }
        public string? FormName { get; set; }
        public string? Url { get; set; }
        public string? SubmitterName { get; set; }
        public string? SubmitterEmail { get; set; }
        public string? LocationGuid { get; set; }
    }
}
