# Afghanistan Verification of Claims and Expenditures (VCEP)

Here you can find an application built with .NET 7 and Angular 15. It features user authentication via Auth0, email functionality through SMTP, and is hosted on Google Cloud Platform's Cloud Run. 

During local development, you can use [Swagger](https://localhost:7079/swagger/v1/swagger.json) to explore the API endpoints.

## Tech stack
- **Backend**: .NET 7
- **Frontend**: Angular 15
- **Authentication**: Auth0
- **Email**: SMTP for sending emails
- **Deployment**: Google Cloud Platform (GCP) Cloud Run
- **API Documentation**: Swagger (available in development)
- **Postgres database**: Database

## Code editors
   - Make sure you have a code editor installed such as [Visual Studio](https://visualstudio.microsoft.com/downloads/) or [Rider](https://www.jetbrains.com/rider/download/#section=mac) for the .NET code.
   - For the client code we recommend you [Visual Studio Code](https://code.visualstudio.com/download)

## Development
### Getting Started
0. **Database:**
   - Make sure you have a Postgres database up and running on your local machine. Update the connection string accordingly in `UNOPS.VCEP/appsettings.json`.
   - Keep in mind that you can also use a remote Postgres connection.

1. **Clone the repository:**
   ```bash
   git clone https://github.com/UNOPS-ITG/cpit-vcep.git
   cd cpit-vcep
   ```
2. **Backend Setup (.NET 7):**
   - Ensure you have [.NET 7 SDK](https://dotnet.microsoft.com/download/dotnet/7.0) installed.
3. **Client Setup (Angular 15):**
   - Ensure you have [Node.js](https://nodejs.org/) and [Angular CLI](https://angular.io/cli) installed.
   - Navigate to the client directory:
     ```bash
     cd ClientApp
     ```
   - Install dependencies:
     ```bash
     npm install
     ```
4. **Run the solution:**
   - Open you backend code editor and run the project `UNOPS.VCEP`
   - The first run is also setting up the database using migrations
5. **Activate your account:**
   - After your UI is available at https://localhost:44426/ you can click login
   - If you are the first user, you can activate your account in the database table `AspNetUsers`


### API Documentation
While in development, you can view and interact with the API using Swagger:
- [Swagger UI](https://localhost:7079/swagger/v1/swagger.json)

### Authentication
cpit-vcep uses Auth0 for user authentication. Ensure you configure Auth0 in your application settings according to the [Auth0 documentation](https://auth0.com/docs).

### Email
The application uses UNOPS SMTP for sending emails. Configure your SMTP settings in the `UNOPS.VCEP/appsettings.json` file of the .NET backend.
#### Keep in mind that emails won't work on local environment due to SMTP whitelisting restrictions.

### Deployment
This project is hosted on [GCP Cloud Run](https://console.cloud.google.com/run?project=unops-cpit-vcep-prod). For deployment instructions, refer to the [Google Cloud Run documentation](https://cloud.google.com/run/docs).

#### Test Environment
- A new revision of the test environment is deployed when new code is merged into `dev`branch.

#### Production Environment
- A new revision of the test environment is deployed when new code is merged into `main` branch.

## Contributing
1. Clone the repository.
2. Create a new branch (`git checkout -b feature-branch`).
3. Commit your changes (`git commit -am 'Add new feature'`).
4. Push to the branch (`git push origin feature-branch`).
5. Create a new Pull Request.

## Contact
For any inquiries, please reach out to [aidanb@unops.org](mailto:aidanb@unops.org).
```