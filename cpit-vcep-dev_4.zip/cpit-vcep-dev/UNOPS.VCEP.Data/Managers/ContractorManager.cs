using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class ContractorManager : IApplicationService
    {
        private readonly InfrastructureDbContext infrastructureDbContext;
        private readonly DataDbContext dataDbContext;

        public ContractorManager(InfrastructureDbContext infrastructureDbContext, DataDbContext dataDbContext)
        {
            this.infrastructureDbContext = infrastructureDbContext;
            this.dataDbContext = dataDbContext;
        }
        
        public async Task<List<TypeaheadInput>> GetExternalEntitiesForFilter(int? sector, int? grantId, int? contractId)
        {
            var externalEntities = infrastructureDbContext.ExternalEntities.AsQueryable();
            if (contractId != null)
            {
                var ids = await dataDbContext.Contracts.Where(a => a.Id == contractId).Select(a => a.Contractor.Id).ToListAsync();
                externalEntities = externalEntities.Where(a => ids.Contains(a.Id));

            }
            
            if (sector != null && Enum.IsDefined(typeof(SectorType), sector))
            {
                var ids = await dataDbContext.Contracts
                    .Where(a => a.Grants.Any(a => a.Sector == (SectorType)sector))
                    .Select(a => a.Contractor.Id).ToListAsync();
                externalEntities = externalEntities.Where(a => ids.Contains(a.Id));
            }
            
            if (grantId != null)
            {
                var ids = await dataDbContext.Contracts
                    .Where(a => a.Grants.Any(a => a.Id.Equals(grantId)))
                    .Select(a => a.Contractor.Id).ToListAsync();
                externalEntities = externalEntities.Where(a => ids.Contains(a.Id));
            }
            
            return await externalEntities.Select(a => new TypeaheadInput
            {
                Value = a.Id.ToString(),
                Label = a.Name
            }).ToListAsync();
        }

    }
}
