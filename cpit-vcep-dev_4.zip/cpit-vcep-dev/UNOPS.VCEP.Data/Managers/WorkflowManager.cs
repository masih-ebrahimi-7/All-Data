﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Stateless;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;
using UNOPS.VCEP.Infrastructure.Models.Audit;
using UNOPS.VCEP.Infrastructure.Security;
using UsersManager.DataAccess;
using UsersManager.Domain;

namespace UNOPS.VCEP.Data.Managers
{
    public class WorkflowManager
    {
        private readonly DataDbContext _dataDbContext;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly NotificationManager _notificationManager;
        public WorkflowManager(DataDbContext dataDbContext, UserManager<ApplicationUser> userManager, ApplicationDbContext applicationDbContext,
            NotificationManager notificationManager)
        {
            _dataDbContext = dataDbContext;
            _userManager = userManager;
            _applicationDbContext = applicationDbContext;
            _notificationManager = notificationManager;
        }

        private IQueryable<WorkflowStepModel> GetAll()
        {
            return _dataDbContext.WorkflowSteps
                .Select(t => new WorkflowStepModel(t));
        }

        public async Task<WorkflowStepModel[]> GetForClaim(int claimId)
        {

            return await _dataDbContext.WorkflowSteps.Where(t => t.ClaimId == claimId)
                .Select(t => new WorkflowStepModel(t)).ToArrayAsync();
        }

        public async Task<ActionModel<ClaimStatus>[]> ClaimActions(int claimId, string currentUser)
        {
            var claim = await _dataDbContext.Claims
                .Include(x => x.DocumentAttachments)
                .Include(x => x.Remarks).SingleAsync(t => t.Id == claimId);

            var wf = await GetClaimWorkflow(claim, currentUser);

            return wf.PermittedTriggers.Select(t => new ActionModel<ClaimStatus>
            {
                Value = t,
                Name = t.ToString(),
                Description = t.GetDescriptionFromEnumValue(),
                LongDescription = t.GetLongDescriptionFromEnumValue(),
                Icon = t.GetIconFromEnumValue(),
                Style = t.GetStyleFromEnumValue()
            }).ToArray();
        }

        public async Task<PaginationResponse<AuditLogModel>> GetAuditLogs(string entityName, int entityId, AuditLogModelFilter filter)
        {
            var auditLogsQuery = this._dataDbContext.DataAuditLogs
                .Include(x => x.Properties)
                .Where(log => log.EntityId == entityId && log.EntityTypeName == entityName);

            if (!string.IsNullOrEmpty(filter.Query))
            {
                auditLogsQuery = auditLogsQuery.Where(x => x.CreatedBy.ToLower().Contains(filter.Query.ToLower()));
            }

            return auditLogsQuery.OrderByDescending(x => x.CreatedDate).Paginate(o => new AuditLogModel(o), filter);
        }

        public async Task Trigger(TransitionModel model, string currentUser)
        {
            var claim = await _dataDbContext.Claims.SingleAsync(t => t.Id == model.ClaimId);

            var wf = await GetClaimWorkflow(claim, currentUser);

            if (wf.PermittedTriggers.Contains(model.ToStatus))
            {

                if (claim.Status == ClaimStatus.AwaitingClearance || claim.Status == ClaimStatus.Rejected)
                {
                    if (model.ClaimType == null && model.ToStatus != ClaimStatus.Rejected)
                        throw new BusinessException("Claim type is mandatory when clearing a claim.");
                    claim.UpdateType(model.ClaimType);
                }

                await wf.FireAsync(model.ToStatus);
                claim.Status = wf.State;

                var step = new WorkflowStep
                {
                    ClaimStatus = wf.State,
                    ClaimId = claim.Id
                };

                if (wf.State == ClaimStatus.Rejected)
                    claim.UpdateRejectionNotes(model.ExternalRejectionNote, model.InternalRejectionNote);
                if (wf.State == ClaimStatus.InitialReview)
                    claim.ResetRejectionNotes();

                _dataDbContext.WorkflowSteps.Add(step);

                await _dataDbContext.SaveChangesAsync();

            }
        }

        public async Task<StateMachine<LeadReportStatus, LeadReportStatus>> GetClaimLeadReportStatuses(StateMachine<LeadReportStatus, LeadReportStatus> workflow, string currentUser)
        {
            var projectManagerUsers = await _userManager.GetUsersInRoleAsync(BaseRole.ProjectManager);

            workflow.Configure(LeadReportStatus.Draft)
                .PermitIf(LeadReportStatus.UnderReview, LeadReportStatus.UnderReview);

            workflow.Configure(LeadReportStatus.UnderReview)
                .PermitIf(LeadReportStatus.Accepted, LeadReportStatus.Accepted, () => projectManagerUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(LeadReportStatus.Accepted)
                .PermitIf(LeadReportStatus.UnderReview, LeadReportStatus.UnderReview);

            return workflow;
        }

        public async Task<StateMachine<ClaimStatus, ClaimStatus>> GetClaimWorkflow(Claim claim, string currentUser)
        {
            var cmsUsers = await _userManager.GetUsersInRoleAsync(BaseRole.ContractMgtSpecialist);

            var workflow = new StateMachine<ClaimStatus, ClaimStatus>(claim.Status);
            workflow.Configure(ClaimStatus.AwaitingClearance)
                .PermitIf(ClaimStatus.InitialReview, ClaimStatus.InitialReview).OnExitAsync(async () => await SendApprovalNotifications(claim, currentUser))
                .PermitIf(ClaimStatus.Rejected, ClaimStatus.Rejected);

            workflow.Configure(ClaimStatus.Rejected)
                .PermitIf(ClaimStatus.InitialReview, ClaimStatus.InitialReview);

            workflow.Configure(ClaimStatus.Created)
                .PermitIf(ClaimStatus.InitialReview, ClaimStatus.InitialReview);

            workflow.Configure(ClaimStatus.InitialReview)
                .PermitIf(ClaimStatus.Rejected, ClaimStatus.Rejected)
                .PermitIf(ClaimStatus.DocumentsRequest, ClaimStatus.DocumentsRequest)
                .PermitIf(ClaimStatus.Back, ClaimStatus.Created, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));


            workflow.Configure(ClaimStatus.DocumentsRequest)
                .PermitIf(ClaimStatus.DocumentsReview, ClaimStatus.DocumentsReview)
                .PermitIf(ClaimStatus.Back, ClaimStatus.InitialReview, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));


            workflow.Configure(ClaimStatus.DocumentsReview)
                .PermitIf(ClaimStatus.AdditionalDocumentsRequest, ClaimStatus.AdditionalDocumentsRequest)
                .PermitIf(ClaimStatus.PaymentCertificate, ClaimStatus.PaymentCertificate)
                .PermitIf(ClaimStatus.Back, ClaimStatus.DocumentsRequest, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.AdditionalDocumentsRequest)
                .PermitIf(ClaimStatus.SiteVerification, ClaimStatus.SiteVerification)
                .PermitIf(ClaimStatus.Back, ClaimStatus.DocumentsReview, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.SiteVerification)
                .PermitIf(ClaimStatus.AnalysisAndVerification, ClaimStatus.AnalysisAndVerification)
                .PermitIf(ClaimStatus.Back, ClaimStatus.AdditionalDocumentsRequest, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.PaymentCertificate)
                .PermitIf(ClaimStatus.AnalysisAndVerification, ClaimStatus.AnalysisAndVerification)
                .PermitIf(ClaimStatus.Back, ClaimStatus.DocumentsReview, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.AnalysisAndVerification)
                .PermitIf(ClaimStatus.DraftReportSubmission, ClaimStatus.DraftReportSubmission)
                .PermitIf(ClaimStatus.Back, ClaimStatus.PaymentCertificate, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.DraftReportSubmission)
                .PermitIf(ClaimStatus.DonorReview, ClaimStatus.DonorReview)
                .PermitIf(ClaimStatus.Back, ClaimStatus.AnalysisAndVerification, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.DonorReview)
                .PermitIf(ClaimStatus.FinalDocumentsRequest, ClaimStatus.FinalDocumentsRequest)
                .PermitIf(ClaimStatus.Back, ClaimStatus.DraftReportSubmission, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.FinalDocumentsRequest)
                .PermitIf(ClaimStatus.FinalVerificationReport, ClaimStatus.FinalVerificationReport)
                .PermitIf(ClaimStatus.Back, ClaimStatus.DonorReview, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.FinalVerificationReport)
                .PermitIf(ClaimStatus.FinalVerificationReportSubmission, ClaimStatus.FinalVerificationReportSubmission)
                .PermitIf(ClaimStatus.Back, ClaimStatus.FinalDocumentsRequest, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.FinalVerificationReportSubmission)
                .PermitIf(ClaimStatus.PaymentNegotiations, ClaimStatus.PaymentNegotiations)
                .PermitIf(ClaimStatus.Back, ClaimStatus.FinalVerificationReport, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.PaymentNegotiations)
                .PermitIf(ClaimStatus.PaymentCertificate, ClaimStatus.PaymentCertificate)
                .PermitIf(ClaimStatus.Back, ClaimStatus.FinalVerificationReportSubmission, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.PaymentCertificate)
                .PermitIf(ClaimStatus.Closure, ClaimStatus.Closure)
                .PermitIf(ClaimStatus.Back, ClaimStatus.PaymentNegotiations, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.Configure(ClaimStatus.Closure)
                .PermitIf(ClaimStatus.Back, ClaimStatus.PaymentCertificate, () => cmsUsers.Any(a => a.Active && a.Email == currentUser));

            workflow.OnTransitioned((transition) =>
            {
                // To trigger audit log on Claims table
                claim.LastModifiedDate = DateTime.UtcNow;
            });

            return workflow;
        }

        private async Task SendApprovalNotifications(Claim claim, string currentUser)
        {
            var reviewerRoles = new List<string> { BaseRole.FinancialLead, BaseRole.TransportSectorLead, $"{claim.Sector.GetDescriptionFromEnumValue()}SectorLead" };
            var users = await _applicationDbContext.Users.Where(o => o.DateActivated != null
                                                               && o.Email != null
                                                               && o.Email.ToLower() != currentUser.ToLower()
                                                               && o.Roles.Any(a => reviewerRoles.Contains(a.Role.Name))).Distinct().ToArrayAsync();
            var headline = $"Claim {claim.Reference} has been approved";
            var description = $"Claim {claim.Reference} has been approved by {currentUser} in {claim.Sector.GetDescriptionFromEnumValue()} and requires your attention.";

            await _notificationManager.SendClaimNotification(users.Select(x => x.Email).ToList(), claim.Id, headline, description);
        }

        public async Task<ActionModel<LeadReportStatus>[]> ClaimLegalLeadReportStatuses(int claimId, string currentUser)
        {
            var claim = await _dataDbContext.Claims.SingleAsync(t => t.Id == claimId);
            var state = new StateMachine<LeadReportStatus, LeadReportStatus>(claim.LegalFunctionalLeadReportStatus);
            var wf = await GetClaimLeadReportStatuses(state, currentUser);
            return wf.PermittedTriggers.Select(t => new ActionModel<LeadReportStatus>
            {
                Value = t,
                Name = t.ToString(),
                Description = t.GetDescriptionFromEnumValue()
            }).ToArray();
        }

        public async Task<ActionModel<LeadReportStatus>[]> ClaimFinanceLeadReportStatuses(int claimId, string currentUser)
        {
            var claim = await _dataDbContext.Claims.SingleAsync(t => t.Id == claimId);
            var state = new StateMachine<LeadReportStatus, LeadReportStatus>(claim.FinanceFunctionalLeadReportStatus);
            var wf = await GetClaimLeadReportStatuses(state, currentUser);
            return wf.PermittedTriggers.Select(t => new ActionModel<LeadReportStatus>
            {
                Value = t,
                Name = t.ToString(),
                Description = t.GetDescriptionFromEnumValue()
            }).ToArray();
        }

        public async Task<ActionModel<LeadReportStatus>[]> ClaimContractsLeadReportStatuses(int claimId, string currentUser)
        {
            var claim = await _dataDbContext.Claims.SingleAsync(t => t.Id == claimId);
            var state = new StateMachine<LeadReportStatus, LeadReportStatus>(claim.ContractsFunctionalLeadReportStatus);
            var wf = await GetClaimLeadReportStatuses(state, currentUser);
            return wf.PermittedTriggers.Select(t => new ActionModel<LeadReportStatus>
            {
                Value = t,
                Name = t.ToString(),
                Description = t.GetDescriptionFromEnumValue()
            }).ToArray();
        }

        public async Task<ActionModel<LeadReportStatus>[]> ClaimTechnicalLeadReportStatuses(int claimId, string currentUser)
        {
            var claim = await _dataDbContext.Claims.SingleAsync(t => t.Id == claimId);
            var state = new StateMachine<LeadReportStatus, LeadReportStatus>(claim.TechnicalFunctionalLeadReportStatus);
            var wf = await GetClaimLeadReportStatuses(state, currentUser);
            return wf.PermittedTriggers.Select(t => new ActionModel<LeadReportStatus>
            {
                Value = t,
                Name = t.ToString(),
                Description = t.GetDescriptionFromEnumValue()
            }).ToArray();
        }
    }
}
