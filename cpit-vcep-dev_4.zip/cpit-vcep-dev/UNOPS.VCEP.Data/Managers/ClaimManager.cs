using GoogleServices;
using GoogleServices.Enums;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.Extensions.Hosting;
using System.Linq.Expressions;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Emailing;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;
using UNOPS.VCEP.Infrastructure.Models.Audit;
using UNOPS.VCEP.Infrastructure.Models.Email;
using UNOPS.VCEP.Infrastructure.Security;
using UsersManager.DataAccess;
using UsersManager.Domain;

namespace UNOPS.VCEP.Data.Managers;
public class ClaimManager : IApplicationService
{
    private readonly DataDbContext dataDbContext;
    private readonly InfrastructureDbContext infraDbContext;
    private readonly ApplicationDbContext applicationDbContext;
    private readonly DocumentManager _documentManager;
    private readonly IReferenceGenerator _referenceGenerator;
    private readonly IGenericDataRepository<Claim> _genericDataRepository;
    private readonly ApplicationUserManager applicationUserManager;
    private readonly CurrencyRateService _currencyRateService;
    private readonly ExternalEntityManager externalEntityManager;
    private readonly NotificationManager _notificationManager;
    private readonly WorkflowManager _workflowManager;
    private readonly GoogleDriveAPIHelper _googleDriveAPIHelper;
    private readonly IWebHostEnvironment hostEnvironment;
    private readonly EmailSenderManager emailSender;

    public ClaimManager(DataDbContext context,
        InfrastructureDbContext infraDbContext,
        ApplicationDbContext applicationDbContext,
        DocumentManager documentManager,
        IReferenceGenerator referenceGenerator,
        IGenericDataRepository<Claim> dataRepository,
        ExternalEntityManager externalEntityManager, GoogleDriveAPIHelper googleDriveAPIHelper,
        IWebHostEnvironment hostEnvironment,
        EmailSenderManager emailSender,
        ApplicationUserManager applicationUserManager, CurrencyRateService currencyRateService, NotificationManager notificationManager, WorkflowManager workflowManager)
    {
        dataDbContext = context;
        this.infraDbContext = infraDbContext;
        this.applicationDbContext = applicationDbContext;
        this.applicationUserManager = applicationUserManager;
        _currencyRateService = currencyRateService;
        _documentManager = documentManager;
        _referenceGenerator = referenceGenerator;
        this.externalEntityManager = externalEntityManager;
        _genericDataRepository = dataRepository;
        _notificationManager = notificationManager;
        _workflowManager = workflowManager;
        _googleDriveAPIHelper = googleDriveAPIHelper;
        this.hostEnvironment = hostEnvironment;
        this.emailSender = emailSender;
    }

    public async Task<ClaimStatisticsResponseModel> GetStatistics(string outputType)
    {
        var claims = await dataDbContext.Claims
            .Where(c => outputType == "output-one"
                ? c.GrantId != null && c.ProjectAgreementId == null
                : c.ProjectAgreementId != null).Select(x => new ClaimResponseModel(x)).ToListAsync();

        foreach (var claim in claims)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
            claim.CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD);
        }
        return new ClaimStatisticsResponseModel(claims);
    }
    public async Task<ClaimResponseModel> CreateClaim(CreateClaimRequestModel request, string currentUser)
    {
        var reference = await _referenceGenerator.GenerateClaimReferenceAsync((SectorType)request.Sector);
        var claim = await InsertClaim(new Claim(request, reference), request, currentUser);

        await SendClaimCreatedNotification(claim, currentUser);
        return new ClaimResponseModel(claim)
        {
            CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD),
            SectorLead = await GetClaimSectorLead(claim.Sector),
            ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}") ?
                claim.ClaimedAmount :
                await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD, claim.ClaimedAmount)
        };
    }

    public async Task<ClaimResponseModel> CreateClaimantClaim(CreateClaimRequestModel request, string currentUser, string baseUrl)
    {
        var dataToValidate = new ClaimDataToValidateModel();
        if (!applicationUserManager.IsValidClaimantUser(currentUser))
            throw new BusinessException("User is not a valid claimant or does not have the proper roles.");

        dataToValidate = await ValidateClaimantData(request, currentUser);
        var reference = await _referenceGenerator.GenerateClaimReferenceAsync((SectorType)request.Sector);
        var claim = await InsertClaim(new Claim(request, reference, dataToValidate, ClaimSource.Claimant), request, currentUser);

        await SendClaimCreatedNotification(claim, currentUser);
        await SendClaimCreationConfirmationEmail(claim, currentUser, baseUrl);
        return new ClaimResponseModel(claim, true)
        {
            CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD),
            ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}") ? claim.ClaimedAmount : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD, claim.ClaimedAmount)
        };
    }

    private async Task SendClaimCreationConfirmationEmail(Claim claim, string currentUser, string baseUrl)
    {
        var emailModel =
            new ClaimConfirmationModel(baseUrl, claim.Id, claim.CreatedBy, claim.CreatedDate, claim.Reference);
        if (!hostEnvironment.IsDevelopment())
        {
            await emailSender.SendEmail(new EmailModel
            {
                TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.ClaimCreationConfirmationTemplate",
                Title = "VCEP - Thank you for your submission",
                Attachments = new List<EmailAttachmentModel>(),
                EmailReceivers = new string[] { currentUser }
            }, emailModel, emailModel.BaseUrl);
        }
    }

    private async Task<ClaimDataToValidateModel> ValidateClaimantData(CreateClaimRequestModel request,
        string currentUser)
    {
        var dataToValidate = new ClaimDataToValidateModel();
        if (request.ClaimDataToValidate != null)
        {
            var claimantParentEntities = await externalEntityManager.GetParentExternalEntitiesByUserEmail(currentUser);
            var parentEntitiesIds = claimantParentEntities.Select(a => a.Id);

            var grantValidForClaimant = await GrantValidForClaimant(request, parentEntitiesIds);
            if (grantValidForClaimant == null)
            {
                dataToValidate.SetInvalidGrantDetails(request.ClaimDataToValidate.GrantDetails);
                request.GrantId = null;
            }
            else
            {
                request.GrantId = grantValidForClaimant.Id;
            }

            var paValidForClaimant = await ProjectAgreementValidForClaimant(request, parentEntitiesIds);
            if (paValidForClaimant == null)
            {
                dataToValidate.SetInvalidProjectAgreementDetails(request.ClaimDataToValidate.ProjectAgreementDetails);
                request.ProjectAgreementId = null;
            }
            else
            {
                request.ProjectAgreementId = paValidForClaimant.Id;
            }

            var contractValidForClaimant = await ContractValidForClaimant(request, claimantParentEntities);

            if (contractValidForClaimant == null)
            {
                dataToValidate.SetInvalidContractDetails(request.ClaimDataToValidate.ContractDetails);
                request.ContractId = null;
            }
            else
            {
                request.ContractId = contractValidForClaimant.Id;
            }
        }
        return dataToValidate;
    }

    private async Task<Contract?> ContractValidForClaimant(CreateClaimRequestModel request,
        List<ExternalEntityModel> claimantParentEntities)
    {
        Contract contract = null;
        if (request.ClaimDataToValidate?.ContractDetails != null)
        {
            Int32.TryParse(request.ClaimDataToValidate.ContractDetails, out var contractId);

            contract = await dataDbContext.Contracts
                .Where(x => x.Id == contractId && claimantParentEntities.Select(a => a.Id).Contains(x.Contractor.Id))
                .AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
        }

        return contract;
    }
    private async Task<ProjectAgreement?> ProjectAgreementValidForClaimant(CreateClaimRequestModel request,
        IEnumerable<int> parentEntitiesIds)
    {
        ProjectAgreement? validPa = null;
        if (request.ClaimDataToValidate?.ProjectAgreementDetails != null)
        {
            Int32.TryParse(request.ClaimDataToValidate.ProjectAgreementDetails, out var paId);

            validPa = await dataDbContext.ProjectAgreements
                .Where(x => x.Id == paId && x.Contracts
                    .Any(contract => parentEntitiesIds.Contains(contract.Contractor.Id)))
                .AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();

        }

        return validPa;
    }

    private async Task<Grant?> GrantValidForClaimant(CreateClaimRequestModel request, IEnumerable<int> parentEntitiesIds)
    {
        Grant validGrant = null;
        if (request.ClaimDataToValidate?.GrantDetails != null)
        {
            Int32.TryParse(request.ClaimDataToValidate.GrantDetails, out var grantId);

            validGrant = await dataDbContext.Grants.Where(x => x.Id == grantId && x.Contracts
                    .Any(contract => parentEntitiesIds.Contains(contract.Contractor.Id)))
                .AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();

        }
        return validGrant;
    }


    private async Task<Claim> InsertClaim(Claim claim, CreateClaimRequestModel request, string currentUser)
    {
        try
        {
            if (claim.ContractId.HasValue)
            {
                var contract = await dataDbContext.Contracts.Where(x => x.Id == claim.ContractId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();

                if (contract is not null && contract.ExternalEntityId.HasValue)
                {
                    var contractor = await infraDbContext.ExternalEntities.Where(x => x.Id == contract.ExternalEntityId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
                    claim.Fraudulent = contractor is not null && contractor.Fraudulent;
                }

                claim.GoogleDriveFolderId = await _googleDriveAPIHelper.FindOrCreateFolder(claim.Reference, UploadFileType.Claim.GetDescriptionFromEnumValue());
            }

            dataDbContext.Claims.Add(claim);
            await dataDbContext.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"There was an error while saving a new claim: {ex}");
        }

        return claim;
    }

    public async Task<ClaimDetailedResponseModel> EditClaimAmounts(EditClaimRequestModel request, string currentUser)
    {
        var dbClaim = await dataDbContext.Claims
                .Include(a => a.Contract)
                .Where(x =>
                    x.Id == request.Id || (!string.IsNullOrEmpty(request.Reference) &&
                                           x.Reference.ToLower() == request.Reference.ToLower())).FirstOrDefaultAsync();
        if (dbClaim is null)
        {
            throw new BusinessException($"No Claim exists with id: {request.Id}");
        }

        dbClaim.UpdateInternalAmounts(request);
        await SendClaimEditNotifications(dbClaim, currentUser);

        await dataDbContext.SaveChangesAsync();
        return await GetClaim(dbClaim.Id);
    }

    public async Task<ClaimDetailedResponseModel> EditClaim(EditClaimRequestModel request, string currentUser)
    {
        try
        {
            var dbClaim = await dataDbContext.Claims
                .Include(a => a.Contract)
                .Include(a => a.ContractingAuthorities)
                .Where(x =>
                x.Id == request.Id || (!string.IsNullOrEmpty(request.Reference) &&
                                       x.Reference.ToLower() == request.Reference.ToLower())).FirstOrDefaultAsync();
            if (dbClaim is null)
            {
                throw new BusinessException($"No Claim exists with id: {request.Id}");
            }

            var validGrant = await dataDbContext.Grants.Where(x => x.Id == request.GrantId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
            if (validGrant != null)
                dbClaim.UpdateGrant(request.GrantId);

            dbClaim.Update(request);
            if (request.ContractingAuthorities != null)
                await UpdateClaimContractingAuthorities(dbClaim.Id, request.ContractingAuthorities);
            if (request.ContractId.HasValue || request.ProjectAgreementId.HasValue || (!request.ContractId.HasValue && dbClaim.ContractId.HasValue) || (!request.ProjectAgreementId.HasValue && dbClaim.ProjectAgreementId.HasValue))
            {
                var validContract = await dataDbContext.Contracts.Where(x => x.Id == request.ContractId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
                if (validContract != null)
                {
                    dbClaim.UpdateContract(request.ContractId);
                    dbClaim.UpdateProjectAgreement(request.ProjectAgreementId);
                }
                else
                {
                    validContract = dbClaim.Contract;
                }

                if (validContract is not null && validContract.ExternalEntityId.HasValue)
                {
                    var contractor = await infraDbContext.ExternalEntities.Where(x => x.Id == validContract.ExternalEntityId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
                    dbClaim.UpdateFraudulentStatus(contractor is not null && contractor.Fraudulent);
                    if (request.LinkedClaimantUserId is not null)
                    {
                        var validClaimantUser = await applicationUserManager.GetExternalEntityById(request.LinkedClaimantUserId.GetValueOrDefault(), validContract.ExternalEntityId.GetValueOrDefault());
                        if (validClaimantUser == null)
                            throw new BusinessException($"Claimant user with id {request.LinkedClaimantUserId} does not exist or it does not belong to the contractor.");
                        dbClaim.LinkToClaimantUserId(validClaimantUser.Id);
                    }
                }
            }

            if (request.Status.HasValue)
            {
                dbClaim.UpdateStatus(request.Status);
                // Send notification to creator if they are external user.
                await SendClaimStatusChangeNotification(dbClaim, currentUser);
            }

            await SendClaimEditNotifications(dbClaim, currentUser);

            await dataDbContext.SaveChangesAsync();
            await infraDbContext.SaveChangesAsync();

            return await GetClaim(dbClaim.Id);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"There was an error while saving a new claim: {ex}");
            throw;
        }
    }

    private async Task UpdateClaimContractingAuthorities(int claimId, int[] ca)
    {
        var updatedAuthorities = (from contractingAuthority in ca where Enum.IsDefined(typeof(ContractingAuthorityType), contractingAuthority) select (ContractingAuthorityType)contractingAuthority).ToList();
        var existingAuthorities = await dataDbContext.ClaimContractingAuthorities
            .Where(ca => ca.ClaimId == claimId)
            .ToListAsync();

        var authoritiesToRemove = existingAuthorities
            .Where(e => !updatedAuthorities.Contains(e.ContractingAuthority))
            .ToList();

        var authoritiesToAdd = updatedAuthorities
            .Where(a => existingAuthorities.All(e => e.ContractingAuthority != a))
            .Select(a => new ClaimContractingAuthority { ClaimId = claimId, ContractingAuthority = a })
            .ToList();

        dataDbContext.ClaimContractingAuthorities.RemoveRange(authoritiesToRemove);
        dataDbContext.ClaimContractingAuthorities.AddRange(authoritiesToAdd);
        await dataDbContext.SaveChangesAsync();
    }

    private async Task SendClaimEditNotifications(Claim dbClaim, string currentUser)
    {
        var reviewerRoles = new List<string> { BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist };
        var users = await applicationDbContext.Users.Where(o => o.DateActivated != null
                                                                 && o.Email != null
                                                                 && o.Email.ToLower() != currentUser.ToLower()
                                                                 && o.Roles.Any(a => reviewerRoles.Contains(a.Role.Name))).Distinct().ToArrayAsync();

        var headline = $"Claim {dbClaim.Reference} has been edited";
        var description = $"Claim: {dbClaim.Reference} details have been updated by {currentUser}";

        await _notificationManager.SendClaimNotification(users.Select(x => x.Email).ToList(), dbClaim.Id, headline, description);
    }

    private async Task SendClaimStatusChangeNotification(Claim dbClaim, string currentUser)
    {
        if (await infraDbContext.ExternalEntityUsers.Where(x => x.Email.ToLower() == dbClaim.CreatedBy).AnyAsync())
        {
            var headline = $"Claim {dbClaim.Reference} status changed to {dbClaim.Status}";
            var description = $"Your claim: {dbClaim.Reference} has been updated to {dbClaim.Status} by {currentUser}";

            await _notificationManager.SendClaimNotification(new List<string> { dbClaim.CreatedBy }, dbClaim.Id, headline, description);
        }
    }

    private async Task<ApplicationUser[]> GetContractManagementSpecialistUsers(SectorType? sector, string currentUser)
    {
        return await applicationDbContext.Users.Where(o => o.DateActivated != null
                                                           && o.Email != null
                                                           && o.Email.ToLower() != currentUser.ToLower()
                                                           && o.Roles.Any(a => a.Role.Name.ToLower() == BaseRole.ContractMgtSpecialist.ToLower())).ToArrayAsync();
    }

    private async Task SendClaimCreatedNotification(Claim claim, string currentUser)
    {
        var receivers = await GetContractManagementSpecialistUsers(claim.Sector, currentUser);

        var headline = $"Claim {claim.Reference} created";
        var description = $"Claim {claim.Reference} has been created by {claim.CreatedBy} in {claim.Sector.GetDescriptionFromEnumValue()} and may require your attention.";

        await _notificationManager.SendClaimNotification(receivers.Select(x => x.Email).ToList(), claim.Id, headline, description);
    }

    private async Task<string?> GetClaimSectorLead(SectorType? sector)
    {

        var sectorLead = await applicationDbContext.Users.Where(o => o.DateActivated != null
                                                                     && o.Email != null
                                                                     && o.Roles.Any(a =>
                                                                         a.Role.Name.ToLower()
                                                                             .Equals(
                                                                                 $"{sector.GetDescriptionFromEnumValue()}sectorlead"
                                                                                     .ToLower()))).FirstOrDefaultAsync();
        return sectorLead?.Email;
    }

    private async Task<decimal> ConvertToUsd(string sourceCurrencyId, decimal? amount)
    {
        if (!amount.HasValue) return 0;
        return sourceCurrencyId == $"{(int)CurrencyCode.USD}" 
            ? amount.Value 
            : await _currencyRateService.GetEquivalentAmount(sourceCurrencyId, CurrencyCode.USD, amount.Value);
    }

    public async Task<ClaimDetailedResponseModel> GetClaim(int claimId, string? currentUser = null)
    {
        var claim = await dataDbContext.Claims
            .Include(a => a.Contract)
            .ThenInclude(a => a.Grants)
            .Include(a => a.ClaimDetailsToValidate)
            .Include(a => a.LinkedClaimantUser)
            .Include(x => x.Grant)
            .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        var remarks = await dataDbContext.Remarks
            .Where(r => r.EntityId == claimId && r.EntityType == RemarkType.Claim)
            .OrderByDescending(r => r.CreatedDate)
            .ToListAsync();

        var contractingAuthorities = await dataDbContext.ClaimContractingAuthorities
            .Where(ca => ca.ClaimId == claimId && !ca.IsDeleted)
            .ToListAsync();

        claim.Remarks = remarks;
        claim.ContractingAuthorities = contractingAuthorities;

        var currencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD);
        var response = new ClaimDetailedResponseModel(claim, currentUser)
        {
            CurrencyRate = currencyRate,
            SectorLead = await GetClaimSectorLead(claim.Sector),
            ClaimedAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.ClaimedAmount),
            VerifiedAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.VerifiedAmount),
            OfficialEstimatedAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.OfficialEstimatedAmount),
            IneligibleEstimatedAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.IneligibleEstimatedAmount),
            VerifiedAmountToBeReclaimedUsd = await ConvertToUsd(claim.CurrencyId, claim.VerifiedAmountToBeReclaimed),
            EstimatedAmountToBeReclaimedUsd = await ConvertToUsd(claim.CurrencyId, claim.EstimatedAmountToBeReclaimed),
            CdcContributionUsd = await ConvertToUsd(claim.CurrencyId, claim.CdcContribution),
            AdbContributionUsd = await ConvertToUsd(claim.CurrencyId, claim.AdbContribution),
            DisbursedAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.DisbursedAmount),
            SpentAmountUsd = await ConvertToUsd(claim.CurrencyId, claim.SpentAmount)
        };

        var currentStageHistory = await dataDbContext.ClaimStageHistories
            .Include(h => h.ClaimStage)
            .Where(h => h.ClaimId == claimId && h.IsCurrentStage && !h.IsDeleted)
            .FirstOrDefaultAsync();
            
        if (currentStageHistory != null && currentStageHistory.ClaimStage != null)
        {
            response.CurrentStageId = currentStageHistory.ClaimStageId;
            response.CurrentStageName = currentStageHistory.ClaimStage.Name;
            response.CurrentStageDescription = currentStageHistory.ClaimStage.Description;
            response.CurrentStageWeightPercentage = currentStageHistory.ClaimStage.WeightPercentage;
            response.CurrentStageStartDate = currentStageHistory.StartDate;
            response.CurrentStageEstimatedCompletionDate = currentStageHistory.EstimatedCompletionDate;
            
            var daysSinceStart = (DateTime.UtcNow - currentStageHistory.StartDate).Days;
            response.CurrentStageDurationDays = daysSinceStart;
            
            if (currentStageHistory.EstimatedCompletionDate.HasValue)
            {
                response.CurrentStageIsOverdue = DateTime.UtcNow > currentStageHistory.EstimatedCompletionDate.Value;
            }
        }

        return response;
    }

    public async Task<ClaimResponseModel> GetSimplifiedClaim(int claimId)
    {
        var claim = await dataDbContext.Claims
            .Include(a => a.Remarks)
            .Include(a => a.Contract)
            .ThenInclude(a => a.Grants)
            .Include(a => a.ProjectAgreement)
            .Include(x => x.Grant)
            .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        var response = new ClaimResponseModel(claim, simpleVersion: true)
        {
            CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD),
            ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}") ? claim.ClaimedAmount : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD, claim.ClaimedAmount)
        };

        var currentStageHistory = await dataDbContext.ClaimStageHistories
            .Include(h => h.ClaimStage)
            .Where(h => h.ClaimId == claimId && h.IsCurrentStage && !h.IsDeleted)
            .FirstOrDefaultAsync();
            
        if (currentStageHistory != null && currentStageHistory.ClaimStage != null)
        {
            response.CurrentStageId = currentStageHistory.ClaimStageId;
            response.CurrentStageName = currentStageHistory.ClaimStage.Name;
            response.CurrentStageDescription = currentStageHistory.ClaimStage.Description;
            response.CurrentStageWeightPercentage = currentStageHistory.ClaimStage.WeightPercentage;
            response.CurrentStageStartDate = currentStageHistory.StartDate;
            response.CurrentStageEstimatedCompletionDate = currentStageHistory.EstimatedCompletionDate;
            
            var daysSinceStart = (DateTime.UtcNow - currentStageHistory.StartDate).Days;
            response.CurrentStageDurationDays = daysSinceStart;
            
            if (currentStageHistory.EstimatedCompletionDate.HasValue)
            {
                response.CurrentStageIsOverdue = DateTime.UtcNow > currentStageHistory.EstimatedCompletionDate.Value;
            }
        }

        return response;
    }

    public async Task<ClaimantClaimResponseModel> GetClaimantClaim(int claimId, string currentUser)
    {
        if (!applicationUserManager.IsValidClaimantUser(currentUser))
            throw new BusinessException(
                $"Claimant {currentUser} does not exist, was not activated or does not have the proper role.");

        var claim = await dataDbContext.Claims
            .Include(a => a.Grant)
            .Include(a => a.Contract)
            .ThenInclude(a => a.Grants)
            .Include(a => a.Remarks)
            .Include(a => a.LinkedClaimantUser)
            .SingleOrDefaultAsync(a => !a.IsDeleted && a.Id == claimId &&
                                       (a.CreatedBy.ToLower() == currentUser.ToLower() ||
                                        (a.LinkedClaimantUser != null && a.LinkedClaimantUser.Email.ToLower() == currentUser.ToLower())));

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        return new ClaimantClaimResponseModel(claim)
        {
            CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD),
            ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}") ? claim.ClaimedAmount : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD, claim.ClaimedAmount)
        };
    }

    public List<TypeaheadInput> GetReviewers()
    {
        var reviewerRoles = DataPermissions.CanBeAssignedToClaims.Roles;
        return applicationDbContext.Users.Where(o => o.Roles.Any(a => reviewerRoles.Contains(a.Role.Name)))
            .Select(a => new TypeaheadInput
            {
                Value = a.Email,
                Label = a.UserName,
            }).ToList();
    }

    public async Task AssignReviewer(AssignUserEmailRequestModel data, string currentUser)
    {
        var claims = await dataDbContext.Claims
            .Where(x => data.Ids.Contains(x.Id))
            .ToListAsync();

        var reviewer = await applicationDbContext.Users
            .SingleOrDefaultAsync(o => o.DateActivated != null
                                       && o.Email != null && o.Email.ToLower() == data.Email.ToLower());
        if (reviewer == null)
            throw new BusinessException($"User email {data.Email} does not exist.");

        foreach (var claim in claims)
        {
            claim.AssignToWork(data.Email, data.UserAssignmentType);

            if (claim.Status == ClaimStatus.Created)
            {
                var transitionModel = new TransitionModel
                {
                    ClaimId = claim.Id,
                    ToStatus = ClaimStatus.InitialReview
                };
                await _workflowManager.Trigger(transitionModel, currentUser);
            }
            await SendClaimsAssignedToUserNotification(claim, reviewer);
        }
        await dataDbContext.SaveChangesAsync();
    }

    private async Task SendClaimsAssignedToUserNotification(Claim claim, ApplicationUser notificationReceiverUser)
    {
        var headline = $"Claim {claim.Reference} assigned to you.";
        var description =
            $"Claim {claim.Reference} has been assigned to you by {claim.CreatedBy} and requires your attention.";
        await _notificationManager.SendClaimNotification(new List<string> { notificationReceiverUser.Email }, claim.Id, headline,
            description);
    }

    public async Task<PaginationResponse<AuditLogModel>> GetClaimAuditLogs(int claimId, AuditLogModelFilter filter)
    {
        var auditLogsQuery = this.dataDbContext.DataAuditLogs
            .Include(x => x.Properties)
            .Where(log => log.EntityId == claimId && log.EntityTypeName == nameof(Claim));

        if (!string.IsNullOrEmpty(filter.Query))
        {
            auditLogsQuery = auditLogsQuery.Where(x => x.CreatedBy.ToLower().Contains(filter.Query.ToLower()));
        }

        return auditLogsQuery.OrderByDescending(x => x.CreatedDate).Paginate(o => new AuditLogModel(o), filter);
    }

    public async Task ToggleClaimFraudulentFlag(int claimId, string currentUser, string? reason = null)
    {
        var claim = await dataDbContext.Claims.Where(x => x.Id == claimId).FirstOrDefaultAsync();

        if (claim is null)
        {
            throw new Exception($"Claim with id: {claimId} does not exist");
        }
        
        bool newFraudulentStatus = !claim.Fraudulent;
        claim.UpdateFraudulentStatus(newFraudulentStatus, reason);

        if (claim.ContractId.HasValue)
        {
            var contract = await dataDbContext.Contracts.Where(x => x.Id == claim.ContractId).AsNoTrackingWithIdentityResolution().FirstOrDefaultAsync();
            if (contract is not null && contract.ExternalEntityId.HasValue)
            {
                var contractor = await infraDbContext.ExternalEntities.Where(x => x.Id == contract.ExternalEntityId).FirstOrDefaultAsync();
                contractor.Fraudulent = claim.Fraudulent;
            }
        }
        await dataDbContext.SaveChangesAsync();
        await infraDbContext.SaveChangesAsync();

        await SendFraudulentClaimNotification(claim, currentUser);
    }

    private async Task SendFraudulentClaimNotification(Claim dbClaim, string currentUser)
    {
        var reviewerRoles = new List<string> { BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.ProjectManager };
        var users = await applicationDbContext.Users.Where(o => o.DateActivated != null
                                                                && o.Email != null
                                                                && o.Email.ToLower() != currentUser.ToLower()
                                                                && o.Roles.Any(a => reviewerRoles.Contains(a.Role.Name))).Distinct().ToArrayAsync();

        var headline = $"Claim {dbClaim.Reference} marked as {(dbClaim.Fraudulent ? "fraudulent" : "not fraudulent")}";
        var description = dbClaim.Fraudulent
            ? $"Claim: {dbClaim.Reference} has been marked as fraudulent by {currentUser}{(string.IsNullOrEmpty(dbClaim.FraudulentReason) ? "" : $". Reason: {dbClaim.FraudulentReason}")}"
            : $"Claim: {dbClaim.Reference} has been unmarked as fraudulent by {currentUser}";

        await _notificationManager.SendClaimNotification(users.Select(x => x.Email).ToList(), dbClaim.Id, headline, description);
    }

    public async Task<PaginationResponse<ClaimResponseModel>> GetAllClaimsInternal(string? outputType,
        ClaimsFilterModel filter)
    {
        filter.OrderBy ??= "InternalReferenceCode";
        filter.Ascending ??= true;

        if (outputType != null && outputType == OutputType.AwaitingClearance)
            return await GetAllClearanceClaims(filter);
        if (outputType != null && outputType == OutputType.Rejected)
            return await GetAllRejectedClaims(filter);
        if (outputType != null && outputType == OutputType.OutputOne)
            return await GetAllOutputOneClaims(filter);
        if (outputType != null && outputType == OutputType.OutputTwo)
            return await GetAllOutputTwoClaims(filter);
        else
            throw new BusinessException(
                $"Provide a valid output type value. This can be either: {OutputType.OutputOne} or {OutputType.OutputTwo} ");
    }

    public async Task<PaginationResponse<ClaimantClaimResponseModel>> GetAllClaimantClaims(ClaimsFilterModel filter,
        string currentUser)
    {
        if (!applicationUserManager.IsValidClaimantUser(currentUser))
            throw new BusinessException(
                $"Claimant {currentUser} does not exist, was not activated or does not have the proper role.");

        return await _genericDataRepository.GetAllWithPagination<ClaimsFilterModel, ClaimantClaimResponseModel>(filter,
            selector: c => !c.IsDeleted && (c.CreatedBy == currentUser ||
                                            (c.LinkedClaimantUser != null && c.LinkedClaimantUser.Email.ToLower() == currentUser.ToLower())),
            include: g => g
                .Include(c => c.LinkedClaimantUser)
                .Include(c => c.Grant)
                .Include(c => c.Contract)
        );
    }
    public async Task<RemarkModel[]> GetClaimRemarks(int claimId, string? currentUser = null)
    {
        var claim = await dataDbContext.Claims
          .Include(a => a.Remarks)
          .ThenInclude(a => a.Replies)
          .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        return claim
            .Remarks
            .Where(t => (t.IsExternal == null || !t.IsExternal.Value) && t.ParentId == null)
            .OrderByDescending(a => a.CreatedDate)
            .Select(t => currentUser != null ? new RemarkModel(t, currentUser) : new RemarkModel(t)).ToArray();
    }
    public async Task<RemarkModel[]> GetExternalClaimRemarks(int claimId, string? currentUser = null)
    {
        var claim = await dataDbContext.Claims
          .Include(a => a.Remarks)
          .ThenInclude(a => a.Replies)
          .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        return claim
            .Remarks
            .Where(t => t.ParentId == null && t.IsExternal.HasValue && t.IsExternal.Value)
            .OrderByDescending(a => a.CreatedDate)
            .Select(t => currentUser != null ? new RemarkModel(t, currentUser) : new RemarkModel(t)).ToArray();
    }

    private bool IsValidClaimantUser(string currentUser)
    {
        return applicationDbContext.Users.Any(o => o.DateActivated != null
                                                   && o.Email != null
                                                   && o.Email.ToLower() == currentUser.ToLower()
                                                   && o.Roles.Any(a =>
                                                       ExternalRole.Claimant == a.Role.Name));
    }

    private async Task<PaginationResponse<ClaimResponseModel>> GetAllClaims(ClaimsFilterModel filter,
        Func<IQueryable<Claim>, IIncludableQueryable<Claim, object>>? includeQuery,
        Expression<Func<Claim, bool>>? selector = null)
    {
        var results = await _genericDataRepository.GetAllWithPagination<ClaimsFilterModel, ClaimResponseModel>(filter,
            selector: selector,
            include: includeQuery);
        foreach (var claim in results.Records)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
            claim.CurrencyRate = await _currencyRateService.GetCurrentRate(claim.CurrencyId, CurrencyCode.USD);
            
            var currentStageHistory = await dataDbContext.ClaimStageHistories
                .Include(h => h.ClaimStage)
                .Where(h => h.ClaimId == claim.Id && h.IsCurrentStage && !h.IsDeleted)
                .FirstOrDefaultAsync();
                
            if (currentStageHistory != null && currentStageHistory.ClaimStage != null)
            {
                claim.CurrentStageId = currentStageHistory.ClaimStageId;
                claim.CurrentStageName = currentStageHistory.ClaimStage.Name;
                claim.CurrentStageDescription = currentStageHistory.ClaimStage.Description;
                claim.CurrentStageWeightPercentage = currentStageHistory.ClaimStage.WeightPercentage;
                claim.CurrentStageStartDate = currentStageHistory.StartDate;
                claim.CurrentStageEstimatedCompletionDate = currentStageHistory.EstimatedCompletionDate;
                
                var daysSinceStart = (DateTime.UtcNow - currentStageHistory.StartDate).Days;
                claim.CurrentStageDurationDays = daysSinceStart;
                
                if (currentStageHistory.EstimatedCompletionDate.HasValue)
                {
                    claim.CurrentStageIsOverdue = DateTime.UtcNow > currentStageHistory.EstimatedCompletionDate.Value;
                }
            }
        }
        return results;
    }
    /**
     * Returns all cleared, not deleted claims with any other type than Individual Consultant or Community Development Councils (CDC)
     */
    private async Task<PaginationResponse<ClaimResponseModel>> GetAllOutputOneClaims(ClaimsFilterModel filter)
    {
        return await GetAllClaims(filter, selector: c => (c.Type != ContractType.IndividualConsultant && c.Type != ContractType.Cdc && c.Type != ContractType.SupplierOutputTwo && !c.IsDeleted && c.Status != ClaimStatus.AwaitingClearance && c.Status != ClaimStatus.Rejected),
            includeQuery: g => g
                .Include(a => a.Grant)
                .Include(a => a.ContractingAuthorities)
                .Include(a => a.ClaimDetailsToValidate)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Contractor)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Grants)
                .Include(a => a.LinkedClaimantUser));
    }

    /**
     * Returns all cleared, not deleted claims with type Individual Consultant or Community Development Councils or Supplier-output2 (CDC)
     */
    private async Task<PaginationResponse<ClaimResponseModel>> GetAllOutputTwoClaims(ClaimsFilterModel filter)
    {
        return await GetAllClaims(filter,
            selector: c => ((c.Type == ContractType.IndividualConsultant || c.Type == ContractType.Cdc || c.Type == ContractType.SupplierOutputTwo) && !c.IsDeleted && c.Status != ClaimStatus.AwaitingClearance && c.Status != ClaimStatus.Rejected),
            includeQuery: g => g
                .Include(a => a.Grant)
                .Include(a => a.ContractingAuthorities)
                .Include(a => a.ClaimDetailsToValidate)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Contractor)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Grants)
                .Include(a => a.LinkedClaimantUser));
    }

    private async Task<PaginationResponse<ClaimResponseModel>> GetAllClearanceClaims(ClaimsFilterModel filter)
    {
        return await GetAllClaims(filter,
            selector: c => (c.Status == ClaimStatus.AwaitingClearance && !c.IsDeleted),
            includeQuery: g => g
                .Include(a => a.Grant)
                .Include(a => a.ClaimDetailsToValidate)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Contractor)
                .Include(a => a.ContractingAuthorities)
                .Include(a => a.LinkedClaimantUser));
    }

    private async Task<PaginationResponse<ClaimResponseModel>> GetAllRejectedClaims(ClaimsFilterModel filter)
    {
        return await GetAllClaims(filter,
            selector: c => (c.Status == ClaimStatus.Rejected && !c.IsDeleted),
            includeQuery: g => g
                .Include(a => a.Grant)
                .Include(a => a.ClaimDetailsToValidate)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Contractor)
                .Include(a => a.Contract)
                .ThenInclude(a => a.Grants)
                .Include(a => a.ContractingAuthorities)
                .Include(a => a.LinkedClaimantUser));
    }

    public async Task<LocationModel[]> GetClaimLocations(int claimId)
    {
        var claim = await dataDbContext.Claims
            .Include(a => a.Locations)
            .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        return claim
            .Locations
            .Select(t => new LocationModel(t)).ToArray();
    }

    public async Task<LocationModel> AddClaimLocation(int claimId, LocationModel req, string? currentUser)
    {
        var claim = await dataDbContext.Claims
            .Include(a => a.Locations)
            .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        claim.Locations.Add(new Location(req));
        await dataDbContext.SaveChangesAsync();
        return req;
    }

    public async Task RemoveClaimLocation(int claimId, int locId)
    {
        var claim = await dataDbContext.Claims
            .Include(a => a.Locations)
            .SingleOrDefaultAsync(a => a.Id == claimId);

        if (claim is null)
            throw new BusinessException($"Claim {claimId} does not exist.");

        var location = claim.Locations.SingleOrDefault(a => a.Id == locId);

        if (location is null)
            throw new BusinessException($"Location {locId} does not exist.");
        else
        {
            dataDbContext.Remove(location);
            await dataDbContext.SaveChangesAsync();
        }
    }

    public async Task EditClaimLeadReport(ClaimLeadReportModel req, LeadReportType leadReportType)
    {
        var claim = await dataDbContext.Claims.Where(x => x.Id == req.ClaimId).FirstOrDefaultAsync();
        if (claim is null)
            throw new BusinessException($"Claim {req.ClaimId} does not exist.");

        switch (leadReportType)
        {
            case LeadReportType.Contracts:
                claim.ContractsFunctionalLeadReport = req.ReportData;
                if (req.ReportStatus.HasValue)
                    claim.ContractsFunctionalLeadReportStatus = (LeadReportStatus)req.ReportStatus;
                break;
            case LeadReportType.Finance:
                claim.FinanceFunctionalLeadReport = req.ReportData;
                if (req.ReportStatus.HasValue)
                    claim.FinanceFunctionalLeadReportStatus = (LeadReportStatus)req.ReportStatus;
                break;
            case LeadReportType.Technical:
                claim.TechnicalFunctionalLeadReport = req.ReportData;
                if (req.ReportStatus.HasValue)
                    claim.TechnicalFunctionalLeadReportStatus = (LeadReportStatus)req.ReportStatus;
                break;
            case LeadReportType.Legal:
                claim.LegalFunctionalLeadReport = req.ReportData;
                if (req.ReportStatus.HasValue)
                    claim.LegalFunctionalLeadReportStatus = (LeadReportStatus)req.ReportStatus;
                break;
        }

        await dataDbContext.SaveChangesAsync();

    }

    public Task<List<ClaimantClaimResponseModel>> GetClaimForContract(int contractId, string? currentUser)
    {
        var claims = dataDbContext.Claims
            .Include(a => a.Grant)
            .Include(a => a.Contract)
            .ThenInclude(a => a.Grants)
            .Include(a => a.Remarks)
            .Include(a => a.LinkedClaimantUser)
            .Where(a => !a.IsDeleted && a.ContractId == contractId).AsQueryable();

        if (applicationUserManager.IsValidClaimantUser(currentUser))
            claims = claims.Where(a => a.CreatedBy == currentUser ||
                                       (a.LinkedClaimantUser != null && a.LinkedClaimantUser.Email.ToLower() == currentUser.ToLower()));

        return Task.FromResult(claims.Select(claim => new ClaimantClaimResponseModel(claim)).ToList());
    }
}
