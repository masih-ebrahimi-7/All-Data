using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Emailing;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;
using UNOPS.VCEP.Infrastructure.Models.Email;
using UsersManager.DataAccess;
using TaskStatus = UNOPS.VCEP.Data.Domain.TaskStatus;

namespace UNOPS.VCEP.Data.Managers
{
    public class RemarkManager : IApplicationService
    {
        private readonly ApplicationDbContext applicationDbContext;
        private readonly DataDbContext dataDbContext;
        private readonly GenericDataRepository<Remark> _genericDataRepository;
        private readonly ApplicationUserManager applicationUserManager;
        private readonly EmailSenderManager emailSender;
        private readonly IConfiguration configuration;
        private readonly NotificationManager _notificationManager;
        private readonly IWebHostEnvironment hostEnvironment;

        public RemarkManager(ApplicationDbContext applicationDbContext,
            DataDbContext dataContext, NotificationManager notificationManager,
            GenericDataRepository<Remark> genericDataRepository, ApplicationUserManager applicationUserManager,
            EmailSenderManager emailSender, IConfiguration configuration, IWebHostEnvironment hostEnvironment)
        {
            this.applicationDbContext = applicationDbContext;
            this.dataDbContext = dataContext;
            _genericDataRepository = genericDataRepository;
            this.applicationUserManager = applicationUserManager;
            this.emailSender = emailSender;
            this.configuration = configuration;
            _notificationManager = notificationManager;
            this.hostEnvironment = hostEnvironment;
        }

        public async Task<PaginationResponse<RemarkModel>> GetMyTasks(RemarkFilter? filter, string currentUser)
        {
            var ministryRole = await applicationUserManager.GetUserMinistryRole(currentUser);
            if (ministryRole != null)
            {
                var ministryType = applicationUserManager.GetMinistryTypeForTaskUserType(ministryRole);
                if (ministryType.HasValue)
                {
                    return await GetTasksByUserType(filter, (TaskUserType)ministryType.Value, currentUser, true);
                }
            }
            else if (applicationUserManager.IsValidDonorUser(currentUser))
                return await GetTasksByUserType(filter, TaskUserType.Donor, currentUser);
            else if (await applicationUserManager.IsClaimantUser(currentUser))
                return await GetUserTasks(filter, currentUser, true);

            return await GetUserTasks(filter, currentUser, false);
        }

        private async Task<PaginationResponse<RemarkModel>> GetTasksByUserType(RemarkFilter? filter, TaskUserType type, string currentUser, bool isMinistryType = false)
        {
            var remarks = this.dataDbContext.Remarks
                .Include(a => a.Claim)
                .Where(t => t.IsTask.HasValue && t.IsTask.Value && t.TaskUserType == type && t.ParentId == null);
            remarks = filter?.OrderBy != null ? remarks.OrderByColumnName(filter.OrderBy, filter.Ascending ?? true) : remarks.OrderByDescending(a => a.CreatedDate);
            if (filter != null)
                remarks = remarks.ApplyFilters(filter);

            return await remarks.PaginateAsync(o => new RemarkModel(o, isMinistryType, currentUser),
                    new GenericPaginationRequest<RemarkFilter?>(filter));
        }

        private async Task<PaginationResponse<RemarkModel>> GetUserTasks(RemarkFilter? filter, string currentUser, bool isClaimant)
        {
            var remarks = this.dataDbContext.Remarks
                .Include(a => a.Claim)
                .Where(t => t.IsTask.HasValue && t.IsTask.Value && t.AssignedTo != null && t.AssignedTo.ToLower() == currentUser.ToLower() && t.ParentId == null);

            if (filter != null)
                remarks = remarks.ApplyFilters(filter);

            remarks = filter?.OrderBy != null ? remarks.OrderByColumnName(filter.OrderBy, filter.Ascending ?? true) : remarks.OrderByDescending(a => a.CreatedDate);
            return await remarks.PaginateAsync(o => new RemarkModel(o, isClaimant, currentUser), new GenericPaginationRequest<RemarkFilter?>(filter));
        }

        public async Task<PaginationResponse<RemarkModel>> GetMyCreatedTasks(RemarkFilter filter, string currentUser)
        {
            var remarks = this.dataDbContext.Remarks
                .Include(a => a.Claim)
                .Where(t => t.IsTask.HasValue && t.IsTask.Value && t.CreatedBy == currentUser);
            remarks = filter?.OrderBy != null ? remarks.OrderByColumnName(filter.OrderBy, filter.Ascending ?? true) : remarks.OrderByDescending(a => a.CreatedDate);

            if (filter != null)
                remarks = remarks.ApplyFilters(filter);

            return await remarks.PaginateAsync(o => new RemarkModel(o), new GenericPaginationRequest<RemarkFilter>(filter));
        }

        public async Task<RemarkModel> GetTask(int taskId, string currentUser)
        {
            var shouldHideAudit = await applicationUserManager.IsMinistryUser(currentUser) || await applicationUserManager.IsClaimantUser(currentUser);
            var entity = this.dataDbContext.Remarks
                .Include(a => a.Claim)
                .Include(t => t.Replies)
                .SingleOrDefault(t => t.Id == taskId && t.IsTask.HasValue && t.IsTask.Value);
            return new RemarkModel(entity, shouldHideAudit, currentUser);
        }
        public List<TypeaheadInput> GetTaskAssignableUsers(TaskUserType taskForUserType)
        {
            var roles = new string[] { };
            if (taskForUserType == TaskUserType.Internal)
                roles = DataPermissions.CanBeAssignedTasks.Roles;
            if (taskForUserType == TaskUserType.Donor)
                roles = DataPermissions.CanAccessAsDonor.Roles;
            if (taskForUserType == TaskUserType.MoF)
                roles = DataPermissions.CanAccessAsMoF.Roles;
            if (taskForUserType == TaskUserType.MPW)
                roles = DataPermissions.CanAccessAsMPW.Roles;
            if (taskForUserType == TaskUserType.MoPH)
                roles = DataPermissions.CanAccessAsMoPH.Roles;
            if (taskForUserType == TaskUserType.MRRD)
                roles = DataPermissions.CanAccessAsMRRD.Roles;
            if (taskForUserType == TaskUserType.MAIL)
                roles = DataPermissions.CanAccessAsMAIL.Roles;
            if (taskForUserType == TaskUserType.DABS)
                roles = DataPermissions.CanAccessAsDABS.Roles;
            if (taskForUserType == TaskUserType.MEW)
                roles = DataPermissions.CanAccessAsMEW.Roles;

            return applicationDbContext.Users.Where(o => o.Roles.Any(a => roles.Contains(a.Role.Name)))
                .Select(a => new TypeaheadInput
                {
                    Value = a.Email,
                    Label = a.UserName,
                    Description = a.Roles.Select(a => a.Role.Name).ToString()
                }).ToList();
        }

        public async Task<List<TypeaheadInput>> GetTaskAssignableUsersForEntity(int entityId, bool externalUsersOnly, int entityType)
        {
            List<TypeaheadInput> externalUsersToAssign = new List<TypeaheadInput>();
            if (entityType == (int)RemarkType.Claim && externalUsersOnly)
            {
                var submission = await dataDbContext.Claims.Include(a => a.LinkedClaimantUser).SingleOrDefaultAsync(a => a.Id == entityId);
                if (submission == null)
                    throw new BusinessException($"Unable to find submission with id: {entityId}");

                var isCreatedByClaimant = await applicationUserManager.IsClaimantUser(submission.CreatedBy);
                if (isCreatedByClaimant)
                    externalUsersToAssign.Add(new TypeaheadInput
                    {
                        Value = submission.CreatedBy,
                        Label = submission.CreatedBy,
                    });
                if (submission.LinkedClaimantUser != null)
                {
                    var isLinkedToClaimant = await applicationUserManager.IsClaimantUser(submission.LinkedClaimantUser.Email);
                    if (isLinkedToClaimant)
                        externalUsersToAssign.Add(new TypeaheadInput
                        {
                            Value = submission.LinkedClaimantUser.Email,
                            Label = submission.LinkedClaimantUser.Email,
                        });
                }
            }

            return externalUsersToAssign;
        }

        public async Task<RemarkModel> CreateRemark(CreateRemarkModel req, string currentUser)
        {
            var remark = await SaveRemark(req);
            if (remark == null)
                throw new BusinessException("An error occured while creating a new remark.");

            if (req.EntityType == (int)RemarkType.Claim)
            {
                var submission = await dataDbContext.Claims.Include(a => a.LinkedClaimantUser).SingleOrDefaultAsync(a => a.Id == req.EntityId);
                if (submission == null)
                    throw new BusinessException($"Claim {req.EntityId} does not exist.");

                if (remark.TaskUserType == TaskUserType.Claimant)
                {
                    if (remark.ParentId != null && !currentUser.EndsWith("@unops.org"))
                    {
                        var parentRemark = await dataDbContext.Remarks.SingleOrDefaultAsync(a => a.Id == remark.ParentId);
                        if (parentRemark != null && parentRemark.CreatedBy != currentUser)
                            // since external users can only post replies to tasks, we can notify creator about new replies to their remark
                            await SendClaimRemarkReplyNotifications(remark.EntityId, currentUser, submission.Reference, parentRemark?.CreatedBy, true);
                    }
                    if (currentUser.EndsWith("@unops.org"))
                    {
                        if (await applicationUserManager.IsClaimantUser(submission.CreatedBy))
                            await SendNewRemarkNotificationToExternalUsers(remark.EntityId, submission.Reference, req.TaskUserType, submission.CreatedBy);
                        if (submission.LinkedClaimantUser != null && await applicationUserManager.IsClaimantUser(submission.LinkedClaimantUser.Email))
                            await SendNewRemarkNotificationToExternalUsers(remark.EntityId, submission.Reference, req.TaskUserType, submission.LinkedClaimantUser.Email);
                    }
                }
                else if ((ApplicationUserManager.IsOfTypeMinistryUser(remark.TaskUserType) || req.TaskUserType == TaskUserType.Donor) && currentUser.EndsWith("@unops.org"))
                {
                    await SendNewRemarkNotificationToExternalUsers(remark.EntityId, submission.Reference, req.TaskUserType);
                }
                else
                {
                    if (req.AssignedTo != null)
                    {
                        await SendNotificationToTaskAssignee(currentUser, submission.Id, submission.Reference, req.AssignedTo);
                        req.TaggedUsers = req.TaggedUsers.Where(t => t != req.AssignedTo).ToArray();
                    }
                    if (req.TaggedUsers.Length > 0)
                        await SendNotificationOnTag(currentUser, submission.Id, submission.Reference, req.TaggedUsers);

                    if (remark.ParentId.HasValue)
                    {
                        var parentRemark = await dataDbContext.Remarks.SingleOrDefaultAsync(a => a.Id == remark.ParentId);
                        if (parentRemark != null && parentRemark.CreatedBy != currentUser)
                            await SendClaimRemarkReplyNotifications(remark.EntityId, currentUser, submission.Reference, parentRemark.CreatedBy, false);
                    }
                    else
                    {
                        var assignedInternalUsersToInformAboutNewRemark = new List<string>
                        {
                            submission.AssignedToFinance,
                            submission.AssignedToLegal,
                            submission.AssignedToSectorLead,
                            submission.AssignedToCMS
                        }.Where(user => user != null && user != currentUser).ToArray();

                        await SendNewRemarkNotificationToInternalUsers(remark.EntityId, submission.Reference,
                            currentUser, assignedInternalUsersToInformAboutNewRemark);
                    }
                }
            }

            return remark;
        }

        public async Task UpdateTaskStatus(SimpleRemarkModel model, string? currentUser)
        {
            var entity = this.dataDbContext.Remarks.SingleOrDefault(t => t.Id == model.Id && t.IsTask.HasValue && t.IsTask.Value);

            if (entity == null)
                throw new BusinessException($"Task with id {model.Id} does not exist");

            if (model.TaskStatus == TaskStatus.Done && currentUser != entity.CreatedBy)
                throw new BusinessException("Only task creator can change the status to done.");

            entity.TaskStatus = model.TaskStatus;
            await this.dataDbContext.SaveChangesAsync();

            if (entity.TaskStatus != TaskStatus.Done)
            {
                await SendTaskStatusChangeNotification(entity, currentUser);
            }

            if (entity.TaskStatus == TaskStatus.Done && !string.IsNullOrEmpty(entity.AssignedTo))
            {
                await SendTaskClosedNotification(entity.EntityId, currentUser, entity.AssignedTo, entity.Id);
            }
        }

        private async Task SendNewRemarkNotificationToExternalUsers(int remarkEntityId, string reference, TaskUserType userType, string? claimantEmail = null)
        {
            var assigneeHeadline = $"Task on submission #{reference}";
            var assigneeDesc = $"Please check submission #{reference}";
            var receivers = new List<string>();

            
            List<string> usersInUserRole = new List<string>();

            if (userType == TaskUserType.Donor)
            {
                
                usersInUserRole = await applicationUserManager.GetAllDonorUsers();
            }
            else if (ApplicationUserManager.IsOfTypeMinistryUser(userType))
            {
                usersInUserRole = await applicationUserManager.GetAllUsersInMinistryType(userType.ToString());
            } 
            else if (claimantEmail != null)
            {
                usersInUserRole.Add(claimantEmail);
            }
            
            foreach (var user in usersInUserRole)
            {
                // separately send emails (bcc option not yet enabled)
                await SendEmailNotificationToTaggedUsers(remarkEntityId, reference, "internal", new string[] { user });
            }
            

            await _notificationManager.SendClaimNotification(receivers, remarkEntityId, assigneeHeadline, assigneeDesc);
        }

        private async Task SendNewRemarkNotificationToInternalUsers(int remarkEntityId, string reference, string currentUser, string[] users)
        {
            var assigneeHeadline = $"Task on submission #{reference}";
            var assigneeDesc = $"Please check submission #{reference}";
            var receivers = new List<string>();
            await SendEmailNotificationToTaggedUsers(remarkEntityId, reference, currentUser, users);
            await _notificationManager.SendClaimNotification(receivers, remarkEntityId, assigneeHeadline, assigneeDesc);
        }

        private async Task SendNotificationToTaskAssignee(string currentUser, int remarkEntityId, string reference, string taskAssignee)
        {
            var assigneeHeadline = $"Task assigned by {currentUser}";
            var assigneeDesc = $"You were assigned a task by {currentUser} on submission #{reference}";

            await _notificationManager.SendClaimNotification(new List<string> { taskAssignee }, remarkEntityId, assigneeHeadline, assigneeDesc);
            await SendEmailNotificationForNewTaskAssigned(remarkEntityId, reference, currentUser, new string[] { taskAssignee });
        }

        private async Task SendClaimRemarkReplyNotifications(int remarkEntityId, string currentUser, string reference, string claimParentCreatedBy, bool externalReply)
        {
            var replyType = externalReply ? "EXTERNAL" : "INTERNAL";
            var headline = $"[{replyType}] An {replyType.ToLower()} reply to remark by {currentUser}";
            var description = $"{replyType} An {replyType.ToLower()} reply has been posted to one of your remarks on submission #{reference}";

            await _notificationManager.SendClaimNotification(new List<string> { claimParentCreatedBy }, remarkEntityId, headline, description);
            await SendEmailNotificationForRemarkReply(remarkEntityId, reference, currentUser, new string[] { claimParentCreatedBy }, replyType);
        }

        private async Task SendTaskStatusChangeNotification(Remark task, string currentUser)
        {
            var submission = await dataDbContext.Claims.Where(x => x.Id == task.EntityId).FirstOrDefaultAsync();
            var headline = $"Task #{task.Id} status changed";
            var description = $"The status of the task #{task.Id} for submission #{submission?.Reference} has been updated to ${task.TaskStatus} by {currentUser}.";
            var notificationForUsers = new List<string>();
            if (task.CreatedBy != currentUser)
                notificationForUsers.Add(task.CreatedBy);
            if (task.AssignedTo != null && task.AssignedTo != currentUser)
                notificationForUsers.Add(task.AssignedTo);

            await _notificationManager.SendClaimNotification(notificationForUsers, submission.Id, headline, description);
        }
        private async Task SendTaskClosedNotification(int entityId, string? currentUser, string assignedTo, int taskId)
        {
            var submission = await dataDbContext.Claims.Where(x => x.Id == entityId).FirstOrDefaultAsync();
            var headline = $"Your task #{taskId} bas been closed";
            var description = $"Task #{taskId} for submission #{submission.Reference} that was assigned to you has been closed by {currentUser}";

            await _notificationManager.SendClaimNotification(new List<string> { assignedTo }, submission.Id, headline, description);
        }

        public async Task ReassignTask(SimpleRemarkModel model, string? currentUser)
        {
            var entity = this.dataDbContext.Remarks
              .SingleOrDefault(t => t.Id == model.Id && t.IsTask.HasValue && t.IsTask.Value);

            if (entity.CreatedBy != currentUser && entity.AssignedTo != currentUser)
                throw new BusinessException("Only the assignee or creator can reassign a Task");

            string oldAssignee = entity.AssignedTo;
            entity.AssignedTo = model.AssignedTo;
            entity.TaskUserType = TaskUserType.Internal;
            entity.SetUpdateAuditData(currentUser);
            this.dataDbContext.SaveChangesAsync();

            await SendNotificationsOnTaskReassign(entity.Id, entity.EntityId, entity.CreatedBy, oldAssignee, entity.AssignedTo);
        }

        private async Task<RemarkModel?> SaveRemark(CreateRemarkModel req)
        {
            Remark remark = null;
            try
            {
                if (req.EntityType == (int)RemarkType.Claim)
                    remark = new Remark(req);

                return await _genericDataRepository.Add<RemarkModel>(remark);
            }
            catch (Exception ex)
            {
                throw new BusinessException("Unable to process remark. If this issue persists, please contact your administrator.");
            }
        }

        private async Task SendNotificationOnTag(string currentUser, int remarkEntityId, string reference, string[] taggedUsers)
        {
            if (taggedUsers.Length == 0)
                return;
            var taggedHeadline = $"You were mentioned by {currentUser}";
            var taggedDesc = $"You have been tagged in a remark on submission #{reference} by {currentUser}.";

            await _notificationManager.SendClaimNotification(taggedUsers.ToList(), remarkEntityId, taggedHeadline, taggedDesc);
            await SendEmailNotificationToTaggedUsers(remarkEntityId, reference, currentUser, taggedUsers);
        }

        private async Task SendEmailNotificationForRemarkReply(int remarkEntityId, string reference, string currentUser, string[] emailReceivers, string replyType)
        {
            string baseUrl = configuration.GetExternalEntityAppBaseUrl();
            var taskModel = new ClaimConfirmationModel(baseUrl, remarkEntityId, currentUser, DateTime.Now, reference);
            if (!hostEnvironment.IsDevelopment())
            {
                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.TaskReplyPostedNotification",
                    Title = $"VCEP - [{replyType}] new reply to remark",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = emailReceivers
                }, taskModel, baseUrl);
            }
        }

        private async Task SendEmailNotificationForNewTaskAssigned(int remarkEntityId, string reference, string currentUser, string[] emailReceivers)
        {
            string baseUrl = configuration.GetExternalEntityAppBaseUrl();
            var taskModel = new ClaimConfirmationModel(baseUrl, remarkEntityId, currentUser, DateTime.Now, reference);
            if (!hostEnvironment.IsDevelopment())
            {
                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.TaskAssigned",
                    Title = "VCEP - Task Assigned",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = emailReceivers
                }, taskModel, baseUrl);
            }
        }

        private async Task SendEmailNotificationToTaggedUsers(int entityId, string reference, string currentUser, string[] emailReceivers)
        {
            string baseUrl = configuration.GetExternalEntityAppBaseUrl();
            var taskModel = new ClaimConfirmationModel(baseUrl, entityId, currentUser, DateTime.Now, reference);
            if (!hostEnvironment.IsDevelopment())
            {
                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.TaggedUserNotification",
                    Title = "VCEP - Tag notification",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = emailReceivers
                }, taskModel, baseUrl);
            }
        }

        public async Task<RemarkModel> UpdateRemark(UpdateRemarkModel model, string currentUser)
        {
            var remark = await dataDbContext.Remarks.SingleOrDefaultAsync(r => r.Id == model.Id && !r.IsDeleted);
            
            if (remark == null)
                throw new BusinessException($"Remark with id {model.Id} does not exist or has been deleted.");
            
            if (remark.CreatedBy != currentUser)
                throw new BusinessException("Only the creator of a remark can edit it.");
            
            remark.RemarkText = model.RemarkText;
            remark.SetUpdateAuditData(currentUser);
            
            await dataDbContext.SaveChangesAsync();
            
            return new RemarkModel(remark, currentUser);
        }

        public async Task SoftDeleteRemark(int remarkId, string currentUser)
        {
            var remark = await dataDbContext.Remarks.SingleOrDefaultAsync(r => r.Id == remarkId && !r.IsDeleted);
            
            if (remark == null)
                throw new BusinessException($"Remark with id {remarkId} does not exist or has already been deleted.");
            
            if (remark.CreatedBy != currentUser)
                throw new BusinessException("Only the creator of a remark can delete it.");
            
            ((IDeletable)remark).SetDeletedAuditData(currentUser);
            
            await dataDbContext.SaveChangesAsync();
        }

        private async Task SendNotificationsOnTaskReassign(int remarkEntityId, int submissionId, string creator, string oldAssignee, string newAssignee)
        {
            var receivers = new List<string> { creator, newAssignee };

            var headline = $"Task reassigned by {oldAssignee}";
            var description = $"A task you created on submission #{submissionId} was reassigned from {oldAssignee} to {newAssignee}";

            await _notificationManager.SendClaimNotification(receivers, remarkEntityId, headline, description);

            string baseUrl = configuration.GetExternalEntityAppBaseUrl();
            var taskModel = new TaskEmailModel(baseUrl, submissionId, creator, newAssignee);
            if (!hostEnvironment.IsDevelopment())
            {
                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.TaskReassigned",
                    Title = "VCEP - Task Reassigned",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = new string[] { creator, newAssignee }
                }, taskModel, baseUrl);
            }
        }
    }
}