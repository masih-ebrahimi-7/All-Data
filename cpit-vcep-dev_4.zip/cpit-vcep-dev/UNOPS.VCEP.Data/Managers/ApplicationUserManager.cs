using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Emailing;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models.Email;
using UNOPS.VCEP.Infrastructure.Security;
using UsersManager.DataAccess;
using UsersManager.Domain;
using UsersManager.Helpers;

namespace UNOPS.VCEP.Data.Managers
{
    public class ApplicationUserManager : IApplicationService
    {
        private readonly ApplicationDbContext applicationDbContext;
        private readonly InfrastructureDbContext baseDbContext;
        private readonly UsersServices usersServices;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly EmailSenderManager emailSender;

        public ApplicationUserManager(UsersServices usersServices, ApplicationDbContext context,
            InfrastructureDbContext baseDbContext, UserManager<ApplicationUser> userManager,
            EmailSenderManager emailSender)
        {
            this.applicationDbContext = context;
            this.baseDbContext = baseDbContext;
            this.usersServices = usersServices;
            this.userManager = userManager;
            this.emailSender = emailSender;
        }

        public bool IsValidClaimantUser(string currentUser)
        {
            return applicationDbContext.Users.Any(o => o.DateActivated != null
                                                       && o.Email != null
                                                       && o.Email.ToLower() == currentUser.ToLower()
                                                       && o.Roles.Any(a => ExternalRole.Claimant == a.Role.Name));
        }

        public async Task<bool> IsClaimantUser(string currentUser)
        {
            return await applicationDbContext.Users.AnyAsync(o => o.Email != null
                                                                  && o.Email.ToLower() == currentUser.ToLower()
                                                                  && o.Roles.Any(a =>
                                                                      ExternalRole.Claimant == a.Role.Name));
        }

        public Task<ExternalEntityUser?> GetExternalEntityById(int userId, int externalEntityId)
        {
            return baseDbContext.ExternalEntityUsers.FirstOrDefaultAsync(o =>
                o.Id == userId && o.ExternalEntityId == externalEntityId);
        }

        public bool IsValidDonorUser(string currentUser)
        {
            return applicationDbContext.Users.Any(o => o.DateActivated != null
                                                       && o.Email != null
                                                       && o.Email.ToLower() == currentUser.ToLower()
                                                       && o.Roles.Any(a => ExternalRole.Donor == a.Role.Name));
        }

        public ExternalEntityType? GetExternalUserType(string email)
        {
            if (IsInternalUser(email))
                return null;

            if (email.EndsWith("@adb.org"))
                return ExternalEntityType.Donor;
            if (email.EndsWith("@mof.gov.af"))
                return ExternalEntityType.MoF;
            if (email.EndsWith("@mopw.gov.af"))
                return ExternalEntityType.MPW;
            if (email.EndsWith("@moph.gov.af"))
                return ExternalEntityType.MoPH;
            if (email.EndsWith("@mrrd.gov.af"))
                return ExternalEntityType.MRRD;
            if (email.EndsWith("@mail.gov.af"))
                return ExternalEntityType.MAIL;
            if (email.EndsWith("@dabs.af"))
                return ExternalEntityType.DABS;
            if (email.EndsWith("@mew.gov.af"))
                return ExternalEntityType.MEW;
            return ExternalEntityType.Claimant;
        }

        public bool IsInternalUser(string email)
        {
            return email.EndsWith("@unops.org");
        }

        public async Task<ApplicationUser> ManageExternalUsersRegistration(UserLoginInfo info, string email)
        {
            ApplicationUser user = new ApplicationUser();
            var externalUserType = this.GetExternalUserType(email);

            // Register user and activate account
            user = await usersServices.Register(info, email);

            // Automatically activate all external users including ministry users
            if (externalUserType != null)
            {
                user.Activate();
            }

            // check if user was already invited to the system and if not, then assign role by email domain
            ExternalEntityUser? externalUser = await baseDbContext.ExternalEntityUsers.Include(x => x.ExternalEntity)
                .Where(a => a.Email == email).SingleOrDefaultAsync();
            var role = GetExternalUserRole(externalUser?.ExternalEntity.ExternalEntityType ?? externalUserType);
            await usersServices.AssignRoles(user, role);

            await baseDbContext.SaveChangesAsync();
            return user;
        }

        private string GetExternalUserRole(ExternalEntityType? externalUserType)
        {
            if (externalUserType == ExternalEntityType.Donor) return ExternalRole.Donor;
            else if (externalUserType == ExternalEntityType.MoF) return ExternalRole.MoF;
            else if (externalUserType == ExternalEntityType.MPW) return ExternalRole.MPW;
            else if (externalUserType == ExternalEntityType.MoPH) return ExternalRole.MoPH;
            else if (externalUserType == ExternalEntityType.MRRD) return ExternalRole.MRRD;
            else if (externalUserType == ExternalEntityType.MAIL) return ExternalRole.MAIL;
            else if (externalUserType == ExternalEntityType.DABS) return ExternalRole.DABS;
            else if (externalUserType == ExternalEntityType.MEW) return ExternalRole.MEW;
            else return ExternalRole.Claimant;
        }

        public async Task NotifyInternalUserRegistration(string baseUrl, bool isDevelopmentHostEnvironment,
            string email)
        {
            if (isDevelopmentHostEnvironment)
            {
                var receivers = (await userManager.GetUsersInRoleAsync(BaseRole.SystemAdmin))
                    .Where(a => a.Active);

                var model = new NewUserRegisteredEmailModel(email, baseUrl);

                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.NewUserRegisteredTemplate",
                    Title = "VCEP - New user registration pending approval",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = receivers.Select(a => a.Email).ToArray()!
                }, model, baseUrl);

                // For internal users, admin needs to activate and assign them roles.
                await emailSender.SendEmail(new EmailModel
                {
                    TemplateName = "UNOPS.VCEP.Infrastructure.EmailTemplates.AccountRegisteredTemplate",
                    Title = "VCEP - Registration pending approval",
                    Attachments = new List<EmailAttachmentModel>(),
                    EmailReceivers = new string[] { email }
                }, model, baseUrl);
            }
        }

        public async Task<ApplicationUser?> ManageInternalUsersRegistration(UserLoginInfo info, string payloadEmail,
            string baseUrl, bool isDevelopment)
        {
            ApplicationUser user = new ApplicationUser();
            user = await usersServices.Register(info, payloadEmail);

            // Added because to prevent wrong registration emails to be sent. Can be removed after.
            var account = await userManager.FindByEmailAsync(payloadEmail);

            if (account != null)
            {
                // External users get activated and auto assigned roles hence no need for emails.
                // UNOPS users we are not sure which roles they will play and hence need emails
                await this.NotifyInternalUserRegistration(baseUrl, isDevelopment, payloadEmail);
            }

            return user;
        }

        public async Task<List<string>> GetAllUsersInRole(string roleName)
        {
            if (string.IsNullOrEmpty(roleName))
                return new List<string>();

            var users = await userManager.GetUsersInRoleAsync(roleName);
            return users.Where(u => !string.IsNullOrEmpty(u.Email))
                .Select(u => u.Email!)
                .ToList();
        }

        public async Task<List<string>> GetAllDonorUsers()
        {
            return await GetAllUsersInRole(ExternalRole.Donor);
        }

        public async Task<List<string>> GetAllUsersInMinistryType(string ministryRole)
        {
            var validMinistryRoles = new[]
            {
                ExternalRole.MoF,
                ExternalRole.MPW,
                ExternalRole.MoPH,
                ExternalRole.MRRD,
                ExternalRole.MAIL,
                ExternalRole.DABS,
                ExternalRole.MEW
            };

            if (!validMinistryRoles.Contains(ministryRole))
                return new List<string>();

            return await GetAllUsersInRole(ministryRole);
        }

        public async Task<string?> GetUserMinistryRole(string currentUser)
        {
            var ministryRoles = new[]
            {
                ExternalRole.MoF,
                ExternalRole.MPW,
                ExternalRole.MoPH,
                ExternalRole.MRRD,
                ExternalRole.MAIL,
                ExternalRole.DABS,
                ExternalRole.MEW
            };

            var user = await applicationDbContext.Users
                .Include(u => u.Roles)
                .ThenInclude(r => r.Role)
                .FirstOrDefaultAsync(o => o.DateActivated != null
                                          && o.Email != null
                                          && o.Email.ToLower() == currentUser.ToLower());

            if (user == null)
                return null;

            var userRoles = user.Roles.Select(r => r.Role.Name).ToList();
            return userRoles.FirstOrDefault(r => ministryRoles.Contains(r));
        }

        public async Task<bool> IsMinistryUser(string currentUser)
        {
            var ministryRole = await GetUserMinistryRole(currentUser);
            return ministryRole != null;
        }

        public ExternalEntityType? GetMinistryType(string ministryRole)
        {
            return ministryRole switch
            {
                ExternalRole.MoF => ExternalEntityType.MoF,
                ExternalRole.MPW => ExternalEntityType.MPW,
                ExternalRole.MoPH => ExternalEntityType.MoPH,
                ExternalRole.MRRD => ExternalEntityType.MRRD,
                ExternalRole.MAIL => ExternalEntityType.MAIL,
                ExternalRole.DABS => ExternalEntityType.DABS,
                ExternalRole.MEW => ExternalEntityType.MEW,
                _ => null
            };
        }

        public TaskUserType? GetMinistryTypeForTaskUserType(string ministryRole)
        {
            return ministryRole switch
            {
                ExternalRole.MoF => TaskUserType.MoF,
                ExternalRole.MPW => TaskUserType.MPW,
                ExternalRole.MoPH => TaskUserType.MoPH,
                ExternalRole.MRRD => TaskUserType.MRRD,
                ExternalRole.MAIL => TaskUserType.MAIL,
                ExternalRole.DABS => TaskUserType.DABS,
                ExternalRole.MEW => TaskUserType.MEW,
                _ => null
            };
        }

        public static bool IsOfTypeMinistryUser(TaskUserType userType)
        {
            var ministryTypes = new[]
            {
                TaskUserType.MoF,
                TaskUserType.MPW,
                TaskUserType.MoPH,
                TaskUserType.MRRD,
                TaskUserType.MAIL,
                TaskUserType.DABS,
                TaskUserType.MEW
            };
            return ministryTypes.Contains(userType);
        }
    }
}