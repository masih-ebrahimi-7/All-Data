using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Models.ClaimStage;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers;

public class ClaimStageManager : IApplicationService
{
    private readonly DataDbContext _context;
    private readonly UserResolverService _userService;

    public ClaimStageManager(DataDbContext context, UserResolverService userService)
    {
        _context = context;
        _userService = userService;
    }

    public async Task<List<ClaimStageResponseModel>> GetAllStagesAsync()
    {
        var stages = await _context.ClaimStages
            .Where(s => !s.IsDeleted)
            .OrderBy(s => s.SortOrder)
            .ToListAsync();

        return BuildHierarchy(stages);
    }

    public async Task<List<ClaimStageResponseModel>> GetActiveStagesAsync()
    {
        var stages = await _context.ClaimStages
            .Where(s => !s.IsDeleted && s.IsActive)
            .OrderBy(s => s.SortOrder)
            .ToListAsync();

        return BuildHierarchy(stages);
    }

    public async Task<ClaimStageResponseModel?> GetStageByIdAsync(int id)
    {
        var stage = await _context.ClaimStages
            .Where(s => s.Id == id && !s.IsDeleted)
            .FirstOrDefaultAsync();

        if (stage == null) return null;

        var children = await _context.ClaimStages
            .Where(s => s.ParentStageId == id && !s.IsDeleted)
            .OrderBy(s => s.SortOrder)
            .ToListAsync();

        return MapToResponseModel(stage, children);
    }

    public async Task<ClaimStageResponseModel> CreateStageAsync(CreateClaimStageRequestModel request)
    {
        if (request.ParentStageId.HasValue)
        {
            var parentExists = await _context.ClaimStages
                .AnyAsync(s => s.Id == request.ParentStageId.Value && !s.IsDeleted);
            if (!parentExists)
                throw new BusinessException("Parent stage not found");
        }

        var stage = new ClaimStage
        {
            Name = request.Name,
            Description = request.Description,
            WeightPercentage = request.WeightPercentage,
            EstimatedDurationWeeks = request.EstimatedDurationWeeks,
            SortOrder = request.SortOrder,
            IsActive = request.IsActive,
            ParentStageId = request.ParentStageId,
            EstimatedDeliveryTimeline = request.EstimatedDeliveryTimeline
        };

        _context.ClaimStages.Add(stage);
        await _context.SaveChangesAsync();

        return MapToResponseModel(stage);
    }

    public async Task<ClaimStageResponseModel> UpdateStageAsync(EditClaimStageRequestModel request)
    {
        var stage = await _context.ClaimStages
            .FirstOrDefaultAsync(s => s.Id == request.Id && !s.IsDeleted);

        if (stage == null)
            throw new BusinessException("Stage not found");

        if (request.ParentStageId.HasValue)
        {
            if (request.ParentStageId == request.Id)
                throw new BusinessException("Stage cannot be its own parent");

            var parentExists = await _context.ClaimStages
                .AnyAsync(s => s.Id == request.ParentStageId.Value && !s.IsDeleted);
            if (!parentExists)
                throw new BusinessException("Parent stage not found");

            if (await WouldCreateCircularReference(request.Id, request.ParentStageId.Value))
                throw new BusinessException("This would create a circular reference");
        }

        stage.Name = request.Name;
        stage.Description = request.Description;
        stage.WeightPercentage = request.WeightPercentage;
        stage.EstimatedDurationWeeks = request.EstimatedDurationWeeks;
        stage.SortOrder = request.SortOrder;
        stage.IsActive = request.IsActive;
        stage.ParentStageId = request.ParentStageId;
        stage.EstimatedDeliveryTimeline = request.EstimatedDeliveryTimeline;

        await _context.SaveChangesAsync();

        return MapToResponseModel(stage);
    }

    public async Task DeleteStageAsync(int id)
    {
        var stage = await _context.ClaimStages
            .Include(s => s.Children)
            .FirstOrDefaultAsync(s => s.Id == id && !s.IsDeleted);

        if (stage == null)
            throw new BusinessException("Stage not found");

        if (stage.Children.Any(c => !c.IsDeleted))
            throw new BusinessException("Cannot delete stage with active children");

        var isInUse = await _context.ClaimStageHistories
            .AnyAsync(h => h.ClaimStageId == id && !h.IsDeleted);

        if (isInUse)
            throw new BusinessException("Cannot delete stage that is in use by claims");

        stage.IsDeleted = true;
        await _context.SaveChangesAsync();
    }

    public async Task<ClaimStageHistoryResponseModel> MoveClaimToStageAsync(MoveClaimStageRequestModel request)
    {
        var claim = await _context.Claims
            .Include(c => c.StageHistories)
            .FirstOrDefaultAsync(c => c.Id == request.ClaimId && !c.IsDeleted);

        if (claim == null)
            throw new BusinessException("Claim not found");

        var stage = await _context.ClaimStages
            .FirstOrDefaultAsync(s => s.Id == request.ToStageId && !s.IsDeleted && s.IsActive);

        if (stage == null)
            throw new BusinessException("Stage not found or inactive");

        var currentStage = claim.StageHistories.FirstOrDefault(h => h.IsCurrentStage && !h.IsDeleted);
        if (currentStage != null)
        {
            currentStage.IsCurrentStage = false;
            currentStage.CompletedDate = DateTime.UtcNow;
        }

        var newStageHistory = new ClaimStageHistory
        {
            ClaimId = request.ClaimId,
            ClaimStageId = request.ToStageId,
            StartDate = DateTime.UtcNow,
            EstimatedCompletionDate = request.EstimatedCompletionDate,
            Notes = request.Notes,
            IsCurrentStage = true,
            MovedByUserId = _userService.GetUser(),
            MovedByUserName = _userService.GetUser()
        };

        _context.ClaimStageHistories.Add(newStageHistory);
        await _context.SaveChangesAsync();

        return MapToHistoryResponseModel(newStageHistory, stage);
    }

    public async Task<List<ClaimStageHistoryResponseModel>> GetClaimStageHistoryAsync(int claimId)
    {
        var histories = await _context.ClaimStageHistories
            .Include(h => h.ClaimStage)
            .Where(h => h.ClaimId == claimId && !h.IsDeleted)
            .OrderBy(h => h.CreatedDate)
            .ToListAsync();

        return histories
            .Where(h => h.ClaimStage != null)
            .Select(h => MapToHistoryResponseModel(h, h.ClaimStage!))
            .ToList();
    }

    public async Task<ClaimStageHistoryResponseModel?> GetCurrentClaimStageAsync(int claimId)
    {
        var currentHistory = await _context.ClaimStageHistories
            .Include(h => h.ClaimStage)
            .FirstOrDefaultAsync(h => h.ClaimId == claimId && h.IsCurrentStage && !h.IsDeleted);

        if (currentHistory == null || currentHistory.ClaimStage == null) return null;

        return MapToHistoryResponseModel(currentHistory, currentHistory.ClaimStage);
    }

    public async Task<List<TypeaheadInput>> GetStagesForFilterAsync()
    {
        var stages = await _context.ClaimStages
            .Where(s => !s.IsDeleted && s.IsActive)
            .OrderBy(s => s.SortOrder)
            .Select(s => new TypeaheadInput
            {
                Value = s.Id.ToString(),
                Label = s.Name
            })
            .ToListAsync();

        return stages;
    }

    private List<ClaimStageResponseModel> BuildHierarchy(List<ClaimStage> stages)
    {
        var stageDict = stages.ToDictionary(s => s.Id, s => MapToResponseModel(s));
        var rootStages = new List<ClaimStageResponseModel>();

        foreach (var stage in stages)
        {
            var stageModel = stageDict[stage.Id];
            
            if (stage.ParentStageId.HasValue && stageDict.ContainsKey(stage.ParentStageId.Value))
            {
                stageDict[stage.ParentStageId.Value].Children.Add(stageModel);
            }
            else
            {
                rootStages.Add(stageModel);
            }
        }

        return rootStages.OrderBy(s => s.SortOrder).ToList();
    }

    private async Task<bool> WouldCreateCircularReference(int stageId, int parentId)
    {
        var visited = new HashSet<int>();
        var currentId = parentId;

        while (currentId != 0)
        {
            if (currentId == stageId) return true;
            if (visited.Contains(currentId)) return true;
            
            visited.Add(currentId);
            
            var parent = await _context.ClaimStages
                .Where(s => s.Id == currentId && !s.IsDeleted)
                .Select(s => s.ParentStageId)
                .FirstOrDefaultAsync();
                
            currentId = parent ?? 0;
        }

        return false;
    }

    private static ClaimStageResponseModel MapToResponseModel(ClaimStage stage, List<ClaimStage>? children = null)
    {
        return new ClaimStageResponseModel
        {
            Id = stage.Id,
            Name = stage.Name,
            Description = stage.Description,
            WeightPercentage = stage.WeightPercentage,
            EstimatedDurationWeeks = stage.EstimatedDurationWeeks,
            SortOrder = stage.SortOrder,
            IsActive = stage.IsActive,
            ParentStageId = stage.ParentStageId,
            EstimatedDeliveryTimeline = stage.EstimatedDeliveryTimeline,
            CreatedDate = stage.CreatedDate,
            LastModifiedDate = stage.LastModifiedDate,
            Children = children?.Select(c => MapToResponseModel(c)).OrderBy(c => c.SortOrder).ToList() ?? new List<ClaimStageResponseModel>()
        };
    }

    private static ClaimStageHistoryResponseModel MapToHistoryResponseModel(ClaimStageHistory history, ClaimStage stage)
    {
        return new ClaimStageHistoryResponseModel
        {
            Id = history.Id,
            ClaimId = history.ClaimId,
            ClaimStageId = history.ClaimStageId,
            StageName = stage.Name,
            StageDescription = stage.Description,
            StageWeightPercentage = stage.WeightPercentage,
            StageEstimatedDurationWeeks = stage.EstimatedDurationWeeks,
            StartDate = history.StartDate,
            CompletedDate = history.CompletedDate,
            EstimatedCompletionDate = history.EstimatedCompletionDate,
            Notes = history.Notes,
            IsCurrentStage = history.IsCurrentStage,
            MovedByUserId = history.MovedByUserId,
            MovedByUserName = history.MovedByUserName,
            CreatedDate = history.CreatedDate
        };
    }
}
