using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class GrantManager : IApplicationService
    {
        private readonly IGenericDataRepository<Grant> genericDataRepository;
        private readonly ApplicationUserManager applicationUserManager;
        private readonly ExternalEntityManager externalEntityManager;
        private readonly DataDbContext dataDbContext;
        
        public GrantManager(IGenericDataRepository<Grant> dataRepository, ApplicationUserManager applicationUserManager,  ExternalEntityManager externalEntityManager, DataDbContext dataDbContext)
        {
            genericDataRepository = dataRepository;
            this.applicationUserManager = applicationUserManager;
            this.externalEntityManager = externalEntityManager;
            this.dataDbContext = dataDbContext;
        }

        public async Task<PaginationResponse<GrantResponseModel>> GetAllGrants(GrantsFilterModel? filter)
        {
            return await genericDataRepository.GetAllWithPagination<GrantsFilterModel, GrantResponseModel>(filter, 
                include: g => g
                    .Include(c => c.Contracts)
                    .ThenInclude(c => c.Contractor));
        }

        public async Task<GrantResponseModel> GetGrant(int grantId)
        {
            return await genericDataRepository.GetById<GrantResponseModel>(grantId);
        }

        public async Task<List<TypeaheadInput>> GetGrantsForFilter(string? currentUser, int? sector)
        {
            var displayOnlyCurrentEntityGrants = currentUser != null &&
                                                 applicationUserManager.IsValidClaimantUser(currentUser);

            if (displayOnlyCurrentEntityGrants)
                return await GetClaimantGrantsForFilter(currentUser, sector);
            return await GetAllGrantsForFilter(sector);
        }

        private async Task<List<TypeaheadInput>> GetAllGrantsForFilter(int? sector)
        {
            Expression<Func<Grant, bool>>? selector = null;
            if (sector != null && Enum.IsDefined(typeof(SectorType), sector))
            {
                selector = g => g.Sector == (SectorType)sector;
            }
            
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector: t => t.Reference,
                descriptionPropertySelector: t => t.Sector, selector: selector);
        }

        private async Task<List<TypeaheadInput>> GetClaimantGrantsForFilter(string? currentUser, int? sector)
        {
            var parentEntities = await externalEntityManager.GetParentExternalEntitiesByUserEmail(currentUser);
            var parentEntitiesIds = parentEntities.Select(a => a.Id);
           
            Expression<Func<Grant, bool>>? selector = g => g
                .Contracts
                .Any(contract => parentEntitiesIds.Contains(contract.Contractor.Id));

            if (sector != null && Enum.IsDefined(typeof(SectorType), sector))
            {
                Expression<Func<Grant, bool>> sectorSelector = g => g.Sector == (SectorType)sector;
                selector = selector.AndAlso(sectorSelector);
            }
            
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector: t => t.Reference,
                descriptionPropertySelector: t => t.Sector, selector: selector);
        }

        public async Task<GrantResponseModel> CreateGrant(GrantRequestModel grant)
        {
            var newGrant = new Grant(grant);
            return await this.genericDataRepository.Add<GrantResponseModel>(newGrant);
        }

        public async Task<GrantResponseModel> EditGrant(int grantId, GrantRequestModel grant)
        {
            var existingGrant = await this.genericDataRepository.GetById(grantId);
            if (existingGrant == null)
                throw new BusinessException($"Grant {grantId} does not exist.");
            else
            {
                await this.HandleUpdate(existingGrant, grant);
                return new GrantResponseModel(existingGrant);
            }
        }

        private async Task HandleUpdate(Grant existingGrant, GrantRequestModel grant)
        {
            existingGrant.UpdateName(grant.Name);
            existingGrant.UpdateReference(grant.Reference);
            existingGrant.UpdateDescription(grant.Description);
            existingGrant.UpdatePriority(grant.Priority);
            existingGrant.UpdateSector(grant.Sector);
            await dataDbContext.SaveChangesAsync();
        }
    }
}
