using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class ContractManager : IApplicationService
    {
        private readonly IGenericDataRepository<Contract> genericDataRepository;
        private readonly ApplicationUserManager applicationUserManager;
        private readonly ExternalEntityManager externalEntityManager;
        private readonly DataDbContext dataDbContext;
        private readonly CurrencyRateService _currencyRateService;
        public ContractManager(IGenericDataRepository<Contract> dataRepository, ApplicationUserManager applicationUserManager, ExternalEntityManager externalEntityManager, DataDbContext dataDbContext, CurrencyRateService currencyRateService)
        {
            genericDataRepository = dataRepository;
            this.applicationUserManager = applicationUserManager;
            this.externalEntityManager = externalEntityManager;
            this.dataDbContext = dataDbContext;
            this._currencyRateService = currencyRateService;
        }

        public async Task<PaginationResponse<ContractResponseModel>> GetAllContracts(ContractsFilterModel? filter)
        {
            var results = await genericDataRepository.GetAllWithPagination<ContractsFilterModel, ContractResponseModel>(filter,
                include: g => g
                    .Include(c => c.Contractor)
                    .Include(c => c.Grants)
                    .Include(c => c.Location));

            foreach (var contract in results.Records)
            {
                contract.AmountUsd = (contract.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? contract.Amount
                    : await _currencyRateService.GetEquivalentAmount(contract.CurrencyId, CurrencyCode.USD,
                        contract.Amount);
                contract.CurrencyRate = await _currencyRateService.GetCurrentRate(contract.CurrencyId, CurrencyCode.USD);
            }

            return results;
        }

        public async Task<List<TypeaheadInput>> GetForFilter(string? currentUser, int? sector, int? grantId, string? searchTerm = null)
        {
            var displayOnlyCurrentEntityContracts = currentUser != null &&
                                                 applicationUserManager.IsValidClaimantUser(currentUser);

            Expression<Func<Contract, bool>>? selector = null;
            if (displayOnlyCurrentEntityContracts)
            {
                var parentEntities = await externalEntityManager.GetParentExternalEntitiesByUserEmail(currentUser);
                selector = c => parentEntities.Select(a => a.Id).Contains(c.Contractor.Id);
            }

            if (sector != null && Enum.IsDefined(typeof(SectorType), sector))
            {
                Expression<Func<Contract, bool>> sectorSelector = g => g.Grants.Any(g => g.Sector == (SectorType)sector);
                selector = selector.AndAlso(sectorSelector);
            }

            if (grantId != null)
            {
                Expression<Func<Contract, bool>> grantSelector = g => g.Grants.Any(a => a.Id == grantId);
                selector = selector.AndAlso(grantSelector);
            }

            if (!string.IsNullOrEmpty(searchTerm))
            {
                Expression<Func<Contract, bool>> searchSelector = c => 
                    c.Name.ToLower().Contains(searchTerm.Trim().ToLower()) ||
                    c.Reference.ToLower().Contains(searchTerm.Trim().ToLower()) ||
                    c.Grants.Any(g => g.Reference.ToLower().Contains(searchTerm.Trim().ToLower()) || 
                                     g.Name.ToLower().Contains(searchTerm.Trim().ToLower()));
                selector = selector.AndAlso(searchSelector);
            }

            return await genericDataRepository.GetForFilterWithDescription(
                t => t.Name + " - " + t.Reference + " | " + string.Join(", ", t.Grants.Select(g => g.Sector.ToString())),
                c => "Grants: " + string.Join(", ", c.Grants.Select(g => g.Reference + " (" + g.Sector.ToString() + ")")),
                selector: selector,
                include: c => c.Include(a => a.Grants)
                    .Include(a => a.Contractor));
        }

        public async Task<ContractResponseModel> GetById(int contractId)
        {
            var contract = await genericDataRepository.GetById<ContractResponseModel>(contractId, include: c => c.Include(x => x.Grants));
            contract.AmountUsd = (contract.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? contract.Amount
                : await _currencyRateService.GetEquivalentAmount(contract.CurrencyId, CurrencyCode.USD,
                    contract.Amount);
            contract.CurrencyRate = await _currencyRateService.GetCurrentRate(contract.CurrencyId, CurrencyCode.USD);

            return contract;
        }

        public async Task<ContractResponseModel> CreateContract(ContractRequestModel contract)
        {
            ICollection<Grant> validGrants = new List<Grant>();
            if (contract.GrantIds is { Length: > 0 })
            {
                validGrants = await GetGrantsById(contract.GrantIds);
                if (validGrants.Count != contract.GrantIds.Length)
                    throw new BusinessException("Unable to create contracts with invalid Grant Ids.");
            }
            var newContract = new Contract(contract, validGrants);
            return await this.genericDataRepository.Add<ContractResponseModel>(newContract);
        }

        private async Task<ICollection<Grant>> GetGrantsById(int[] contractGrantIds)
        {
            return await dataDbContext.Grants.Where(a => contractGrantIds.Contains(a.Id)).ToListAsync();
        }

        public async Task<ContractResponseModel> EditContract(int contractId, ContractRequestModel contract)
        {
            var existingContract = await this.genericDataRepository.GetById(contractId, g => g.Include(x => x.Grants));
            if (existingContract == null)
                throw new BusinessException($"Contract {contractId} does not exist.");
            else
            {
                await this.HandleUpdate(existingContract, contract);
                return new ContractResponseModel(existingContract);
            }
        }

        private async Task HandleUpdate(Contract existingContract, ContractRequestModel contract)
        {
            ICollection<Grant> validGrants = new List<Grant>();
            if (contract.GrantIds is { Length: > 0 })
            {
                validGrants = await GetGrantsById(contract.GrantIds);
                if (validGrants.Count != contract.GrantIds.Length)
                    throw new BusinessException("Unable to link contracts with invalid Grants.");
            }
            existingContract.Update(contract, validGrants);
            await dataDbContext.SaveChangesAsync();
        }
    }
}
