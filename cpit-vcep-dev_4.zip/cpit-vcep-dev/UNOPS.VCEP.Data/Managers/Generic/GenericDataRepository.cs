using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using System.Linq.Expressions;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;
using Z.EntityFramework.Plus;

namespace UNOPS.VCEP.Data.Generic;

public class GenericDataRepository<TEntity> : IGenericDataRepository<TEntity> where TEntity : ModifiableDeletableEntity
{
    protected readonly DataDbContext _dataDbContext;
    protected readonly IMapper _mapper;
    protected DbSet<TEntity> _dbSet;

    public GenericDataRepository(IMapper mapper, DataDbContext context)
    {
        _mapper = mapper;
        _dataDbContext = context;
        _dbSet = context.Set<TEntity>();
    }

    public GenericDataRepository(DataDbContext context)
    {
        _dataDbContext = context;
        _dbSet = context.Set<TEntity>();
    }

    public async Task<TEntity?> GetById(int id, Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include = null)
    {
        var queryable = _dbSet.AsQueryable().Where(e => !e.IsDeleted);
        if (include != null)
            queryable = include(queryable);
        return await queryable.SingleOrDefaultAsync(a => a.Id == id);
    }

    public async Task<TResponseModel> GetById<TResponseModel>(int id, Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include)
    {
        var entrity = await GetById(id, include);
        if (entrity is null)
            throw new BusinessException($"Entity {id} does not exist.");

        return _mapper.Map<TResponseModel>(entrity);
    }

    public IQueryable<TEntity> GetAllWithFilter<TEntityFilter>(TEntityFilter? filter = default)
    {
        var entities = _dbSet.AsQueryable().Where(e => !e.IsDeleted);
        if (filter != null)
            entities.ApplyFilters(filter);

        return entities;
    }

    public async Task<List<TypeaheadInput>> GetForFilter<TProperty>(Expression<Func<TEntity, TProperty>> labelPropertySelector, Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include = null, Expression<Func<TEntity, bool>>? selector = null)
    {
        var queryable = GetAllWithIncludeAndConditions(include, selector);
        Func<TEntity, TProperty> labelSelectorFunc = labelPropertySelector.Compile();

        return await queryable.Select(a => new TypeaheadInput
        {
            Value = a.Id.ToString(),
            Label = labelSelectorFunc(a) != null ? labelSelectorFunc(a).ToString() : a.Id.ToString(),
        }).ToListAsync();
    }

    public async Task<List<TypeaheadInput>> GetForFilterWithDescription<TProperty, TDescProperty>(Expression<Func<TEntity, TProperty>> labelPropertySelector, Expression<Func<TEntity, TDescProperty>> descriptionPropertySelector = null, Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include = null, Expression<Func<TEntity, bool>>? selector = null)
    {
        var queryable = GetAllWithIncludeAndConditions(include, selector);
        Func<TEntity, TProperty> labelSelectorFunc = labelPropertySelector.Compile();
        Func<TEntity, TDescProperty> descSelectorFunc = descriptionPropertySelector.Compile();
        queryable = queryable.OrderBy(a => a.Id);
        
        return await queryable.Select(a => new TypeaheadInput
        {
            Value = a.Id.ToString(),
            Label = labelSelectorFunc(a) != null ? labelSelectorFunc(a).ToString() : a.Id.ToString(),
            Description = descSelectorFunc(a) != null ? descSelectorFunc(a).ToString() : a.Id.ToString()
        }).ToListAsync();
    }

    public async Task<PaginationResponse<TResponseModel>> GetAllWithPagination<TEntityFilter, TResponseModel>(TEntityFilter? filter = default,
        Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include = null, Expression<Func<TEntity, bool>>? selector = null) where TEntityFilter : PaginationRequest
    {
        var queryable = GetAllWithIncludeAndConditions(include, selector);
        if (filter != null)
            queryable = queryable.ApplyFilters(filter);

        queryable = filter?.OrderBy != null ? queryable.OrderByColumnName(filter.OrderBy, filter.Ascending ?? true) : queryable.OrderByDescending(a => a.CreatedDate);
        return queryable.Paginate(o => _mapper.Map<TResponseModel>(o),
                new GenericPaginationRequest<TEntityFilter>(filter));
    }

    private IQueryable<TEntity> GetAllWithIncludeAndConditions(Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>>? include = null, Expression<Func<TEntity, bool>>? selector = null)
    {
        var queryable = _dbSet.AsQueryable().Where(e => !e.IsDeleted);
        if (include != null)
            queryable = include(queryable);
        if (selector != null)
            queryable = queryable.Where(selector);

        return queryable;
    }

    public async Task<IEnumerable<TEntity>> GetAllWithFilterAndIncludes<TEntityFilter>(TEntityFilter? filter = default, params string[] includes)
    {
        var query = ApplyIncludes(_dbSet, includes).Where(e => !e.IsDeleted);
        if (filter != null)
            query.ApplyFilters(filter);

        var entities = await query.ToListAsync();
        return _mapper.Map<IEnumerable<TEntity>>(entities);
    }

    private IQueryable<TEntity> ApplyIncludes(IQueryable<TEntity> query, params string[] includes)
    {
        return includes.Aggregate(query, (current, include) => current.Include(include));
    }

    public async Task<IEnumerable<TEntity>> GetAll()
    {
        return await _dataDbContext.Set<TEntity>().Where(e => !e.IsDeleted).ToListAsync();
    }

    public async Task<TResponseModel> Add<TResponseModel>(TEntity entityToInsert)
    {
        await Add(entityToInsert);
        return _mapper.Map<TResponseModel>(entityToInsert);
    }

    public async Task Add(TEntity entity)
    {
        await _dbSet.AddAsync(entity);
        await _dataDbContext.SaveChangesAsync();
    }

    public void Delete(TEntity entity)
    {
        _dataDbContext.Set<TEntity>().Remove(entity);
    }
    
    public async Task<TResponseModel> Update<TResponseModel>(TEntity entityToUpdate)
    {
        await Update(entityToUpdate);
        return _mapper.Map<TResponseModel>(entityToUpdate);
    }

    public async Task Update(TEntity entity)
    {
        await _dataDbContext.SingleUpdateAsync<TEntity>(entity.Id);
        await _dataDbContext.SaveChangesAsync();
    }
}