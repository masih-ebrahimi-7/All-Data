using AutoMapper;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Generic.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<AdvanceAccount, AdvanceAccountResponseModel>()
            .ConstructUsing(x => new AdvanceAccountResponseModel(x)); 
        CreateMap<Claim, ClaimResponseModel>()
            .ConstructUsing(x => new ClaimResponseModel(x))
            .ForMember(x => x.Status, opt => opt.Ignore());
        CreateMap<Contract, ContractResponseModel>()
            .ConstructUsing(x => new ContractResponseModel(x));
        CreateMap<ExternalEntity, ExternalEntityModel>()
            .ConstructUsing(x => new ExternalEntityModel(x));
        CreateMap<Grant, GrantResponseModel>()
            .ConstructUsing(x => new GrantResponseModel(x));
        CreateMap<Invoice, InvoiceResponseModel>()
            .ConstructUsing(x => new InvoiceResponseModel(x))
            .ForMember(x => x.Status, opt => opt.Ignore());
        CreateMap<ProjectAgreement, ProjectAgreementResponseModel>()
            .ConstructUsing(x => new ProjectAgreementResponseModel(x));
        CreateMap<WithdrawalApplication, WithdrawalApplicationResponseModel>()
            .ConstructUsing(x => new WithdrawalApplicationResponseModel(x));
        CreateMap<Remark, RemarkModel>()
            .ConstructUsing(x => new RemarkModel(x));
        CreateMap<Expense, ExpenseResponseModel>()
            .ConstructUsing(x => new ExpenseResponseModel(x));
        CreateMap<Salary, SalaryResponseModel>()
            .ConstructUsing(x => new SalaryResponseModel(x)); 
        CreateMap<Staff, StaffResponseModel>()
            .ConstructUsing(x => new StaffResponseModel(x)); 
        CreateMap<StaffContract, StaffContractResponseModel>()
            .ConstructUsing(x => new StaffContractResponseModel(x)); 
    }
}