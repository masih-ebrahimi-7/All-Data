using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class SalariesManager : IApplicationService
    {
        private readonly IGenericDataRepository<Salary> genericDataRepository;
        private readonly DataDbContext dataDbContext;
        private readonly CurrencyRateService _currencyRateService;
        public SalariesManager(IGenericDataRepository<Salary> dataRepository, DataDbContext dataDbContext, CurrencyRateService currencyRateService)
        {
            genericDataRepository = dataRepository;
            this.dataDbContext = dataDbContext;
            this._currencyRateService = currencyRateService;
        }

        public async Task<PaginationResponse<SalaryResponseModel>> GetAllSalaries(SalariesFilterModel? filter)
        {
           return await genericDataRepository.GetAllWithPagination<SalariesFilterModel, SalaryResponseModel>(filter,
                selector: g => !g.IsDeleted,
                include: g => g
                    .Include(c => c.Grant)
                    .Include(c => c.Staff)
                    .Include(c => c.StaffContract));
        }
        
        public async Task<SalaryResponseModel> GetById(int salaryId)
        {
            return await genericDataRepository.GetById<SalaryResponseModel>(salaryId);
        }

        public async Task<SalaryResponseModel> CreateSalary(SalaryBaseModel salary)
        {
            var validEntities = await ValidatateRelatedEntities(salary);
            if (validEntities)
            {
                var newSalary = new Salary(salary);
                return await this.genericDataRepository.Add<SalaryResponseModel>(newSalary);
            }
            else
            {
                throw new BusinessException("Unable to create a new salary with invalid related entities.");
            }
        }

        private async Task<bool> ValidatateRelatedEntities(SalaryBaseModel model)
        {
            bool validGrant = true, validStaff = true, validStaffContract = true;
            if (model.GrantId != null)
                validGrant = (await dataDbContext.Grants.SingleAsync(a => a.Id.Equals(model.GrantId))) != null;
            if (model.StaffId != null)
                validStaff = (await dataDbContext.Staff.SingleAsync(a => a.Id.Equals(model.StaffId))) != null;
            if (model.StaffContractId != null)
                validGrant = (await dataDbContext.StaffContracts.SingleAsync(a => a.Id.Equals(model.StaffContractId))) != null;

            return validGrant && validStaff && validStaffContract;
        }

        public async Task<SalaryResponseModel> EditSalary(int salaryId, SalaryBaseModel salary)
        {
            var existingSalary = await this.genericDataRepository.GetById(salaryId);
            if (existingSalary == null)
                throw new BusinessException($"Salary {salaryId} does not exist.");
            else
            {
                var validEntities = await ValidatateRelatedEntities(salary);
                if (validEntities) {
                    existingSalary.Update(salary);
                    await dataDbContext.SaveChangesAsync();
                    return new SalaryResponseModel(existingSalary);
                }
                else
                {
                    throw new BusinessException("Unable to create a new salary with invalid related entities.");
                }
            }
        }
    }
}
