using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class ExpensesManager : IApplicationService
    {
        private readonly IGenericDataRepository<Expense> genericDataRepository;
        private readonly DataDbContext dataDbContext;
        private readonly CurrencyRateService _currencyRateService;
        private readonly IReferenceGenerator _referenceGenerator;
        public ExpensesManager(IGenericDataRepository<Expense> dataRepository, DataDbContext dataDbContext, CurrencyRateService currencyRateService, IReferenceGenerator referenceGenerator)
        {
            genericDataRepository = dataRepository;
            this.dataDbContext = dataDbContext;
            _currencyRateService = currencyRateService;
            _referenceGenerator = referenceGenerator;
        }

        public async Task<PaginationResponse<ExpenseResponseModel>> GetAllExpenses(ExpensesFilterModel? filter)
        {
            var results = await genericDataRepository.GetAllWithPagination<ExpensesFilterModel, ExpenseResponseModel>(filter,
                selector: g => !g.IsDeleted,
                include: g => g
                    .Include(c => c.Contractor)
                    .Include(c => c.Grants));
            
            foreach (var expense in results.Records)
            {
                expense.PendingClaimsAmountUsd = (expense.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? expense.PendingClaimsAmount
                    : await _currencyRateService.GetEquivalentAmount(expense.CurrencyId, CurrencyCode.USD,
                        expense.PendingClaimsAmount);
                
                expense.MonthlyCostUsd = (expense.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? expense.MonthlyCost
                    : await _currencyRateService.GetEquivalentAmount(expense.CurrencyId, CurrencyCode.USD,
                        expense.MonthlyCost);
                
                expense.CurrencyRate = await _currencyRateService.GetCurrentRate(expense.CurrencyId, CurrencyCode.USD);
            }

            return results;
        }
        
        public async Task<ExpenseResponseModel> GetById(int expenseId)
        {
            var expense = await genericDataRepository.GetById<ExpenseResponseModel>(expenseId);
            expense.PendingClaimsAmountUsd = (expense.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? expense.PendingClaimsAmount
                : await _currencyRateService.GetEquivalentAmount(expense.CurrencyId, CurrencyCode.USD,
                    expense.PendingClaimsAmount);
                
            expense.MonthlyCostUsd = (expense.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? expense.MonthlyCost
                : await _currencyRateService.GetEquivalentAmount(expense.CurrencyId, CurrencyCode.USD,
                    expense.MonthlyCost);
            expense.CurrencyRate = await _currencyRateService.GetCurrentRate(expense.CurrencyId, CurrencyCode.USD);

            return expense;
        }

        public async Task<ExpenseResponseModel> CreateExpense(ExpenseBaseModel expense)
        {
            ICollection<Grant> validGrants = new List<Grant>();
            if (expense.GrantIds is { Length: > 0 })
            {
                validGrants = await GetGrantsById(expense.GrantIds);
                if (validGrants.Count != expense.GrantIds.Length)
                    throw new BusinessException("Unable to create expenses with invalid Grant Ids.");
            }

            var reference = await _referenceGenerator.GenerateIdReferenceAsync<Expense>("EX");
            var newExpense = new Expense(expense, reference, validGrants);
            
            return await this.genericDataRepository.Add<ExpenseResponseModel>(newExpense);
        }

        private async Task<ICollection<Grant>> GetGrantsById(int[] expenseGrantIds)
        {
            return await dataDbContext.Grants.Where(a => expenseGrantIds.Contains(a.Id)).ToListAsync();
        }

        public async Task<ExpenseResponseModel> EditExpense(int expenseId, ExpenseBaseModel expense)
        {
            var existingExpense = await this.genericDataRepository.GetById(expenseId);
            if (existingExpense == null)
                throw new BusinessException($"Expense {expenseId} does not exist.");
            else
            {
                await this.HandleUpdate(existingExpense, expense);
                return new ExpenseResponseModel(existingExpense);
            }
        }

        private async Task HandleUpdate(Expense existingExpense, ExpenseBaseModel expense)
        {
            ICollection<Grant> validGrants = new List<Grant>();
            if (expense.GrantIds is { Length: > 0 })
            {
                validGrants = await GetGrantsById(expense.GrantIds);
                if (validGrants.Count != expense.GrantIds.Length)
                    throw new BusinessException("Unable to link expenses with invalid Grants.");
            }
            existingExpense.Update(expense, validGrants);
            await dataDbContext.SaveChangesAsync();
        }
    }
}
