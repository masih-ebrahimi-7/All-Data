using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class StaffManager : IApplicationService
    {
        private readonly IGenericDataRepository<Staff> genericDataRepository;
        private readonly DataDbContext dataDbContext;
        public StaffManager(IGenericDataRepository<Staff> dataRepository, DataDbContext dataDbContext)
        {
            genericDataRepository = dataRepository;
            this.dataDbContext = dataDbContext;
        }

        public async Task<PaginationResponse<StaffResponseModel>> GetAllStaff(StaffFilterModel? filter)
        {
            return  await genericDataRepository.GetAllWithPagination<StaffFilterModel, StaffResponseModel>(filter,
                selector: g => !g.IsDeleted,
                include: null);
        }
        
        public async Task<StaffResponseModel> GetById(int staffId)
        {
            return await genericDataRepository.GetById<StaffResponseModel>(staffId);
        }

        public async Task<StaffResponseModel> CreateStaff(StaffBaseModel staff)
        {
            var newStaff = new Staff(staff);
            return await this.genericDataRepository.Add<StaffResponseModel>(newStaff);
        }
        
        public async Task<StaffResponseModel> EditStaff(int staffId, StaffBaseModel staff)
        {
            var existingStaff = await this.genericDataRepository.GetById(staffId);
            if (existingStaff == null)
                throw new BusinessException($"Staff {staffId} does not exist.");
            else
            {
                existingStaff.Update(staff);
                await dataDbContext.SaveChangesAsync();
                return new StaffResponseModel(existingStaff);
            }
        }
        
        public async Task<List<TypeaheadInput>> GetForFilter()
        {
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector: t => t.FullName,
                descriptionPropertySelector: t => t.FullName, selector: null);
        }
    }
}
