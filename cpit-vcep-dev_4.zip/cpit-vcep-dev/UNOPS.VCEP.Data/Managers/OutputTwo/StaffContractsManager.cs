using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class StaffContractsManager : IApplicationService
    {
        private readonly IGenericDataRepository<StaffContract> genericDataRepository;
        private readonly DataDbContext dataDbContext;
        public StaffContractsManager(IGenericDataRepository<StaffContract> dataRepository, DataDbContext dataDbContext)
        {
            genericDataRepository = dataRepository;
            this.dataDbContext = dataDbContext;
        }

        public async Task<PaginationResponse<StaffContractResponseModel>> GetAllStaffContracts(StaffContractsFilterModel? filter)
        {
            return await genericDataRepository.GetAllWithPagination<StaffContractsFilterModel, StaffContractResponseModel>(filter,
                selector: g => !g.IsDeleted,
                include: null);
        }
        
        public async Task<StaffContractResponseModel> GetById(int staffContractId)
        {
            return await genericDataRepository.GetById<StaffContractResponseModel>(staffContractId);
        }

        public async Task<StaffContractResponseModel> CreateStaffContract(StaffContractBaseModel staffContract)
        {
            var newStaffContract = new StaffContract(staffContract);
            return await this.genericDataRepository.Add<StaffContractResponseModel>(newStaffContract);
        }

        public async Task<StaffContractResponseModel> EditStaffContract(int staffContractId, StaffContractBaseModel staffContract)
        {
            var existingStaffContract = await this.genericDataRepository.GetById(staffContractId);
            if (existingStaffContract == null)
                throw new BusinessException($"StaffContract {staffContractId} does not exist.");
            else
            {
                existingStaffContract.Update(staffContract);
                await dataDbContext.SaveChangesAsync();
                return new StaffContractResponseModel(existingStaffContract);
            }
        }
        public async Task<List<TypeaheadInput>> GetForFilter()
        {
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector: t => t.Reference,
                descriptionPropertySelector: t => t.Reference, selector: null);
        }
    }
}
