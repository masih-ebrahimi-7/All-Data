using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class AdvanceAccountManager : IApplicationService
    {
        private readonly DataDbContext dataDbContext;
        private readonly IGenericDataRepository<AdvanceAccount> genericDataRepository;
        private readonly IGenericDataRepository<WithdrawalApplication> waGenericDataRepository;
        private readonly CurrencyRateService currencyRateService;
        public AdvanceAccountManager(IGenericDataRepository<AdvanceAccount> dataRepository,
            IGenericDataRepository<WithdrawalApplication> waGenericDataRepository, DataDbContext context,
            CurrencyRateService currencyRateService)
        {
            this.dataDbContext = context;
            this.genericDataRepository = dataRepository;
            this.waGenericDataRepository = waGenericDataRepository;
            this.currencyRateService = currencyRateService;
        }

        public async Task<AdvanceAccountResponseModel> GetOne(int advanceAccountId)
        {
            var advanceAccount = await dataDbContext.AdvanceAccounts
                .SingleOrDefaultAsync(a=> a.Id == advanceAccountId);
            if (advanceAccount is null)
                throw new BusinessException($"Advance Account {advanceAccountId} does not exist.");
            
            return new AdvanceAccountResponseModel(advanceAccount);
        }

        public async Task<AdvanceAccountResponseModel> Create(AdvanceAccountBaseModel advanceAccount)
        {
            var newAdvanceAccount = new AdvanceAccount(advanceAccount);
            if (advanceAccount.LatestWithdrawalApplication != null)
            {
                var newWithdrawalApplication = new WithdrawalApplication(advanceAccount.LatestWithdrawalApplication);
                await this.waGenericDataRepository.Add<WithdrawalApplication>(newWithdrawalApplication);
            }

            return await this.genericDataRepository.Add<AdvanceAccountResponseModel>(newAdvanceAccount);
        }
        
        
        public async Task<AdvanceAccountResponseModel> Edit(int advanceAccountId, AdvanceAccountBaseModel advanceAccount)
        {
            var existingAdvanceAccount = await this.genericDataRepository.GetById(advanceAccountId, include: g => g
                .Include(c => c.LatestWithdrawalApplication));
            
            if (existingAdvanceAccount == null)
                throw new BusinessException($"Advance Account {advanceAccountId} does not exist.");
            else
            {
                await this.HandleUpdate(existingAdvanceAccount, advanceAccount);
                return new AdvanceAccountResponseModel(existingAdvanceAccount);
            }
        }

        private async Task HandleUpdate(AdvanceAccount existingAdvanceAccount, AdvanceAccountBaseModel advanceAccount)
        {
            if (advanceAccount.LatestWithdrawalApplication != null)
            {
                if (existingAdvanceAccount.LatestWithdrawalApplication == null)
                {
                    var newWithdrawalApplication = new WithdrawalApplication(advanceAccount.LatestWithdrawalApplication);
                    await this.waGenericDataRepository.Add<WithdrawalApplication>(newWithdrawalApplication);
                }
                else
                {
                    existingAdvanceAccount.LatestWithdrawalApplication.HandleUpdate(advanceAccount.LatestWithdrawalApplication);
                }
            }

            existingAdvanceAccount.Update(advanceAccount);
            await dataDbContext.SaveChangesAsync();
        }

        public async Task<PaginationResponse<AdvanceAccountResponseModel>> GetAll(AdvanceAccountsFilterModel filter)
        {
            var results = await this.genericDataRepository.GetAllWithPagination<AdvanceAccountsFilterModel, AdvanceAccountResponseModel>(filter,
                include: g => g
                    .Include(c => c.LatestWithdrawalApplication)
                    .Include(a => a.Grant)
            );
            foreach (var advanceAccount in results.Records)
            {
                advanceAccount.LastDistributionAmountUsd = (advanceAccount.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? advanceAccount.LastDistributionAmount
                    : await currencyRateService.GetEquivalentAmount(advanceAccount.CurrencyId, CurrencyCode.USD,
                        advanceAccount.LastDistributionAmount);

                advanceAccount.RefundableAmountUsd = (advanceAccount.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? advanceAccount.RefundableAmount
                    : await currencyRateService.GetEquivalentAmount(advanceAccount.CurrencyId, CurrencyCode.USD,
                        advanceAccount.RefundableAmount);
                
                advanceAccount.CurrencyRate = await currencyRateService.GetCurrentRate(advanceAccount.CurrencyId, CurrencyCode.USD);
            }

            return results;
        }
    }
}
