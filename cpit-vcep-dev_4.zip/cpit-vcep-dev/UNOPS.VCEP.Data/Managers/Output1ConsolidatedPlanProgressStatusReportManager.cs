using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers;

public class Output1ConsolidatedPlanProgressStatusReportManager : IApplicationService
{
    private readonly DataDbContext _context;
    private readonly CurrencyRateService _currencyRateService;

    public Output1ConsolidatedPlanProgressStatusReportManager(DataDbContext context, CurrencyRateService currencyRateService)
    {
        _context = context;
        _currencyRateService = currencyRateService;
    }

    public async Task<PaginationResponse<Output1ConsolidatedPlanProgressStatusReportModel>> GetOutput1ConsolidatedPlanProgressStatusReportAsync(
        Output1ConsolidatedPlanProgressStatusReportRequest request)
    {
        var query = _context.Claims
            .Include(c => c.Contract)
            .Include(c => c.Grant)
            .Include(c => c.ProjectAgreement)
            .Include(c => c.LinkedClaimantUser)
                .ThenInclude(u => u.ExternalEntity)
            .Include(c => c.StageHistories)
                .ThenInclude(sh => sh.ClaimStage)
            .Where(c => c.Type != ContractType.IndividualConsultant && c.Type != ContractType.Cdc && c.Type != ContractType.SupplierOutputTwo && !c.IsDeleted && c.Status != ClaimStatus.AwaitingClearance && c.Status != ClaimStatus.Rejected);

        if (!string.IsNullOrEmpty(request.SearchTerm))
        {
            query = query.Where(c => 
                c.InternalReferenceCode.Contains(request.SearchTerm) ||
                c.Title.Contains(request.SearchTerm) ||
                c.Contract.Name.Contains(request.SearchTerm) ||
                c.LinkedClaimantUser.ExternalEntity.Name.Contains(request.SearchTerm));
        }

        if (!string.IsNullOrEmpty(request.PriorityFilter))
        {
            if (int.TryParse(request.PriorityFilter, out var priorityValue) && 
                Enum.IsDefined(typeof(PriorityType), priorityValue))
            {
                var priority = (PriorityType)priorityValue;
                query = query.Where(c => c.Priority == priority);
            }
        }

        if (!string.IsNullOrEmpty(request.DonorFilter))
        {
            if (int.TryParse(request.DonorFilter, out var fundSourceValue) && 
                Enum.IsDefined(typeof(FundSourceType), fundSourceValue))
            {
                var fundSource = (FundSourceType)fundSourceValue;
                query = query.Where(c => c.FundSource == fundSource);
            }
        }

        var totalCount = await query.CountAsync();
        
        var claims = await query
            .OrderBy(c => c.InternalReferenceCode)
            .Skip((request.PageIndex - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        var reportItems = new List<Output1ConsolidatedPlanProgressStatusReportModel>();
        var counter = (request.PageIndex - 1) * request.PageSize + 1;

        foreach (var claim in claims)
        {
            var reportItem = await MapClaimToReportItemAsync(claim, counter);
            if (request.ProgressMin.HasValue && reportItem.ProgressPercentageComplete < request.ProgressMin.Value)
                continue;
            if (request.ProgressMax.HasValue && reportItem.ProgressPercentageComplete > request.ProgressMax.Value)
                continue;
                
            reportItems.Add(reportItem);
            counter++;
        }

        return new PaginationResponse<Output1ConsolidatedPlanProgressStatusReportModel>
        {
            Records = reportItems,
            TotalCount = totalCount
        };
    }

    private async Task<Output1ConsolidatedPlanProgressStatusReportModel> MapClaimToReportItemAsync(Claim claim, int number)
    {
        string claimedCurrency = "USD";
        string unopsRecommendationCurrency = "USD";
        
        if (!string.IsNullOrEmpty(claim.CurrencyId) && Enum.TryParse(claim.CurrencyId, out CurrencyCode currencyCode))
        {
            claimedCurrency = currencyCode.GetDescriptionFromEnumValue();
            unopsRecommendationCurrency = currencyCode.GetDescriptionFromEnumValue();
        }

        var reportItem = new Output1ConsolidatedPlanProgressStatusReportModel
        {
            ClaimId = claim.Id,
            WBS = claim.InternalReferenceCode ?? "",
            Number = number,
            Priority = claim.Priority.ToString(),
            Donor = claim.FundSource.GetDescriptionFromEnumValue() ?? claim.FundSource.ToString(),
            GrantNumber = claim.Grant?.Reference ?? "",
            ContractNumber = claim.Contract?.Reference ?? "",
            ContractTitle = claim.Contract?.Name ?? "",
            Claimant = claim.LinkedClaimantUser?.ExternalEntity?.Name ?? "",
            CountryOfRegistration = claim.LinkedClaimantUser?.ExternalEntity?.Nationality ?? "",
            ClaimedAmount = claim.ClaimedAmount,
            ClaimedAmountCurrency = claimedCurrency,
            UNOPSRecommendation = claim.OfficialEstimatedAmount,
            UNOPSRecommendationCurrency = unopsRecommendationCurrency
        };

        if (reportItem.UNOPSRecommendationCurrency != "USD" && reportItem.UNOPSRecommendation > 0)
        {
            try
            {
                reportItem.UNOPSRecommendationAugust2025USD = await _currencyRateService
                    .GetEquivalentAmount(reportItem.UNOPSRecommendationCurrency, CurrencyCode.USD, reportItem.UNOPSRecommendation);
            }
            catch
            {
                reportItem.UNOPSRecommendationAugust2025USD = reportItem.UNOPSRecommendation;
            }
        }
        else
        {
            reportItem.UNOPSRecommendationAugust2025USD = reportItem.UNOPSRecommendation;
        }

        var allStages = await _context.ClaimStages
            .Include(s => s.ParentStage)
            .Include(s => s.Children)
            .Where(s => !s.IsDeleted && s.IsActive)
            .OrderBy(s => s.SortOrder)
            .ToListAsync();

        var stageHistories = claim.StageHistories
            .Where(sh => !sh.IsDeleted)
            .ToList();

        decimal completedWeight = 0;
        var stageProgressList = new List<ClaimStageProgressModel>();

        var currentStageHistory = stageHistories
            .Where(sh => sh.IsCurrentStage)
            .OrderByDescending(sh => sh.ClaimStage.SortOrder)
            .FirstOrDefault();

        var highestCompletedStageHistory = stageHistories
            .Where(sh => sh.CompletedDate.HasValue)
            .OrderByDescending(sh => sh.ClaimStage.SortOrder)
            .FirstOrDefault();

        int? currentStageSortOrder = currentStageHistory?.ClaimStage.SortOrder;
        int? highestCompletedSortOrder = highestCompletedStageHistory?.ClaimStage.SortOrder;

        var stageProgressMap = new Dictionary<int, ClaimStageProgressModel>();
        
        foreach (var stage in allStages)
        {
            var stageHistory = stageHistories.FirstOrDefault(sh => sh.ClaimStageId == stage.Id);
            var hasActualHistory = stageHistory != null;
            var isActuallyCompleted = stageHistory?.CompletedDate.HasValue ?? false;
            var isActuallyCurrentStage = stageHistory?.IsCurrentStage ?? false;

            bool shouldBeMarkedCompleted = isActuallyCompleted;
            
            // If stage is not the current stage and has a lower sort order than the current stage,
            // it should be marked as completed regardless of completion date
            if (!shouldBeMarkedCompleted && currentStageSortOrder.HasValue && !isActuallyCurrentStage)
            {
                shouldBeMarkedCompleted = stage.SortOrder < currentStageSortOrder.Value;
            }
            // If there's no current stage but we have a highest completed stage,
            // mark all stages up to and including that stage as completed
            else if (!shouldBeMarkedCompleted && !currentStageSortOrder.HasValue && highestCompletedSortOrder.HasValue)
            {
                shouldBeMarkedCompleted = stage.SortOrder <= highestCompletedSortOrder.Value;
            }

            var stageProgress = new ClaimStageProgressModel
            {
                StageId = stage.Id,
                StageName = stage.Name,
                StageDescription = stage.Description ?? "",
                WeightPercentage = stage.WeightPercentage ?? 0,
                SortOrder = stage.SortOrder,
                EstimatedDurationWeeks = stage.EstimatedDurationWeeks,
                EstimatedDeliveryTimeline = stage.EstimatedDeliveryTimeline ?? "",
                EstimatedCompletionDate = hasActualHistory ? stageHistory?.EstimatedCompletionDate : null,
                ActualCompletionDate = hasActualHistory ? stageHistory?.CompletedDate : null,
                IsCompleted = shouldBeMarkedCompleted,
                IsCurrentStage = isActuallyCurrentStage,
                StatusLabel = isActuallyCurrentStage ? "Current" : (shouldBeMarkedCompleted ? "Completed" : "Pending"),
                ParentStageId = stage.ParentStageId,
                ParentStageName = stage.ParentStage?.Name ?? "",
                HasChildren = stage.Children.Any(),
                Children = new List<ClaimStageProgressModel>()
            };

            stageProgressMap[stage.Id] = stageProgress;
        }

        foreach (var stage in allStages)
        {
            if (stage.ParentStageId.HasValue && stageProgressMap.ContainsKey(stage.ParentStageId.Value))
            {
                var parentStage = stageProgressMap[stage.ParentStageId.Value];
                var childStage = stageProgressMap[stage.Id];
                parentStage.Children.Add(childStage);
            }
        }

        foreach (var stageProgress in stageProgressMap.Values)
        {
            if (stageProgress.HasChildren)
            {
                foreach (var child in stageProgress.Children)
                {
                    if (child.IsCompleted)
                    {
                        completedWeight += child.WeightPercentage;
                    }
                    else if (child.IsCurrentStage)
                    {
                        completedWeight += child.WeightPercentage * 0.5m;
                    }
                }
            }
            else if (!stageProgress.ParentStageId.HasValue)
            {
                if (stageProgress.IsCompleted)
                {
                    completedWeight += stageProgress.WeightPercentage;
                }
                else if (stageProgress.IsCurrentStage)
                {
                    completedWeight += stageProgress.WeightPercentage * 0.5m;
                }
            }
        }

        stageProgressList = stageProgressMap.Values
            .Where(s => !s.ParentStageId.HasValue)
            .OrderBy(s => s.SortOrder)
            .ToList();

        reportItem.ProgressPercentageComplete = Math.Round(Math.Min(completedWeight, 100), 1);
        reportItem.Stages = stageProgressList;

        return reportItem;
    }
}
