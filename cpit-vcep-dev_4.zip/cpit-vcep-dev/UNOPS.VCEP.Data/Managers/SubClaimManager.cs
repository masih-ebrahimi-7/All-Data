using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Models.SubClaim;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Managers
{
    public class SubClaimManager : IApplicationService
    {
        private readonly DataDbContext _context;
        private readonly CurrencyRateService _currencyRateService;

        public SubClaimManager(DataDbContext context, CurrencyRateService currencyRateService)
        {
            _context = context;
            _currencyRateService = currencyRateService;
        }

        public async Task<List<SubClaimResponseModel>> GetSubClaimsByClaimIdAsync(int claimId)
        {
            var subClaims = await _context.SubClaims
                .Where(sc => sc.ClaimId == claimId && !sc.IsDeleted)
                .ToListAsync();

            var results = new List<SubClaimResponseModel>();
            
            foreach (var subClaim in subClaims)
            {
                subClaim.ClaimAmountUsd = (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? subClaim.ClaimAmount
                    : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.ClaimAmount);
                
                subClaim.VerifiedAmountUsd = subClaim.VerifiedAmount.HasValue
                    ? (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                        ? subClaim.VerifiedAmount
                        : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.VerifiedAmount.Value)
                    : null;
                
                var currencyRate = await _currencyRateService.GetCurrentRate(subClaim.CurrencyId, CurrencyCode.USD);
                
                results.Add(new SubClaimResponseModel
                {
                    Id = subClaim.Id,
                    ClaimId = subClaim.ClaimId,
                    SubSeqNo = subClaim.SubSeqNo,
                    ReferenceCode = subClaim.ReferenceCode,
                    Type = subClaim.Type,
                    InvoiceIpcDate = subClaim.InvoiceIpcDate,
                    InvoiceIpcNumber = subClaim.InvoiceIpcNumber,
                    InvoiceIpcDescription = subClaim.InvoiceIpcDescription,
                    CurrencyId = subClaim.CurrencyId,
                    ClaimAmount = subClaim.ClaimAmount,
                    ClaimAmountUsd = subClaim.ClaimAmountUsd,
                    VerifiedAmount = subClaim.VerifiedAmount,
                    VerifiedAmountUsd = subClaim.VerifiedAmountUsd,
                    EligibilityStatus = subClaim.EligibilityStatus,
                    Remarks = subClaim.Remarks,
                    CreatedDate = subClaim.CreatedDate,
                    ModifiedDate = subClaim.ModifiedDate,
                    CurrencyRate = currencyRate
                });
            }
            
            return results;
        }

        public async Task<SubClaimResponseModel> GetSubClaimByIdAsync(int id)
        {
            var subClaim = await _context.SubClaims
                .Where(sc => sc.Id == id && !sc.IsDeleted)
                .FirstOrDefaultAsync();
                
            if (subClaim == null)
                return null;
                
            subClaim.ClaimAmountUsd = (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? subClaim.ClaimAmount
                : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.ClaimAmount);
            
            subClaim.VerifiedAmountUsd = subClaim.VerifiedAmount.HasValue
                ? (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? subClaim.VerifiedAmount
                    : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.VerifiedAmount.Value)
                : null;
            
            var currencyRate = await _currencyRateService.GetCurrentRate(subClaim.CurrencyId, CurrencyCode.USD);
            
            return new SubClaimResponseModel
            {
                Id = subClaim.Id,
                ClaimId = subClaim.ClaimId,
                SubSeqNo = subClaim.SubSeqNo,
                ReferenceCode = subClaim.ReferenceCode,
                Type = subClaim.Type,
                InvoiceIpcDate = subClaim.InvoiceIpcDate,
                InvoiceIpcNumber = subClaim.InvoiceIpcNumber,
                InvoiceIpcDescription = subClaim.InvoiceIpcDescription,
                CurrencyId = subClaim.CurrencyId,
                ClaimAmount = subClaim.ClaimAmount,
                ClaimAmountUsd = subClaim.ClaimAmountUsd,
                VerifiedAmount = subClaim.VerifiedAmount,
                VerifiedAmountUsd = subClaim.VerifiedAmountUsd,
                EligibilityStatus = subClaim.EligibilityStatus,
                Remarks = subClaim.Remarks,
                CreatedDate = subClaim.CreatedDate,
                ModifiedDate = subClaim.ModifiedDate,
                CurrencyRate = currencyRate
            };
        }

        public async Task<SubClaimResponseModel> CreateSubClaimAsync(CreateSubClaimRequestModel model)
        {
            var claim = await _context.Claims.FirstOrDefaultAsync(c => c.Id == model.ClaimId);
            if (claim == null)
                throw new ArgumentException($"Claim with ID {model.ClaimId} not found");

            var existingSubClaimsCount = await _context.SubClaims
                .CountAsync(sc => sc.ClaimId == model.ClaimId && !sc.IsDeleted);
            var nextSequenceNumber = existingSubClaimsCount + 1;

            var subClaim = new Domain.SubClaim
            {
                ClaimId = model.ClaimId,
                Type = model.Type,
                InvoiceIpcDate = model.InvoiceIpcDate,
                InvoiceIpcNumber = model.InvoiceIpcNumber,
                InvoiceIpcDescription = model.InvoiceIpcDescription,
                CurrencyId = model.CurrencyId,
                ClaimAmount = model.ClaimAmount,
                VerifiedAmount = model.VerifiedAmount,
                Remarks = model.Remarks
            };

            subClaim.SetReferenceCode(claim.Reference, nextSequenceNumber);
            await CalculateFieldsAsync(subClaim);

            _context.SubClaims.Add(subClaim);
            await _context.SaveChangesAsync();

            return await GetSubClaimByIdAsync(subClaim.Id);
        }

        public async Task<SubClaimResponseModel> UpdateSubClaimAsync(EditSubClaimRequestModel model)
        {
            var subClaim = await _context.SubClaims
                .FirstOrDefaultAsync(sc => sc.Id == model.Id && !sc.IsDeleted);

            if (subClaim == null)
                return null;

            subClaim.Type = model.Type;
            subClaim.InvoiceIpcDate = model.InvoiceIpcDate;
            subClaim.InvoiceIpcNumber = model.InvoiceIpcNumber;
            subClaim.InvoiceIpcDescription = model.InvoiceIpcDescription;
            subClaim.ClaimAmount = model.ClaimAmount;
            subClaim.VerifiedAmount = model.VerifiedAmount;
            subClaim.Remarks = model.Remarks;

            await CalculateFieldsAsync(subClaim);
            await _context.SaveChangesAsync();

            return await GetSubClaimByIdAsync(subClaim.Id);
        }

        public async Task<bool> DeleteSubClaimAsync(int id)
        {
            var subClaim = await _context.SubClaims
                .FirstOrDefaultAsync(sc => sc.Id == id && !sc.IsDeleted);

            if (subClaim == null)
                return false;

            subClaim.IsDeleted = true;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<SubClaimSummaryModel> GetSubClaimSummaryAsync(int claimId)
        {
            var subClaims = await _context.SubClaims
                .Where(sc => sc.ClaimId == claimId && !sc.IsDeleted)
                .ToListAsync();

            var summary = new SubClaimSummaryModel
            {
                TotalCount = subClaims.Count,
                EligibleCount = subClaims.Count(sc => sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Eligible),
                IneligibleCount = subClaims.Count(sc => sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Ineligible),
                TotalClaimAmount = subClaims.Sum(sc => sc.ClaimAmount),
                TotalVerifiedAmount = subClaims.Where(sc => sc.VerifiedAmount.HasValue).Sum(sc => sc.VerifiedAmount.Value),
                EligibleAmount = subClaims.Where(sc => sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Eligible)
                    .Sum(sc => sc.VerifiedAmount ?? sc.ClaimAmount),
                IneligibleAmount = subClaims.Where(sc => sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Ineligible)
                    .Sum(sc => sc.ClaimAmount - (sc.VerifiedAmount ?? 0))
            };

            return summary;
        }

        private async Task CalculateFieldsAsync(Domain.SubClaim subClaim)
        {
            subClaim.ClaimAmountUsd = (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? subClaim.ClaimAmount
                : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.ClaimAmount);
            
            subClaim.VerifiedAmountUsd = subClaim.VerifiedAmount.HasValue
                ? (subClaim.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? subClaim.VerifiedAmount
                    : await _currencyRateService.GetEquivalentAmount(subClaim.CurrencyId, CurrencyCode.USD, subClaim.VerifiedAmount.Value)
                : null;

            if (subClaim.VerifiedAmount.HasValue)
            {
                subClaim.EligibilityStatus = subClaim.VerifiedAmount == subClaim.ClaimAmount 
                    ? Domain.Enums.EligibilityStatus.Eligible 
                    : Domain.Enums.EligibilityStatus.Ineligible;
            }
            else
            {
                subClaim.EligibilityStatus = null;
            }
        }
    }
}