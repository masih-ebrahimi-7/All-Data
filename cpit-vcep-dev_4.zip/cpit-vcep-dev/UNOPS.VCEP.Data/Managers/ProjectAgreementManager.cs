using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;

namespace UNOPS.VCEP.Data.Managers
{
    public class ProjectAgreementManager : IApplicationService
    {
        private readonly IGenericDataRepository<ProjectAgreement> genericDataRepository;
        private readonly ApplicationUserManager applicationUserManager;
        private readonly ExternalEntityManager externalEntityManager;
        public ProjectAgreementManager(IGenericDataRepository<ProjectAgreement> dataRepository, 
            ExternalEntityManager externalEntityManager,
            ApplicationUserManager applicationUserManager)
        {
            this.genericDataRepository = dataRepository;
            this.externalEntityManager = externalEntityManager;
            this.applicationUserManager = applicationUserManager;
        }

        public async Task<PaginationResponse<ProjectAgreementResponseModel>> GetAll(ProjectAgreementsFilterModel filter)
        {
            return await genericDataRepository.GetAllWithPagination<ProjectAgreementsFilterModel, ProjectAgreementResponseModel>(filter, 
                include: g => g
                    .Include(a=> a.Grant)
                    .Include(a=> a.AdvanceAccount)
                    .Include(a => a.Contracts));
        }

        public async Task<ProjectAgreementResponseModel> Get(int projectAgreementId)
        { 
            return await genericDataRepository.GetById<ProjectAgreementResponseModel>(projectAgreementId, include: p => p.Include(p => p.Grant));
        }

        public async Task<List<TypeaheadInput>> GetForFilter(string? currentUser)
        {
            var displayOnlyCurrentEntityGrants = currentUser != null &&
                                                 applicationUserManager.IsValidClaimantUser(currentUser);

            Expression<Func<ProjectAgreement, bool>>? selector = null;
            if (displayOnlyCurrentEntityGrants)
            {
                var parentEntities = await externalEntityManager.GetParentExternalEntitiesByUserEmail(currentUser);
                var parentEntitiesIds = parentEntities.Select(a => a.Id);
               
                selector = g => g
                    .Contracts
                    .Any(contract => parentEntitiesIds.Contains(contract.Contractor.Id));
            }
            
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector:t => t.Reference, descriptionPropertySelector: t =>t.GrantId, selector: selector);
        }
    }
}
