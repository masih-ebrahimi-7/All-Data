using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;
using UsersManager.DataAccess;

namespace UNOPS.VCEP.Data.Managers;

public class DashboardManager : IApplicationService
{
    private readonly DataDbContext dataDbContext;
    private readonly InfrastructureDbContext infraDbContext;
    private readonly ApplicationDbContext applicationDbContext;
    private readonly CurrencyRateService _currencyRateService;

    public DashboardManager(DataDbContext context, InfrastructureDbContext infraDbContext,
        ApplicationDbContext applicationDbContext, CurrencyRateService currencyRateService)
    {
        dataDbContext = context;
        this.infraDbContext = infraDbContext;
        this.applicationDbContext = applicationDbContext;
        _currencyRateService = currencyRateService;
    }

    public async Task<ClaimStatisticsResponseModel> GetStatisticsForOutputByStatus(string outputType,
        ClaimStatus status)
    {
        var claims = GetClaimsByOutput(outputType);
        var sectorClaims = await claims.Where(a => a.Status == status).Select(x => new ClaimResponseModel(x)).ToListAsync();
        foreach (var claim in sectorClaims)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
        }
        return new ClaimStatisticsResponseModel(sectorClaims);
    }

    public async Task<ClaimStatisticsResponseModel> GetStatisticsForOutputByPriority(string outputType,
        PriorityType priority)
    {
        var claims = GetClaimsByOutput(outputType);
        var claimsForPriority = await claims.Where(a => a.Priority == priority).Select(x => new ClaimResponseModel(x)).ToListAsync();
        foreach (var claim in claimsForPriority)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
        }
        return new ClaimStatisticsResponseModel(claimsForPriority);
    }

    public async Task<ClaimStatisticsResponseModel> GetStatisticsForOutputByClaimType(string outputType, ContractType type)
    {
        var claims = GetClaimsByOutput(outputType);
        var sectorClaims = await claims.Where(a => a.Type == type).Select(x => new ClaimResponseModel(x)).ToListAsync();
        foreach (var claim in sectorClaims)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
        }
        return new ClaimStatisticsResponseModel(sectorClaims);
    }

    public async Task<ContractStatisticsResponseModel> GetStatisticsForOutputByContractType(string outputType,
        ContractType type)
    {
        var contracts = GetContractsByOutput(outputType);
        var typeContracts = await contracts.Where(a => a.ContractType == type).ToListAsync();
        return new ContractStatisticsResponseModel(typeContracts);
    }

    public async Task<ClaimStatisticsResponseModel> GetStatisticsForOutputBySector(string outputType, SectorType sector)
    {
        var claims = GetClaimsByOutput(outputType);
        var sectorClaims = await claims.Where(a => a.Sector == sector).Select(x => new ClaimResponseModel(x)).ToListAsync();
        foreach (var claim in sectorClaims)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
        }
        return new ClaimStatisticsResponseModel(sectorClaims);
    }

    private IQueryable<Claim> GetClaimsByOutput(string outputType)
    {
        return dataDbContext.Claims
            .Where(c => outputType == "output-one"
                ? c.GrantId != null && c.ProjectAgreementId == null
                : c.ProjectAgreementId != null).AsQueryable();
    }

    private IQueryable<Contract> GetContractsByOutput(string outputType)
    {
        return dataDbContext.Contracts
            .Include(a => a.Grants)
            .Include(a => a.ProjectAgreement)
            .AsQueryable();
    }

    public async Task<ClaimStatisticsResponseModel> GetStatisticsForClaimOutput(string outputType)
    {
        var claims = await GetClaimsByOutput(outputType).Select(x => new ClaimResponseModel(x)).ToListAsync();
        foreach (var claim in claims)
        {
            claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                ? claim.ClaimedAmount
                : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                    claim.ClaimedAmount);
        }
        return new ClaimStatisticsResponseModel(claims);
    }

    public async Task<ContractStatisticsResponseModel> GetStatisticsForContractOutput(string outputType)
    {
        var contracts = await GetContractsByOutput(outputType).ToListAsync();
        return new ContractStatisticsResponseModel(contracts);
    }

    public async Task<AggregatedStatisticsResponseModel<ClaimStatisticsResponseModel, ContractType, ClaimStatus>>
        GetAllClaimsStatistics(string output)
    {
        ClaimStatisticsResponseModel? byOutput = null;

        byOutput = await GetStatisticsForClaimOutput(output);
        var bySector =
            new Dictionary<SectorType, ClaimStatisticsResponseModel>();
        var sectorTypes = EnumExtensions.GetAllItems<SectorType>();
        foreach (var sectorType in sectorTypes)
        {
            bySector.Add(sectorType, await GetStatisticsForOutputBySector(output, sectorType));
        }

        var byType =
            new Dictionary<ContractType, ClaimStatisticsResponseModel>();
        var claimTypes = EnumExtensions.GetAllItems<ContractType>();
        foreach (var claimType in claimTypes)
        {
            byType.Add(claimType, await GetStatisticsForOutputByClaimType(output, claimType));
        }

        var byStatus =
            new Dictionary<ClaimStatus, ClaimStatisticsResponseModel>();
        var claimStatuses = EnumExtensions.GetAllItems<ClaimStatus>();
        foreach (var claimStatus in claimStatuses)
        {
            byStatus.Add(claimStatus, await GetStatisticsForOutputByStatus(output, claimStatus));
        }

        var byPriority =
            new Dictionary<PriorityType, ClaimStatisticsResponseModel>();
        var claimPriorities = EnumExtensions.GetAllItems<PriorityType>();
        foreach (var priority in claimPriorities)
        {
            byPriority.Add(priority, await GetStatisticsForOutputByPriority(output, priority));
        }

        var byNationality =
            new Dictionary<string, ClaimStatisticsResponseModel>();
        var claimsByNationality = dataDbContext.Claims
            .GroupBy(a =>
                a.Contract != null && a.Contract.Contractor != null && a.Contract.Contractor.Nationality != null
                    ? a.Contract.Contractor.Nationality
                    : "Not available")
            .Select(g => new
            {
                Key = g.Key,
                Claims = g.ToList()
            });

        foreach (var nationalityGroup in claimsByNationality)
        {
            var claimModels = nationalityGroup.Claims.Select(x => new ClaimResponseModel(x)).ToList();
            foreach (var claim in claimModels)
            {
                claim.ClaimedAmountUsd = (claim.CurrencyId == $"{(int)CurrencyCode.USD}")
                    ? claim.ClaimedAmount
                    : await _currencyRateService.GetEquivalentAmount(claim.CurrencyId, CurrencyCode.USD,
                        claim.ClaimedAmount);
            }
            byNationality.Add(nationalityGroup.Key, new ClaimStatisticsResponseModel(claimModels));
        }

        return new AggregatedStatisticsResponseModel<ClaimStatisticsResponseModel, ContractType, ClaimStatus>(
            byOutput: byOutput, bySector: bySector, byStatus: byStatus,
            byType: byType, byPriority: byPriority, byNationality: byNationality);
    }

    public async Task<AggregatedStatisticsResponseModel<ContractStatisticsResponseModel, ContractType, StatusType>>
        GetAllContractsStatistics(string output)
    {
        ContractStatisticsResponseModel? byOutput = null;
        Dictionary<SectorType, ContractStatisticsResponseModel> bySector =
            new Dictionary<SectorType, ContractStatisticsResponseModel>();
        Dictionary<PriorityType, ContractStatisticsResponseModel> byPriority =
            new Dictionary<PriorityType, ContractStatisticsResponseModel>();
        Dictionary<ContractType, ContractStatisticsResponseModel> byType =
            new Dictionary<ContractType, ContractStatisticsResponseModel>();

        byOutput = await GetStatisticsForContractOutput(output);

        var sectorTypes = EnumExtensions.GetAllItems<SectorType>();
        foreach (var sectorType in sectorTypes)
        {
            var contracts = GetContractsByOutput(output);
            bySector.Add(sectorType, new ContractStatisticsResponseModel(contracts.ToList()));
        }

        var contractTypes = EnumExtensions.GetAllItems<ContractType>();
        foreach (var type in contractTypes)
        {
            byType.Add(type, await GetStatisticsForOutputByContractType(output, type));
        }

        var contractsByNationality = dataDbContext.Contracts
            .GroupBy(a =>
                a.Contractor != null && a.Contractor.Nationality != null
                    ? a.Contractor.Nationality
                    : "Not available")
            .Select(g => new
            {
                Key = g.Key,
                Contracts = g.ToList()
            });

        var byNationality =
            new Dictionary<string, ContractStatisticsResponseModel>();
        foreach (var nationalityGroup in contractsByNationality)
        {
            byNationality.Add(nationalityGroup.Key, new ContractStatisticsResponseModel(nationalityGroup.Contracts));
        }

        return new AggregatedStatisticsResponseModel<ContractStatisticsResponseModel, ContractType, StatusType>(
            byOutput: byOutput, bySector: bySector, byPriority: byPriority,
            byType: byType, byNationality: byNationality);
    }
}