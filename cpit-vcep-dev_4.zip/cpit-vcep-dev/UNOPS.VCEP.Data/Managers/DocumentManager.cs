﻿using GoogleServices;
using GoogleServices.Enums;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Generic;
using UNOPS.VCEP.Data.Helpers;
using UNOPS.VCEP.Data.Models.Documents;
using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Managers;
using UNOPS.VCEP.Infrastructure.Models;
using UNOPS.VCEP.Infrastructure.Security;
using UsersManager.DataAccess;
using Claim = UNOPS.VCEP.Data.Domain.Claim;

namespace UNOPS.VCEP.Data.Managers
{
    public class DocumentManager
    {
        private readonly DataDbContext dbContext;
        private readonly GoogleDriveAPIHelper _googleDriveAPIHelper;
        private readonly ApplicationUserManager applicationUserManager;
        private readonly NotificationManager _notificationManager;
        private readonly IGenericDataRepository<DocumentAttachment> genericDataRepository;
        private readonly UserResolverService userService;
        private readonly IDbContextSchema schema;
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly IServiceScopeFactory _serviceProviderFactory;

        public DocumentManager(DataDbContext dbContext, NotificationManager notificationManager,
            ApplicationDbContext applicationDbContext,
            GoogleDriveAPIHelper googleDriveApiHelper, ApplicationUserManager applicationUserManager,
            IGenericDataRepository<DocumentAttachment> genericDataRepository, UserResolverService userService,
            IDbContextSchema schema, IConfiguration configuration, IWebHostEnvironment hostEnvironment,
            IServiceScopeFactory serviceProviderFactory)
        {
            this.dbContext = dbContext;
            this.applicationUserManager = applicationUserManager;
            _googleDriveAPIHelper = googleDriveApiHelper;
            this.genericDataRepository = genericDataRepository;
            this.userService = userService;
            this.schema = schema;
            _notificationManager = notificationManager;
            _applicationDbContext = applicationDbContext;
            _configuration = configuration;
            _hostEnvironment = hostEnvironment;
            _serviceProviderFactory = serviceProviderFactory;
        }

        public async Task<PaginationResponse<DocumentAttachmentModel>> GetAllDocuments(string? currentUser = null,
            DocumentAttachmentModelFilterModel? filter = null)
        {
            var displayOnlyCurrentClaimantDocs =
                currentUser != null && applicationUserManager.IsValidClaimantUser(currentUser);
            var displayOnlyDocsForDonorEntities =
                currentUser != null && applicationUserManager.IsValidDonorUser(currentUser);
            var displayOnlyDocsForMinistryEntities =
                currentUser != null && await applicationUserManager.IsMinistryUser(currentUser);

            var entityDocuments = GetDocuments();
            List<string> users;

            if (displayOnlyDocsForDonorEntities)
            {
                users = await applicationUserManager.GetAllDonorUsers();
                entityDocuments = entityDocuments.GetDocumentsCreatedByUsers(users);
            }
            else if (displayOnlyDocsForMinistryEntities)
            {
                var ministryRole = await applicationUserManager.GetUserMinistryRole(currentUser);
                users = await applicationUserManager.GetAllUsersInMinistryType(ministryRole);
                entityDocuments = entityDocuments.GetDocumentsCreatedByUsers(users);
            }
            else if (displayOnlyCurrentClaimantDocs)
                entityDocuments = entityDocuments.GetDocumentsCreatedByUser(currentUser);

            var response = entityDocuments.ApplyFilters(filter)
                .Paginate(o => new DocumentAttachmentModel(o, true),
                    new GenericPaginationRequest<DocumentAttachmentModelFilterModel>(filter));
            foreach (var documentAttachmentModel in response.Records)
            {
                documentAttachmentModel.IsExternalUpload =
                    await CheckIsExternalUploadFile(documentAttachmentModel.CreatedBy);
            }

            return response;
        }

        private IQueryable<DocumentAttachment> GetDocuments()
        {
            return this.dbContext.DocumentAttachments
                .Include(x => x.Grant)
                .Include(x => x.Invoice)
                .Include(x => x.Contract)
                .Include(x => x.Document)
                .ThenInclude(t => t.DocumentCategory)
                .Include(x => x.Claim)
                .Include(x => x.SubClaim)
                .OrderByDescending(a => a.CreatedDate)
                .Where(a => !a.IsDeleted)
                .AsQueryable();
        }

        public async Task<List<TypeaheadInput>> GetDocumentsForFilter(int? claimId)
        {
            return await genericDataRepository.GetForFilterWithDescription(labelPropertySelector: t => t.Document.Name,
                descriptionPropertySelector: t => t.Document.Url, selector: a => a.ClaimId == claimId && !a.IsDeleted,
                include: g =>
                    g.Include(c => c.Document));
        }

        public async Task BulkLinkDocumentsToSubClaims(BulkDocumentSubClaimLinkModel model, string currentUser)
        {
            foreach (var link in model.DocumentLinks)
            {
                var attachment = await dbContext.DocumentAttachments
                    .FirstOrDefaultAsync(da => da.Id == link.DocumentAttachmentId && !da.IsDeleted);
                
                if (attachment != null)
                {
                    attachment.SubClaimId = link.SubClaimId;
                    attachment.LastModifiedBy = currentUser;
                    attachment.LastModifiedDate = DateTime.UtcNow;
                }
            }
            
            await dbContext.SaveChangesAsync();
        }

        public async Task<List<string>> CheckDocumentsExist(DocumentCheckModel model)
        {
            var documentQuery = dbContext.DocumentAttachments.Include(x => x.Document).Where(a => !a.IsDeleted)
                .AsQueryable();

            if (model.ClaimId.HasValue)
            {
                var uploadType = UploadFileType.Claim;
                var fileNames = model.FileNames.Select(p =>
                    _googleDriveAPIHelper.GenerateFileName(Path.GetFileNameWithoutExtension(p), uploadType,
                        Path.GetExtension(p))).ToList();
                documentQuery = documentQuery.Where(x => fileNames.Any(p => EF.Functions.ILike(x.Document.Name, p)) &&
                                                         x.ClaimId == model.ClaimId);
            }
            else if (model.ContractId.HasValue)
            {
                var uploadType = UploadFileType.Contract;
                var fileNames = model.FileNames.Select(p =>
                    _googleDriveAPIHelper.GenerateFileName(Path.GetFileNameWithoutExtension(p), uploadType,
                        Path.GetExtension(p))).ToList();
                documentQuery = documentQuery.Where(x => fileNames.Any(p => EF.Functions.ILike(x.Document.Name, p)) &&
                                                         x.ContractId == model.ClaimId);
            }
            else if (model.Invoice.HasValue)
            {
                var uploadType = UploadFileType.Invoice;
                var fileNames = model.FileNames.Select(p =>
                    _googleDriveAPIHelper.GenerateFileName(Path.GetFileNameWithoutExtension(p), uploadType,
                        Path.GetExtension(p))).ToList();
                documentQuery = documentQuery.Where(x => fileNames.Any(p => EF.Functions.ILike(x.Document.Name, p)) &&
                                                         x.InvoiceId == model.ClaimId);
            }

            return await documentQuery.Select(g => g.Document.Name).ToListAsync();
        }

        public async Task ArchiveDocumentId(int id, string? currentUser)
        {
            var attachment = await this.dbContext.DocumentAttachments
                .Include(a => a.Document)
                .SingleOrDefaultAsync(a => a.DocumentId == id && !a.IsDeleted);
            if (attachment == null)
                throw new BusinessException($"Unable to find document: {id}");
            var isExternalUpload = await CheckIsExternalUploadFile(attachment.CreatedBy);
            if (isExternalUpload)
                throw new BusinessException($"Internal users are not allowed to delete external uploads.");
            await DriveFileToArchiveHandler(attachment, currentUser);
            this.dbContext.Remove(attachment);
            this.dbContext.Remove(attachment.Document);
            await this.dbContext.SaveChangesAsync();
        }

        private async Task<bool> CheckIsExternalUploadFile(string documentCreatedBy)
        {
            var fileUploadedByClaimant = applicationUserManager.IsValidClaimantUser(documentCreatedBy);
            var fileUploadedByDonor = applicationUserManager.IsValidDonorUser(documentCreatedBy);
            var fileUploadedByMinistry = await applicationUserManager.IsMinistryUser(documentCreatedBy);

            return fileUploadedByClaimant || fileUploadedByDonor || fileUploadedByMinistry;
        }

        public async Task UploadEntityDocumentsFromDrive(List<DocumentBaseModel> models, string uploadedBy)
        {
            var connectionString = GetConnectionString();
            var tasks = models.Select(model => Task.Run(async () =>
            {
                await using var innerDataDbContext =
                    new DataDbContext(new DbContextOptionsBuilder<DataDbContext>().UseNpgsql(connectionString).Options,
                        userService, schema);

                var detailsForDriveUpload = await GetFileDetailsForDriveUpload(model);

                var fileName = _googleDriveAPIHelper.GenerateFileName(
                    Path.GetFileNameWithoutExtension(model.DocumentName),
                    detailsForDriveUpload.EntityType, Path.GetExtension(model.DocumentName));
                var uploadedFileUrl =
                    await HandleCloneDriveFileToDrive(detailsForDriveUpload, model.Url, fileName);
                var googleFileId = _googleDriveAPIHelper.GetFileIdFromLink(uploadedFileUrl);

                var document = new Document
                {
                    GoogleDriveId = googleFileId,
                    DocumentSource = detailsForDriveUpload.DocumentSource,
                    DocumentCategoryId = detailsForDriveUpload.DocumentCategory,
                    Name = model.DocumentName!,
                    OriginalName = model.DocumentName!,
                    Url = uploadedFileUrl,
                    OriginalDriveLink = model.Url,
                    Linked = true
                };

                var attachmentAttachment = new DocumentAttachment
                {
                    Document = document,
                    GrantId = model.GrantId,
                    InvoiceId = model.InvoiceId,
                    ContractId = model.ContractId,
                    ClaimId = model.ClaimId,
                    SubClaimId = model.SubClaimId
                };

                innerDataDbContext.DocumentAttachments.Add(attachmentAttachment);
                await innerDataDbContext.SaveChangesAsync();
            })).ToArray();
            await Task.WhenAll(tasks);
        }

        public async Task UploadEntityDocumentsFromLocal(DocumentUploadModel model, string uploadedBy)
        {
            if (model?.Files is not null && model.Files.Count > 0)
            {
                var tasks = model.Files.Select(file => Task.Run(async () =>
                {
                    await using var innerDataDbContext =
                        new DataDbContext(
                            new DbContextOptionsBuilder<DataDbContext>().UseNpgsql(GetConnectionString()).Options,
                            userService, schema);

                    var documentCategoryMapping = model.MappingPairs.FirstOrDefault(t => t.Filename == file.FileName);
                    if (documentCategoryMapping != null)
                    {
                        model.CategoryId = documentCategoryMapping.DocumentCategoryId;
                        model.SubClaimId = documentCategoryMapping.SubClaimId;
                    }

                    var detailsForDriveUpload = await GetFileDetailsForDriveUpload(model);
                    var userEmails =
                        await GetUserEmailsToShareFileWith(model, uploadedBy);

                    var fileName = _googleDriveAPIHelper.GenerateFileName(
                        Path.GetFileNameWithoutExtension(file.FileName), detailsForDriveUpload.EntityType,
                        Path.GetExtension(file.FileName));

                    var uploadedFileUrl =
                        await HandleUploadLocalFileToDrive(detailsForDriveUpload, file, fileName, userEmails);
                    var googleFileId = _googleDriveAPIHelper.GetFileIdFromLink(uploadedFileUrl);

                    // Create Document
                    var document = new Document
                    {
                        GoogleDriveId = googleFileId,
                        Name = fileName,
                        OriginalName = fileName,
                        Url = uploadedFileUrl,
                        Linked = false,
                        DocumentSource = detailsForDriveUpload.DocumentSource,
                        DocumentCategoryId = detailsForDriveUpload.DocumentCategory
                    };

                    var attachmentAttachment = new DocumentAttachment
                    {
                        Document = document,
                        GrantId = model.GrantId,
                        InvoiceId = model.InvoiceId,
                        ContractId = model.ContractId,
                        ClaimId = model.ClaimId,
                        SubClaimId = model.SubClaimId
                    };

                    innerDataDbContext.DocumentAttachments.Add(attachmentAttachment);
                    await innerDataDbContext.SaveChangesAsync();
                })).ToArray();

                await Task.WhenAll(tasks);
            }
        }

        private async Task<List<string>> GetUserEmailsToShareFileWith(DocumentBaseModel model, string uploadedBy)
        {
            await using var innerDataDbContext =
                new DataDbContext(
                    new DbContextOptionsBuilder<DataDbContext>().UseNpgsql(GetConnectionString()).Options,
                    userService, schema);
            await using var innerInfraDbContext = new InfrastructureDbContext(
                new DbContextOptionsBuilder<InfrastructureDbContext>().UseNpgsql(GetConnectionString()).Options,
                userService,
                schema);
            // Get all user emails attached to entity to which this document belongs
            // var userEmailsQuery = await GetExternalEntityUsersToShareFile(model.ClaimId, model.ContractId,
            //     model.InvoiceId, model.GrantId, innerDataDbContext, innerInfraDbContext);

            // Get user emails

            var userEmails = new List<string> { uploadedBy };
            return userEmails;
        }

        private async Task<string> HandleUploadLocalFileToDrive(DetailsForDriveUpload detailsForDriveUpload,
            IFormFile file, string fileName, List<string> userEmails)
        {
            var secondLevelFolderId = await CreateFoldersAsync(detailsForDriveUpload,
                detailsForDriveUpload.EntityType.GetDescriptionFromEnumValue());
            return await _googleDriveAPIHelper.UploadFileToDrive(file, fileName, secondLevelFolderId,
                detailsForDriveUpload.EntityType, file.ContentType, userEmails.ToArray());
        }

        private async Task HandleCopyDriveFileToDrive(DetailsForDriveUpload detailsForDriveUpload,
            string fileDriveUrl)
        {
            var fileId = _googleDriveAPIHelper.GetFileIdFromLink(fileDriveUrl);
            var secondLevelFolderId = await CreateFoldersAsync(detailsForDriveUpload,
                detailsForDriveUpload.EntityType.GetDescriptionFromEnumValue());
            await _googleDriveAPIHelper.MoveFileToFolder(fileId, secondLevelFolderId);
        }

        private async Task DriveFileToArchiveHandler(DocumentAttachment attachment, string currentUser)
        {
            var model = new DocumentBaseModel(attachment);
            var detailsForDriveUpload = await GetFileDetailsForDriveUpload(model);
            var fileId = _googleDriveAPIHelper.GetFileIdFromLink(model.Url);
            var secondLevelFolderId = await CreateFoldersAsync(detailsForDriveUpload,
                detailsForDriveUpload.EntityType.GetDescriptionFromEnumValue(), archive: true);
            await _googleDriveAPIHelper.MoveFileToFolder(fileId, secondLevelFolderId);
        }

        private async Task<string> HandleCloneDriveFileToDrive(DetailsForDriveUpload detailsForDriveUpload,
            string fileDriveUrl, string fileName, List<string>? userEmails = null)
        {
            var fileId = _googleDriveAPIHelper.GetFileIdFromLink(fileDriveUrl);
            var secondLevelFolderId = await CreateFoldersAsync(detailsForDriveUpload,
                detailsForDriveUpload.EntityType.GetDescriptionFromEnumValue());
            return await _googleDriveAPIHelper.CloneFileToNewFolder(fileName, fileId, secondLevelFolderId,
                userEmails?.ToArray());
        }

        private async Task<string> CreateFoldersAsync(DetailsForDriveUpload detailsForDriveUpload, string type,
            bool archive = false)
        {
            var rootFolder = "";
            if (archive)
            {
                var archiveRootFolder = UploadFileType.Archived.GetDescriptionFromEnumValue();
                var archiveRoot = await _googleDriveAPIHelper.FindOrCreateFolder(archiveRootFolder, archiveRootFolder);
                rootFolder =
                    await _googleDriveAPIHelper.FindOrCreateFolder(detailsForDriveUpload.RootFolderName, type,
                        archiveRoot);
            }
            else
            {
                rootFolder = await _googleDriveAPIHelper.FindOrCreateFolder(detailsForDriveUpload.RootFolderName, type);
            }

            var firstLevelFolder =
                await _googleDriveAPIHelper.FindOrCreateFolder(detailsForDriveUpload.DocumentCategoryName, type,
                    rootFolder);
            var secondLevelFolder =
                await _googleDriveAPIHelper.FindOrCreateFolder(detailsForDriveUpload.DocumentSourceName, type,
                    firstLevelFolder);
            return secondLevelFolder;
        }

        // private async Task<IQueryable<ExternalEntityUser>> GetExternalEntityUsersToShareFile(int? claimId,
        //     int? contractId, int? invoiceId, int? grantId, DataDbContext innerDataDbContext,
        //     InfrastructureDbContext innerInfrastructureDbContext)
        // {
        //     var query = innerInfrastructureDbContext.ExternalEntityUsers;
        //     var entityIds = new List<int>();
        //
        //     if (claimId.HasValue)
        //     {
        //         var claim = await innerDataDbContext.Claims
        //             .Include(x => x.Contract)
        //             .Where(x => x.Id == claimId).FirstOrDefaultAsync();
        //         entityIds.Add(claim?.Contract?.ExternalEntityId ?? 0);
        //     }
        //
        //     if (contractId.HasValue)
        //     {
        //         var contract = await innerDataDbContext.Contracts.Where(x => x.Id == contractId).FirstOrDefaultAsync();
        //         entityIds.Add(contract?.ExternalEntityId ?? 0);
        //     }
        //
        //     if (invoiceId.HasValue)
        //     {
        //         var invoice = await innerDataDbContext.Invoices.Include(x => x.Contract).Where(x => x.Id == invoiceId)
        //             .FirstOrDefaultAsync();
        //         entityIds.Add(invoice?.Contract?.ExternalEntityId ?? 0);
        //     }
        //
        //     if (grantId.HasValue)
        //     {
        //         var grants = await innerDataDbContext.Grants.Include(x => x.Contracts).Where(x => x.Id == grantId)
        //             .ToListAsync();
        //         foreach (var grant in grants)
        //         {
        //             foreach (var contract in grant.Contracts)
        //             {
        //                 entityIds.Add(contract.ExternalEntityId ?? 0);
        //             }
        //         }
        //     }
        //
        //     return query.Where(x => entityIds.Contains(x.ExternalEntityId));
        // }

        /*
         * Deprecated; Not sending notifications on doc uploads ATM
         */
        private async Task SendDocumentUploadedNotifications(Claim claim, string currentUser, int docNumber)
        {
            var reviewerRoles = new List<string>
            {
                BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist,
                $"{claim.Sector.GetDescriptionFromEnumValue()}SectorLead"
            };
            var users = await _applicationDbContext.Users.Where(o => o.DateActivated != null
                                                                     && o.Email != null
                                                                     && o.Email.ToLower() != currentUser.ToLower()
                                                                     && o.Roles.Any(a =>
                                                                         reviewerRoles.Contains(a.Role.Name)))
                .Distinct().ToArrayAsync();
            var headline = $"Documents uploaded to claim {claim.Reference}";
            var description = $"{docNumber} documents have been uploaded to claim {claim.Reference} by {currentUser}.";

            await _notificationManager.SendClaimNotification(users.Select(x => x.Email).ToList(), claim.Id, headline,
                description);
        }

        private async Task<string> GetDocumentCategoryName(int? documentCategoryId)
        {
            var connectionString = GetConnectionString();
            await using var innerDataDbContext = new DataDbContext(
                new DbContextOptionsBuilder<DataDbContext>().UseNpgsql(connectionString).Options,
                userService, schema);
            var documentCategory =
                await innerDataDbContext.DocumentCategories.SingleOrDefaultAsync(a => a.Id == documentCategoryId);
            return documentCategory != null ? documentCategory.Name : "Uncategorized";
        }

        public async Task EditDocuments(List<DocumentEditModel> models, string currentUser)
        {
            var documentIds = models.Select(o => o.DocumentId).ToList();
            var documents = await dbContext.Documents.Where(x => documentIds.Contains(x.Id) && !x.IsDeleted)
                .ToListAsync();
            foreach (var document in documents)
            {
                var documentChangeModel = models.First(x => x.DocumentId == document.Id);
                bool requiresDriveChanges = false;
                if (document.Name != documentChangeModel.DocumentName)
                {
                    document.UpdateName(documentChangeModel.DocumentName);
                    Task.Run(async () => { await RenameDriveFile(document, documentChangeModel.DocumentName); });
                }

                var detailsForDriveUpload = await GetFileDetailsForDriveUpload(documentChangeModel);

                if (document.DocumentSource != detailsForDriveUpload.DocumentSource)
                {
                    document.UpdateSource(documentChangeModel.DocumentSource);
                    requiresDriveChanges = true;
                }


                if (document.DocumentCategoryId != detailsForDriveUpload.DocumentCategory)
                {
                    requiresDriveChanges = true;
                    document.UpdateCategoryId(detailsForDriveUpload.DocumentCategory);
                }

                await dbContext.SaveChangesAsync();

                if (requiresDriveChanges)
                {
                    Task.Run(async () => { await HandleCopyDriveFileToDrive(detailsForDriveUpload, document.Url); });
                }
            }
        }

        private async Task RenameDriveFile(Document document, string newName)
        {
            await using var scope = _serviceProviderFactory.CreateAsyncScope();
            try
            {
                var fileId = _googleDriveAPIHelper.GetFileIdFromLink(document.Url);
                await _googleDriveAPIHelper.RenameFile(fileId, newName);
            }
            catch (Exception ex)
            {
                var infrastructureDbContext = scope.ServiceProvider.GetRequiredService<InfrastructureDbContext>();
                var error = new ErrorModel
                {
                    Message =
                        $"Unable to rename document {document.Id} | {document.Name} to new name {newName} in Drive. Error: {ex.Message}.",
                    Code = 500,
                    Date = DateTime.Now,
                    Stack = ex.StackTrace
                };
                await infrastructureDbContext.RecordError("", "", error);
            }
        }

        private async Task<DetailsForDriveUpload> GetFileDetailsForDriveUpload(
            DocumentBaseModel baseModel)
        {
            var connectionString = GetConnectionString();
            await using var innerDataDbContext =
                new DataDbContext(new DbContextOptionsBuilder<DataDbContext>().UseNpgsql(connectionString).Options,
                    userService, schema);

            var type = UploadFileType.Claim;
            var rootFolderName = string.Empty;
            var rootFolderDriveId = string.Empty;


            if (baseModel.ClaimId.HasValue)
            {
                var claimDetails =
                    await innerDataDbContext.Claims.Where(x => x.Id == baseModel.ClaimId).FirstOrDefaultAsync();
                if (claimDetails == null)
                    throw new BusinessException($"Unable to find claim: {baseModel.ClaimId}");
                rootFolderName = claimDetails?.Reference;
                rootFolderDriveId = claimDetails?.GoogleDriveFolderId;
                if (string.IsNullOrEmpty(rootFolderDriveId))
                {
                    rootFolderDriveId =
                        await _googleDriveAPIHelper.FindOrCreateFolder(rootFolderName,
                            type.GetDescriptionFromEnumValue());
                    claimDetails.GoogleDriveFolderId = rootFolderDriveId;
                    innerDataDbContext.Entry(claimDetails).State = EntityState.Modified;
                }
            }
            else if (baseModel.GrantId.HasValue)
            {
                type = UploadFileType.Grant;
                var grantDetails =
                    await innerDataDbContext.Grants.Where(x => x.Id == baseModel.GrantId).FirstOrDefaultAsync();
                if (grantDetails == null)
                    throw new BusinessException($"Unable to find grant: {baseModel.GrantId}");
                rootFolderName = grantDetails?.Reference;
                rootFolderDriveId = grantDetails?.GoogleDriveFolderId;
                if (string.IsNullOrEmpty(rootFolderDriveId))
                {
                    rootFolderDriveId =
                        await _googleDriveAPIHelper.FindOrCreateFolder(rootFolderName,
                            type.GetDescriptionFromEnumValue());
                    grantDetails.GoogleDriveFolderId = rootFolderDriveId;
                    innerDataDbContext.Entry(grantDetails).State = EntityState.Modified;
                }
            }
            else if (baseModel.ContractId.HasValue)
            {
                type = UploadFileType.Contract;
                var contractDetails = await innerDataDbContext.Contracts.Where(x => x.Id == baseModel.ContractId)
                    .FirstOrDefaultAsync();
                if (contractDetails == null)
                    throw new BusinessException($"Unable to find contract: {baseModel.ContractId}");
                rootFolderName = contractDetails?.Reference;
                rootFolderDriveId = contractDetails?.GoogleDriveFolderId;
                if (string.IsNullOrEmpty(rootFolderDriveId))
                {
                    rootFolderDriveId =
                        await _googleDriveAPIHelper.FindOrCreateFolder(rootFolderName,
                            type.GetDescriptionFromEnumValue());
                    contractDetails.GoogleDriveFolderId = rootFolderDriveId;
                    innerDataDbContext.Entry(contractDetails).State = EntityState.Modified;
                }
            }
            else if (baseModel.InvoiceId.HasValue)
            {
                type = UploadFileType.Invoice;
                var invoiceDetails = await innerDataDbContext.Invoices.Where(x => x.Id == baseModel.InvoiceId)
                    .FirstOrDefaultAsync();
                if (invoiceDetails == null)
                    throw new BusinessException($"Unable to find invoice: {baseModel.InvoiceId}");
                rootFolderName = invoiceDetails?.Reference;
                rootFolderDriveId = invoiceDetails?.GoogleDriveFolderId;
                if (string.IsNullOrEmpty(rootFolderDriveId))
                {
                    rootFolderDriveId =
                        await _googleDriveAPIHelper.FindOrCreateFolder(rootFolderName,
                            type.GetDescriptionFromEnumValue());
                    invoiceDetails.GoogleDriveFolderId = rootFolderDriveId;
                    innerDataDbContext.Entry(invoiceDetails).State = EntityState.Modified;
                }
            }
            else
            {
                throw new BusinessException("Document not attached to any entity");
            }

            var documentCategory = baseModel.CategoryId;
            var documentCategoryName = baseModel.CategoryId.HasValue
                ? await GetDocumentCategoryName(baseModel.CategoryId)
                : "Uncategorized";
            var documentSource = baseModel.DocumentSource.HasValue
                ? (DocumentSource)baseModel.DocumentSource
                : DocumentSource.Unknown;
            var documentSourceName = baseModel.DocumentSource.HasValue
                ? ((DocumentSource)baseModel.DocumentSource).GetDescriptionFromEnumValue()
                : DocumentSource.Unknown.GetDescriptionFromEnumValue();

            await innerDataDbContext.SaveChangesAsync();
            return new DetailsForDriveUpload()
            {
                RootFolderName = rootFolderName,
                RootFolderDriveId = rootFolderDriveId,
                EntityType = type,
                DocumentCategoryName = documentCategoryName,
                DocumentCategory = documentCategory,
                DocumentSource = documentSource,
                DocumentSourceName = documentSourceName,
            };
        }

        private string GetConnectionString()
        {
            string connectionString;

            if (!_hostEnvironment.IsDevelopment())
            {
                var envDbConSecretName = _configuration.GetConnectionString("ConnectionSecretName");
                var projectId = _configuration.GetSection("AppConfig")["ProjectId"];
                var secretManager = new GoogleSecretManagerConfigurationProvider(projectId);
                connectionString = envDbConSecretName != null
                    ? secretManager.GetSecretVersion(envDbConSecretName, "latest")
                    : Environment.GetEnvironmentVariable("CONNECTION_STRING");
            }
            else
            {
                connectionString = _configuration.GetConnectionString("DbContext");
            }

            return connectionString;
        }
    }

    internal class DetailsForDriveUpload
    {
        public DetailsForDriveUpload()
        {
        }

        public string RootFolderName { get; set; }
        public string RootFolderDriveId { get; set; }
        public UploadFileType EntityType { get; set; }
        public string DocumentCategoryName { get; set; }
        public int? DocumentCategory { get; set; }
        public DocumentSource DocumentSource { get; set; }
        public string DocumentSourceName { get; set; }
    }
}