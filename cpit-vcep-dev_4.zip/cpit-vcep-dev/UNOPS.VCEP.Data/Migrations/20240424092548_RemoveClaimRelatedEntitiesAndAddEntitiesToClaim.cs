﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoveClaimRelatedEntitiesAndAddEntitiesToClaim : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Claim_PreClaimLinkedEntities_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropTable(
                name: "PreClaimLinkedEntities",
                schema: "public");

            migrationBuilder.RenameColumn(
                name: "PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                newName: "ProjectAgreementId");

            migrationBuilder.RenameIndex(
                name: "IX_Claim_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                newName: "IX_Claim_ProjectAgreementId");

            migrationBuilder.AddColumn<int>(
                name: "ContractId",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Claim_ContractId",
                schema: "public",
                table: "Claim",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_Claim_GrantId",
                schema: "public",
                table: "Claim",
                column: "GrantId");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_Contract_ContractId",
                schema: "public",
                table: "Claim",
                column: "ContractId",
                principalSchema: "public",
                principalTable: "Contract",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_Grant_GrantId",
                schema: "public",
                table: "Claim",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Claim",
                column: "ProjectAgreementId",
                principalSchema: "public",
                principalTable: "ProjectAgreement",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Claim_Contract_ContractId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropForeignKey(
                name: "FK_Claim_Grant_GrantId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropForeignKey(
                name: "FK_Claim_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropIndex(
                name: "IX_Claim_ContractId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropIndex(
                name: "IX_Claim_GrantId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "ContractId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "GrantId",
                schema: "public",
                table: "Claim");

            migrationBuilder.RenameColumn(
                name: "ProjectAgreementId",
                schema: "public",
                table: "Claim",
                newName: "PreClaimLinkedEntitiesId");

            migrationBuilder.RenameIndex(
                name: "IX_Claim_ProjectAgreementId",
                schema: "public",
                table: "Claim",
                newName: "IX_Claim_PreClaimLinkedEntitiesId");

            migrationBuilder.CreateTable(
                name: "PreClaimLinkedEntities",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ContractId = table.Column<int>(type: "integer", nullable: true),
                    GrantId = table.Column<int>(type: "integer", nullable: true),
                    ProjectAgreementId = table.Column<int>(type: "integer", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    DeletedBy = table.Column<string>(type: "text", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreClaimLinkedEntities", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreClaimLinkedEntities_Contract_ContractId",
                        column: x => x.ContractId,
                        principalSchema: "public",
                        principalTable: "Contract",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_PreClaimLinkedEntities_Grant_GrantId",
                        column: x => x.GrantId,
                        principalSchema: "public",
                        principalTable: "Grant",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_PreClaimLinkedEntities_ProjectAgreement_ProjectAgreementId",
                        column: x => x.ProjectAgreementId,
                        principalSchema: "public",
                        principalTable: "ProjectAgreement",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_ContractId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_GrantId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "GrantId");

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_ProjectAgreementId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ProjectAgreementId");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_PreClaimLinkedEntities_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                column: "PreClaimLinkedEntitiesId",
                principalSchema: "public",
                principalTable: "PreClaimLinkedEntities",
                principalColumn: "Id");
        }
    }
}
