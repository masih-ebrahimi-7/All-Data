﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddPriotityOnAllEntities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                schema: "public",
                table: "Payment",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                schema: "public",
                table: "Grant",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProjectAgreementId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Contract_ProjectAgreementId",
                schema: "public",
                table: "Contract",
                column: "ProjectAgreementId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Contract",
                column: "ProjectAgreementId",
                principalSchema: "public",
                principalTable: "ProjectAgreement",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropIndex(
                name: "IX_Contract_ProjectAgreementId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "Priority",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropColumn(
                name: "Priority",
                schema: "public",
                table: "Payment");

            migrationBuilder.DropColumn(
                name: "Priority",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "Priority",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropColumn(
                name: "ProjectAgreementId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");
        }
    }
}
