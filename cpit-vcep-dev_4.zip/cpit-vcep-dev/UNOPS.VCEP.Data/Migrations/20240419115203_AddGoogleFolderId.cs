﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddGoogleFolderId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Grant",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Contract",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Claim",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropColumn(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "GoogleDriveFolderId",
                schema: "public",
                table: "Claim");
        }
    }
}
