﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class LinkGrantsWithAdvanceAccounts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_AdvanceAccount_AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropIndex(
                name: "IX_ProjectAgreement_AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropColumn(
                name: "AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.AddColumn<int>(
                name: "AdvanceAccountId",
                schema: "public",
                table: "Grant",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AdvanceAccountId1",
                schema: "public",
                table: "Grant",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Grant_AdvanceAccountId",
                schema: "public",
                table: "Grant",
                column: "AdvanceAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_Grant_AdvanceAccountId1",
                schema: "public",
                table: "Grant",
                column: "AdvanceAccountId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Grant_AdvanceAccount_AdvanceAccountId",
                schema: "public",
                table: "Grant",
                column: "AdvanceAccountId",
                principalSchema: "public",
                principalTable: "AdvanceAccount",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Grant_AdvanceAccount_AdvanceAccountId1",
                schema: "public",
                table: "Grant",
                column: "AdvanceAccountId1",
                principalSchema: "public",
                principalTable: "AdvanceAccount",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Grant_AdvanceAccount_AdvanceAccountId",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropForeignKey(
                name: "FK_Grant_AdvanceAccount_AdvanceAccountId1",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropIndex(
                name: "IX_Grant_AdvanceAccountId",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropIndex(
                name: "IX_Grant_AdvanceAccountId1",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropColumn(
                name: "AdvanceAccountId",
                schema: "public",
                table: "Grant");

            migrationBuilder.DropColumn(
                name: "AdvanceAccountId1",
                schema: "public",
                table: "Grant");

            migrationBuilder.AddColumn<int>(
                name: "AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAgreement_AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement",
                column: "AdvanceAccountId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_AdvanceAccount_AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement",
                column: "AdvanceAccountId",
                principalSchema: "public",
                principalTable: "AdvanceAccount",
                principalColumn: "Id");
        }
    }
}
