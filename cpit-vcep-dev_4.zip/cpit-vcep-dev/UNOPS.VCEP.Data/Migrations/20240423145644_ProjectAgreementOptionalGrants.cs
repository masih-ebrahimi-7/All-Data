﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class ProjectAgreementOptionalGrants : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_ContractId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_GrantId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "GrantId");

            migrationBuilder.CreateIndex(
                name: "IX_PreClaimLinkedEntities_ProjectAgreementId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ProjectAgreementId");

            migrationBuilder.AddForeignKey(
                name: "FK_PreClaimLinkedEntities_Contract_ContractId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ContractId",
                principalSchema: "public",
                principalTable: "Contract",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_PreClaimLinkedEntities_Grant_GrantId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_PreClaimLinkedEntities_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "PreClaimLinkedEntities",
                column: "ProjectAgreementId",
                principalSchema: "public",
                principalTable: "ProjectAgreement",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PreClaimLinkedEntities_Contract_ContractId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.DropForeignKey(
                name: "FK_PreClaimLinkedEntities_Grant_GrantId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.DropForeignKey(
                name: "FK_PreClaimLinkedEntities_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropIndex(
                name: "IX_PreClaimLinkedEntities_ContractId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.DropIndex(
                name: "IX_PreClaimLinkedEntities_GrantId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.DropIndex(
                name: "IX_PreClaimLinkedEntities_ProjectAgreementId",
                schema: "public",
                table: "PreClaimLinkedEntities");

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
