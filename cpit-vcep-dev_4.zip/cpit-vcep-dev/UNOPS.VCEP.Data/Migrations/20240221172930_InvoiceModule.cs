﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class InvoiceModule : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Invoice_Contract_ContractId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropTable(
                name: "Claims",
                schema: "public");

            migrationBuilder.DropColumn(
                name: "Latitude",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "Longitude",
                schema: "public",
                table: "Claim");

            migrationBuilder.RenameColumn(
                name: "InvoiceNumber",
                schema: "public",
                table: "Invoice",
                newName: "Reference");

            migrationBuilder.RenameColumn(
                name: "GeoLocation",
                schema: "public",
                table: "Claim",
                newName: "Name");

            migrationBuilder.AlterColumn<int>(
                name: "ContractId",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AddColumn<string>(
                name: "AssignedTo",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CurrencyId",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Path",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "Status",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<decimal>(
                name: "Amount",
                schema: "public",
                table: "Claim",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<string>(
                name: "AssignedTo",
                schema: "public",
                table: "Claim",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Description",
                schema: "public",
                table: "Claim",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Status",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Type",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Currency",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Name = table.Column<string>(type: "text", nullable: true),
                    Code = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Currency", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Location",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    GeoLocation = table.Column<string>(type: "text", nullable: false),
                    Latitude = table.Column<double>(type: "double precision", nullable: false),
                    Longitude = table.Column<double>(type: "double precision", nullable: false),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Location", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Remarks",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Description = table.Column<string>(type: "text", nullable: false),
                    Type = table.Column<int>(type: "integer", nullable: false),
                    ParentId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Remarks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Remarks_Invoice_ParentId",
                        column: x => x.ParentId,
                        principalSchema: "public",
                        principalTable: "Invoice",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Invoice_CurrencyId",
                schema: "public",
                table: "Invoice",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_Remarks_ParentId",
                schema: "public",
                table: "Remarks",
                column: "ParentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoice_Contract_ContractId",
                schema: "public",
                table: "Invoice",
                column: "ContractId",
                principalSchema: "public",
                principalTable: "Contract",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice",
                column: "CurrencyId",
                principalSchema: "public",
                principalTable: "Currency",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Invoice_Contract_ContractId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropTable(
                name: "Currency",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Location",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Remarks",
                schema: "public");

            migrationBuilder.DropIndex(
                name: "IX_Invoice_CurrencyId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "AssignedTo",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "CurrencyId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "Path",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "Status",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "Amount",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "AssignedTo",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "Description",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "Priority",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "Status",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "Type",
                schema: "public",
                table: "Claim");

            migrationBuilder.RenameColumn(
                name: "Reference",
                schema: "public",
                table: "Invoice",
                newName: "InvoiceNumber");

            migrationBuilder.RenameColumn(
                name: "Name",
                schema: "public",
                table: "Claim",
                newName: "GeoLocation");

            migrationBuilder.AlterColumn<int>(
                name: "ContractId",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AddColumn<double>(
                name: "Latitude",
                schema: "public",
                table: "Claim",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "Longitude",
                schema: "public",
                table: "Claim",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.CreateTable(
                name: "Claims",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Amount = table.Column<decimal>(type: "numeric", nullable: false),
                    AssignedTo = table.Column<string>(type: "text", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Description = table.Column<string>(type: "text", nullable: true),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    Name = table.Column<string>(type: "text", nullable: false),
                    Priority = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    Type = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Claims", x => x.Id);
                });

            migrationBuilder.AddForeignKey(
                name: "FK_Invoice_Contract_ContractId",
                schema: "public",
                table: "Invoice",
                column: "ContractId",
                principalSchema: "public",
                principalTable: "Contract",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
