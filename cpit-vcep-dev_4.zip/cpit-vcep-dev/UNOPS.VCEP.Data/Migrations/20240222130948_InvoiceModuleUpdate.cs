﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class InvoiceModuleUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Remarks_Invoice_ParentId",
                schema: "public",
                table: "Remarks");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Remarks",
                schema: "public",
                table: "Remarks");

            migrationBuilder.RenameTable(
                name: "Remarks",
                schema: "public",
                newName: "Remark",
                newSchema: "public");

            migrationBuilder.RenameIndex(
                name: "IX_Remarks_ParentId",
                schema: "public",
                table: "Remark",
                newName: "IX_Remark_ParentId");

            migrationBuilder.AddColumn<decimal>(
                name: "AmountUSD",
                schema: "public",
                table: "Invoice",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Remark",
                schema: "public",
                table: "Remark",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Invoice_ParentId",
                schema: "public",
                table: "Remark",
                column: "ParentId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Invoice_ParentId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Remark",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropColumn(
                name: "AmountUSD",
                schema: "public",
                table: "Invoice");

            migrationBuilder.RenameTable(
                name: "Remark",
                schema: "public",
                newName: "Remarks",
                newSchema: "public");

            migrationBuilder.RenameIndex(
                name: "IX_Remark_ParentId",
                schema: "public",
                table: "Remarks",
                newName: "IX_Remarks_ParentId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Remarks",
                schema: "public",
                table: "Remarks",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remarks_Invoice_ParentId",
                schema: "public",
                table: "Remarks",
                column: "ParentId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
