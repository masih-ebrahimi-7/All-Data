﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AdditionalEntities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_ExternalEntity_ContractorId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Grant_GrantId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Contract_ContractorId",
                schema: "public",
                table: "Contract");

            migrationBuilder.RenameColumn(
                name: "GeoLocation",
                schema: "public",
                table: "Location",
                newName: "GeographicalLocation");

            migrationBuilder.RenameColumn(
                name: "GrantNumber",
                schema: "public",
                table: "Grant",
                newName: "Reference");

            migrationBuilder.RenameColumn(
                name: "ContractorId",
                schema: "public",
                table: "Contract",
                newName: "PriorityType");

            migrationBuilder.AlterColumn<int>(
                name: "InvoiceId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<int>(
                name: "ClaimId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AddColumn<int>(
                name: "ProjectAgreementId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "WithdrawalApplicationId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Path",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AlterColumn<int>(
                name: "CurrencyId",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "Amount",
                schema: "public",
                table: "Invoice",
                type: "numeric",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric");

            migrationBuilder.AddColumn<int>(
                name: "AuthorityType",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "TaxPercentage",
                schema: "public",
                table: "Invoice",
                type: "numeric",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<decimal>(
                name: "Amount",
                schema: "public",
                table: "Contract",
                type: "numeric",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric");

            migrationBuilder.AddColumn<decimal>(
                name: "AmountUsd",
                schema: "public",
                table: "Contract",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<int>(
                name: "CurrencyId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ExternalEntityId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "LocationId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PcssNumber",
                schema: "public",
                table: "Contract",
                type: "text",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "AdvanceAccount",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    TotalAmountUsd = table.Column<decimal>(type: "numeric", nullable: false),
                    TotalAmount = table.Column<decimal>(type: "numeric", nullable: false),
                    CurrencyId = table.Column<int>(type: "integer", nullable: true),
                    OfficialUnliquidatedAmount = table.Column<decimal>(type: "numeric", nullable: true),
                    UnofficialUnliquidatedAmount = table.Column<decimal>(type: "numeric", nullable: true),
                    PriorityType = table.Column<int>(type: "integer", nullable: false),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdvanceAccount", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AdvanceAccount_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalSchema: "public",
                        principalTable: "Currency",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Payment",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Amount = table.Column<decimal>(type: "numeric", nullable: true),
                    AmountUsd = table.Column<decimal>(type: "numeric", nullable: false),
                    CurrencyId = table.Column<int>(type: "integer", nullable: false),
                    Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AuthorityType = table.Column<int>(type: "integer", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payment", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Payment_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalSchema: "public",
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WithdrawalApplication",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Reference = table.Column<string>(type: "text", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    Path = table.Column<string>(type: "text", nullable: true),
                    Amount = table.Column<decimal>(type: "numeric", nullable: true),
                    AmountUsd = table.Column<decimal>(type: "numeric", nullable: false),
                    CurrencyId = table.Column<int>(type: "integer", nullable: false),
                    AssignedTo = table.Column<string>(type: "text", nullable: true),
                    Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ContractId = table.Column<int>(type: "integer", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WithdrawalApplication", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WithdrawalApplication_Contract_ContractId",
                        column: x => x.ContractId,
                        principalSchema: "public",
                        principalTable: "Contract",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_WithdrawalApplication_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalSchema: "public",
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProjectAgreement",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Reference = table.Column<string>(type: "text", nullable: false),
                    SignedWith = table.Column<string>(type: "text", nullable: true),
                    AgreementDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AdvanceAccountId = table.Column<int>(type: "integer", nullable: true),
                    GrantId = table.Column<int>(type: "integer", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectAgreement", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProjectAgreement_AdvanceAccount_AdvanceAccountId",
                        column: x => x.AdvanceAccountId,
                        principalSchema: "public",
                        principalTable: "AdvanceAccount",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ProjectAgreement_Grant_GrantId",
                        column: x => x.GrantId,
                        principalSchema: "public",
                        principalTable: "Grant",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Remark_ProjectAgreementId",
                schema: "public",
                table: "Remark",
                column: "ProjectAgreementId");

            migrationBuilder.CreateIndex(
                name: "IX_Remark_WithdrawalApplicationId",
                schema: "public",
                table: "Remark",
                column: "WithdrawalApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_AdvanceAccount_CurrencyId",
                schema: "public",
                table: "AdvanceAccount",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_Payment_CurrencyId",
                schema: "public",
                table: "Payment",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAgreement_AdvanceAccountId",
                schema: "public",
                table: "ProjectAgreement",
                column: "AdvanceAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAgreement_GrantId",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId");

            migrationBuilder.CreateIndex(
                name: "IX_WithdrawalApplication_ContractId",
                schema: "public",
                table: "WithdrawalApplication",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_WithdrawalApplication_CurrencyId",
                schema: "public",
                table: "WithdrawalApplication",
                column: "CurrencyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Grant_GrantId",
                schema: "public",
                table: "Contract",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId",
                principalSchema: "public",
                principalTable: "Location",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice",
                column: "CurrencyId",
                principalSchema: "public",
                principalTable: "Currency",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark",
                column: "ClaimId",
                principalSchema: "public",
                principalTable: "Claim",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark",
                column: "InvoiceId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Remark",
                column: "ProjectAgreementId",
                principalSchema: "public",
                principalTable: "ProjectAgreement",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_WithdrawalApplication_WithdrawalApplicationId",
                schema: "public",
                table: "Remark",
                column: "WithdrawalApplicationId",
                principalSchema: "public",
                principalTable: "WithdrawalApplication",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Grant_GrantId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_ProjectAgreement_ProjectAgreementId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_WithdrawalApplication_WithdrawalApplicationId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropTable(
                name: "Payment",
                schema: "public");

            migrationBuilder.DropTable(
                name: "ProjectAgreement",
                schema: "public");

            migrationBuilder.DropTable(
                name: "WithdrawalApplication",
                schema: "public");

            migrationBuilder.DropTable(
                name: "AdvanceAccount",
                schema: "public");

            migrationBuilder.DropIndex(
                name: "IX_Remark_ProjectAgreementId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Remark_WithdrawalApplicationId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "ProjectAgreementId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropColumn(
                name: "WithdrawalApplicationId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropColumn(
                name: "AuthorityType",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "TaxPercentage",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "AmountUsd",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "CurrencyId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "ExternalEntityId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "PcssNumber",
                schema: "public",
                table: "Contract");

            migrationBuilder.RenameColumn(
                name: "GeographicalLocation",
                schema: "public",
                table: "Location",
                newName: "GeoLocation");

            migrationBuilder.RenameColumn(
                name: "Reference",
                schema: "public",
                table: "Grant",
                newName: "GrantNumber");

            migrationBuilder.RenameColumn(
                name: "PriorityType",
                schema: "public",
                table: "Contract",
                newName: "ContractorId");

            migrationBuilder.AlterColumn<int>(
                name: "InvoiceId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ClaimId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Path",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CurrencyId",
                schema: "public",
                table: "Invoice",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<decimal>(
                name: "Amount",
                schema: "public",
                table: "Invoice",
                type: "numeric",
                nullable: false,
                defaultValue: 0m,
                oldClrType: typeof(decimal),
                oldType: "numeric",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "GrantId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "Amount",
                schema: "public",
                table: "Contract",
                type: "numeric",
                nullable: false,
                defaultValue: 0m,
                oldClrType: typeof(decimal),
                oldType: "numeric",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Contract_ContractorId",
                schema: "public",
                table: "Contract",
                column: "ContractorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_ExternalEntity_ContractorId",
                schema: "public",
                table: "Contract",
                column: "ContractorId",
                principalSchema: "public",
                principalTable: "ExternalEntity",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Grant_GrantId",
                schema: "public",
                table: "Contract",
                column: "GrantId",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Invoice_Currency_CurrencyId",
                schema: "public",
                table: "Invoice",
                column: "CurrencyId",
                principalSchema: "public",
                principalTable: "Currency",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark",
                column: "ClaimId",
                principalSchema: "public",
                principalTable: "Claim",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark",
                column: "InvoiceId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
