﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AdditionalEntitiesRelationshipsUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "ExternalEntityId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.CreateIndex(
                name: "IX_Contract_ExternalEntityId",
                schema: "public",
                table: "Contract",
                column: "ExternalEntityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_ExternalEntity_ExternalEntityId",
                schema: "public",
                table: "Contract",
                column: "ExternalEntityId",
                principalSchema: "public",
                principalTable: "ExternalEntity",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_ExternalEntity_ExternalEntityId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropIndex(
                name: "IX_Contract_ExternalEntityId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AlterColumn<int>(
                name: "ExternalEntityId",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);
        }
    }
}
