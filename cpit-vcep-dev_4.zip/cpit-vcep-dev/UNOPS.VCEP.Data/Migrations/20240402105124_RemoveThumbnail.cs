﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoveThumbnail : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Thumbnail",
                schema: "public",
                table: "Documents");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Thumbnail",
                schema: "public",
                table: "Documents",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}
