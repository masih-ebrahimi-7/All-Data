﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AdditionalEntitiesRelationshipsUpdateII : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AddColumn<string>(
                name: "ExecutingAgency",
                schema: "public",
                table: "Contract",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ImplementingAgency",
                schema: "public",
                table: "Contract",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OutputCategory",
                schema: "public",
                table: "Contract",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<decimal>(
                name: "TotalAmount",
                schema: "public",
                table: "AdvanceAccount",
                type: "numeric",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExecutingAgency",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "ImplementingAgency",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "OutputCategory",
                schema: "public",
                table: "Contract");

            migrationBuilder.AlterColumn<decimal>(
                name: "TotalAmount",
                schema: "public",
                table: "AdvanceAccount",
                type: "numeric",
                nullable: false,
                defaultValue: 0m,
                oldClrType: typeof(decimal),
                oldType: "numeric",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId",
                principalSchema: "public",
                principalTable: "Location",
                principalColumn: "Id");
        }
    }
}
