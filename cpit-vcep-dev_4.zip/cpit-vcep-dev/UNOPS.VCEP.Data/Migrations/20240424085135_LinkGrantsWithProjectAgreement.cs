﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class LinkGrantsWithProjectAgreement : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_AdvanceAccount_AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId1",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropIndex(
                name: "IX_ProjectAgreement_AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropIndex(
                name: "IX_ProjectAgreement_GrantId1",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropColumn(
                name: "AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement");

            migrationBuilder.DropColumn(
                name: "GrantId1",
                schema: "public",
                table: "ProjectAgreement");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GrantId1",
                schema: "public",
                table: "ProjectAgreement",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAgreement_AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement",
                column: "AdvanceAccountId1");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectAgreement_GrantId1",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId1");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_AdvanceAccount_AdvanceAccountId1",
                schema: "public",
                table: "ProjectAgreement",
                column: "AdvanceAccountId1",
                principalSchema: "public",
                principalTable: "AdvanceAccount",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectAgreement_Grant_GrantId1",
                schema: "public",
                table: "ProjectAgreement",
                column: "GrantId1",
                principalSchema: "public",
                principalTable: "Grant",
                principalColumn: "Id");
        }
    }
}
