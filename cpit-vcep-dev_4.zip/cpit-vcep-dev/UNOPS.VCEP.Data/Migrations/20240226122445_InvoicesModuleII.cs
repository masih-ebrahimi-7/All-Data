﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class InvoicesModuleII : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Invoice_ParentId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Remark_ParentId",
                schema: "public",
                table: "Remark");

            migrationBuilder.RenameColumn(
                name: "AmountUSD",
                schema: "public",
                table: "Invoice",
                newName: "AmountUsd");

            migrationBuilder.AddColumn<int>(
                name: "ClaimId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "InvoiceId",
                schema: "public",
                table: "Remark",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<decimal>(
                name: "AmountUsd",
                schema: "public",
                table: "Claim",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<int>(
                name: "CurrencyId",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Remark_ClaimId",
                schema: "public",
                table: "Remark",
                column: "ClaimId");

            migrationBuilder.CreateIndex(
                name: "IX_Remark_InvoiceId",
                schema: "public",
                table: "Remark",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_Claim_CurrencyId",
                schema: "public",
                table: "Claim",
                column: "CurrencyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_Currency_CurrencyId",
                schema: "public",
                table: "Claim",
                column: "CurrencyId",
                principalSchema: "public",
                principalTable: "Currency",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark",
                column: "ClaimId",
                principalSchema: "public",
                principalTable: "Claim",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark",
                column: "InvoiceId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Claim_Currency_CurrencyId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Claim_ClaimId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropForeignKey(
                name: "FK_Remark_Invoice_InvoiceId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Remark_ClaimId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Remark_InvoiceId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropIndex(
                name: "IX_Claim_CurrencyId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "ClaimId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropColumn(
                name: "InvoiceId",
                schema: "public",
                table: "Remark");

            migrationBuilder.DropColumn(
                name: "AmountUsd",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "CurrencyId",
                schema: "public",
                table: "Claim");

            migrationBuilder.RenameColumn(
                name: "AmountUsd",
                schema: "public",
                table: "Invoice",
                newName: "AmountUSD");

            migrationBuilder.CreateIndex(
                name: "IX_Remark_ParentId",
                schema: "public",
                table: "Remark",
                column: "ParentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Remark_Invoice_ParentId",
                schema: "public",
                table: "Remark",
                column: "ParentId",
                principalSchema: "public",
                principalTable: "Invoice",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
