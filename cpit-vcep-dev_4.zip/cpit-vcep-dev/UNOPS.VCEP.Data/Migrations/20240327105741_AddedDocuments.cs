﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddedDocuments : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DeletedBy",
                schema: "public",
                table: "Location",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DeletedOn",
                schema: "public",
                table: "Location",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "public",
                table: "Location",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "DeletedBy",
                schema: "public",
                table: "Invoice",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DeletedOn",
                schema: "public",
                table: "Invoice",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "public",
                table: "Invoice",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "DeletedBy",
                schema: "public",
                table: "Contract",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DeletedOn",
                schema: "public",
                table: "Contract",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "public",
                table: "Contract",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "DeletedBy",
                schema: "public",
                table: "Claim",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DeletedOn",
                schema: "public",
                table: "Claim",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "public",
                table: "Claim",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "Documents",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Name = table.Column<string>(type: "text", nullable: false),
                    Thumbnail = table.Column<string>(type: "text", nullable: false),
                    Url = table.Column<string>(type: "text", nullable: false),
                    GoogleDriveId = table.Column<string>(type: "text", nullable: false),
                    Linked = table.Column<bool>(type: "boolean", nullable: false),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedBy = table.Column<string>(type: "text", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Documents", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DocumentAttachments",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    DocumentId = table.Column<int>(type: "integer", nullable: false),
                    GrantId = table.Column<int>(type: "integer", nullable: true),
                    InvoiceId = table.Column<int>(type: "integer", nullable: true),
                    ClaimId = table.Column<int>(type: "integer", nullable: true),
                    ContractId = table.Column<int>(type: "integer", nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedBy = table.Column<string>(type: "text", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentAttachments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Claim_ClaimId",
                        column: x => x.ClaimId,
                        principalSchema: "public",
                        principalTable: "Claim",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Contract_ContractId",
                        column: x => x.ContractId,
                        principalSchema: "public",
                        principalTable: "Contract",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Documents_DocumentId",
                        column: x => x.DocumentId,
                        principalSchema: "public",
                        principalTable: "Documents",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Grant_GrantId",
                        column: x => x.GrantId,
                        principalSchema: "public",
                        principalTable: "Grant",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DocumentAttachments_Invoice_InvoiceId",
                        column: x => x.InvoiceId,
                        principalSchema: "public",
                        principalTable: "Invoice",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DocumentAttachments_ClaimId",
                schema: "public",
                table: "DocumentAttachments",
                column: "ClaimId");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentAttachments_ContractId",
                schema: "public",
                table: "DocumentAttachments",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentAttachments_DocumentId",
                schema: "public",
                table: "DocumentAttachments",
                column: "DocumentId");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentAttachments_GrantId",
                schema: "public",
                table: "DocumentAttachments",
                column: "GrantId");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentAttachments_InvoiceId",
                schema: "public",
                table: "DocumentAttachments",
                column: "InvoiceId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DocumentAttachments",
                schema: "public");

            migrationBuilder.DropTable(
                name: "Documents",
                schema: "public");

            migrationBuilder.DropColumn(
                name: "DeletedBy",
                schema: "public",
                table: "Location");

            migrationBuilder.DropColumn(
                name: "DeletedOn",
                schema: "public",
                table: "Location");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "public",
                table: "Location");

            migrationBuilder.DropColumn(
                name: "DeletedBy",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "DeletedOn",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "public",
                table: "Invoice");

            migrationBuilder.DropColumn(
                name: "DeletedBy",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "DeletedOn",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropColumn(
                name: "DeletedBy",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "DeletedOn",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "public",
                table: "Claim");
        }
    }
}
