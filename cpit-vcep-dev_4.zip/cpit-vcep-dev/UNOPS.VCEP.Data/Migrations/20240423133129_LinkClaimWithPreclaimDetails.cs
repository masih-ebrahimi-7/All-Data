﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class LinkClaimWithPreclaimDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Claim_ClaimId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropIndex(
                name: "IX_Contract_ClaimId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AddColumn<int>(
                name: "PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "PreClaimLinkedEntities",
                schema: "public",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    GrantId = table.Column<int>(type: "integer", nullable: true),
                    ProjectAgreementId = table.Column<int>(type: "integer", nullable: true),
                    ContractId = table.Column<int>(type: "integer", nullable: true),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedBy = table.Column<string>(type: "text", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedBy = table.Column<string>(type: "text", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LastModifiedBy = table.Column<string>(type: "text", nullable: true),
                    LastModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreClaimLinkedEntities", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Claim_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                column: "PreClaimLinkedEntitiesId");

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_PreClaimLinkedEntities_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim",
                column: "PreClaimLinkedEntitiesId",
                principalSchema: "public",
                principalTable: "PreClaimLinkedEntities",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Claim_PreClaimLinkedEntities_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropTable(
                name: "PreClaimLinkedEntities",
                schema: "public");

            migrationBuilder.DropIndex(
                name: "IX_Claim_PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "PreClaimLinkedEntitiesId",
                schema: "public",
                table: "Claim");

            migrationBuilder.CreateIndex(
                name: "IX_Contract_ClaimId",
                schema: "public",
                table: "Contract",
                column: "ClaimId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Claim_ClaimId",
                schema: "public",
                table: "Contract",
                column: "ClaimId",
                principalSchema: "public",
                principalTable: "Claim",
                principalColumn: "Id");
        }
    }
}
