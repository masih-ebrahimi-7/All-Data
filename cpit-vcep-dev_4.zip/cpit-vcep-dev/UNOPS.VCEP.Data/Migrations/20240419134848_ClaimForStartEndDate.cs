﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class ClaimForStartEndDate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClaimDate",
                schema: "public",
                table: "Claim");

            migrationBuilder.AddColumn<DateTime>(
                name: "ClaimForEndDate",
                schema: "public",
                table: "Claim",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ClaimForStartDate",
                schema: "public",
                table: "Claim",
                type: "timestamp with time zone",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClaimForEndDate",
                schema: "public",
                table: "Claim");

            migrationBuilder.DropColumn(
                name: "ClaimForStartDate",
                schema: "public",
                table: "Claim");

            migrationBuilder.AddColumn<DateTime>(
                name: "ClaimDate",
                schema: "public",
                table: "Claim",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
