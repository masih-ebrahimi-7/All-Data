﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddContractToClaimI : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Claim_Contract_Id",
                schema: "public",
                table: "Claim");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.CreateIndex(
                name: "IX_Contract_ClaimId",
                schema: "public",
                table: "Contract",
                column: "ClaimId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Claim_ClaimId",
                schema: "public",
                table: "Contract",
                column: "ClaimId",
                principalSchema: "public",
                principalTable: "Claim",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Claim_ClaimId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropIndex(
                name: "IX_Contract_ClaimId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                schema: "public",
                table: "Claim",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddForeignKey(
                name: "FK_Claim_Contract_Id",
                schema: "public",
                table: "Claim",
                column: "Id",
                principalSchema: "public",
                principalTable: "Contract",
                principalColumn: "Id");
        }
    }
}
