﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UNOPS.VCEP.Data.Migrations
{
    /// <inheritdoc />
    public partial class LocationForContractsUpdates : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<double>(
                name: "Longitude",
                schema: "public",
                table: "Location",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.AlterColumn<double>(
                name: "Latitude",
                schema: "public",
                table: "Location",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.CreateIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract",
                column: "LocationId",
                principalSchema: "public",
                principalTable: "Location",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contract_Location_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.DropIndex(
                name: "IX_Contract_LocationId",
                schema: "public",
                table: "Contract");

            migrationBuilder.AlterColumn<double>(
                name: "Longitude",
                schema: "public",
                table: "Location",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "Latitude",
                schema: "public",
                table: "Location",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);
        }
    }
}
