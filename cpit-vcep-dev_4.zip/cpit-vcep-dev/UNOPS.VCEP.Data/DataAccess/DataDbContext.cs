using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess.Mapping;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Infrastructure.DataAccess;
using UNOPS.VCEP.Infrastructure.DataAccess.Mapping;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Domain.Audit;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Managers;
using Z.EntityFramework.Plus;

namespace UNOPS.VCEP.Data.DataAccess;

public class DataDbContext : BaseDbContext
{
    public DataDbContext(DbContextOptions<DataDbContext> connection, UserResolverService userService,
        IDbContextSchema schema)
        : base(connection, userService, schema)
    {
    }
    public DbSet<Claim> Claims { get; set; }
    public DbSet<ClaimDetailsToValidate> ClaimDetailsToValidate { get; set; }
    public DbSet<Contract> Contracts { get; set; }
    public DbSet<Grant> Grants { get; set; }
    public DbSet<Invoice> Invoices { get; set; }
    public DbSet<Location> Locations { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<ClaimContractingAuthority> ClaimContractingAuthorities { get; set; }
    public DbSet<Remark> Remarks { get; set; }
    public DbSet<WithdrawalApplication> WithdrawalApplications { get; set; }
    public DbSet<Document> Documents { get; set; }
    public DbSet<DocumentAttachment> DocumentAttachments { get; set; }
    public DbSet<DocumentCategory> DocumentCategories { get; set; }
    public DbSet<WorkflowStep> WorkflowSteps { get; set; }
    public DbSet<AuditLog> DataAuditLogs { get; set; }
    public DbSet<AuditEntryProperty> DataAuditProperties { get; set; }
    // output 2
    public DbSet<AdvanceAccount> AdvanceAccounts { get; set; }
    public DbSet<Expense> Expenses { get; set; }
    public DbSet<Salary> Salaries { get; set; }
    public DbSet<Staff> Staff { get; set; }
    public DbSet<StaffContract> StaffContracts { get; set; }
    public DbSet<ProjectAgreement> ProjectAgreements { get; set; }
    public DbSet<ClaimStage> ClaimStages { get; set; }
    public DbSet<ClaimStageHistory> ClaimStageHistories { get; set; }
    public DbSet<SubClaim> SubClaims { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.HasDefaultSchema("public");
        modelBuilder.ApplyConfiguration(new AdvanceAccountMap());
        modelBuilder.ApplyConfiguration(new ClaimMap());
        modelBuilder.ApplyConfiguration(new ContractMap());
        modelBuilder.ApplyConfiguration(new ExpenseMap());
        modelBuilder.ApplyConfiguration(new SalaryMap());
        modelBuilder.ApplyConfiguration(new StaffMap());
        modelBuilder.ApplyConfiguration(new StaffContractMap());
        modelBuilder.ApplyConfiguration(new DocumentMap());
        modelBuilder.ApplyConfiguration(new DocumentCategoryMap());
        modelBuilder.ApplyConfiguration(new ExternalEntityMap());
        modelBuilder.ApplyConfiguration(new ExternalEntityUsersMap());
        modelBuilder.ApplyConfiguration(new GrantMap());
        modelBuilder.ApplyConfiguration(new InvoiceMap());
        modelBuilder.ApplyConfiguration(new LocationMap());
        modelBuilder.ApplyConfiguration(new ClaimContractingAuthorityMap());
        modelBuilder.ApplyConfiguration(new PaymentMap());
        modelBuilder.ApplyConfiguration(new ProjectAgreementMap());
        modelBuilder.ApplyConfiguration(new RemarkMap());
        modelBuilder.ApplyConfiguration(new WithdrawalApplicationMap());
        modelBuilder.ApplyConfiguration(new ClaimStageMap());
        modelBuilder.ApplyConfiguration(new ClaimStageHistoryMap());
        modelBuilder.ApplyConfiguration(new SubClaimMap());

        // Audit 
        modelBuilder.Ignore<AuditEntry>();
        modelBuilder.ApplyConfiguration(new AuditPropertyMap("DataAuditProperty"));
        modelBuilder.ApplyConfiguration(new AuditLogMap("DataAuditLog"));

        modelBuilder.Entity<ExternalEntity>().Metadata.SetIsTableExcludedFromMigrations(true);
        modelBuilder.Entity<ExternalEntityUser>().Metadata.SetIsTableExcludedFromMigrations(true);
    }

    public override int SaveChanges()
    {
        var audit = DataAuditLogs.InitializeAudit(UserEmail);
        audit.PreSaveChanges(this);
        var result = base.SaveChanges();
        audit.PostSaveChanges();

        if (audit.Configuration.AutoSavePreAction != null)
        {
            audit.Configuration.AutoSavePreAction(this, audit);
            base.SaveChanges();
        }

        return result;
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new())
    {
        var audit = DataAuditLogs.InitializeAudit(UserEmail);

        audit.PreSaveChanges(this);
        var result = await base.SaveChangesAsync(cancellationToken);
        audit.PostSaveChanges();

        if (audit.Configuration.AutoSavePreAction != null)
        {
            audit.Configuration.AutoSavePreAction(this, audit);
            await base.SaveChangesAsync(cancellationToken);
        }

        return result;
    }
}