using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping
{
    public class SubClaimMap : IEntityTypeConfiguration<SubClaim>
    {
        public void Configure(EntityTypeBuilder<SubClaim> builder)
        {
            builder.ToTable("SubClaims");
            
            builder.HasKey(x => x.Id);
            builder.Property(x => x.ReferenceCode);
            builder.HasIndex(x => x.ReferenceCode);
            builder.HasIndex(x => new { x.ClaimId, x.SubSeqNo });
            builder.Property(x => x.InvoiceIpcNumber);
            builder.Property(x => x.InvoiceIpcDescription);
            builder.Property(x => x.CurrencyId);
            builder.Property(x => x.Remarks);
            builder.Property(x => x.ClaimAmount);
            builder.Property(x => x.ClaimAmountUsd);
            builder.Property(x => x.VerifiedAmount);
            builder.Property(x => x.VerifiedAmountUsd);
                
            builder.HasOne(x => x.Claim)
                .WithMany(x => x.SubClaims)
                .HasForeignKey(x => x.ClaimId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}