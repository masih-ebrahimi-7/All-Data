using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ProjectAgreementMap : IEntityTypeConfiguration<ProjectAgreement>
{
    public void Configure(EntityTypeBuilder<ProjectAgreement> builder)
    {
        builder.ToTable("ProjectAgreement");
        builder.HasKey(t => t.Id);
        builder.Property(t => t.Priority).HasDefaultValue(PriorityType.Fourth);

        builder.HasMany(t => t.Contracts)
            .WithOne(t => t.ProjectAgreement)
            .HasForeignKey(t => t.ProjectAgreementId);

        builder.HasOne(m => m.Grant)
            .WithMany(a => a.ProjectAgreements)
            .HasForeignKey(c => c.GrantId);
        
    }
}