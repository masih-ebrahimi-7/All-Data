using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class DocumentMap : IEntityTypeConfiguration<Document>
{
    public void Configure(EntityTypeBuilder<Document> builder)
    {
        builder.ToTable("Documents");
        builder.HasKey(r => r.Id);
    }
}