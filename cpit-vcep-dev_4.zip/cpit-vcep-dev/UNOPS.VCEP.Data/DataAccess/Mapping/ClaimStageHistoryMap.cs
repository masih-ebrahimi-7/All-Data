using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ClaimStageHistoryMap : IEntityTypeConfiguration<ClaimStageHistory>
{
    public void Configure(EntityTypeBuilder<ClaimStageHistory> builder)
    {
        builder.ToTable("ClaimStageHistory");
        builder.HasKey(t => t.Id);

        builder.Property(t => t.Notes);

        builder.Property(t => t.MovedByUserName);

        builder.HasOne(t => t.Claim)
            .WithMany(c => c.StageHistories)
            .HasForeignKey(t => t.ClaimId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(t => t.ClaimStage)
            .WithMany(s => s.ClaimStageHistories)
            .HasForeignKey(t => t.ClaimStageId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(t => t.ClaimId);
        builder.HasIndex(t => t.ClaimStageId);
        builder.HasIndex(t => t.IsCurrentStage);
        builder.HasIndex(t => new { t.ClaimId, t.IsCurrentStage });
    }
}
