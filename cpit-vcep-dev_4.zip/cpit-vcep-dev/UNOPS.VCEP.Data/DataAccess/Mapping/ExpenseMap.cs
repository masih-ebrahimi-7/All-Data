using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Infrastructure.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ExpenseMap : IEntityTypeConfiguration<Expense>
{
    public void Configure(EntityTypeBuilder<Expense> builder)
    {
        builder.ToTable("Expense");
        builder.HasKey(t => t.Id);

        builder.HasOne(t => t.Contractor)
            .WithMany()
            .HasForeignKey(t => t.ExternalEntityId);
    }
}