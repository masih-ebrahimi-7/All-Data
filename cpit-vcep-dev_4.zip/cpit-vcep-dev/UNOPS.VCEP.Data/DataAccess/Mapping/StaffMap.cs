using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class StaffMap : IEntityTypeConfiguration<Staff>
{
    public void Configure(EntityTypeBuilder<Staff> builder)
    {
        builder.ToTable("Staff");
        builder.HasKey(t => t.Id);
    }
}