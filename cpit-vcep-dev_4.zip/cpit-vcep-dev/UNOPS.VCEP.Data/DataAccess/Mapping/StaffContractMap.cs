using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class StaffContractMap : IEntityTypeConfiguration<StaffContract>
{
    public void Configure(EntityTypeBuilder<StaffContract> builder)
    {
        builder.ToTable("StaffContract");
        builder.HasKey(t => t.Id);
    }
}