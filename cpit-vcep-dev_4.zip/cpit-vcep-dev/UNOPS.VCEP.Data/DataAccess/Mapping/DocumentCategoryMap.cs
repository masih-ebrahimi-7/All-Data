using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class DocumentCategoryMap : IEntityTypeConfiguration<DocumentCategory>
{
    public void Configure(EntityTypeBuilder<DocumentCategory> builder)
    {
        builder.ToTable("DocumentCategory");
        builder.HasKey(r => r.Id);
        
        builder.HasMany(e => e.Documents)
            .WithOne(e => e.DocumentCategory)
            .HasForeignKey(e => e.DocumentCategoryId)
            .IsRequired(false);
    }
}