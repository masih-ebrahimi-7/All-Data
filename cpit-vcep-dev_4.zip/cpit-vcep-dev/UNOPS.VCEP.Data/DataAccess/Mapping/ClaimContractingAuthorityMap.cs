using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ClaimContractingAuthorityMap : IEntityTypeConfiguration<ClaimContractingAuthority>
{
    public void Configure(EntityTypeBuilder<ClaimContractingAuthority> builder)
    {
        builder.ToTable("ClaimContractingAuthority");
        builder.HasKey(t => t.Id);
    }
}