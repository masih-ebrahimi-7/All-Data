using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class LocationMap : IEntityTypeConfiguration<Location>
{
    public void Configure(EntityTypeBuilder<Location> builder)
    {
        builder.ToTable("Location");
        builder.HasKey(t => t.Id);
    }
}