using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class GrantMap : IEntityTypeConfiguration<Grant>
{
    public void Configure(EntityTypeBuilder<Grant> builder)
    {
        builder.ToTable("Grant");
        builder.HasKey(t => t.Id);
        
        builder.HasMany(e => e.Contracts)
            .WithMany(e => e.Grants)
            .UsingEntity<GrantContract>(
                l => l.HasOne<Contract>().WithMany().HasForeignKey(e => e.ContractId),
                r => r.HasOne<Grant>().WithMany().HasForeignKey(e => e.GrantId));


        builder.HasMany(e => e.Expenses)
            .WithMany(e => e.Grants)
            .UsingEntity<GrantExpense>(
                l => l.HasOne<Expense>().WithMany().HasForeignKey(e => e.ExpenseId),
                r => r.HasOne<Grant>().WithMany().HasForeignKey(e => e.GrantId));
    }
}