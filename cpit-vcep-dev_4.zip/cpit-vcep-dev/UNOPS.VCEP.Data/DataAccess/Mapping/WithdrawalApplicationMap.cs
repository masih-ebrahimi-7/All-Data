using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class WithdrawalApplicationMap : IEntityTypeConfiguration<WithdrawalApplication>
{
    public void Configure(EntityTypeBuilder<WithdrawalApplication> builder)
    {
        builder.ToTable("WithdrawalApplication");
        builder.HasKey(t => t.Id);
    }
}