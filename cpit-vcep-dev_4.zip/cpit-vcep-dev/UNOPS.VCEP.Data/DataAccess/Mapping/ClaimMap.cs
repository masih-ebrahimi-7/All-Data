using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ClaimMap : IEntityTypeConfiguration<Claim>
{
    public void Configure(EntityTypeBuilder<Claim> builder)
    {
        builder.ToTable("Claim");
        builder.HasKey(t => t.Id);
        builder.Property(a => a.Source).HasDefaultValue(ClaimSource.Unknown);

        builder.HasOne(m => m.Contract)
            .WithMany()
            .HasForeignKey(c => c.ContractId);

        builder.HasOne(m => m.Grant)
            .WithMany()
            .HasForeignKey(c => c.GrantId);

        builder.HasOne(m => m.ProjectAgreement)
            .WithMany()
            .HasForeignKey(c => c.ProjectAgreementId);

        builder.HasOne(m => m.ClaimDetailsToValidate)
            .WithOne(a => a.Claim)
            .HasForeignKey<ClaimDetailsToValidate>(c => c.ClaimId)
            .IsRequired(false);

        builder.HasMany(t => t.Remarks)
            .WithOne(a => a.Claim)
            .HasForeignKey(r => r.EntityId)
            .IsRequired(false);

        builder.HasMany(e => e.Locations)
            .WithOne(e => e.Claim)
            .HasForeignKey(e => e.ClaimId)
            .IsRequired(false);
        
        builder.HasMany(e => e.ContractingAuthorities)
            .WithOne(e => e.Claim)
            .HasForeignKey(e => e.ClaimId)
            .IsRequired(false);
        
        builder.HasOne(m => m.LinkedClaimantUser)
            .WithMany()
            .HasForeignKey(c => c.LinkedClaimantUserId)
            .IsRequired(false);
            
        builder.HasMany(t => t.StageHistories)
            .WithOne(a => a.Claim)
            .HasForeignKey(r => r.ClaimId)
            .IsRequired(true);
            
        builder.HasMany(t => t.SubClaims)
            .WithOne(a => a.Claim)
            .HasForeignKey(r => r.ClaimId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}