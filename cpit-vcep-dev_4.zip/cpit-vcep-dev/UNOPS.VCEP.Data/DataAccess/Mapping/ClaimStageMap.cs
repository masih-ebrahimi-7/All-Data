using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ClaimStageMap : IEntityTypeConfiguration<ClaimStage>
{
    public void Configure(EntityTypeBuilder<ClaimStage> builder)
    {
        builder.ToTable("ClaimStage");
        builder.HasKey(t => t.Id);

        builder.Property(t => t.Name)
            .IsRequired();

        builder.Property(t => t.Description);
            
        builder.Property(t => t.WeightPercentage)
            .HasPrecision(5, 2);

        builder.Property(t => t.EstimatedDeliveryTimeline);

        builder.HasOne(t => t.ParentStage)
            .WithMany(t => t.Children)
            .HasForeignKey(t => t.ParentStageId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(t => t.SortOrder);
        builder.HasIndex(t => t.ParentStageId);
        builder.HasIndex(t => t.IsActive);
    }
}
