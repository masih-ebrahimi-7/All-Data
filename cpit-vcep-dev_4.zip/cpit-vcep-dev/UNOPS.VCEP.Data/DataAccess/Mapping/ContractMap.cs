using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Infrastructure.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class ContractMap : IEntityTypeConfiguration<Contract>
{
    public void Configure(EntityTypeBuilder<Contract> builder)
    {
        builder.ToTable("Contract");
        builder.HasKey(t => t.Id);

        builder.HasOne(t => t.Location)
            .WithMany()
            .HasForeignKey(t => t.LocationId);
        
        builder.HasOne(t => t.Contractor)
            .WithMany()
            .HasForeignKey(t => t.ExternalEntityId);
    }
}