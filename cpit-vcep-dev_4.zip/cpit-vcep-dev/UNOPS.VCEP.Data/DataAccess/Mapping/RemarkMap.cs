using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class RemarkMap : IEntityTypeConfiguration<Remark>
{
    public void Configure(EntityTypeBuilder<Remark> builder)
    {
        builder.ToTable("Remark");
        builder.HasKey(r => r.Id);

        builder.Property(a => a.ParentId).HasDefaultValue(null);

        builder.HasOne(r => r.Parent)
            .WithMany(r => r.Replies)
            .HasForeignKey(r => r.ParentId)
            .IsRequired(false);
    }
}