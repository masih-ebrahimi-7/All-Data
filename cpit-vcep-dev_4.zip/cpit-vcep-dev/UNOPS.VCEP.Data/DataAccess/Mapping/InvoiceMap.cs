using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class InvoiceMap : IEntityTypeConfiguration<Invoice>
{
    public void Configure(EntityTypeBuilder<Invoice> builder)
    {
        builder.ToTable("Invoice");
        builder.HasKey(t => t.Id);

        builder.HasOne(t => t.Contract)
            .WithMany(t => t.Invoices)
            .HasForeignKey(t => t.ContractId);
    }
}