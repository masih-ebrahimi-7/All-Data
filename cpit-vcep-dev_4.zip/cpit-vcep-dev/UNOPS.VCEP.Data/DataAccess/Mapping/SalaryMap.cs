using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.DataAccess.Mapping;

internal class SalaryMap : IEntityTypeConfiguration<Salary>
{
    public void Configure(EntityTypeBuilder<Salary> builder)
    {
        builder.ToTable("Salary");
        builder.HasKey(t => t.Id);
        
        builder.HasOne(t => t.Staff)
            .WithMany()
            .HasForeignKey(t => t.StaffId);
        
        builder.HasOne(t => t.StaffContract)
            .WithMany()
            .HasForeignKey(t => t.StaffContractId);

        builder.HasOne(t => t.Grant)
            .WithMany()
            .HasForeignKey(t => t.GrantId);
    }
}