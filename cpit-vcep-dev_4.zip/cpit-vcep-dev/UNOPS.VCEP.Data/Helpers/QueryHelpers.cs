using UNOPS.VCEP.Data.Domain;

namespace UNOPS.VCEP.Data.Helpers;

public static class QueryHelpers
{
    public static IQueryable<DocumentAttachment> GetDocumentsCreatedByUser(this IQueryable<DocumentAttachment> documents,
        string? userEmail)
    {
        if (userEmail == null) return documents;

        if (!string.IsNullOrEmpty(userEmail))
            documents = documents.Where(a => a.CreatedBy.ToLower().Contains(userEmail.ToLower().Trim()));

        return documents;
    }
    
    public static IQueryable<DocumentAttachment> GetDocumentsCreatedByUsers(this IQueryable<DocumentAttachment> documents,
        List<string?>? userEmails)
    {
        if (userEmails is { Count: > 0 })
            return documents.Where(a => userEmails.Contains(a.CreatedBy));
        return documents;
    }

}

