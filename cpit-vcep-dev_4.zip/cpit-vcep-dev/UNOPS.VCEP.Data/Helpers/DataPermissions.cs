using UNOPS.VCEP.Infrastructure.Security;
using UsersManager.Security;

namespace UNOPS.VCEP.Data.Helpers;

public class DataPermissions : BasePermissions
{
    public static readonly SystemAction CanAccessAsClaimant = new(nameof(CanAccessAsClaimant),
        ExternalRole.Claimant);

    public static readonly SystemAction CanAccessAsDonor = new(nameof(CanAccessAsDonor),
        ExternalRole.Donor);

    public static readonly SystemAction CanAccessAsMoF = new(nameof(CanAccessAsMoF),
        ExternalRole.MoF);

    public static readonly SystemAction CanAccessAsMPW = new(nameof(CanAccessAsMPW),
        ExternalRole.MPW);

    public static readonly SystemAction CanAccessAsMoPH = new(nameof(CanAccessAsMoPH),
        ExternalRole.MoPH);

    public static readonly SystemAction CanAccessAsMRRD = new(nameof(CanAccessAsMRRD),
        ExternalRole.MRRD);

    public static readonly SystemAction CanAccessAsMAIL = new(nameof(CanAccessAsMAIL),
        ExternalRole.MAIL);

    public static readonly SystemAction CanAccessAsDABS = new(nameof(CanAccessAsDABS),
        ExternalRole.DABS);

    public static readonly SystemAction CanAccessAsMEW = new(nameof(CanAccessAsMEW),
        ExternalRole.MEW);
    
    public static readonly SystemAction CanAccessAsMinistry = new(nameof(CanAccessAsMinistry),
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW);
        
    public static readonly SystemAction CanSubmitClaims = new(nameof(CanSubmitClaims),
        BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer,
        ExternalRole.Claimant);

    public static readonly SystemAction CanReviewClaims = new(nameof(CanReviewClaims), BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanLinkClaimToExternal = new(nameof(CanLinkClaimToExternal), BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanAssignClaims = new(nameof(CanAssignClaims), BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanViewDataMap = new(nameof(CanViewDataMap),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.InternalViewer, 
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.FinanceSpecialist, BaseRole.CmsTeam,
        ExternalRole.Donor);

    public static readonly SystemAction CanViewDashboard = new(nameof(CanViewDashboard),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.InternalViewer,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.FinanceSpecialist, BaseRole.CmsTeam,
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW, 
        ExternalRole.Donor);

    public static readonly SystemAction CanViewTasks = new(nameof(CanViewTasks),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.FinanceSpecialist, BaseRole.CmsTeam,
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW, 
        ExternalRole.Donor, ExternalRole.Claimant);

    public static readonly SystemAction CanViewTasksCreatedByMe = new(nameof(CanViewTasksCreatedByMe),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewGrants = new(nameof(CanViewGrants),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.FinanceSpecialist, BaseRole.CmsTeam,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewAdvanceAccounts = new(nameof(CanViewAdvanceAccounts),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead,
        ExternalRole.Donor);

    public static readonly SystemAction CanViewSalaries = new(nameof(CanViewSalaries),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead,
        ExternalRole.Donor);

    public static readonly SystemAction CanViewProjectAgreements = new(nameof(CanViewProjectAgreements),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewContracts = new(nameof(CanViewContracts),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.SafeGuard, BaseRole.CmsTeam);

    public static readonly SystemAction CanViewInvoices = new(nameof(CanViewInvoices),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewWithdrawalApplications = new(nameof(CanViewWithdrawalApplications),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewExpenses = new(nameof(CanViewExpenses),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead,
        ExternalRole.Donor);

    public static readonly SystemAction CanManageGrants = new(nameof(CanManageGrants),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanManageContracts = new(nameof(CanManageContracts),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.CmsTeam);

    public static readonly SystemAction CanManageCurrencyRates = new(nameof(CanManageCurrencyRates),
        BaseRole.SystemAdmin, BaseRole.ProjectManager);

    public static readonly SystemAction CanManageUsers = new(nameof(CanManageUsers),
        BaseRole.SystemAdmin, BaseRole.ProjectManager);

    public static readonly SystemAction CanManageExternalUsers = new(nameof(CanManageExternalUsers),
        BaseRole.SystemAdmin, BaseRole.ProjectManager);

    public static readonly SystemAction CanManageDocumentCategories = new(nameof(CanManageDocumentCategories),
        BaseRole.SystemAdmin, BaseRole.ProjectManager);

    public static readonly SystemAction CanManageExpenses = new(nameof(CanManageExpenses),
        BaseRole.ProjectManager, BaseRole.FinancialLead);

    public static readonly SystemAction CanManageAdvanceAccounts = new(nameof(CanManageAdvanceAccounts),
        BaseRole.ProjectManager, BaseRole.FinancialLead);

    public static readonly SystemAction CanManageSalaries = new(nameof(CanManageSalaries),
        BaseRole.ProjectManager, BaseRole.FinancialLead);

    public static readonly SystemAction CanAccessErrorLogs = new(nameof(CanAccessErrorLogs),
        BaseRole.SystemAdmin);

    public static readonly SystemAction CanViewAllClaims = new(nameof(CanViewAllClaims),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.CmsTeam,
        ExternalRole.Donor);

    public static readonly SystemAction CanViewLimitedClaims = new(nameof(CanViewLimitedClaims),
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager,
        BaseRole.CaseOfficer, ExternalRole.Donor);

    public static readonly SystemAction CanBeAssignedToClaims = new(nameof(CanBeAssignedToClaims),
        BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.CmsTeam);

    public static readonly SystemAction CanViewClaimDetails = new(nameof(CanViewClaimDetails),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanViewLimitedClaimDetails = new(nameof(CanViewLimitedClaimDetails),
        ExternalRole.Donor, ExternalRole.Claimant);

    public static readonly SystemAction CanViewClaimsClearance = new(nameof(CanViewClaimsClearance),
        BaseRole.ContractMgtSpecialist, 
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead
    );
    
    public static readonly SystemAction CanManageClaimsClearance = new(nameof(CanManageClaimsClearance),
        BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanEditClaimDetails = new(nameof(CanEditClaimDetails),
        BaseRole.ProjectManager, BaseRole.ContractMgtSpecialist,
        BaseRole.FinancialLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead);

    public static readonly SystemAction CanChangeClaimStatus = new(nameof(CanChangeClaimStatus),
        BaseRole.ContractMgtSpecialist,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead);

    public static readonly SystemAction CanEditClaimAmounts = new(nameof(CanEditClaimAmounts),
        BaseRole.ContractMgtSpecialist,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead);

    public static readonly SystemAction CanFlagFraudulentClaims = new(nameof(CanFlagFraudulentClaims),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.CmsTeam);

    public static readonly SystemAction CanAddDocumentsToClaims = new(nameof(CanAddDocumentsToClaims),
        BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam,
        ExternalRole.Claimant, ExternalRole.Donor, 
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW
    );
    
    

    public static readonly SystemAction CanAddDriveDocumentsToClaims = new(nameof(CanAddDriveDocumentsToClaims),
        BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam
    );

    public static readonly SystemAction CanArchiveDocuments = new(nameof(CanArchiveDocuments),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead, BaseRole.CmsTeam);

    public static readonly SystemAction CanAccessCollaboration = new(nameof(CanAccessCollaboration),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam,
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW, 
        ExternalRole.Donor, ExternalRole.Claimant);

    public static readonly SystemAction CanAddRemarks = new(nameof(CanAddRemarks),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam,
        BaseRole.CaseOfficer);
    
    public static readonly SystemAction CanManageExternalRemarks = new(nameof(CanManageExternalRemarks),
        BaseRole.ContractMgtSpecialist, BaseRole.ProjectManager, BaseRole.FinancialLead);

    public static readonly SystemAction CanBeAssignedTasks = new(nameof(CanBeAssignedTasks),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam, BaseRole.CaseOfficer);

    public static readonly SystemAction CanReplyToRemarks = new(nameof(CanReplyToRemarks),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam,
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW, 
        ExternalRole.Donor, ExternalRole.Claimant);

    public static readonly SystemAction CanAssignTasksToInternalUsers = new(nameof(CanAssignTasksToInternalUsers),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager, BaseRole.CmsTeam, BaseRole.CaseOfficer);

    public static readonly SystemAction CanAssignTasksToMinistriesAndDonor = new(nameof(CanAssignTasksToMinistriesAndDonor),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist);
        
    public static readonly SystemAction CanAssignTasksToClaimant = new(nameof(CanAssignTasksToClaimant),
        BaseRole.ProjectManager, BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanUpdateLocationsOnClaimMap = new(nameof(CanUpdateLocationsOnClaimMap),
        BaseRole.ContractMgtSpecialist,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead);

    public static readonly SystemAction CanManageClaimStages = new(nameof(CanManageClaimStages),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.ContractMgtSpecialist);

    public static readonly SystemAction CanAccessClaimReport = new(nameof(CanAccessClaimReport),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanEditClaimReport = new(nameof(CanEditClaimReport),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer);

    public static readonly SystemAction CanManageClaimCertificate = new(nameof(CanManageClaimCertificate),
        BaseRole.ProjectManager);

    public static readonly SystemAction CanAccessAudit = new(nameof(CanAccessAudit),
        BaseRole.SystemAdmin, BaseRole.ProjectManager);

    public static readonly SystemAction CanAccessHelp = new(nameof(CanAccessHelp),
        BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.CaseOfficer, BaseRole.InternalViewer, BaseRole.SafeGuard, BaseRole.DataManager,
        ExternalRole.MoF, ExternalRole.MPW, ExternalRole.MoPH, ExternalRole.MRRD, ExternalRole.MAIL, ExternalRole.DABS, ExternalRole.MEW, 
        ExternalRole.Donor);

    public static readonly SystemAction CanAccessExternalHelp = new(nameof(CanAccessExternalHelp),
        ExternalRole.Claimant);

    public static readonly SystemAction CanAccessUserGuideAsMoF = new(nameof(CanAccessUserGuideAsMoF),
        ExternalRole.MoF);

    public static readonly SystemAction CanAccessUserGuideAsClaimant = new(nameof(CanAccessUserGuideAsClaimant),
            ExternalRole.Claimant);

    public static readonly SystemAction CanAccessUserGuideAsDonor = new(nameof(CanAccessUserGuideAsDonor),
        ExternalRole.Donor);

    public static readonly SystemAction CanAccessReleaseNotes = new(nameof(CanAccessReleaseNotes),
        BaseRole.SystemAdmin, BaseRole.ProjectManager, BaseRole.FinancialLead, BaseRole.ContractMgtSpecialist, BaseRole.LegalLead,
        BaseRole.ANRSectorLead, BaseRole.HealthSectorLead, BaseRole.EnergySectorLead, BaseRole.TransportSectorLead,
        BaseRole.ANRTeamLead, BaseRole.HealthTeamLead, BaseRole.EnergyTeamLead, BaseRole.TransportTeamLead,
        BaseRole.SafeGuard, BaseRole.DataManager,
        BaseRole.CaseOfficer);
}