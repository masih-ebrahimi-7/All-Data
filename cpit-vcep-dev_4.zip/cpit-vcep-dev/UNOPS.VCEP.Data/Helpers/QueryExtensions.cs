using System.Linq.Expressions;
using System.Reflection;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Data.Models.Filter;
using UNOPS.VCEP.Infrastructure.Helpers;

namespace UNOPS.VCEP.Data.Helpers;

public static class QueryExtensions
{

    public static IQueryable<TEntity> ApplyFilters<TEntity, TEntityFilterModel>(this IQueryable<TEntity> entity, TEntityFilterModel? filter)
    {
        if (filter == null) return entity;

        Type type = typeof(QueryExtensions);
        var filterMethod = type.GetMethods(BindingFlags.Public | BindingFlags.Static)
            .Single(mi => mi.Name == nameof(ApplyFilters) && mi.ReturnType == typeof(IQueryable<TEntity>));

        if (filterMethod == null)
        {
            throw new NotImplementedException(
                $"No implementation for {nameof(ApplyFilters)} with parameter type {typeof(TEntity)}.");
        }
        return (IQueryable<TEntity>)filterMethod.Invoke(null, new object[] { entity, filter });
    }

    public static IQueryable<Grant> ApplyFilters(this IQueryable<Grant> grants, GrantsFilterModel? filter = null)
    {
        if (filter == null) return grants;

        if (!string.IsNullOrEmpty(filter.GrantName))
            grants = grants.Where(a => a.Name.ToLower().Contains(filter.GrantName.Trim().ToLower()));

        if (filter.Sectors is { Length: > 0 })
        {
            grants = grants.Where(a => filter.Sectors.Contains((int)a.Sector));
        }

        if (filter.Priorities is { Length: > 0 })
            grants = grants.Where(a => filter.Priorities.Contains((int)a.Priority));

        if (!string.IsNullOrEmpty(filter.GrantReference))
            grants = grants.Where(a => a.Reference.ToLower().Contains(filter.GrantReference.Trim().ToLower()));

        if (!string.IsNullOrEmpty(filter.Description))
            grants = grants.Where(a => a.Description != null && a.Description.ToLower().Contains(filter.Description.Trim().ToLower()));

        return grants;
    }

    public static IQueryable<Remark> ApplyFilters(this IQueryable<Remark> remarks, RemarkFilter? filter = null)
    {
        if (filter == null) return remarks;

        if (filter.IsTask != null)
            remarks = remarks.Where(a => a.IsTask.Equals(filter.IsTask));

        if (!string.IsNullOrEmpty(filter.Status))
            remarks = remarks.Where(a => a.TaskStatus != null && a.TaskStatus.Contains(filter.Status.Trim()));

        if (filter.Statuses is { Length: > 0 })
        {
            remarks = remarks.Where(a => filter.Statuses.Contains((int)a.TaskStatus));
        }
        
        if (!string.IsNullOrEmpty(filter.Description))
            remarks = remarks.Where(a => a.RemarkText.Contains(filter.Description.Trim()));

        if (!string.IsNullOrEmpty(filter.Query))
            remarks = remarks.Where(a => a.CreatedBy.Contains(filter.Query.Trim()) || a.RemarkText.Contains(filter.Query.Trim()));
        
        if (filter.DeadlineStartDate != null)
        {
            filter.DeadlineStartDate = filter.DeadlineStartDate.Value.ToUTCDate();
            remarks = remarks.Where(a => a.Deadline >= filter.DeadlineStartDate);
        }

        if (filter.DeadlineEndDate != null)
        {
            filter.DeadlineEndDate = filter.DeadlineEndDate.Value.ToUTCDate();
            remarks = remarks.Where(a => a.Deadline <= filter.DeadlineEndDate);
        }
        
        return remarks;
    }

    public static IQueryable<Expense> ApplyFilters(this IQueryable<Expense> expenses, ExpensesFilterModel? filter = null)
    {
        if (filter == null) return expenses;

        if (filter.Reference != null)
            expenses = expenses.Where(a => a.Reference == filter.Reference);
        if (filter.MonthlyCost != null)
            expenses = expenses.Where(a => a.MonthlyCost.Equals(filter.MonthlyCost));

        if (filter.PendingClaimsAmount != null)
            expenses = expenses.Where(a => a.PendingClaimsAmount.Equals(filter.PendingClaimsAmount));

        if (filter.NumberOfMonths != null)
            expenses = expenses.Where(a => a.NumberOfMonths.Equals(filter.NumberOfMonths));

        if (filter is { StartDateOfExpenditure: not null, EndDateOfExpenditure: not null })
        {
            filter.StartDateOfExpenditure = filter.StartDateOfExpenditure.Value.ToUTCDate();
            filter.EndDateOfExpenditure = filter.EndDateOfExpenditure.Value.ToUTCDate();
            expenses = expenses.Where(a => a.DateOfExpenditureStart >= filter.StartDateOfExpenditure && a.DateOfExpenditureEnd <= filter.EndDateOfExpenditure);
        }

        if (filter is { StartScreeningDate: not null, EndScreeningDate: not null })
        {
            filter.StartScreeningDate = filter.StartScreeningDate.Value.ToUTCDate();
            filter.EndScreeningDate = filter.EndScreeningDate.Value.ToUTCDate();
            expenses = expenses.Where(a => a.ScreeningDate >= filter.StartScreeningDate && a.ScreeningDate <= filter.EndScreeningDate);
        }

        if (filter.AdbSanctionStatus is { Length: > 0 })
            expenses = expenses.Where(a => filter.AdbSanctionStatus.Contains((int)a.AdbSanctionStatus));

        if (filter.ExpenseType is { Length: > 0 })
            expenses = expenses.Where(a => filter.ExpenseType.Contains((int)a.ExpenseType));

        if (!string.IsNullOrEmpty(filter.Nationality))
            expenses = expenses.Where(a => a.Nationality != null && a.Nationality.Contains(filter.Nationality.Trim()));

        if (!string.IsNullOrEmpty(filter.Remarks))
            expenses = expenses.Where(a => a.Remarks != null && a.Remarks.Contains(filter.Remarks.Trim()));

        if (filter.Sector is { Length: > 0 })
            expenses = expenses.Where(a => a.Sector != null && filter.Sector.Contains((int)a.Sector));

        if (filter.ContractAuthority is { Length: > 0 })
            expenses = expenses.Where(a => a.ContractAuthority != null && filter.ContractAuthority.Contains((int)a.ContractAuthority));

        if (!string.IsNullOrEmpty(filter.ExpenditureType))
            expenses = expenses.Where(a => a.ExpenditureType != null && a.ExpenditureType.Contains(filter.ExpenditureType.Trim()));

        if (!string.IsNullOrEmpty(filter.ContractReference))
            expenses = expenses.Where(a => a.ContractReference != null && a.ContractReference.Contains(filter.ContractReference.Trim()));

        return expenses;
    }

    public static IQueryable<DocumentAttachment> ApplyFilters(this IQueryable<DocumentAttachment> entities, DocumentAttachmentModelFilterModel? filter = null)
    {
        if (filter == null) return entities;

        if (!string.IsNullOrEmpty(filter.DocumentName))
            entities = entities.Where(a => a.Document.Name.ToLower().Contains(filter.DocumentName.ToLower()));
        if (!string.IsNullOrEmpty(filter.OriginalName))
            entities = entities.Where(a => a.Document.OriginalName.ToLower().Contains(filter.OriginalName.ToLower()));
        if (filter.DocumentSource.HasValue)
            entities = entities.Where(a => a.Document.DocumentSource == (DocumentSource)filter.DocumentSource.Value);
        if (!string.IsNullOrEmpty(filter.GrantName))
            entities = entities.Where(a => a.Grant.Name.ToLower().Contains(filter.GrantName.ToLower()));
        if (!string.IsNullOrEmpty(filter.ClaimName))
            entities = entities.Where(a => a.Claim.Reference.ToLower().Contains(filter.ClaimName.ToLower()));
        if (!string.IsNullOrEmpty(filter.InvoiceName))
            entities = entities.Where(a => a.Invoice.Reference.ToLower().Contains(filter.InvoiceName.ToLower()));
        if (!string.IsNullOrEmpty(filter.ContractName))
            entities = entities.Where(a => a.Contract.Name.Contains(filter.ContractName));
        if (filter.GrantId.HasValue)
            entities = entities.Where(a => a.GrantId.Equals(filter.GrantId));
        if (filter.InvoiceId.HasValue)
            entities = entities.Where(a => a.InvoiceId.Equals(filter.InvoiceId));
        if (filter.ContractId.HasValue)
            entities = entities.Where(a => a.ContractId.Equals(filter.ContractId));
        if (filter.ClaimId.HasValue)
            entities = entities.Where(a => a.ClaimId.Equals(filter.ClaimId));
        if (filter.OnlyNew is true)
        {
            var threeDaysAgo = DateTime.Now.AddDays(-3).ToUTCDate();
            entities = entities.Where(a => a.CreatedDate >= threeDaysAgo);
        }
        if (filter.CategoryId.HasValue)
        {
            if (filter.CategoryId == -1)
            {
                entities = entities.Where(a => a.Document.DocumentCategoryId == null);
            }
            else if (filter.CategoryId == -2)
            {
                // treat the filter on new uploads
                var threeDaysAgo = DateTime.Now.AddDays(-3).ToUTCDate();
                entities = entities.Where(a => a.CreatedDate >= threeDaysAgo);
            }
            else
                entities = entities.Where(a => a.Document.DocumentCategoryId.Equals(filter.CategoryId));
        }

        if (!string.IsNullOrEmpty(filter.CreatedBy))
            entities = entities.Where(a => a.Document.CreatedBy.ToLower().Contains(filter.CreatedBy.ToLower()));
    
        if (filter.CreatedDate.HasValue)
        {
            filter.CreatedDate = filter.CreatedDate.Value.ToUTCDate();
            entities = entities.Where(a => a.Document.CreatedDate >= filter.CreatedDate);
        }
    
        if (filter.CreatedDateEnd.HasValue)
        {
            filter.CreatedDateEnd = filter.CreatedDateEnd.Value.ToUTCDate();
            entities = entities.Where(a => a.Document.CreatedDate <= filter.CreatedDateEnd);
        }
        
        if (filter.LinkedFromGoogleDrive.HasValue)
            entities = entities.Where(a => a.Document.Linked == filter.LinkedFromGoogleDrive.Value);

        if (!string.IsNullOrEmpty(filter.LastModifiedBy))
            entities = entities.Where(a => a.Document.LastModifiedBy.ToLower().Contains(filter.LastModifiedBy.ToLower()));

        return entities;
    }

    public static IQueryable<ProjectAgreement> ApplyFilters(this IQueryable<ProjectAgreement> projectAgreements, ProjectAgreementsFilterModel? filter = null)
    {
        if (filter == null) return projectAgreements;

        if (!string.IsNullOrEmpty(filter.Reference))
            projectAgreements = projectAgreements.Where(a => a.Reference.Contains(filter.Reference.Trim()));

        if (filter.Sectors is { Length: > 0 })
        {
            projectAgreements = projectAgreements.Where(a => filter.Sectors.Contains((int)a.Grant.Sector));
        }

        if (filter.Priorities is { Length: > 0 })
            projectAgreements = projectAgreements.Where(a => filter.Priorities.Contains((int)a.Priority));

        return projectAgreements;
    }

    public static IQueryable<Staff> ApplyFilters(this IQueryable<Staff> staff, StaffFilterModel? filter = null)
    {
        if (filter == null) return staff;

        if (!string.IsNullOrEmpty(filter.FullName))
            staff = staff.Where(a => a.FullName.Contains(filter.FullName.Trim()));

        if (!string.IsNullOrEmpty(filter.Designation))
            staff = staff.Where(a => a.Designation.Contains(filter.Designation.Trim()));

        if (filter.Employer is { Length: > 0 })
            staff = staff.Where(a => filter.Employer.Contains((int)a.Employer));

        if (!string.IsNullOrEmpty(filter.Nationality))
            staff = staff.Where(a => a.Nationality.Contains(filter.Nationality.Trim()));
        return staff;
    }

    public static IQueryable<StaffContract> ApplyFilters(this IQueryable<StaffContract> staffContracts, StaffContractsFilterModel? filter = null)
    {
        if (filter == null) return staffContracts;

        if (!string.IsNullOrEmpty(filter.Reference))
            staffContracts = staffContracts.Where(a => a.Reference.Contains(filter.Reference.Trim()));

        return staffContracts;
    }

    public static IQueryable<Salary> ApplyFilters(this IQueryable<Salary> salaries, SalariesFilterModel? filter = null)
    {
        if (filter == null) return salaries;

        if (!string.IsNullOrEmpty(filter.Reference))
            salaries = salaries.Where(a => a.Reference.Contains(filter.Reference.Trim()));
        
        if (filter.StaffEmployer is { Length: > 0 })
            salaries = salaries.Where(a => filter.StaffEmployer.Contains((int)a.Staff.Employer));

        if (!string.IsNullOrEmpty(filter.StaffAccountNumber))
            salaries = salaries.Where(a => a.Staff.AccountNumber != null && a.Staff.AccountNumber.Contains(filter.StaffAccountNumber.Trim()));
        
        if (!string.IsNullOrEmpty(filter.GrantReference))
            salaries = salaries.Where(a => a.Grant != null && a.Grant.Reference.Contains(filter.GrantReference.Trim()));

        if (!string.IsNullOrEmpty(filter.ContractReference))
            salaries = salaries.Where(a => a.StaffContract.Reference.Contains(filter.ContractReference.Trim()));

        return salaries;
    }

    public static IQueryable<Contract> ApplyFilters(this IQueryable<Contract> contracts, ContractsFilterModel? filter = null)
    {
        if (filter == null) return contracts;

        if (!string.IsNullOrEmpty(filter.Name))
            contracts = contracts.Where(a => a.Name.ToLower().Contains(filter.Name.Trim().ToLower()));
        if (!string.IsNullOrEmpty(filter.Reference))
            contracts = contracts.Where(a => a.Reference.ToLower().Contains(filter.Reference.Trim().ToLower()));
        if (!string.IsNullOrEmpty(filter.PCSSNumber))
            contracts = contracts.Where(a => a.PcssNumber != null && a.PcssNumber.ToLower().Contains(filter.PCSSNumber.Trim().ToLower()));
        if (!string.IsNullOrEmpty(filter.FundSource))
            contracts = contracts.Where(a => a.FundSource.ToLower().Contains(filter.FundSource.Trim().ToLower()));
        if (!string.IsNullOrEmpty(filter.Location))
            contracts = contracts.Where(a => a.Location != null && a.Location.GeographicalLocation.ToLower().Contains(filter.Location.Trim().ToLower()));

        if (filter.Sectors is { Length: > 0 })
            contracts = contracts.Where(c => c.Grants.Any(g => filter.Sectors.Contains((int)g.Sector)));

        if (!string.IsNullOrEmpty(filter.GrantReference))
            contracts = contracts.Where(a => a.Grants.Any(g => g.Reference.ToLower().Contains(filter.GrantReference.Trim().ToLower())));

        if (filter.Priorities is { Length: > 0 })
            contracts = contracts.Where(a => filter.Priorities.Contains((int)a.PriorityType));

        if (filter.ContractTypes is { Length: > 0 })
            contracts = contracts.Where(a => filter.ContractTypes.Contains((int)a.ContractType));

        if (filter.ContractStartDate != null)
        {
            filter.ContractStartDate = filter.ContractStartDate.Value.ToUTCDate();
            contracts = contracts.Where(a => a.StartDate >= filter.ContractStartDate);
        }

        if (filter.ContractEndDate != null)
        {
            filter.ContractEndDate = filter.ContractEndDate.Value.ToUTCDate();
            contracts = contracts.Where(a => a.EndDate <= filter.ContractEndDate);
        }

        return contracts;
    }

    public static IQueryable<AdvanceAccount> ApplyFilters(this IQueryable<AdvanceAccount> advanceAccounts, AdvanceAccountsFilterModel? filter = null)
    {
        if (filter == null) return advanceAccounts;

        if (!string.IsNullOrEmpty(filter.Reference))
            advanceAccounts = advanceAccounts.Where(a => a.Reference.Contains(filter.Reference.Trim()));
        if (!string.IsNullOrEmpty(filter.AccountName))
            advanceAccounts = advanceAccounts.Where(a => a.AccountName.Contains(filter.AccountName.Trim()));
        if (filter.AccountNumber != null)
            advanceAccounts = advanceAccounts.Where(a => a.AccountNumber.Equals(filter.AccountNumber));
        if (!string.IsNullOrEmpty(filter.ImplementingAgency))
            advanceAccounts = advanceAccounts.Where(a => a.ImplementingAgency.Contains(filter.ImplementingAgency.Trim()));
        if (filter.Sectors is { Length: > 0 })
            advanceAccounts = advanceAccounts.Where(a => filter.Sectors.Contains((int)a.Sector));
        if (filter.FundSources is { Length: > 0 })
            advanceAccounts = advanceAccounts.Where(a => filter.FundSources.Contains((int)a.FundSource));
        if (filter.LastDistributionAmount != null)
            advanceAccounts = advanceAccounts.Where(a => a.LastDistributionAmount.Equals(filter.LastDistributionAmount));

        return advanceAccounts;
    }

    public static IQueryable<Invoice> ApplyFilters(this IQueryable<Invoice> invoices, InvoicesFilterModel? filter = null)
    {
        if (filter == null) return invoices;

        if (!string.IsNullOrEmpty(filter.Reference))
            invoices = invoices.Where(a => a.Reference.Contains(filter.Reference.Trim()));

        if (filter.Amount != null)
            invoices = invoices.Where(a => a.Amount.Equals(filter.Amount));

        if (!string.IsNullOrEmpty(filter.AssignedTo))
            invoices = invoices.Where(a => a.AssignedTo != null && a.AssignedTo.Contains(filter.AssignedTo.Trim()));

        if (filter.Statuses is { Length: > 0 })
        {
            var statuses = new List<StatusType>();
            foreach (var status in filter.Statuses)
                statuses.Add(Extensions.GetValueFromDescription<StatusType>(status.Trim()));

            invoices = invoices.Where(a => statuses.Contains(a.Status));
        }

        if (filter.StartInvoiceDate != null)
        {
            filter.StartInvoiceDate = filter.StartInvoiceDate.Value.ToUTCDate();
            invoices = invoices.Where(a => a.InvoiceDate >= filter.StartInvoiceDate);
        }

        if (filter.EndInvoiceDate != null)
        {
            filter.EndInvoiceDate = filter.EndInvoiceDate.Value.ToUTCDate();
            invoices = invoices.Where(a => a.InvoiceDate <= filter.StartInvoiceDate);
        }

        return invoices;
    }

    public static IQueryable<WithdrawalApplication> ApplyFilters(this IQueryable<WithdrawalApplication> withdrawalApplications, WithdrawalApplicationFilterModel? filter = null)
    {
        if (filter == null) return withdrawalApplications;

        if (!string.IsNullOrEmpty(filter.WithdrawalApplicationNumber))
            withdrawalApplications = withdrawalApplications.Where(a => a.WithdrawalApplicationNumber.Contains(filter.WithdrawalApplicationNumber.Trim()));

        return withdrawalApplications;
    }


    public static IQueryable<Claim> ApplyFilters(this IQueryable<Claim> claims, ClaimsFilterModel? filter = null)
    {
        if (filter == null) return claims;

        if (!string.IsNullOrEmpty(filter.Reference))
            claims = claims.Where(a => a.Reference.ToLower().Contains(filter.Reference.Trim().ToLower()));

        if (!string.IsNullOrEmpty(filter.GrantReference))
            claims = claims.Where(a => a.Grant != null && a.Grant.Reference.ToLower().Contains(filter.GrantReference.Trim().ToLower()));
        
        if (!string.IsNullOrEmpty(filter.ContractReference))
            claims = claims.Where(a => a.Contract != null && a.Contract.Reference.ToLower().Contains(filter.ContractReference.Trim().ToLower()));
        
        if (!string.IsNullOrEmpty(filter.Title))
            claims = claims.Where(a => a.Title.ToLower().Contains(filter.Title.Trim().ToLower()));

        if (!string.IsNullOrEmpty(filter.InternalReferenceCode))
            claims = claims.Where(a => a.InternalReferenceCode != null && a.InternalReferenceCode.ToLower().Contains(filter.InternalReferenceCode.Trim().ToLower()));
        
        if (filter.Sectors is { Length: > 0 })
            claims = claims.Where(a => (a.Sector != null && filter.Sectors.Contains((int)a.Sector))
                                       || (a.Grant != null && filter.Sectors.Contains((int)a.Grant.Sector)));

        if (filter.Priorities is { Length: > 0 })
            claims = claims.Where(a => filter.Priorities.Contains((int)a.Priority));

        if (filter.Types is { Length: > 0 })
            claims = claims.Where(a => filter.Types.Contains((int)a.Type));

        if (filter.CurrentStageIds is { Length: > 0 })
            claims = claims.Where(a => a.StageHistories.Any(h => h.IsCurrentStage && !h.IsDeleted && filter.CurrentStageIds.Contains(h.ClaimStageId)));

        if (filter.Users is { Length: > 0 })
            claims = claims.Where(a => filter.Users.Any(x => x.Equals(a.AssignedToSectorLead)) || filter.Users.Any(x => x.Equals(a.AssignedToFinance)) ||
                                       filter.Users.Any(x => x.Equals(a.AssignedToLegal)) || filter.Users.Any(x => x.Equals(a.AssignedToCMS)));

        if (filter.FundSources is { Length: > 0 })
            claims = claims.Where(a => filter.FundSources.Contains((int)a.FundSource));

        if (filter.ClaimSources is { Length: > 0 })
            claims = claims.Where(a => filter.ClaimSources.Contains((int)a.Source));
        
        if (filter.ContractingAuthorities != null && filter.ContractingAuthorities.Any())
        {
            claims = claims.Where(c => c.ContractingAuthorities != null &&
                                       c.ContractingAuthorities.Any(ca =>
                                           filter.ContractingAuthorities.Contains((int)ca.ContractingAuthority)));
        }
   
        if (filter.Id != null)
            claims = claims.Where(a => a.Id.Equals(filter.Id));

        return claims;
    }

    public static Expression<Func<T, bool>>? AndAlso<T>(this Expression<Func<T, bool>>? initialPredicate,
        Expression<Func<T, bool>>? additionalPredicate)
    {
        if (initialPredicate == null && additionalPredicate == null)
            return null;

        if (initialPredicate == null)
            return additionalPredicate; // If the first expression is null, return the second one directly

        if (additionalPredicate == null)
            return initialPredicate; // If the second expression is null, return the first one directly

        var parameter = Expression.Parameter(typeof(T));

        var combined = new ReplacingExpressionVisitor(initialPredicate.Parameters[0], parameter)
            .VisitAndConvert(initialPredicate.Body, "AndAlso");

        var second = new ReplacingExpressionVisitor(additionalPredicate.Parameters[0], parameter)
            .VisitAndConvert(additionalPredicate.Body, "AndAlso");

        return Expression.Lambda<Func<T, bool>>(
            Expression.AndAlso(combined, second), parameter);
    }

    private class ReplacingExpressionVisitor : ExpressionVisitor
    {
        private readonly Expression _oldValue;
        private readonly Expression _newValue;

        public ReplacingExpressionVisitor(Expression oldValue, Expression newValue)
        {
            _oldValue = oldValue;
            _newValue = newValue;
        }

        public override Expression Visit(Expression node)
        {
            if (node == _oldValue)
                return _newValue;
            return base.Visit(node);
        }
    }
}