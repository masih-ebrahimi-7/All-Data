using Microsoft.EntityFrameworkCore;
using UNOPS.VCEP.Data.DataAccess;
using UNOPS.VCEP.Data.Domain;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Helpers;

public interface IReferenceGenerator
{
    Task<string> GenerateClaimReferenceAsync(SectorType sector);
    Task<string> GenerateIdReferenceAsync<T>(string startString) where T : ModifiableEntity<int>;
}

public class ReferenceGenerator : IReferenceGenerator
{
    private readonly DataDbContext _context;

    public ReferenceGenerator(DataDbContext context)
    {
        _context = context;
    }

    public async Task<string> GenerateClaimReferenceAsync(SectorType sector)
    {
        int sameSectorClaimsCount = await _context.Claims.CountAsync(e => e.Sector == sector);
        int newReferenceNumber = sameSectorClaimsCount + 1;

        return $"{sector.GetDescriptionFromEnumValue()[0]}-{newReferenceNumber:000}";
    }
    
    public async Task<string> GenerateIdReferenceAsync<T>(string startString) where T : ModifiableEntity<int>
    {
        int previousIdInDb = await GetPreviousEntityId<T>();
        int nextId = previousIdInDb + 1;
        return $"{startString}-{nextId:000}";
    }
    private async Task<int> GetPreviousEntityId<T>() where T : ModifiableEntity<int>
    {
        var previousEntity = await _context.Set<T>().OrderByDescending(e => e.Id).FirstOrDefaultAsync();
        return previousEntity?.Id ?? 0;
    }
}
