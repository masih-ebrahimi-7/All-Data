using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class ProjectAgreement : ModifiableDeletableEntity
{
    public string Reference { get; private set; }
    public string? SignedWith { get; private set; }
    public DateTime? AgreementDate { get; private set; }
    public virtual AdvanceAccount? AdvanceAccount { get; }
    public int? AdvanceAccountId { get; private set; }
    public PriorityType Priority { get; set; }
    public virtual Grant? Grant { get; }
    public int? GrantId { get; private set; }
    public virtual ICollection<Contract> Contracts { get; private set; }
}