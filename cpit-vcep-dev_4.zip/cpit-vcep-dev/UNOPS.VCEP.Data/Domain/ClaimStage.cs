using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class ClaimStage : ModifiableDeletableEntity
{
    public ClaimStage()
    {
        Children = new HashSet<ClaimStage>();
        ClaimStageHistories = new HashSet<ClaimStageHistory>();
    }

    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; } = string.Empty;
    public decimal? WeightPercentage { get; set; }
    public int? EstimatedDurationWeeks { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public int? ParentStageId { get; set; }
    public virtual ClaimStage? ParentStage { get; set; }
    public virtual ICollection<ClaimStage> Children { get; set; }
    public string? EstimatedDeliveryTimeline { get; set; }
    public virtual ICollection<ClaimStageHistory> ClaimStageHistories { get; set; }
}
