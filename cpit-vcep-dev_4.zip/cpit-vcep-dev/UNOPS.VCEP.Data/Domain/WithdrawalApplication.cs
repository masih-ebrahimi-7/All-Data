using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class WithdrawalApplication : ModifiableDeletableEntity
{
    public WithdrawalApplication(){}
    public WithdrawalApplication(WithdrawalApplicationRequestModel i)
    {
        WithdrawalApplicationNumber = i.WithdrawalApplicationNumber;
        WithdrawalApplicationDate = i.WithdrawalApplicationDate;
        Type = i.Type;
        UnliquidatedBalance = i.UnliquidatedBalance;
        NotCreditedAmount = i.NotCreditedAmount;
        CurrencyId = i.CurrencyId;
    }
    public string WithdrawalApplicationNumber { get; private set; }
    public DateTime WithdrawalApplicationDate { get; private set; }
    public string CurrencyId { get; set; }
    public WithdrawalApplicationType Type { get; private set; }
    public decimal UnliquidatedBalance { get; private set; }
    public decimal NotCreditedAmount { get; private set; }
    public virtual AdvanceAccount? AdvanceAccount { get; }
    public int? AdvanceAccountId { get; private set; }

    public void HandleUpdate(WithdrawalApplicationRequestModel i)
    {
        WithdrawalApplicationNumber = i.WithdrawalApplicationNumber;
        WithdrawalApplicationDate = i.WithdrawalApplicationDate;
        Type = i.Type;
        UnliquidatedBalance = i.UnliquidatedBalance;
        NotCreditedAmount = i.NotCreditedAmount;
        CurrencyId = i.CurrencyId;
    }
}