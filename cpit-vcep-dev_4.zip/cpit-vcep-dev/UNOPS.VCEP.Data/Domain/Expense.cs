using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class Expense : ModifiableDeletableEntity
{
    public Expense()
    {
    }

    public Expense(ExpenseBaseModel c)
    {
        Description = c.Description;
        CurrencyId = c.CurrencyId;
        MonthlyCost = c.MonthlyCost;
        NumberOfMonths = c.NumberOfMonths;
        PendingClaimsAmount = c.PendingClaimsAmount;
        ExternalEntityId = c.ExternalEntityId;
        ScreeningDate = c.ScreeningDate;
        DateOfExpenditureStart = c.DateOfExpenditureStart;
        DateOfExpenditureEnd = c.DateOfExpenditureEnd;
        AdbSanctionStatus = EnumExtensions.IsValidEnumValue<ADBSanctionStatus>(c.AdbSanctionStatus)
            ? (ADBSanctionStatus)c.AdbSanctionStatus
            : ADBSanctionStatus.Cleared;
        ExpenseType = AuthorityType.PMO;
        Nationality = c.Nationality;
        Remarks = c.Remarks;
        Sector = c.Sector;
        ContractAuthority = c.ContractAuthority;
        ExpenditureType = c.ExpenditureType;
        ContractReference = c.ContractReference;
        DocumentUploadUrl = c.DocumentUploadUrl;
    }

    public Expense(ExpenseBaseModel c, string reference, ICollection<Grant> grants) : this(c)
    {
        Reference = reference;
        UpdateGrants(grants);
    }

    public string Reference { get; private set; }
    public string Description { get; private set; }
    public string CurrencyId { get; private set; }
    public decimal MonthlyCost { get; private set; }
    public decimal NumberOfMonths { get; private set; }
    public decimal PendingClaimsAmount { get; private set; }
    public virtual ICollection<Grant>? Grants { get; set; }
    public virtual ExternalEntity? Contractor { get; }
    public int? ExternalEntityId { get; private set; }
    public DateTime? ScreeningDate { get; private set; }
    public DateTime? DateOfExpenditureStart { get; private set; }
    public DateTime? DateOfExpenditureEnd { get; private set; }
    public AuthorityType ExpenseType { get; private set; } = AuthorityType.PMO;
    public ADBSanctionStatus AdbSanctionStatus { get; private set; }
    public string? Nationality { get; private set; }
    public string? Remarks { get; private set; }
    public SectorType? Sector { get; private set; }
    public AuthorityType? ContractAuthority { get; private set; }
    public string? ExpenditureType { get; private set; }
    public string? ContractReference { get; private set; }
    public string? DocumentUploadUrl { get; private set; }

    public void Update(ExpenseBaseModel model, ICollection<Grant> linkedGrants)
    {
        UpdateDescription(model.Description);
        UpdateCurrencyId(model.CurrencyId);
        UpdateMonthlyCost(model.MonthlyCost);
        UpdateNumberOfMonths(model.NumberOfMonths);
        UpdatePendingClaimsAmount(model.PendingClaimsAmount);
        UpdateExternalEntityId(model.ExternalEntityId);
        UpdateScreeningDate(model.ScreeningDate);
        UpdatesDateOfExpenditure(model.DateOfExpenditureStart, DateOfExpenditureEnd);
        UpdateExpenseType(model.ExpenseType);
        UpdateAdbSanctionStatus(model.AdbSanctionStatus);
        UpdateGrants(linkedGrants);
        UpdateNationality(model.Nationality);
        UpdateRemarks(model.Remarks);
        UpdateSector(model.Sector);
        UpdateContractAuthority(model.ContractAuthority);
        UpdateExpenditureType(model.ExpenditureType);
        UpdateContractReference(model.ContractReference);
        UpdateDocumentUploadUrl(model.DocumentUploadUrl);
    }

    private void UpdateReference(string reference)
    {
        Reference = reference;
    }

    private void UpdateDescription(string description)
    {
        Description = description;
    }

    private void UpdateCurrencyId(string currencyId)
    {
        CurrencyId = currencyId;
    }

    private void UpdateMonthlyCost(decimal monthlyCost)
    {
        MonthlyCost = monthlyCost;
    }

    private void UpdateNumberOfMonths(decimal numberOfMonths)
    {
        NumberOfMonths = numberOfMonths;
    }

    private void UpdatePendingClaimsAmount(decimal pendingClaimsAmount)
    {
        PendingClaimsAmount = pendingClaimsAmount;
    }

    private void UpdateExternalEntityId(int? externalEntityId)
    {
        ExternalEntityId = externalEntityId;
    }

    private void UpdateScreeningDate(DateTime? screeningDate)
    {
        ScreeningDate = screeningDate;
    }

    private void UpdatesDateOfExpenditure(DateTime? dateOfExpenditureStart, DateTime? dateOfExpenditureEnd)
    {
        DateOfExpenditureStart = dateOfExpenditureStart;
        DateOfExpenditureEnd = dateOfExpenditureEnd;
    }

    private void UpdateExpenseType(AuthorityType expenseType)
    {
        ExpenseType = expenseType;
    }

    private void UpdateAdbSanctionStatus(ADBSanctionStatus adbSanctionStatus)
    {
        AdbSanctionStatus = adbSanctionStatus;
    }

    private void UpdateGrants(ICollection<Grant>? grants)
    {
        if (grants != null)
        {
            Grants = new List<Grant>(grants);
        }
        else
        {
            Grants = null;
        }
    }

    private void UpdateNationality(string? nationality)
    {
        Nationality = nationality;
    }

    private void UpdateRemarks(string? remarks)
    {
        Remarks = remarks;
    }

    private void UpdateSector(SectorType? sector)
    {
        Sector = sector;
    }

    private void UpdateContractAuthority(AuthorityType? contractAuthority)
    {
        ContractAuthority = contractAuthority;
    }

    private void UpdateExpenditureType(string? expenditureType)
    {
        ExpenditureType = expenditureType;
    }

    private void UpdateContractReference(string? contractReference)
    {
        ContractReference = contractReference;
    }

    private void UpdateDocumentUploadUrl(string? documentUploadUrl)
    {
        DocumentUploadUrl = documentUploadUrl;
    }
}