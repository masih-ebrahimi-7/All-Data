using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Enums;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class Claim : ModifiableDeletableEntity
{
    public Claim()
    {
    }

    public Claim(CreateClaimRequestModel request, string reference)
    {
        this.Title = request.Title ?? "Claim";
        this.InternalReferenceCode = request.InternalReferenceCode;
        this.Note = request.Note;
        this.Description = request.Description;
        this.Priority = request.Priority != null && Enum.IsDefined(typeof(PriorityType), request.Priority) ? (PriorityType)request.Priority : PriorityType.Fourth;
        this.Source = request.Source != null && Enum.IsDefined(typeof(ClaimSource), request.Source) ? (ClaimSource)request.Source : ClaimSource.Unknown;
        this.FundSource = request.FundSource != null && EnumExtensions.IsValidEnumValue<FundSourceType>(request.FundSource)
            ? (FundSourceType)request.FundSource
            : FundSourceType.Unknown;
        this.CurrencyId = request.CurrencyId;
        this.ClaimedAmount = request.ClaimedAmount;
        ContractType type = request.Type != null && Enum.IsDefined(typeof(ContractType), request.Type) ? (ContractType)request.Type : ContractType.Unknown;
        this.Type = type;
        ClaimStatus status = request.Status != null ? (ClaimStatus)request.Status : ClaimStatus.Created;
        this.Status = status;
        HandleContractingAuthorities(request.ContractingAuthorities);
        this.Reference = reference;
        SectorType sector = Enum.IsDefined(typeof(SectorType), request.Sector) ? (SectorType)request.Sector : SectorType.Other;
        this.Sector = sector;
        this.GrantId = request.GrantId;
        this.ContractId = request.ContractId;
        this.ProjectAgreementId = request.ProjectAgreementId;
        this.ClaimForEndDate = request.ClaimForEndDate;
        this.ClaimForStartDate = request.ClaimForStartDate;
        this.LinkedClaimantUserId = request.LinkedClaimantUserId;
        FinanceFunctionalLeadReportStatus = LeadReportStatus.Draft;
        LegalFunctionalLeadReportStatus = LeadReportStatus.Draft;
        TechnicalFunctionalLeadReportStatus = LeadReportStatus.Draft;
        ContractsFunctionalLeadReportStatus = LeadReportStatus.Draft;
    }

    public Claim(CreateClaimRequestModel request, string reference, ClaimDataToValidateModel dataToValidate, ClaimSource source) : this(request, reference)
    {
        this.Source = source;
        if (source == ClaimSource.Claimant)
            this.Status = ClaimStatus.AwaitingClearance;
        this.ClaimDetailsToValidate = new ClaimDetailsToValidate(dataToValidate);
    }

    private void UpdateOfficialEstimatedAmount(decimal amount)
    {
        this.OfficialEstimatedAmount = amount;
    }

    public string Title { get; set; }
    public string? InternalReferenceCode { get; private set; }
    public string Reference { get; private set; }
    public string? Description { get; private set; }
    public decimal ClaimedAmount { get; private set; }
    public decimal VerifiedAmount { get; private set; }
    public decimal OfficialEstimatedAmount { get; private set; }
    public decimal IneligibleEstimatedAmount { get; private set; }
    public decimal? EstimatedAmountToBeReclaimed { get; private set; }
    public decimal? VerifiedAmountToBeReclaimed { get; private set; }
    public string CurrencyId { get; private set; }
    public DateTime? ClaimForStartDate { get; set; }
    public DateTime? ClaimForEndDate { get; set; }
    public PriorityType Priority { get; set; }
    public ClaimSource Source { get; set; }
    public FundSourceType FundSource { get; private set; }
    public virtual ICollection<ClaimContractingAuthority>? ContractingAuthorities { get; set; }
    public ContractType Type { get; set; }
    public ClaimStatus Status { get; set; }
    public string? AssignedToSectorLead { get; set; }
    public string? AssignedToFinance { get; set; }
    public string? AssignedToLegal { get; set; }
    public string? AssignedToCMS { get; set; }
    public int? LinkedClaimantUserId { get; set; }
    public virtual ExternalEntityUser? LinkedClaimantUser { get; set; }
    public string? FinanceFunctionalLeadReport { get; set; }
    public string? LegalFunctionalLeadReport { get; set; }
    public string? ContractsFunctionalLeadReport { get; set; }
    public string? TechnicalFunctionalLeadReport { get; set; }
    public LeadReportStatus TechnicalFunctionalLeadReportStatus { get; set; }
    public LeadReportStatus ContractsFunctionalLeadReportStatus { get; set; }
    public LeadReportStatus FinanceFunctionalLeadReportStatus { get; set; }
    public LeadReportStatus LegalFunctionalLeadReportStatus { get; set; }
    public string? GoogleDriveFolderId { get; set; }
    public bool Fraudulent { get; set; }
    public string? FraudulentReason { get; set; }
    public virtual ICollection<Remark?> Remarks { get; set; }
    public virtual ICollection<DocumentAttachment> DocumentAttachments { get; set; }
    public virtual ICollection<Location> Locations { get; set; }
    public virtual ICollection<ClaimStageHistory> StageHistories { get; set; } = new HashSet<ClaimStageHistory>();
    public virtual ICollection<SubClaim> SubClaims { get; set; } = new HashSet<SubClaim>();
    public SectorType? Sector { get; set; }
    public virtual Grant? Grant { get; }
    public int? GrantId { get; set; }
    public virtual ProjectAgreement? ProjectAgreement { get; }
    public int? ProjectAgreementId { get; set; }
    public virtual Contract? Contract { get; }
    public int? ContractId { get; set; }
    public string? InternalRejectionNote { get; private set; }
    public string? ExternalRejectionNote { get; private set; }
    public string? Note { get; private set; }
    public virtual ClaimDetailsToValidate? ClaimDetailsToValidate { get; }
    public decimal? CdcContribution { get; set; }
    public decimal? AdbContribution { get; set; }
    public decimal? DisbursedAmount { get; set; }
    public decimal? SpentAmount { get; set; }
    public string? BankAccountNo { get; set; }
    public string? Province { get; set; }
    public string? District { get; set; }
    public string? ClaimantPhoneNumber { get; set; }
    public void UpdateRejectionNotes(string? externalRejectionNote, string? internalRejectionNote)
    {
        if (this.Status == ClaimStatus.Rejected)
        {
            this.ExternalRejectionNote = externalRejectionNote;
            this.InternalRejectionNote = internalRejectionNote;
        }
    }
    public void ResetRejectionNotes()
    {
        this.ExternalRejectionNote = string.Empty;
        this.InternalRejectionNote = string.Empty;
    }

    public void AssignToWork(string dataEmail, UserAssignmentType userType)
    {
        switch (userType)
        {
            case UserAssignmentType.Finance:
                this.AssignedToFinance = dataEmail;
                break;
            case UserAssignmentType.Legal:
                this.AssignedToLegal = dataEmail;
                break;
            case UserAssignmentType.CMS:
                this.AssignedToCMS = dataEmail;
                break;
            default:
                this.AssignedToSectorLead = dataEmail;
                break;
        }
    }

    public void LinkToClaimantUserId(int userId)
    {
        this.LinkedClaimantUserId = userId;
    }

    private void UpdateTitle(string? newTitle)
    {
        if (!string.IsNullOrEmpty(newTitle) && newTitle != this.Title)
        {
            this.Title = newTitle;
        }
    }
    
    private void UpdatePhoneNumber(string? newPhoneNumber)
    {
        this.ClaimantPhoneNumber = newPhoneNumber;
    }
    
    private void UpdateDistrict(string? district)
    {
        this.District = district;
    }
    
    private void UpdateProvince(string? province)
    {
        this.Province = province;
    }
    private void UpdateInternalReferenceCode(string? irc)
    {
        if (!string.IsNullOrEmpty(irc) && irc != this.InternalReferenceCode)
        {
            this.InternalReferenceCode = irc;
        }
    }

    private void UpdateNote(string? note)
    {
        if (!string.IsNullOrEmpty(note) && note != this.Note)
        {
            this.Note = note;
        }
    }
    public void UpdateGrant(int? newGrantId)
    {
        if (newGrantId.HasValue && newGrantId != this.GrantId)
        {
            this.GrantId = newGrantId;
        }
    }

    private void UpdateSector(int? newSector)
    {
        if (newSector.HasValue && Enum.IsDefined(typeof(SectorType), newSector) && (SectorType)newSector != this.Sector)
        {
            SectorType sector = (SectorType)newSector;
            this.Sector = sector;
        }
    }

    public void UpdateStatus(int? newStatus)
    {
        if (newStatus.HasValue && Enum.IsDefined(typeof(ClaimStatus), newStatus) && (ClaimStatus)newStatus != this.Status)
        {
            var status = (ClaimStatus)newStatus;
            this.Status = status;
        }
    }

    private void UpdatePriority(int? newPrio)
    {
        if (newPrio.HasValue && Enum.IsDefined(typeof(PriorityType), newPrio) && (PriorityType)newPrio != this.Priority)
        {
            var claimPriority = (PriorityType)newPrio;
            this.Priority = claimPriority;
        }
    }

    private void UpdateClaimSource(int? newSource)
    {
        if (newSource.HasValue && Enum.IsDefined(typeof(ClaimSource), newSource) && (ClaimSource)newSource != this.Source)
        {
            var claimSource = (ClaimSource)newSource;
            this.Source = claimSource;
        }
    }
    
    private void UpdateClaimFundSource(int? newFundSource)
    {
        if (newFundSource.HasValue && Enum.IsDefined(typeof(FundSourceType), newFundSource) && (FundSourceType)newFundSource != this.FundSource)
        {
            var fs = (FundSourceType)newFundSource;
            this.FundSource = fs;
        }
    }

    public void UpdateContract(int? newContractId)
    {
        if (newContractId.HasValue && newContractId != this.ContractId)
        {
            this.ContractId = newContractId;
        }
    }

    public void UpdateProjectAgreement(int? newProjectAgreementId)
    {
        if (newProjectAgreementId.HasValue && newProjectAgreementId != this.ProjectAgreementId)
        {
            this.ProjectAgreementId = newProjectAgreementId;
        }
    }

    public void UpdateFraudulentStatus(bool fraudulent, string? reason = null)
    {
        this.Fraudulent = fraudulent;
        if (fraudulent && !string.IsNullOrEmpty(reason))
        {
            this.FraudulentReason = reason;
        }
        else if (!fraudulent)
        {
            this.FraudulentReason = null;
        }
    }

    public void UpdateInternalAmounts(EditClaimRequestModel request)
    {
        if (request.VerifiedAmount.HasValue && (decimal)request.VerifiedAmount != this.VerifiedAmount)
            this.VerifiedAmount = (decimal)request.VerifiedAmount;

        if (request.OfficialEstimatedAmount.HasValue && (decimal)request.OfficialEstimatedAmount != this.OfficialEstimatedAmount)
            this.OfficialEstimatedAmount = (decimal)request.OfficialEstimatedAmount;

        if (request.IneligibleEstimatedAmount.HasValue && (decimal)request.IneligibleEstimatedAmount != this.IneligibleEstimatedAmount)
            this.IneligibleEstimatedAmount = (decimal)request.IneligibleEstimatedAmount;

        if (request.ClaimedAmount.HasValue && (decimal)request.ClaimedAmount != this.ClaimedAmount)
            this.ClaimedAmount = (decimal)request.ClaimedAmount;
        
        if (request.EstimatedAmountToBeReclaimed.HasValue && (decimal)request.EstimatedAmountToBeReclaimed != this.EstimatedAmountToBeReclaimed)
            this.EstimatedAmountToBeReclaimed = (decimal)request.EstimatedAmountToBeReclaimed;
        
        if (request.VerifiedAmountToBeReclaimed.HasValue && (decimal)request.VerifiedAmountToBeReclaimed != this.VerifiedAmountToBeReclaimed)
            this.VerifiedAmountToBeReclaimed = (decimal)request.VerifiedAmountToBeReclaimed;

        if (request.CdcContribution.HasValue && (decimal)request.CdcContribution != this.CdcContribution)
            this.CdcContribution = (decimal)request.CdcContribution;

        if (request.AdbContribution.HasValue && (decimal)request.AdbContribution != this.AdbContribution)
            this.AdbContribution = (decimal)request.AdbContribution;

        if (request.DisbursedAmount.HasValue && (decimal)request.DisbursedAmount != this.DisbursedAmount)
            this.DisbursedAmount = (decimal)request.DisbursedAmount;

        if (request.SpentAmount.HasValue && (decimal)request.SpentAmount != this.SpentAmount)
            this.SpentAmount = (decimal)request.SpentAmount;

        if (!string.IsNullOrEmpty(request.BankAccountNo) && request.BankAccountNo != this.BankAccountNo)
            this.BankAccountNo = request.BankAccountNo;
        
        this.UpdateCurrencyId(request.CurrencyId);
    }

    private void UpdateClaimedDates(DateTime? requestClaimForStartDate, DateTime? requestClaimForEndDate)
    {
        if (requestClaimForStartDate != null)
        {
            this.ClaimForStartDate = requestClaimForStartDate;
        }
        if (requestClaimForEndDate != null)
        {
            this.ClaimForEndDate = requestClaimForEndDate;
        }
    }

    public void UpdateType(int? claimType)
    {
        if (claimType.HasValue && Enum.IsDefined(typeof(ContractType), claimType) && (ContractType)claimType != this.Type)
        {
            this.Type = (ContractType)claimType;
        }
    }

    private void HandleContractingAuthorities(int[]? contractingAuthorities)
    {
        if (contractingAuthorities != null)
        {
            ContractingAuthorities = new List<ClaimContractingAuthority>();
            foreach (var contractingAuthority in contractingAuthorities)
            {
                if (Enum.IsDefined(typeof(ContractingAuthorityType), contractingAuthority))
                    ContractingAuthorities.Add(
                        new ClaimContractingAuthority((ContractingAuthorityType)contractingAuthority));
            }
        }
    }

    private void UpdateDescription(string? requestDescription)
    {
        if (requestDescription != null && requestDescription != this.Description)
        {
            this.Description = requestDescription;
        }
    }
    
    private void UpdateCurrencyId(string? currencyId)
    {
        if (!string.IsNullOrEmpty(currencyId) && currencyId != CurrencyId)
        {
            CurrencyId = currencyId;
        }
    }

    public void Update(EditClaimRequestModel request)
    {
        this.UpdateTitle(request.Title);
        this.UpdateInternalReferenceCode(request.InternalReferenceCode);
        this.UpdateNote(request.Note);
        this.UpdateSector(request.Sector);
        this.UpdateType(request.Type);
        this.UpdatePriority(request.Priority);
        this.UpdateClaimSource(request.Source);
        this.UpdateClaimFundSource(request.FundSource);
        this.UpdateDescription(request.Description);
        this.UpdateClaimedDates(request.ClaimForStartDate, request.ClaimForEndDate);
        this.UpdatePhoneNumber(request.ClaimantPhoneNumber);
        this.UpdateDistrict(request.District);
        this.UpdateProvince(request.Province);
    }
    
    public decimal CalculateTotalSubClaimAmount()
    {
        return SubClaims?.Where(sc => !sc.IsDeleted)
                        .Sum(sc => sc.ClaimAmount) ?? 0;
    }
    
    public decimal CalculateTotalVerifiedAmount()
    {
        return SubClaims?.Where(sc => !sc.IsDeleted && sc.VerifiedAmount.HasValue)
                        .Sum(sc => sc.VerifiedAmount.Value) ?? 0;
    }
    
    public decimal CalculateEligibleAmount()
    {
        return SubClaims?.Where(sc => !sc.IsDeleted && sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Eligible)
                        .Sum(sc => sc.VerifiedAmount ?? sc.ClaimAmount) ?? 0;
    }
    
    public decimal CalculateIneligibleAmount()
    {
        return SubClaims?.Where(sc => !sc.IsDeleted && sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Ineligible)
                        .Sum(sc => sc.ClaimAmount - (sc.VerifiedAmount ?? 0)) ?? 0;
    }
    
    public int GetSubClaimCount()
    {
        return SubClaims?.Count(sc => !sc.IsDeleted) ?? 0;
    }
    
    public int GetEligibleSubClaimCount()
    {
        return SubClaims?.Count(sc => !sc.IsDeleted && sc.EligibilityStatus == Domain.Enums.EligibilityStatus.Eligible) ?? 0;
    }
}