﻿using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class Staff : ModifiableDeletableEntity
    {
        public string FullName { get; private set; }
        public string Designation { get; private set; }
        public string Nationality { get; private set; }
        public StaffEmployerType Employer { get; private set; }
        public string? AccountNumber { get; private set; }
        public StaffType StaffType { get; private set; }

        public Staff(string fullName, string designation, string nationality, StaffEmployerType employer,
            StaffType staffType, string? accountNumber)
        {
            FullName = fullName;
            Designation = designation;
            Nationality = nationality;
            Employer = employer;
            AccountNumber = accountNumber;
            StaffType = staffType;
        }

        public Staff(StaffBaseModel model)
        {
            StaffType = model.StaffType;
            FullName = model.FullName;
            Designation = model.Designation;
            Nationality = model.Nationality;
            Employer = model.Employer;
            AccountNumber = model.AccountNumber;
        }

        public void UpdateFullName(string fullName)
        {
            FullName = fullName;
        }

        public void UpdateDesignation(string designation)
        {
            Designation = designation;
        }

        public void UpdateNationality(string nationality)
        {
            Nationality = nationality;
        }

        public void UpdateEmployer(StaffEmployerType employer)
        {
            Employer = employer;
        }

        private void UpdateStaffType(StaffType staffType)
        {
            StaffType = staffType;
        }

        public void UpdateAccountNumber(string? accountNumber)
        {
            AccountNumber = accountNumber;
        }

        public void Update(StaffBaseModel staff)
        {
            UpdateFullName(staff.FullName);
            UpdateDesignation(staff.Designation);
            UpdateNationality(staff.Nationality);
            UpdateEmployer(staff.Employer);
            UpdateStaffType(staff.StaffType);
            UpdateAccountNumber(staff.AccountNumber);
        }
    }
}