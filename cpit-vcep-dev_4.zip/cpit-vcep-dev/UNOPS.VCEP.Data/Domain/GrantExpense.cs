using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class GrantExpense: ModifiableDeletableEntity
{
    public int GrantId { get; set; }
    public int ExpenseId { get; set; }
}