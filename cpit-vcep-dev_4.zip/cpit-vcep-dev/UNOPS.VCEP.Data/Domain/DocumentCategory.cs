﻿using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class DocumentCategory : ModifiableDeletableEntity
    {
        public DocumentCategory()
        {
        }

        public string Name { get; set; }
        public string Description { get; set; }
        public bool? IsRequired { get; set; }
        public virtual ICollection<Document> Documents { get; set; }
    }
}