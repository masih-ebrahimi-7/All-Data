﻿using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class DocumentAttachment : ModifiableDeletableEntity
    {
        public DocumentAttachment()
        {
        }

        public int Id { get; set; }
        public virtual Document Document { get; set; }
        public int DocumentId { get; set; }

        public virtual Grant Grant { get; set; }
        public int? GrantId { get; set; }
        public virtual Invoice Invoice { get; set; }
        public int? InvoiceId { get; set; }
        public virtual Claim Claim { get; set; }
        public int? ClaimId { get; set; }
        public virtual SubClaim SubClaim { get; set; }
        public int? SubClaimId { get; set; }
        public virtual Contract Contract { get; set; }
        public int? ContractId { get; set; }
    }
}