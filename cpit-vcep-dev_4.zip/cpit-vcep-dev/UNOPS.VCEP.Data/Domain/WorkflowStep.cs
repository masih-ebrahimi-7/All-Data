﻿using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain
{
    public class WorkflowStep : ModifiableDeletableEntity
    {
        public int ClaimId { get; set; }
        public ClaimStatus ClaimStatus { get; set; }
        public virtual Claim Claim { get; set; }
    }
}
