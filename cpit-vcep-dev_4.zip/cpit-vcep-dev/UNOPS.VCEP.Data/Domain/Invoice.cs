using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class Invoice : ModifiableDeletableEntity
{
    public Invoice()
    {
    }

    public string Reference { get; private set; }
    public StatusType Status { get; private set; }
    public AuthorityType? AuthorityType { get; private set; }
    public string? Path { get; private set; }
    public decimal? Amount { get; private set; }
    public decimal AmountUsd { get; private set; }
    public string CurrencyId { get; private set; }
    public string? AssignedTo { get; private set; }
    public DateTime? InvoiceDate { get; private set; }
    public virtual Contract? Contract { get; }
    public int? ContractId { get; private set; }
    public decimal? TaxPercentage { get; private set; }
    public PriorityType Priority { get; set; }
    public string? GoogleDriveFolderId { get; set; }
}