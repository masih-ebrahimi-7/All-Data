﻿using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class StaffContract : ModifiableDeletableEntity
    {
        public StaffContract()
        {
        }

        public string Reference { get; private set; }
        public DateTime ContractStartDate { get; private set; }
        public DateTime ContractEndDate { get; private set; }
        public string ContractCurrencyId { get; private set; }
        public decimal BasicSalary { get; private set; }
        public decimal? Allowances { get; private set; }

        public StaffContract(StaffContractBaseModel model)
        {
            Reference = model.Reference;
            ContractStartDate = model.ContractStartDate;
            ContractEndDate = model.ContractEndDate;
            ContractCurrencyId = model.ContractCurrencyId;
            BasicSalary = model.BasicSalary;
            Allowances = model.Allowances;
        }

        public StaffContract(string reference, DateTime contractStartDate, DateTime contractEndDate,
            string contractCurrency, decimal basicSalary, decimal allowances)
        {
            Reference = reference;
            ContractStartDate = contractStartDate;
            ContractEndDate = contractEndDate;
            ContractCurrencyId = contractCurrency;
            BasicSalary = basicSalary;
            Allowances = allowances;
        }

        private void UpdateReference(string reference)
        {
            Reference = reference;
        }

        private void UpdateContractStartDate(DateTime contractStartDate)
        {
            ContractStartDate = contractStartDate;
        }

        private void UpdateContractEndDate(DateTime contractEndDate)
        {
            ContractEndDate = contractEndDate;
        }

        private void UpdateContractCurrency(string contractCurrency)
        {
            ContractCurrencyId = contractCurrency;
        }

        private void UpdateBasicSalary(decimal basicSalary)
        {
            BasicSalary = basicSalary;
        }

        private void UpdateAllowances(decimal? allowances)
        {
            Allowances = allowances;
        }

        public void Update(StaffContractBaseModel staffContract)
        {
            UpdateReference(staffContract.Reference);
            UpdateContractStartDate(staffContract.ContractStartDate);
            UpdateContractEndDate(staffContract.ContractEndDate);
            UpdateContractCurrency(staffContract.ContractCurrencyId);
            UpdateBasicSalary(staffContract.BasicSalary);
            UpdateAllowances(staffContract.Allowances);
        }
    }
}