using System;
using System.ComponentModel.DataAnnotations;
using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain
{
    public class SubClaim : ModifiableDeletableEntity
    {
        public new int Id { get; set; }
        public int ClaimId { get; set; }
        public virtual Claim Claim { get; set; }
        public int SubSeqNo { get; private set; }
        public string ReferenceCode { get; private set; }
        public SubClaimType Type { get; set; }
        public DateTime? InvoiceIpcDate { get; set; }
        public string InvoiceIpcNumber { get; set; }
        public string InvoiceIpcDescription { get; set; }
        public string CurrencyId { get; set; }
        public decimal ClaimAmount { get; set; }
        public decimal? ClaimAmountUsd { get; set; }
        public decimal? VerifiedAmount { get; set; }
        public decimal? VerifiedAmountUsd { get; set; }
        public EligibilityStatus? EligibilityStatus { get; set; }
        public string Remarks { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public void SetReferenceCode(string claimReference, int sequenceNumber)
        {
            SubSeqNo = sequenceNumber;
            ReferenceCode = $"{claimReference}-{sequenceNumber}";
        }
    }
}