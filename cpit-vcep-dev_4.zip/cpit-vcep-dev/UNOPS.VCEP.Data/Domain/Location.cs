using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class Location : ModifiableDeletableEntity
{
    public Location()
    {
    }

    public Location(LocationModel locationModel)
    {
        this.Latitude = locationModel.Latitude;
        this.Longitude = locationModel.Longitude;
        this.GeographicalLocation = locationModel.GeographicalLocation;
    }

    public Location(ContractLocationModel locationModel)
    {
        this.Latitude = locationModel.Latitude;
        this.Longitude = locationModel.Longitude;
        this.GeographicalLocation = locationModel.GeographicalLocation;
    }

    public Location(double latitude, double longitude)
    {
        this.Latitude = latitude;
        this.Longitude = longitude;
    }

    public string GeographicalLocation { get; private set; }
    public double? Latitude { get; private set; }
    public double? Longitude { get; private set; }
    public virtual Claim? Claim { get; set; }
    public int? ClaimId { get; set; }
}