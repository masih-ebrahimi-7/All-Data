using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class ClaimStageHistory : ModifiableDeletableEntity
{
    public int ClaimId { get; set; }
    public virtual Claim Claim { get; set; } = null!;
    
    public int ClaimStageId { get; set; }
    public virtual ClaimStage ClaimStage { get; set; } = null!;
    
    public DateTime StartDate { get; set; }
    public DateTime? CompletedDate { get; set; }
    public DateTime? EstimatedCompletionDate { get; set; }
    
    public string? Notes { get; set; }
    public bool IsCurrentStage { get; set; }
    
    public string? MovedByUserId { get; set; }
    public string? MovedByUserName { get; set; }
}
