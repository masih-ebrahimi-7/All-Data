using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain.Enums;

public enum StaffType
{
    [Description("MPW PMO Staff")]
    MpwPmoStaff = 1,
    [Description("DABS PMO Staff")]
    DabsPmoStaff = 2,
    [Description("ANR - MAIL CPMO Staff")]
    AnrMailCpmoStaff = 3,
    [Description("ANR - MAIL - Project Staff")]
    AnrMailProjectStaff = 4,
    [Description("ANR - NWARA - MOF Based Staff")]
    AnrNwaraMofBasedStaff = 5,
    [Description("ANR - NWARA - MOF Staff")]
    AnrNwaraMofStaff = 6,
    [Description("ANR - NWARA - CAESU Based Staff")]
    AnrNwaraCaesuBasedStaff = 7,
    [Description("ANR - MRRD CPMO Staff")]
    AnrMrrdCpmoStaff = 8,
    [Description("Health Sector PMO Staff")]
    HealthSectorPmoStaff = 9,
    [Description("ARA PMO Staff")]
    AraPmoStaff = 10,
    [Description("ANR - NWARA CPMO")]
    AnrNwaraCpmo = 11,
    [Description("Other")]
    Other = 99,
}