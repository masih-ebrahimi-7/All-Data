using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain;

public enum ADBSanctionStatus
{
    Cleared = 1,
    Rejected = 2,
    OnHold = 3,
    Unknown = 99,
}