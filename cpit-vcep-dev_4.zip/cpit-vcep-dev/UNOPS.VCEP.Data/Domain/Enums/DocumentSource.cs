namespace UNOPS.VCEP.Data.Domain;

public enum DocumentSource
{
    ADB = 1,
    Claimant = 3,
    MoF = 2,      // Ministry of Finance
    MPW = 4,      // Ministry of Public Work
    MoPH = 5,     // Ministry of Public Health
    MRRD = 6,     // Ministry of Rural Rehabilitation Development
    MAIL = 7,     // Ministry of Agriculture Irrigation and Livestock
    DABS = 8,     // D Afghanistan Brishna Sherkat
    MEW = 9,      // Ministry of Energy and Water
    Unknown = 99,
}
