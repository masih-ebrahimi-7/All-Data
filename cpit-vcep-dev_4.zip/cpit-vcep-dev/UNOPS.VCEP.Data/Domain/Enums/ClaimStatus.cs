using System.ComponentModel;
using UNOPS.VCEP.Infrastructure.Attributes;

namespace UNOPS.VCEP.Data.Domain;

public enum ClaimStatus
{
    [Description("Awaiting Clearance")]
    [LongDescription("Claims submitted by an external user awaiting initial clearance")]
    [Style(StyleUtility.Warning, "security")]
    AwaitingClearance = 0,
    
    [Description("Created")]
    [LongDescription("Claim entry")]
    [Style(StyleUtility.Primary, "edit")]
    Created = 1,

    [Description("Initial review")]
    [LongDescription("Claim data to be reviewed by legal, technical, contracts, finance")]
    [Style(StyleUtility.Success, "fact_check")]
    InitialReview = 2,

    [Description("Documents Request")]
    [LongDescription("Claim requires additional documents")]
    [Style(StyleUtility.Warning, "upload_file")]
    DocumentsRequest = 3,

    [Description("Documents review")]
    [LongDescription("Claim documentation under analysis")]
    [Style(StyleUtility.Primary, "rule")]
    DocumentsReview = 4,

    [Description("Additional Documents request")]
    [LongDescription("Claim requires additional documents")]
    [Style(StyleUtility.Warning, "upload_file")]
    AdditionalDocumentsRequest = 5,

    [Description("Site verification")]
    [LongDescription("Perform site data verification")]
    [Style(StyleUtility.Primary, "task")]
    SiteVerification = 6,

    [Description("Analysis and Verification")]
    [LongDescription("Analysis and Verification")]
    [Style(StyleUtility.Success, "checklist_rtl")]
    AnalysisAndVerification = 7,

    [Description("Draft Report Submission")]
    [LongDescription("Submission of the Draft Report.")]
    [Style(StyleUtility.Success, "preview")]
    DraftReportSubmission = 8,

    [Description("Donor review.")]
    [LongDescription("Perform donor review on claim.")]
    [Style(StyleUtility.Success, "approval")]
    DonorReview = 9,

    [Description("Final Documents Request")]
    [LongDescription("Additional Documents request")]
    [Style(StyleUtility.Warning, "upload_file")]
    FinalDocumentsRequest = 10,

    [Description("Final Verification Report")]
    [LongDescription("Conduct the Final Verification Report")]
    [Style(StyleUtility.Primary, "interpreter_mode")]
    FinalVerificationReport = 11,

    [Description("Submission of the Final Report")]
    [LongDescription("Submission of the Final Report")]
    [Style(StyleUtility.Success, "upload_file")]
    FinalVerificationReportSubmission = 12,

    [Description("Negotiations")]
    [LongDescription("Conduct payment negotiations")]
    [Style(StyleUtility.Success, "interpreter_mode")]
    PaymentNegotiations = 13,
    
    [Description("Payment certificate")]
    [LongDescription("Draft payment certificate")]
    [Style(StyleUtility.Success, "paid")]
    PaymentCertificate = 14,
    
    [Description("Closure")]
    [LongDescription("Close claim")]
    [Style(StyleUtility.Success, "done_all")]
    Closure = 15,

    [Ignore]
    [Description("Undo previous status")]
    [LongDescription("")]
    [Style(StyleUtility.Danger, "undo")]
    Back = 99,
    
    [Description("Claim Rejected")]
    [LongDescription("Claim does not match clearance requirements")]
    [Style(StyleUtility.Danger, "error")]
    Rejected = 98,
}

public class StyleUtility
{
    public const string Success = "accent";
    public const string Danger = "warn";
    public const string Primary = "primary";
    public const string Warning = "warn";
}