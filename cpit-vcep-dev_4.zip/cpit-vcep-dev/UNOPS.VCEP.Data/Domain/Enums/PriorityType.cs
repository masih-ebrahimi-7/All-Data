using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain;

public enum PriorityType
{
    [Description("Priority #1")]
    First = 1,
    [Description("Priority #2")]
    Second = 2,
    [Description("Priority #3")]
    Third = 3,
    [Description("Priority #4")]
    Fourth = 4
}