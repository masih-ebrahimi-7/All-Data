namespace UNOPS.VCEP.Data.Domain;

public enum PaymentPurposeType
{
    PMO = 1,
    CivilWork = 2,
    ConsultantFirm = 3,
    ConsultantIndividual = 4,
    SupplierGoods = 5,
    Retention = 6,
    Other = 7
}