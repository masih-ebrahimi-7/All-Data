﻿namespace UNOPS.VCEP.Data.Domain.Enums
{
    public enum LeadReportType
    {
        Finance = 1,
        Legal,
        Technical,
        Contracts
    }
}
