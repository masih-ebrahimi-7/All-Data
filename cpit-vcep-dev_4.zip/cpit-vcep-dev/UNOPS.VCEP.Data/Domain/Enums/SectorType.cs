namespace UNOPS.VCEP.Data.Domain;

public enum SectorType
{
    Transport = 1,
    Energy = 2,
    Health = 3,
    ANR = 4,
    Other = 5
}
