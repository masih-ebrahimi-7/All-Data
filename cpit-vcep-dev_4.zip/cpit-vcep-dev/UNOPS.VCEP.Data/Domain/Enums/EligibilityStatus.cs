namespace UNOPS.VCEP.Data.Domain.Enums
{
    public enum EligibilityStatus
    {
        Eligible = 1,
        Ineligible = 2
    }
}

