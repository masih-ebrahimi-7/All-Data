using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain.Enums;

public enum ContractingAuthorityType
{
    [Description("MAIL")]
    MAIL = 1,
    [Description("NWARA")]
    NWARA = 2,
    [Description("MEW")]
    MEWMAIL = 3,
    [Description("DABS")]
    DABS = 4,
    [Description("MOPH")]
    MOPH = 5,
    [Description("MPW")]
    MPW = 6,
    [Description("MRRD")]
    MRRD = 7,
    [Description("Unknown")]
    Unknown = 99,
}