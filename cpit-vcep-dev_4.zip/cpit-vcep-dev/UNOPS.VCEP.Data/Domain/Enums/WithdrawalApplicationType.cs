using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain.Enums;

public enum WithdrawalApplicationType
{
    [Description("Liquidation & Replenishment")]
    LiquidationReplenishment = 1,
    [Description("Initial Advance")]
    InitialAdvance = 2,
    [Description("Additional Advance")]
    AdditionalAdvance = 3,
    [Description("Replenishment")]
    Replenishment = 4,
    [Description("Liquidation")]
    Liquidation = 5,

    Unknown = 99
}