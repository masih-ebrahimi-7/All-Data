namespace UNOPS.VCEP.Data.Domain;

public enum RemarkType
{
    Remark = 0,
    Claim = 1
}
