namespace UNOPS.VCEP.Data.Domain.Enums
{
    public enum SubClaimType
    {
        Invoice = 1,
        IPC = 2
    }
}

