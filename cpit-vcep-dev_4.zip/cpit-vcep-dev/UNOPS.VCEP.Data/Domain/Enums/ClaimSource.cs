namespace UNOPS.VCEP.Data.Domain;

public enum ClaimSource
{
    ADB = 1,
    MoF = 2,
    Claimant = 3,
    Unknown = 4,
}
