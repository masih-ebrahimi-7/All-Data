namespace UNOPS.VCEP.Data.Domain;

public enum TaskStatus
{
    New = 1,
    InProgress = 2,
    ForReview = 3,
    Done = 4
}
