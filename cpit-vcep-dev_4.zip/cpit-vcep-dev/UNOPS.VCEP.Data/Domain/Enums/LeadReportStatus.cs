﻿using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain.Enums
{
    public enum LeadReportStatus
    {
        [Description("In Draft")]
        Draft = 1,
        [Description("Under Review")]
        UnderReview,
        [Description("Accepted")]
        Accepted
    }
}
