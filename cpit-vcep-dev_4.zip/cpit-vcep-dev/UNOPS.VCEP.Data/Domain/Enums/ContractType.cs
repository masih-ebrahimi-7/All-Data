using System.ComponentModel;
using UNOPS.VCEP.Infrastructure.Enums;

namespace UNOPS.VCEP.Data.Domain;

public enum ContractType
{
    [Description("Civil Work Contractors")]
    CivilWorkContractors = 1,
    [Description("Suppliers")]
    Suppliers = 2,
    [Description("Consultant Firm")]
    ConsultantFirm = 3,
    [EnumDisplayName("IND.CONS")]
    [Description("Individual Consultant")]
    IndividualConsultant = 4,
    // UnpaidInstallation = 5,
    // UnpaidSupply = 6,
    // UnpaidInvoices = 7,
    [Description("Maintenance")]
    Maintenance = 8,
    [Description("Community Development Councils")]
    [EnumDisplayName("CDC")]
    Cdc = 9,
    [Description("Suppliers-Output2")]
    [EnumDisplayName("Suppliers-Output2")]
    SupplierOutputTwo = 10,
    [Description("Unknown")]
    Unknown = 99,
}