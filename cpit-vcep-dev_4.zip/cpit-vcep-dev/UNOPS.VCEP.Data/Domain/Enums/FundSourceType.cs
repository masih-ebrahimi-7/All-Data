using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain;

public enum FundSourceType
{
    [Description("ADB")]
    Adb = 1,
    [Description("ADF")]
    Adf = 2,
    [Description("ADF-EU")]
    AdfEu = 3,
    [Description("ADF/AITF Japan")]
    AdfAitfJapan = 4,
    [Description("AITF (ANATF)")]
    AitfAnatf = 5,
    [Description("AITF (USAID+ANATF)")]
    AitfUsaidAnatf = 6,
    [Description("EU")]
    Eu = 7,
    [Description("ADF/AITF")]
    AdfAitf = 8,
    [Description("ADF (UK + Denmark)")]
    AdfUkDenmark = 9,
    [Description("IFAD")]
    Ifad = 10,
    [Description("Unknown")]
    Unknown = 99,
}