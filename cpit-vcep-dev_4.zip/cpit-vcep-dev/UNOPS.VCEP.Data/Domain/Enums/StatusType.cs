using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain;

public enum StatusType
{
    [Description("Pending Review")]
    PendingReview = 1,
    [Description("In Review")]
    InReview = 2,
    [Description("Rejected")]
    Rejected = 3,
    [Description("Approved")]
    Approved = 4
}