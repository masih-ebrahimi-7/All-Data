namespace UNOPS.VCEP.Data.Domain;

public enum TaskUserType
{
    Internal = 1,
    MoF = 2,
    Donor = 3,
    Claimant = 4,
    MPW = 5,
    MoPH = 6,
    MRRD = 7,
    MAIL = 8,
    DABS = 9,
    MEW = 10
}
