using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain;

public enum AuthorityType
{
    PMO = 2,
    MOF = 1
}