using System.ComponentModel;

namespace UNOPS.VCEP.Data.Domain.Enums;

public enum StaffEmployerType
{
    [Description("MPW PMO")]
    MpwPmo = 1,
    [Description("DABS PMO")]
    DabsPmo = 2,
    [Description("ANR - MAIL CPMO")]
    AnrMailCpmo = 3,
    [Description("ANR - MAIL - Project")]
    AnrMailProject = 4,
    [Description("ANR - NWARA - MOF Based")]
    AnrNwaraMofBased = 5,
    [Description("ANR - NWARA - MOF")]
    AnrNwaraMof = 6,
    [Description("ANR - NWARA - CAESU Based")]
    AnrNwaraCaesuBased = 7,
    [Description("ANR - MRRD CPMO")]
    AnrMrrdCpmo = 8,
    [Description("Health Sector PMO")]
    HealthSectorPmo = 9,
    [Description("ARA PMO")]
    AraPmo = 10,
    [Description("ANR - NWARA CPMO")]
    AnrNwaraCpmo = 11,
    [Description("Other")]
    Other = 99
} 