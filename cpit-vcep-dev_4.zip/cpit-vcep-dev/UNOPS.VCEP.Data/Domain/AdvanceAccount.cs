using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;

namespace UNOPS.VCEP.Data.Domain;

public class AdvanceAccount : ModifiableDeletableEntity
{
    public AdvanceAccount()
    {
    }

    public AdvanceAccount(WithdrawalApplication? latestWithdrawalApplication)
    {
        LatestWithdrawalApplication = latestWithdrawalApplication;
    }

    public AdvanceAccount(AdvanceAccountBaseModel c)
    {
        Reference = $"ADV-{c.AccountNumber}";
        AccountName = c.AccountName;
        AccountNumber = c.AccountNumber;
        GrantId = c.GrantId;
        CurrencyId = c.CurrencyId;
        FundSource = EnumExtensions.IsValidEnumValue<FundSourceType>(c.FundSource)
            ? (FundSourceType)c.FundSource
            : FundSourceType.Unknown;
        Sector = c.Sector;
        ImplementingAgency = c.ImplementingAgency;
        DistributionDate = c.DistributionDate.ToUTCDate();
        LatestDisbursementDate = c.LatestDisbursementDate?.ToUTCDate();
        LastDistributionAmount = c.LastDistributionAmount;
        UnliquidatedAmountUsd = c.UnliquidatedAmountUsd;
        BankBalanceAccountCurrency = c.BankBalanceAccountCurrency;
        UncreditedAmount = c.UncreditedAmount;
        NewOtherReceiptsAmount = c.NewOtherReceiptsAmount;
        NewExpensesPaymentsAmount = c.NewExpensesPaymentsAmount;
        VerifiedExpensesPaymentsAmount = c.VerifiedExpensesPaymentsAmount;
        RejectedExpensesPaymentsAmount = c.RejectedExpensesPaymentsAmount;
        LatestWithdrawalApplication = c.LatestWithdrawalApplication != null
            ? new WithdrawalApplication(c.LatestWithdrawalApplication)
            : null;
    }

    public string Reference { get; private set; }
    public string AccountName { get; private set; }
    public string AccountNumber { get; private set; }
    public string CurrencyId { get; private set; }
    public FundSourceType FundSource { get; private set; }
    public SectorType Sector { get; private set; }
    public string ImplementingAgency { get; private set; }
    public DateTime DistributionDate { get; private set; }
    public DateTime? LatestDisbursementDate { get; private set; }
    public decimal LastDistributionAmount { get; private set; }
    public decimal UnliquidatedAmountUsd { get; private set; }
    public decimal BankBalanceAccountCurrency { get; private set; }
    public decimal? UncreditedAmount { get; private set; }
    public decimal? NewOtherReceiptsAmount { get; private set; }
    public decimal? NewExpensesPaymentsAmount { get; private set; }
    public decimal? VerifiedExpensesPaymentsAmount { get; private set; }
    public decimal? RejectedExpensesPaymentsAmount { get; private set; }
    public int? LatestWithdrawalApplicationId { get; private set; }
    public virtual Grant? Grant { get; }
    public int? GrantId { get; set; }
    public virtual WithdrawalApplication? LatestWithdrawalApplication { get; }

    public void Update(AdvanceAccountBaseModel model)
    {
        UpdateReference(model.AccountName);
        UpdateAccountName(model.AccountName);
        UpdateAccountNumber(model.AccountNumber);
        UpdateGrant(model.GrantId);
        UpdateFundSource(model.FundSource);
        UpdateSector(model.Sector);
        UpdateImplementingAgency(model.ImplementingAgency);
        UpdateDistributionDate(model.DistributionDate);
        UpdateLatestDisbursementDate(model.LatestDisbursementDate);
        UpdateLastDistributionAmount(model.LastDistributionAmount);
        UpdateCurrencyId(model.CurrencyId);
        UpdateUnliquidatedAmountUsd(model.UnliquidatedAmountUsd);
        UpdateBankBalanceAccountCurrency(model.BankBalanceAccountCurrency);
        UpdateUncreditedAmount(model.UncreditedAmount);
        UpdateNewOtherReceiptsAmount(model.NewOtherReceiptsAmount);
        UpdateNewExpensesPaymentsAmount(model.NewExpensesPaymentsAmount);
        UpdateVerifiedExpensesPaymentsAmount(model.VerifiedExpensesPaymentsAmount);
        UpdateRejectedExpensesPaymentsAmount(model.RejectedExpensesPaymentsAmount);
    }

    private void UpdateReference(string accountNumber)
    {
        if (!string.IsNullOrEmpty(accountNumber))
        {
            Reference = $"ADV-{accountNumber}";
        }
    }

    private void UpdateAccountName(string accountName)
    {
        if (!string.IsNullOrEmpty(accountName))
        {
            AccountName = accountName;
        }
    }

    private void UpdateGrant(int? grantId)
    {
        GrantId = grantId;
    }

    private void UpdateCurrencyId(string currencyId)
    {
        CurrencyId = currencyId;
    }

    private void UpdateAccountNumber(string? accountNumber)
    {
        if (accountNumber != null)
        {
            AccountNumber = accountNumber;
        }
    }

    private void UpdateFundSource(FundSourceType? fundSource)
    {
        if (fundSource.HasValue)
        {
            FundSource = fundSource.Value;
        }
    }

    private void UpdateSector(SectorType? sector)
    {
        if (sector.HasValue)
        {
            Sector = sector.Value;
        }
    }

    private void UpdateImplementingAgency(string implementingAgency)
    {
        if (!string.IsNullOrEmpty(implementingAgency))
        {
            ImplementingAgency = implementingAgency;
        }
    }

    private void UpdateDistributionDate(DateTime distributionDate)
    {
        DistributionDate = distributionDate.ToUTCDate();
    }

    private void UpdateLatestDisbursementDate(DateTime? latestDisbursementDate)
    {
        if (latestDisbursementDate != null)
            LatestDisbursementDate = latestDisbursementDate?.ToUTCDate();
    }

    private void UpdateLastDistributionAmount(decimal? lastDistributionAmount)
    {
        if (lastDistributionAmount.HasValue)
        {
            LastDistributionAmount = lastDistributionAmount.Value;
        }
    }

    private void UpdateUnliquidatedAmountUsd(decimal newAmount)
    {
        UnliquidatedAmountUsd = newAmount;
    }

    private void UpdateBankBalanceAccountCurrency(decimal newBalance)
    {
        BankBalanceAccountCurrency = newBalance;
    }

    private void UpdateUncreditedAmount(decimal? newAmount)
    {
        UncreditedAmount = newAmount;
    }

    private void UpdateNewOtherReceiptsAmount(decimal? newAmount)
    {
        NewOtherReceiptsAmount = newAmount;
    }

    private void UpdateNewExpensesPaymentsAmount(decimal? newAmount)
    {
        NewExpensesPaymentsAmount = newAmount;
    }

    private void UpdateVerifiedExpensesPaymentsAmount(decimal? newAmount)
    {
        VerifiedExpensesPaymentsAmount = newAmount;
    }

    private void UpdateRejectedExpensesPaymentsAmount(decimal? newAmount)
    {
        RejectedExpensesPaymentsAmount = newAmount;
    }
}