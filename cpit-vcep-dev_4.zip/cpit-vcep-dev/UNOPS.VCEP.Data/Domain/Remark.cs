using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;
public class Remark : ModifiableDeletableEntity
{
    public Remark(){}
    public Remark(CreateRemarkModel r)
    {
        this.RemarkText = r.RemarkText;
        this.EntityId = r.EntityId;
        this.ParentId = r.ParentId;
        this.IsTask = r.IsTask;
        this.AssignedTo = r.AssignedTo;
        this.TaskUserType = r.TaskUserType;
        this.IsExternal = r.IsExternal;
        this.Deadline = r.Deadline;
        this.EntityType = (RemarkType)r.EntityType;

        // If it's any ministry or donor, make it a task regardless
        if (this.TaskUserType != Domain.TaskUserType.Internal && this.TaskUserType != Domain.TaskUserType.Claimant)
        {
            this.IsTask = true;
            this.AssignedTo = r.AssignedTo ?? this.TaskUserType.ToString();
        }
        if (this.IsTask.HasValue && this.IsTask.Value)
        {
            this.TaskStatus = Domain.TaskStatus.New;
        }
    }

    public string RemarkText { get; set; }
    public int EntityId { get; set; }
    public RemarkType EntityType { get; set; }
    public int? ParentId { get; set; }
    public bool? IsTask { get; set; }
    public bool? IsExternal { get; set; }
    public string? AssignedTo { get; set; }
    public TaskUserType TaskUserType { get; set; }
    public TaskStatus? TaskStatus { get; set; }
    public DateTime? Deadline { get; set; }
    public virtual Remark? Parent { get; set; }
    public virtual ICollection<Remark>? Replies { get; set; }
    public virtual Claim? Claim { get; set; }
    public (int Days, int Hours) CalculateTimeSinceLastModified()
    {
        DateTime referenceDate = LastModifiedDate ?? CreatedDate;
        TimeSpan timeSinceLastModified = DateTime.Now - referenceDate;

        int days = (int)timeSinceLastModified.TotalDays;
        int hours = (int)(timeSinceLastModified.TotalHours % 24);

        return (days, hours);
    }
}

public abstract class Remark<T> : ModifiableDeletableEntity where T : Remark
{

}