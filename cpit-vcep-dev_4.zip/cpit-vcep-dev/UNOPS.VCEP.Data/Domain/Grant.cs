using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class Grant : ModifiableDeletableEntity
{
    public Grant()
    {
    }

    public Grant(int id)
    {
        this.Id = id;
    }

    public Grant(GrantRequestModel model)
    {
        this.Name = model.Name;
        this.Reference = $"G{model.Reference}";
        this.Description = model.Description;
        this.Sector = EnumExtensions.IsValidEnumValue<SectorType>(model.Sector)
            ? (SectorType)model.Sector
            : SectorType.Other;
        this.Priority = EnumExtensions.IsValidEnumValue<PriorityType>(model.Priority)
            ? (PriorityType)model.Priority
            : PriorityType.Fourth;
    }

    public string Name { get; set; }
    public string Reference { get; set; }
    public string? Description { get; set; }
    public SectorType Sector { get; set; }
    public PriorityType Priority { get; set; }
    public string? GoogleDriveFolderId { get; set; }
    public virtual ICollection<Contract>? Contracts { get; set; }
    public virtual ICollection<Expense>? Expenses { get; set; }
    public virtual ICollection<ProjectAgreement>? ProjectAgreements { get; set; }

    public void UpdateName(string grantName)
    {
        if (!string.IsNullOrEmpty(grantName) && grantName != this.Name)
        {
            this.Name = grantName;
        }
    }

    public void UpdateReference(string grantReference)
    {
        if (!string.IsNullOrEmpty(grantReference) && grantReference != this.Reference)
        {
            this.Reference = grantReference;
        }
    }

    public void UpdateDescription(string? grantDescription)
    {
        if (!string.IsNullOrEmpty(grantDescription) && grantDescription != this.Description)
        {
            this.Description = grantDescription;
        }
    }

    public void UpdatePriority(int newPriority)
    {
        if (Enum.IsDefined(typeof(PriorityType), newPriority) && (PriorityType)newPriority != this.Priority)
        {
            this.Priority = (PriorityType)newPriority;
        }
    }

    public void UpdateSector(int newSector)
    {
        if (Enum.IsDefined(typeof(SectorType), newSector) && (SectorType)newSector != this.Sector)
        {
            this.Sector = (SectorType)newSector;
        }
    }
}