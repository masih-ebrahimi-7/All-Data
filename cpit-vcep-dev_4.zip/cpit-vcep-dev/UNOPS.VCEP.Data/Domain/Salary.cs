﻿using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class Salary : ModifiableDeletableEntity
    {
        public Salary()
        {
        }

        public string Reference { get; private set; }
        public int StaffId { get; private set; }
        public virtual Staff Staff { get; private set; }
        public int? GrantId { get; private set; }
        public virtual Grant? Grant { get; private set; }
        public int StaffContractId { get; private set; }
        public virtual StaffContract StaffContract { get; private set; }
        public decimal? PendingForJanuary21 { get; private set; }
        public decimal? PendingForFebruary21 { get; private set; }
        public decimal? PendingForMarch21 { get; private set; }
        public decimal? PendingForApril21 { get; private set; }
        public decimal? PendingForMay21 { get; private set; }
        public decimal? PendingForJune21 { get; private set; }
        public decimal? PendingForJuly21 { get; private set; }
        public decimal? PendingForAugust21 { get; private set; }
        public decimal? TotalPendingSalary { get; private set; }
        public decimal? TerminationPayment { get; private set; }
        public decimal? TaxDeductible { get; private set; }
        public decimal? Advance { get; private set; }
        public string? ContractDocumentUrl { get; private set; }
        public string? TimeSheetDocumentUrl { get; private set; }
        public string? PreviousRecord { get; private set; }
        public bool NonPaymentConfirmation { get; private set; }
        public ADBSanctionStatus AdbSanctionStatus { get; private set; }
        public DateTime? ScreeningDate { get; private set; }
        public string? Remarks { get; private set; }

        public Salary(SalaryBaseModel model)
        {
            Reference = $"SAL-{StaffId}-{StaffContractId}";
            StaffId = model.StaffId;
            GrantId = model.GrantId;
            StaffContractId = model.StaffContractId;
            PendingForJanuary21 = model.PendingForJanuary21;
            PendingForFebruary21 = model.PendingForFebruary21;
            PendingForMarch21 = model.PendingForMarch21;
            PendingForApril21 = model.PendingForApril21;
            PendingForMay21 = model.PendingForMay21;
            PendingForJune21 = model.PendingForJune21;
            PendingForJuly21 = model.PendingForJuly21;
            PendingForAugust21 = model.PendingForAugust21;
            TotalPendingSalary = model.TotalPendingSalary;
            TerminationPayment = model.TerminationPayment;
            TaxDeductible = model.TaxDeductible;
            Advance = model.Advance;
            ContractDocumentUrl = model.ContractDocumentUrl;
            TimeSheetDocumentUrl = model.TimeSheetDocumentUrl;
            PreviousRecord = model.PreviousRecord;
            NonPaymentConfirmation = model.NonPaymentConfirmation;
            AdbSanctionStatus = model.ADBSanctionStatus;
            ScreeningDate = model.ScreeningDate;
            Remarks = model.Remarks;
        }

        private void UpdateStaffId(int staffId)
        {
            StaffId = staffId;
        }

        private void UpdateGrantId(int? grantId)
        {
            GrantId = grantId;
        }

        private void UpdateStaffContractId(int staffContractId)
        {
            StaffContractId = staffContractId;
        }

        private void UpdatePendingForJanuary21(decimal? amount)
        {
            PendingForJanuary21 = amount;
        }

        private void UpdatePendingForFebruary21(decimal? amount)
        {
            PendingForFebruary21 = amount;
        }

        private void UpdatePendingForMarch21(decimal? amount)
        {
            PendingForMarch21 = amount;
        }

        private void UpdatePendingForApril21(decimal? amount)
        {
            PendingForApril21 = amount;
        }

        private void UpdatePendingForMay21(decimal? amount)
        {
            PendingForMay21 = amount;
        }

        private void UpdatePendingForJune21(decimal? amount)
        {
            PendingForJune21 = amount;
        }

        private void UpdatePendingForJuly21(decimal? amount)
        {
            PendingForJuly21 = amount;
        }

        private void UpdatePendingForAugust21(decimal? amount)
        {
            PendingForAugust21 = amount;
        }

        private void UpdateTotalPendingSalary(decimal? totalPendingSalary)
        {
            TotalPendingSalary = totalPendingSalary;
        }

        private void UpdateTerminationPayment(decimal? terminationPayment)
        {
            TerminationPayment = terminationPayment;
        }

        private void UpdateTaxDeductible(decimal? taxDeductible)
        {
            TaxDeductible = taxDeductible;
        }

        private void UpdateAdvance(decimal? advance)
        {
            Advance = advance;
        }

        private void UpdateContractDocumentUrl(string? url)
        {
            ContractDocumentUrl = url;
        }

        private void UpdateTimeSheetUrl(string? url)
        {
            TimeSheetDocumentUrl = url;
        }

        private void UpdatePreviousRecord(string? previousRecord)
        {
            PreviousRecord = previousRecord;
        }

        private void UpdateNonPaymentConfirmation(bool nonPaymentConfirmation)
        {
            NonPaymentConfirmation = nonPaymentConfirmation;
        }

        private void UpdateAdbSanctionStatus(int adbSanctionStatus)
        {
            AdbSanctionStatus = (ADBSanctionStatus)adbSanctionStatus;
        }

        private void UpdateScreeningDate(DateTime? screeningDate)
        {
            ScreeningDate = screeningDate;
        }

        private void UpdateRemarks(string? remarks)
        {
            Remarks = remarks;
        }

        public void Update(SalaryBaseModel salary)
        {
            UpdateStaffId(salary.StaffId);
            UpdateGrantId(salary.GrantId);
            UpdateStaffContractId(salary.StaffContractId);
            UpdatePendingForJanuary21(salary.PendingForJanuary21);
            UpdatePendingForFebruary21(salary.PendingForFebruary21);
            UpdatePendingForMarch21(salary.PendingForMarch21);
            UpdatePendingForApril21(salary.PendingForApril21);
            UpdatePendingForMay21(salary.PendingForMay21);
            UpdatePendingForJune21(salary.PendingForJune21);
            UpdatePendingForJuly21(salary.PendingForJuly21);
            UpdatePendingForAugust21(salary.PendingForAugust21);
            UpdateTotalPendingSalary(salary.TotalPendingSalary);
            UpdateTerminationPayment(salary.TerminationPayment);
            UpdateTaxDeductible(salary.TaxDeductible);
            UpdateAdvance(salary.Advance);
            UpdateContractDocumentUrl(salary.ContractDocumentUrl);
            UpdateTimeSheetUrl(salary.TimeSheetDocumentUrl);
            UpdatePreviousRecord(salary.PreviousRecord);
            UpdateNonPaymentConfirmation(salary.NonPaymentConfirmation);
            UpdateAdbSanctionStatus((int)salary.ADBSanctionStatus);
            UpdateScreeningDate(salary.ScreeningDate);
            UpdateRemarks(salary.Remarks);
        }
    }
}