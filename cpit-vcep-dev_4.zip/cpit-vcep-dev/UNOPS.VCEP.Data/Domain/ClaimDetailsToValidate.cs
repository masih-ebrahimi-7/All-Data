using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class ClaimDetailsToValidate : ModifiableDeletableEntity
{
    public ClaimDetailsToValidate()
    {
    }

    public ClaimDetailsToValidate(ClaimDataToValidateModel model)
    {
        this.GrantDetails = model.GrantDetails;
        this.GrantDetailsValidated = model.GrantDetailsValidated;
        this.GrantDetailsValidatedBy = model.GrantDetailsValidatedBy;

        this.ProjectAgreementDetails = model.ProjectAgreementDetails;
        this.ProjectAgreementDetailsValidated = model.ProjectAgreementDetailsValidated;
        this.ProjectAgreementDetailsValidatedBy = model.ProjectAgreementDetailsValidatedBy;

        this.ContractDetails = model.ContractDetails;
        this.ContractDetailsValidated = model.ContractDetailsValidated;
        this.ContractDetailsValidatedBy = model.ContractDetailsValidatedBy;

        this.ContractorDetails = model.ContractorDetails;
        this.ContractorDetailsValidated = model.ContractorDetailsValidated;
        this.ContractorDetailsValidatedBy = model.ContractorDetailsValidatedBy;
    }

    public int ClaimId { get; set; }
    public Claim Claim { get; set; } = null!;
    public string? GrantDetails { get; set; }
    public bool GrantDetailsValidated { get; set; } = false;
    public string? GrantDetailsValidatedBy { get; set; }

    public string? ProjectAgreementDetails { get; set; }
    public bool ProjectAgreementDetailsValidated { get; set; } = false;
    public string? ProjectAgreementDetailsValidatedBy { get; set; }

    public string? ContractDetails { get; set; }
    public bool ContractDetailsValidated { get; set; } = false;
    public string? ContractDetailsValidatedBy { get; set; }

    public string? ContractorDetails { get; set; }
    public bool ContractorDetailsValidated { get; set; } = false;
    public string? ContractorDetailsValidatedBy { get; set; }
}