namespace UNOPS.VCEP.Data.Domain;

public static class OutputType
{
    public const string AwaitingClearance = "awaiting-clearance";
    public const string OutputOne = "output-one";
    public const string OutputTwo = "output-two";
    public const string Rejected = "rejected";
}
