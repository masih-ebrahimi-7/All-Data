using UNOPS.VCEP.Data.Domain.Enums;
using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class ClaimContractingAuthority: ModifiableDeletableEntity
{
    public ClaimContractingAuthority(ContractingAuthorityType contractingAuthority)
    {
        this.ContractingAuthority = contractingAuthority;
    }

    public ClaimContractingAuthority(int claimId, ContractingAuthorityType contractingAuthority)
    {
        this.ContractingAuthority = contractingAuthority;
        this.ClaimId = claimId;
    }

    public ClaimContractingAuthority()
    {
    }

    public int ClaimId { get; set; }
    public virtual Claim Claim { get; set; }
    public ContractingAuthorityType ContractingAuthority { get; set; }
}