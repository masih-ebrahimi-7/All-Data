﻿using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain
{
    public class Document : ModifiableDeletableEntity
    {
        public Document()
        {
        }

        public string OriginalName { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string GoogleDriveId { get; set; }
        public bool Linked { get; set; }
        public int? DocumentCategoryId { get; set; }
        public virtual DocumentCategory? DocumentCategory { get; set; }
        public DocumentSource DocumentSource { get; set; }
        public string? OriginalDriveLink { get; set; }

        public void UpdateCategoryId(int? newCategoryId)
        {
            this.DocumentCategoryId = newCategoryId;
        }

        public void UpdateName(string? name)
        {
            if (!string.IsNullOrEmpty(name) && name != Name)
            {
                Name = name;
            }
        }

        public void UpdateSource(int? documentSource)
        {
            if (documentSource.HasValue && Enum.IsDefined(typeof(DocumentSource), documentSource) &&
                (DocumentSource)documentSource != this.DocumentSource)
            {
                DocumentSource = (DocumentSource)documentSource;
            }
        }
    }
}