using UNOPS.VCEP.Infrastructure;

namespace UNOPS.VCEP.Data.Domain;

public class Payment : ModifiableDeletableEntity
{
    public Payment()
    {
    }
    public decimal? Amount { get; private set; }
    public decimal AmountUsd { get; private set; }
    public string CurrencyId { get; private set; }
    public DateTime? Date { get; private set; }
    public PriorityType? Priority { get; set; }
    public PaymentPurposeType? AuthorityType { get; private set; }
}