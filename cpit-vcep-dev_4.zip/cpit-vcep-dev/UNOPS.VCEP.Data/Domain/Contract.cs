using UNOPS.VCEP.Data.Models;
using UNOPS.VCEP.Infrastructure;
using UNOPS.VCEP.Infrastructure.Domain;
using UNOPS.VCEP.Infrastructure.Helpers;
using UNOPS.VCEP.Infrastructure.Interfaces;

namespace UNOPS.VCEP.Data.Domain;

public class Contract : ModifiableDeletableEntity
{
    public Contract(string currencyId, string deletedBy)
    {
        CurrencyId = currencyId;
        DeletedBy = deletedBy;
    }

    public Contract(ContractRequestModel c)
    {
        Name = c.Name;
        Reference = $"C-{c.Reference}";
        Description = c.Description;
        PcssNumber = c.PcssNumber;
        FundSource = c.FundSource;
        StartDate = c.StartDate;
        EndDate = c.EndDate;
        RevisedEndDate = c.RevisedEndDate;
        ContractType = EnumExtensions.IsValidEnumValue<ContractType>(c.ContractType)
            ? (ContractType)c.ContractType
            : ContractType.Unknown;
        PriorityType = EnumExtensions.IsValidEnumValue<PriorityType>(c.PriorityType)
            ? (PriorityType)c.PriorityType
            : PriorityType.Fourth;
        Amount = c.Amount;
        CurrencyId = c.CurrencyId;
        Disbursement = c.Disbursement;
        UndisbursedAmount = c.UndisbursedAmount;
        ExternalEntityId = c.ExternalEntityId;
        Location = c.Location != null ? new Location(c.Location) : null;
    }

    public Contract(ContractRequestModel c, ICollection<Grant> grants) : this(c)
    {
        AddGrants(grants);
    }

    private void AddGrants(ICollection<Grant> grants)
    {
        Grants = new List<Grant>(grants);
    }

    public string Name { get; private set; }
    public string Reference { get; private set; }
    public string? Description { get; private set; }
    public ContractType ContractType { get; private set; }
    public PriorityType PriorityType { get; private set; }
    public string? PcssNumber { get; private set; }
    public string FundSource { get; private set; }
    public decimal AmountUsd { get; private set; }
    public string CurrencyId { get; private set; }
    public decimal Amount { get; private set; }
    public decimal? Disbursement { get; private set; }
    public decimal? UndisbursedAmount { get; private set; }
    public DateTime? StartDate { get; private set; }
    public DateTime? EndDate { get; private set; }
    public DateTime? RevisedEndDate { get; private set; }
    public string? ImplementingAgency { get; private set; }
    public string? ExecutingAgency { get; private set; }
    public string? GoogleDriveFolderId { get; set; }
    public virtual ExternalEntity? Contractor { get; }
    public int? ExternalEntityId { get; private set; }
    public int? ProjectAgreementId { get; private set; }
    public virtual ProjectAgreement? ProjectAgreement { get; }

    public virtual Claim? Claim { get; }
    public int? ClaimId { get; private set; }
    public Location? Location { get; private set; }
    public int? LocationId { get; private set; }
    public virtual ICollection<Invoice>? Invoices { get; private set; }
    public virtual ICollection<WithdrawalApplication>? WithdrawalApplications { get; private set; }
    public virtual ICollection<Grant>? Grants { get; set; }

    public void Update(ContractRequestModel updateContract, ICollection<Grant> linkedGrants)
    {
        if (updateContract == null)
        {
            throw new ArgumentNullException(nameof(updateContract));
        }

        UpdateName(updateContract.Name);
        UpdateReference(updateContract.Reference);
        UpdateDescription(updateContract.Description);
        UpdateContractType(updateContract.ContractType);
        UpdatePriorityType(updateContract.PriorityType);
        UpdatePcssNumber(updateContract.PcssNumber);
        UpdateStartDate(updateContract.StartDate);
        UpdateRevisedEndDate(updateContract.RevisedEndDate);
        UpdateEndDate(updateContract.EndDate);
        UpdateCurrencyId(updateContract.CurrencyId);
        UpdateFundSource(updateContract.FundSource);
        UpdateAmount(updateContract.Amount);
        UpdateDisbursement(updateContract.Disbursement);
        UpdateUndisbursedAmount(updateContract.UndisbursedAmount);
        UpdateImplementingAgency(updateContract.ImplementingAgency);
        UpdateExecutingAgency(updateContract.ExecutingAgency);
        UpdateExternalEntity(updateContract.ExternalEntityId);
        UpdateLocation(updateContract.Location);
        AddGrants(linkedGrants);
    }

    private void UpdateExternalEntity(int? updateContractExternalEntityId)
    {
        if (updateContractExternalEntityId.HasValue && updateContractExternalEntityId != this.ExternalEntityId)
        {
            this.ExternalEntityId = updateContractExternalEntityId;
        }
    }

    private void UpdateLocation(ContractLocationModel? updateContractLocation)
    {
        if (updateContractLocation != null)
            this.Location = new Location(updateContractLocation);
    }

    private void UpdateName(string name)
    {
        if (!string.IsNullOrEmpty(name) && name != Name)
        {
            Name = name;
        }
    }

    private void UpdateReference(string reference)
    {
        if (!string.IsNullOrEmpty(reference) && reference != Reference)
        {
            Reference = reference;
        }
    }

    private void UpdateDescription(string? description)
    {
        if (description != Description)
        {
            Description = description;
        }
    }

    private void UpdateContractType(int contractType)
    {
        if (Enum.IsDefined(typeof(ContractType), contractType) && (ContractType)contractType != this.ContractType)
        {
            ContractType = (ContractType)contractType;
        }
    }

    private void UpdatePriorityType(int priorityType)
    {
        if (Enum.IsDefined(typeof(PriorityType), priorityType) && (PriorityType)priorityType != this.PriorityType)
        {
            PriorityType = (PriorityType)priorityType;
        }
    }

    private void UpdatePcssNumber(string? pcssNumber)
    {
        if (pcssNumber != PcssNumber)
        {
            PcssNumber = pcssNumber;
        }
    }

    private void UpdateStartDate(DateTime? startDate)
    {
        if (startDate != StartDate)
        {
            StartDate = startDate;
        }
    }

    private void UpdateEndDate(DateTime? endDate)
    {
        if (endDate != EndDate)
        {
            EndDate = endDate;
        }
    }

    private void UpdateRevisedEndDate(DateTime? revisedDate)
    {
        if (revisedDate != RevisedEndDate)
        {
            RevisedEndDate = revisedDate;
        }
    }

    private void UpdateAmountUsd(decimal amountUsd)
    {
        if (amountUsd != AmountUsd)
        {
            AmountUsd = amountUsd;
        }
    }

    private void UpdateCurrencyId(string currencyId)
    {
        if (!string.IsNullOrEmpty(currencyId) && currencyId != CurrencyId)
        {
            CurrencyId = currencyId;
        }
    }

    private void UpdateFundSource(string fundSource)
    {
        if (!string.IsNullOrEmpty(fundSource) && fundSource != FundSource)
        {
            FundSource = fundSource;
        }
    }

    private void UpdateAmount(decimal amount)
    {
        if (amount != Amount)
        {
            Amount = amount;
        }
    }

    private void UpdateDisbursement(decimal? disbursement)
    {
        if (disbursement != Disbursement)
        {
            Disbursement = disbursement;
        }
    }

    private void UpdateUndisbursedAmount(decimal? undisbursedAmount)
    {
        if (undisbursedAmount != UndisbursedAmount)
        {
            UndisbursedAmount = undisbursedAmount;
        }
    }

    private void UpdateImplementingAgency(string? implementingAgency)
    {
        if (implementingAgency != ImplementingAgency)
        {
            ImplementingAgency = implementingAgency;
        }
    }

    private void UpdateExecutingAgency(string? executingAgency)
    {
        if (executingAgency != ExecutingAgency)
        {
            ExecutingAgency = executingAgency;
        }
    }
}