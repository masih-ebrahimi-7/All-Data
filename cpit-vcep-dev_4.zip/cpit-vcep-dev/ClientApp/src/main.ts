import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

export function getBaseUrl() {
  return document.getElementsByTagName('base')[0].href;
}

fetch('/api/configs')
  .then((response) => response.json())
  .then((config) => {
    // Global site tag (gtag.js) - Google Analytics
    let gaScript = document.createElement('script');
    gaScript.setAttribute('async', 'true');
    gaScript.setAttribute('src', `https://www.googletagmanager.com/gtag/js?id=${config.googleAnalyticsConfig}`);

    let gaScript2 = document.createElement('script');
    gaScript2.innerText = `window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag(\'js\', new Date());gtag(\'config\', \'${config.googleAnalyticsConfig}\');`;

    document?.documentElement?.firstChild?.appendChild(gaScript);
    document.documentElement.firstChild?.appendChild(gaScript2);

    if (environment.production) {
      enableProdMode();
    }
    platformBrowserDynamic([
      { provide: 'APP_CONFIG', useValue: config },
      { provide: 'BASE_URL', useFactory: getBaseUrl, deps: [] },
    ])
      .bootstrapModule(AppModule)
      .catch((err) => console.error(err));
  });
