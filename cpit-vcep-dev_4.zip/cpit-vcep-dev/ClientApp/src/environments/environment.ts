import config from '../../auth_config.test.json';

const { domain, clientId, authorizationParams: { audience }, apiUrl, authority, errorPath } = config as {
  domain: string;
  clientId: string;
  authorizationParams: {
    audience?: string;
  },
  apiUrl: string;
  authority: string;
  errorPath: string;
};

export const environment = {
  production: false,
  auth: {
    domain,
    clientId,
    authorizationParams: {
      ...(audience && audience !== 'YOUR_API_IDENTIFIER' ? { audience } : null),
      redirect_uri: window.location.origin,
    },
    errorPath,
  },
  httpInterceptor: {
    allowedList: ['/api/accounts/externallogin'],
  },
  authority,
  apiUrl: apiUrl
};

