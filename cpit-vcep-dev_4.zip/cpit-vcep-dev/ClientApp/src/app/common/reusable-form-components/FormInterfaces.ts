import { MatSelectChange } from "@angular/material/select";
import { Observable } from "rxjs/internal/Observable";
import { TypeaheadInput } from "src/app/services/typeahead.service";

export interface IDropdownSettings {
  formControlArray: any;
  formControlSelection: any;
  formControlFilteredArray: Observable<TypeaheadInput[]>;
  placeholderLabel: string;
  formControlPlaceholder: string;
  onSelectionChangedEvent(event: MatSelectChange): void;
}

