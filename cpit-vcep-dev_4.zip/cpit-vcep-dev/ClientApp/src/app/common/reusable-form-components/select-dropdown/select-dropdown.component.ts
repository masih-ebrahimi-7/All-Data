import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { Observable } from 'rxjs';
import { StateService } from 'src/app/services/state.service';

@Component({
  selector: 'app-select-dropdown',
  templateUrl: './select-dropdown.component.html',
  styleUrls: ['./select-dropdown.component.css'],
})
export class SelectDropdownComponent implements OnInit {
  @Input() formControlArray: UntypedFormControl = new UntypedFormControl();
  @Input() formControlSelection: UntypedFormControl = new UntypedFormControl();
  @Input() formControlFilteredArray: Observable<any[]>;
  @Input() placeholderLabel: string;
  @Input() formControlPlaceholder: string;
  @Input() required: boolean = false;
  @Input() selectedValue: any;
  @Input() disabled: boolean;
  @Input() hint: string;
  @Input() hasError: boolean = false;

  @Output() selectionChanged = new EventEmitter<MatSelectChange>();

  selected: string;
  selectedLabel = "";

  constructor(private stateService: StateService) {

  }
  
  ngOnInit(): void {
    if (this.selectedValue)
      this.selected = this.selectedValue?.toString();
    else
      this.selected = this.formControlSelection.value?.toString();
  }

  getDisplayLabel() {
    this.formControlFilteredArray.subscribe((data: any) => {
      this.selectedLabel = data.find((a: any) => a.value == this.selected)?.label || "";
    });
    return this.selectedLabel;
  }

  onSelectionChanged(event: MatSelectChange) {
    if (event) {
      this.selected = event.value;
      this.selectionChanged.next(event);
    }
  }
}

