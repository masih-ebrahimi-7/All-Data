import { Component, EventEmitter, Input, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { map, Observable, startWith } from 'rxjs';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-autocomplete-dropdown',
  templateUrl: './autocomplete-dropdown.component.html',
  styleUrls: ['./autocomplete-dropdown.component.css'],
})
export class AutocompleteDropdownComponent {
  itemCtrl: UntypedFormControl = new UntypedFormControl();
  @Input() items: TypeaheadInput[] = [];
  @Output() selectionChanged = new EventEmitter<MatSelectChange>();
  @Input() hint: string;
  @Input() placeholderLabel: string;

  filteredItems: Observable<TypeaheadInput[]>;
  showAddButton: boolean = false;

  prompt = 'Press <enter> to add: "';
  selected: string;
  selectedLabel = '';

  constructor() {
    this.itemCtrl = new UntypedFormControl();
    this.filteredItems = this.itemCtrl.valueChanges.pipe(
      startWith(''),
      map((item) => (item ? this.filterItems(item) : this.items.slice()))
    );
    this.selected = 'Select';
  }

  filterItems(filterValue: string) {
    filterValue = filterValue.toLowerCase().trim();
    let results = this.items.filter((option) => option.label.toLowerCase().includes(filterValue));

    this.showAddButton = results?.length === 0;
    if (this.showAddButton) {
      results = [{ value: filterValue, label: this.prompt + filterValue + '"', description: '' }];
    }

    return results;
  }

  optionSelected(option: any) {
    if (option.value.indexOf(this.prompt) === 0) {
      this.addOption();
    }
    this.selected = option.value;
    this.selectionChanged.next(option);
  }

  addOption() {
    let option = this.removePromptFromOption(this.itemCtrl.value);
    if (!this.items.some((entry) => entry.label === option)) {
      const index = this.items.push({ value: option, label: option, description: '' }) - 1;
      this.itemCtrl.setValue(this.items[index].label);
    }
  }

  removePromptFromOption(option: any) {
    if (option.startsWith(this.prompt)) {
      option = option.substring(this.prompt?.length, option?.length - 1);
    }
    return option;
  }
}
