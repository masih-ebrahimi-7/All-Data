export interface TypeaheadInput {
  label: string;
  value: string;
  description: string;
}
