import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { TypeaheadService } from '../../../services/typeahead.service';
import { UserAssignmentType } from 'src/app/models/enums/server-enums';
@Component({
  selector: 'app-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.css'],
})
export class UserDialogComponent implements OnInit {
  filteredUserOptions: Observable<any[]>;
  filteredUserTypeOptions: Observable<any[]>;
  users: UntypedFormControl = new UntypedFormControl();
  userTypes: UntypedFormControl = new UntypedFormControl();
  userInput: UntypedFormControl = new UntypedFormControl();
  userTypeInput: UntypedFormControl = new UntypedFormControl();
  formGroup = new UntypedFormGroup({ email: this.users });
  userTypeOptions: any[];

  constructor(
    public dialogRef: MatDialogRef<UserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private typeaheadService: TypeaheadService
  ) {
    this.userTypeOptions = [{ value: UserAssignmentType.SectorLead, label: 'Sector Lead' }, { value: UserAssignmentType.Finance, label: 'Finance' },
    { value: UserAssignmentType.Legal, label: 'Legal' }, { value: UserAssignmentType.CMS, label: 'Contract Management' }
    ]
  }

  ngOnInit(): void {
    this.filteredUserOptions = this.typeaheadService.filterData(this.userInput, this.data.users);
    this.filteredUserTypeOptions = this.typeaheadService.filterData(this.userTypeInput, this.userTypeOptions);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
