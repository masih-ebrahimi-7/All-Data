import { Component, Inject, OnInit, AfterViewInit, ElementRef } from '@angular/core';
import { FormControl, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadService } from '../../../services/typeahead.service';
import { getRandomAvatarUrl } from '../../helpers';
import { TaskUserType } from 'src/app/models/enums/server-enums';

@Component({
  selector: 'app-add-remark-dialog',
  templateUrl: './add-remark-dialog.component.html',
  styleUrls: ['./add-remark-dialog.component.css'],
})
export class AddRemarkDialogComponent implements OnInit, AfterViewInit {
  htmlContent: string = '';
  TaskUserType: typeof TaskUserType;
  taskUserTypeLabel: string;
  isEditMode: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<AddRemarkDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddRemarkDialogData,
    private requestService: RequestService,
    private typeaheadService: TypeaheadService,
    private permissionsService: PermissionsService,
    private elementRef: ElementRef
  ) {
    this.permissions = this.permissionsService.get();
    this.TaskUserType = TaskUserType;
    this.isEditMode = !!this.data.isEditMode;
  }

  public editorConfig = EditorConfig;
  permissions: any | null;
  remarkText = new FormControl('', [Validators.required, Validators.minLength(30)]);
  isTask: boolean = false;
  taskForMoF: boolean = false;
  taskForADB: boolean = false;

  showPreview: boolean = false;
  deadline: Date;
  peopleAvailableToTag: any;
  documentsAvailableToTag: any;
  mentionConfig: any = {
    mentions: [],
    disableSort: false,
    disableSearch: false,
    dropUp: false,
    maxItems: 10,
    allowSpace: true,
    returnTrigger: true
  };
  usersTagged: string[] = [];
  docsTagged: string[] = [];
  user: UntypedFormControl = new UntypedFormControl();
  userInput: UntypedFormControl = new UntypedFormControl();
  formGroup = new UntypedFormGroup({ email: this.user });

  getErrorMessage() {
    if (this.remarkText.hasError('required')) {
      return 'You must enter a remark';
    }
    if (this.remarkText.hasError('minlength')) {
      const currentLength = this.remarkText.value?.length || 0;
      return `Remark must be at least 30 characters long. Current length: ${currentLength}`;
    }

    return this.remarkText.hasError('remarkText') ? 'Not a valid remark' : '';
  }

  ngOnInit(): void {
    this.taskUserTypeLabel = TaskUserType[this.data.taskUserType];

    // If in edit mode, pre-populate the text
    if (this.isEditMode && this.data.currentText) {
      this.remarkText.setValue(this.data.currentText);
      this.htmlContent = this.data.currentText;
    }

    if (this.permissions.CanAssignTasksToInternalUsers && !this.isEditMode) {
      if (!this.data.isExternalCommunication) {
        this.requestService.getClaimDocumentsForFilter(this.data.claimId).subscribe((response) => {
          this.getListOfUsersToTag(this.data.taskUserType);

          this.documentsAvailableToTag = response;
          this.mentionConfig.mentions.push({
            items: this.documentsAvailableToTag,
            triggerChar: '#',
            labelKey: 'description',
            mentionSelect: (item: any) => this.onDocMentionSelect(item),
          });
        });
      } else {
        this.requestService.getTaskAssignableUsersForEntity(this.data.claimId).subscribe((response) => {
          this.peopleAvailableToTag = response;
          this.peopleAvailableToTag.forEach((el: any) => {
            (el.type = 'user'), (el.src = getRandomAvatarUrl());
          });
          this.mentionConfig.mentions.push({
            items: this.peopleAvailableToTag,
            triggerChar: '@',
            labelKey: 'label',
            mentionSelect: (item: any) => this.onUserMentionSelect(item),
          });
        });
      }
    }
  }

  ngAfterViewInit(): void {
    // Fix for angular-mentions incompatibility with mat-dialog
    // Remove tabindex="-1" from dialog container to allow mention dropdown clicks
    // This addresses the issue: https://github.com/dmacfarlane/angular-mentions/issues/185
    this.fixTabindexForMentions();
  }

  private fixTabindexForMentions(): void {
    const applyFix = () => {
      // Find dialog containers that might have tabindex="-1"
      const dialogContainers = [
        this.elementRef.nativeElement.closest('.cdk-dialog-container'),
        this.elementRef.nativeElement.closest('.mat-dialog-container'),
        this.elementRef.nativeElement.closest('.mat-mdc-dialog-container'),
        document.querySelector('.cdk-overlay-container .mat-dialog-container'),
        document.querySelector('.mat-dialog-container')
      ].filter(el => el !== null);

      dialogContainers.forEach(container => {
        if (container && container.hasAttribute('tabindex') && container.getAttribute('tabindex') === '-1') {
          container.removeAttribute('tabindex');
          console.log('Removed tabindex="-1" from dialog container for mentions fix');
        }
      });

      const mentionElements = document.querySelectorAll('.mention-menu, .mention-list, angular-editor');
      mentionElements.forEach(element => {
        const parentWithTabindex = element.closest('[tabindex="-1"]');
        if (parentWithTabindex) {
          parentWithTabindex.removeAttribute('tabindex');
          console.log('Removed tabindex="-1" from mention parent element');
        }
      });
    };

    applyFix();
    setTimeout(applyFix, 100);
    setTimeout(applyFix, 500);
    
    setTimeout(() => {
      const mentionObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'childList') {
            const addedNodes = Array.from(mutation.addedNodes);
            addedNodes.forEach((node: any) => {
              if (node.nodeType === Node.ELEMENT_NODE && 
                  (node.classList?.contains('mention-menu') || 
                   node.querySelector?.('.mention-menu'))) {
                applyFix();
              }
            });
          }
        });
      });

      mentionObserver.observe(document.body, { childList: true, subtree: true });
      
      this.dialogRef.afterClosed().subscribe(() => {
        mentionObserver.disconnect();
      });
    }, 100);
  }

  getListOfUsersToTag(taskUserType: TaskUserType) {
    this.requestService.getTaskAssignableUsers(taskUserType).subscribe((response) => {
      this.peopleAvailableToTag = response;
      this.peopleAvailableToTag.forEach((el: any) => {
        (el.type = 'user'), (el.src = getRandomAvatarUrl());
      });
                this.mentionConfig.mentions.push({
            items: this.peopleAvailableToTag,
            triggerChar: '@',
            labelKey: 'label',
            mentionSelect: (item: any) => this.onUserMentionSelect(item),
          });
    });
  }

  onDocMentionSelect(item: any) {
    this.htmlContent += `<a href="${item.description}" target="_blank">${item.label}</a>`;
  }

  onUserMentionSelect(item: any) {
    return item.label || item.value;
  }

  getRandomAvatarUrl(): string {
    const seed = Math.floor(Math.random() * 1000);
    return `https://api.dicebear.com/8.x/shapes/svg?seed=${seed}`;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onTextChange() {
    this.updateTaggedPeople();
    this.docsTagged = this.extractUrls();
  }

  updateTaggedPeople() {
    const regex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const mentions = this.remarkText.value?.toString().match(regex);
    const uniqueMentions = mentions ? Array.from(new Set(mentions)) : [];
    this.usersTagged = uniqueMentions;
  }

  extractUrls(): string[] {
    const urlRegex = /((https?:\/\/)[^\s]+)/g;
    return this.remarkText.value?.toString().match(urlRegex) || [];
  }

  onAssignToggle(e: any) {
    this.isTask = e.checked;
  }

  onPreviewToggle(e: any) {
    this.showPreview = !this.showPreview;
  }
}

export interface AddRemarkDialogData {
  taskUserType: TaskUserType;
  parentRemarkId?: number;
  claimId: number;
  isExternalCommunication: boolean;
  // Edit mode properties
  isEditMode?: boolean;
  remarkId?: number;
  currentText?: string;
}