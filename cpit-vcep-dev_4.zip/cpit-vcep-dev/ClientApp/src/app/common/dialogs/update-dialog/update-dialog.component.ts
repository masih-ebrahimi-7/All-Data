import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditorConfig } from '../../EditorConfig';
import { AngularEditorConfig } from '@kolkov/angular-editor';

@Component({
  selector: 'app-update-dialog',
  templateUrl: './update-dialog.component.html',
  styleUrls: ['./update-dialog.component.css'],
})
export class UpdateDialogComponent implements OnInit {
  editForm: FormGroup;
  fields: any[] = [];
  public editorConfig: AngularEditorConfig = EditorConfig;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<UpdateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    this.fields = this.data.fields;
    this.editForm = this.createFormGroup(this.data.fields);
  }

  createFormGroup(fields: any[]): FormGroup {
    const group: any = {};
    fields.forEach((field) => {
      if (field.type === 'date-range') {
        group[field.name] = this.fb.group({
          start: new FormControl(field.value.start || null, this.getValidators(field)),
          end: new FormControl(field.value.end || null, this.getValidators(field))
        });
      } 
      else if (field.type === 'select' && field.allowMultiple) {
        group[field.name] = new FormControl(this.getValidators(field));
        group[field.name].setValue(field.value);
      } else if (field.type === 'date') {
        group[field.name] = new FormControl(field.value || null, this.getValidators(field));
      } else if (field.type === 'checkbox') {
        group[field.name] = new FormControl(field.value || false, this.getValidators(field));
      } else if (field.type === 'editor') {
        group[field.name] = new FormControl(field.value || '', this.getValidators(field));
      } else {
        let defaultValue = field.type === 'number' ? 0 : '';
        group[field.name] = new FormControl(field.value || defaultValue, this.getValidators(field));
      }
    });
    return new FormGroup(group);
  }

  getValidators(field: any): any[] {
    const validators = [];
    if (field.required) {
      validators.push(Validators.required);
    }
    if (field.email) {
      validators.push(Validators.email);
    }
    // Add more validators as needed
    return validators;
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.editForm.valid) {
      this.dialogRef.close(this.editForm.value);
    }
  }
}