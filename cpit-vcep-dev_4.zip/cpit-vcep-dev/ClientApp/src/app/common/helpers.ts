import { ActivatedRoute, Router } from '@angular/router';
import * as XLSX from 'xlsx';

/**
 * Function used to export to xlsx any array of objects
 * @param data - Array of objects that need to be exported to sheet
 * @param sheetName - Name that will be given to the sheet
 * @param columns - columns that are used both as headers for the sheet and also the only columns allowed to be exported,
 * all extra columns that might be contained in an object will be ignored
 */
export function exportDataToSheet(data: [], sheetName: string, columns: string[]) {
  let filteredData = pluck(data, columns);
  let dataForExport = jsonToArrayOfArrays(filteredData);
  dataForExport.unshift(capitalizeArrayOfColumnNames(columns));

  const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(dataForExport);
  /* generate workbook and add the worksheet */
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  /* save to file */
  XLSX.writeFile(wb, sheetName);
}

/**
 * Pluck function used to only keep a list of wanted properties for each object inside an array
 * @param arrayOfObjects - array of objects that need to be cleaned of unnecessary properties
 * @param keysToKeep - array of properties we want to keep
 * @returns
 */
export function pluck(arrayOfObjects: any, keysToKeep: string[]) {
  const pluckedArray = [];
  for (let currentObject of arrayOfObjects) {
    pluckedArray.push(
      Object.assign(
        {},
        ...keysToKeep.map((property: string) => {
          var prop = property;
          var value = currentObject[property];
          if (property.indexOf('.') !== -1) {
            var split = property.split('.');
            prop = '';
            value = currentObject;
            for (var i = 0; i < split?.length; i++) {
              prop += split[i];
              if (value != null) {
                if (Array.isArray(value)) {
                  var concatenatedValue = '';
                  for (var j = 0; j < value?.length; j++) {
                    concatenatedValue += value[j][split[i]] + ', ';
                  }
                  value = concatenatedValue;
                } else value = value[split[i]];
              }
            }
          }
          return {
            [prop]: value,
          };
        })
      )
    );
  }

  return pluckedArray;
}

export function jsonToArrayOfArrays(arrayOfObjects: any) {
  let arrayOfArrays = [];
  for (let currentObject of arrayOfObjects) {
    arrayOfArrays.push(Object.values(currentObject));
  }

  return arrayOfArrays;
}

export function capitalizeArrayOfColumnNames(arrayOfColumnNames: string[]): string[] {
  let capitalizedColumns = [];

  for (let column of arrayOfColumnNames) {
    column = capitalizeName(column);
    column = insertSpaceBetweenWords(column);
    capitalizedColumns.push(column);
  }
  return capitalizedColumns;
}

function capitalizeName(s: string) {
  return s.replace(/\b(\w)/g, (s) => s.toUpperCase());
}

function insertSpaceBetweenWords(s: string) {
  return s.replace(/([A-Z])/g, ' $1').trim();
}

export function getFlatTree(destArr: any, sourceArr: any, nodeName: string) {
  nodeName = nodeName[0].toUpperCase() + nodeName.substring(1);
  let children = sourceArr.map((a: any) => a.name);
  if (children?.length > 0) destArr.push([nodeName, children]);

  sourceArr.forEach((item: any) => {
    for (const [key, value] of Object.entries(item)) {
      if (Array.isArray(value)) {
        getFlatTree(destArr, value, item['name']);
      }
    }
  });
}

export function getRandomAvatarUrl(): string {
  const seed = Math.floor(Math.random() * 1000);
  return `https://api.dicebear.com/8.x/shapes/svg?seed=${seed}`;
}

export function setUrlQuery(activatedRoute: ActivatedRoute, router: Router, value: any) {
  let currentPath: any = '';
  activatedRoute.snapshot.url.forEach((url) => {
    currentPath += '/' + url.path;
  });
  router.navigate([currentPath], { queryParams: value });
}

export interface DialogData {
  input: {
    name: string;
    selectedIssueType: any;
    issueTypes: any[];
    document: any;
    showExternalUsers: boolean;
  }
  output: {
    summary: string;
    issueTypeId: number;
    locationId: number;
    projectId: number;
    externalUserId: number;
  }
}