import { DatePipe } from '@angular/common';
import { AfterContentInit, Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorDialogComponent } from 'src/app/app-shared/error-page/error-dialog/error-dialog.component';
import { UserDialogComponent } from 'src/app/common/dialogs/user-dialog/user-dialog.component';
import { AppInput } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { GoogleDrivePickerService } from 'src/app/services/google-drive-picker.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { UploadEntityDocumentComponent } from 'src/app/upload-entity-document/upload-entity-document.component';
import { WarningDialogComponent } from '../dialogs/warning-dialog/warning-dialog.component';

@Component({
  selector: 'app-detail-page',
  templateUrl: './detail-page.component.html',
  styleUrls: ['./detail-page.component.css'],
})
export class DetailPageComponent implements OnInit, AfterContentInit {
  loading: boolean = true;
  entityId: number;
  entity: any;
  @Input() entityName: string;
  @Input() api: string;
  @Input() propertyList: string[];
  @Input() pageTitle: string;
  private _driveIntegrationServiceSubscription;

  permissions: any | null;

  documents: any;
  docsTotal: number;
  documentConfig: any;
  documentTableActions: Action[];

  auditLogsColumnsList = [
    new Column('SessionUser', 'createdBy'),
    new Column('Performed Date', 'createdDate', {
      type: ColumnType.Date,
    }),
    new Column('Changes', 'changes', {
      disableSorting: true,
      type: ColumnType.Dictionary,
      size: 'audit-table',
    }),
  ];
  auditLogs: any;
  auditLogsTotal: any;
  auditLogsFilters: AppInput[] = [new AppInput('Performed by', 'query')];
  ngZone: any;

  constructor(
    private activatedRouter: ActivatedRoute,
    private request: RequestService,
    private notify: NotificationService,
    public dialog: MatDialog,
    permissionService: PermissionsService,
    private googleDriveFilePickerService: GoogleDrivePickerService
  ) {
    this.permissions = permissionService.get();
    this.documentTableActions = this.getBulkActions();
    this._driveIntegrationServiceSubscription = this.googleDriveFilePickerService.onFilesSelectedEmitter.subscribe({
      next: (files: boolean) => {
        if (files) 
          this.linkSelectedDriveFilesToEntity(files);
      }
    })
  }

  ngAfterContentInit(): void {
    this.loading = false;
  }

  ngOnInit(): void {
    this.loading = true;
    this.entityId = this.activatedRouter.snapshot.params['id'];

    this.getEntity().subscribe((data) => {
      this.entity = data;
      this.loading = false;
    });
  }

  getEntity() {
    return this.request.getGenericEntity(this.entityName, this.entityId);
  }

  toUpperFirstLetter(string: string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  splitWords(string: string) {
    return string.replace(/([a-zA-Z])([A-Z])([a-z])/g, '$1 $2$3')
  }

  setAuditDataSource(config: any) {
    var filters = config?.filter ?? {};
    this.request.getEntityAuditLogs(this.entityName, this.entityId, filters).subscribe((data: any) => {
      this.auditLogsTotal = data.totalCount;
      this.auditLogs = data.records;
    });
  }

  documentColumnsList: Array<Column> = [
    new Column('label.title', 'url', {
      type: ColumnType.Link,
      value: (e: any) => {
        return new Link(e.document.title, `${e.document.url}`, true);
      },
    }),

    new Column('label.createdDate', 'createdDate', {
      type: ColumnType.Date,
      disableSorting: false,
      value: (e: any) => {
        return new DatePipe('en-us').transform(e.createdDate);
      },
    }),

    new Column('label.createdBy', 'createdBy'),

    new Column('label.documentSource', 'linkedFromGoogleDrive', {
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        var icon =
          e.document.linked === true
            ? '<i class="bx bx-link medium-icon primary-color" ></i>'
            : '<i class="bx bx-file medium-icon primary-color" ></i>';
        var toolTip =
          e.document.linked === true ? 'Linked to existing Google drive document' : 'Uploaded to Google drive';
        var actions: Action[] = [];
        actions.push(
          new Action({
            iconLabel: icon,
            toolTip: toolTip,
            onClick: () => null,
          })
        );
        return new ActionList(actions);
      },
    }),
  ];

  docsFilters: AppInput[] = [new AppInput('label.documentName', 'documentName')];

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions.CanUploadClaimDocuments) {
      actions.push(
        new Action({
          onClick: () => this.openUploadDocumentDialog(),
          iconLabel: 'label.upload',
          color: 'primary',
          type: 'button',
          iconName: 'cloud_upload',
          toolTip: 'label.upload',
        })
      );
    }

    // do not allow claimant nor mof to upload from drive
    if (this.permissions?.CanAddDriveDocumentsToClaims) {
      actions.push(
        new Action({
          onClick: async () => await this.googleDriveFilePickerService.openPicker(),
          iconLabel: 'label.Attach',
          color: 'primary',
          type: 'button',
          iconName: 'attach_file',
          toolTip: 'label.Attach',
        })
      );
    }
    
    return actions;
  }

  openUploadDocumentDialog() {
    const dialogRef = this.dialog.open(UploadEntityDocumentComponent, {
      width: '400px',
      data: { output: {} },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.files && result.files?.length > 0) {
          var fileNames = [];
          var formData = new FormData();
          for (let i = 0; i < result.files?.length; i++) {
            formData.append('files', result.files[i], result.files[i].name);
            fileNames.push(result.files[i].name);
          }
          formData.append(this.entityName + 'Id', this.entityId?.toString());
          // Call backend to check file names:
          // fileNames, claimId
          this.request.checkExistingFiles({ fileNames: fileNames, claimId: this.entityId?.toString() }).subscribe((data: any) => {
            if (data && data.length > 0) {
              var message = `Your upload contains file(s): [ ${data.join(",")} ] that already exist for this claim. <br> Are you sure you want to upload this?`;
              this.dialog.open(WarningDialogComponent, {
                data: { message: message },
              }).afterClosed().subscribe((continueUpload: any) => {
                if (continueUpload) {
                  this.uploadDocument(formData, result);
                }
              });
            }
            else {
              this.uploadDocument(formData, result);
            }
          });
        }
      }
    });
  }

  uploadDocument(formData: FormData, result: any) {
    this.request.uploadEntityDocuments(formData).subscribe((data: any) => {
      this.setDocDataSource(this.documentConfig);
      this.notify.showSuccess(`${result.files.length} Document(s) uploaded successfully.`);
    });
  }

  openAssignUserDialog() {
    this.request.getClaimReviewers().subscribe((users: any) => {
      this.dialog
        .open(UserDialogComponent, {
          width: '25em',
          data: { users: users },
        })
        .afterClosed()
        .subscribe((assignedUser: any) => {
          if (!assignedUser || !assignedUser.value) {
            return this.notify.showError('Please select a user.');
          }
          //     this.assignUsersToClaims([this.entityId], assignedUser.value);
        });
    });
  }

  setDocDataSource(config: any) {
    this.documentConfig = config;
    if (!config.filter) config.filter = {};

    config.filter[this.api ?? this.entityName + 'Id'] = this.entityId;

    this.request.getEntityDocuments(config.filter || {}).subscribe((data: any) => {
      this.docsTotal = data.totalCount;
      this.documents = data.records;
    });
  }


  public async linkSelectedDriveFilesToEntity(selectedDocuments: any) {
    var googleDocuments: any[] = [];

    for (var selectedDocument of selectedDocuments) {
      var document = {
        documentId: selectedDocument.id,
        name: selectedDocument.name.replace(/\.[^/.]+$/, ''),
        url: selectedDocument.url,
        grantId: 0,
        invoiceId: 0,
        contractId: 0,
        claimId: 0,
      };

      // TODO / HACK: Typescript won't let me use associative arrays and just set the property name dynamically
      switch (this.entityName) {
        case 'Grant':
          document.grantId = this.entityId;
          break;
        case 'Invoice':
          document.invoiceId = this.entityId;
          break;
        case 'Claim':
          document.claimId = this.entityId;
          break;
        case 'Contract':
          document.contractId = this.entityId;
          break;
      }

      googleDocuments.push(document);
    }

    this.request.linkEntityToGoogleDriveDocument(googleDocuments).subscribe((dataResponse) => {
      this.setDocDataSource(this.documentConfig);
      this.notify.showSuccess(`${selectedDocuments.length} Document(s) uploaded successfully.`);
    });
  }
}
