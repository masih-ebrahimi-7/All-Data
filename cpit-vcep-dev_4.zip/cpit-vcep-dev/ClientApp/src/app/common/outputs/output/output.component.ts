import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-output',
  templateUrl: './output.component.html',
  styleUrls: ['./output.component.css'],
})
export class OutputComponent implements OnInit {
  @Input()
  type: string;

  @Input()
  value: any;
  actions: any[];
  list: any[];

  constructor(private router: Router) { }
  
  ngOnInit(): void {
    this.actions = this.value && this.value.actions ? this.value.actions : [];
    this.list = this.value ? this.value : [];
  }

  openLink(value: any) {
    if (value.link == '#;') {
      return;
    }
    if (value.callback) {
      value.callback();
    }
    if (value.openInNewTab)
      window.open(value.link, '_blank');
    else
      this.router.navigate([value.link]);
  }
}
