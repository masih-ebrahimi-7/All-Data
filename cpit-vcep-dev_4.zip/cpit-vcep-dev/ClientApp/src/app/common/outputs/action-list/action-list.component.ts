import { Component, Input, OnChanges, OnInit, SimpleChange } from '@angular/core';

@Component({
  selector: 'app-action-list',
  templateUrl: './action-list.component.html',
  styleUrls: ['./action-list.component.css'],
})
export class ActionListComponent implements OnInit, OnChanges {
  @Input()
  actions: any[] = [];
  actionList: any;
  constructor() {}

  ngOnInit(): void {
    this.actionList = this.actions;
  }
  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    let change: SimpleChange = changes['actions'];
    if (change && change.currentValue) this.actionList = this.actions;
  }
  doNothing() {}
}
