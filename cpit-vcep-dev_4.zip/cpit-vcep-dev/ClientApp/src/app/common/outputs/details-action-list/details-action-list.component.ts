import { Component, Input, OnChanges, OnInit, SimpleChange } from '@angular/core';

@Component({
  selector: 'app-details-action-list',
  templateUrl: './details-action-list.component.html',
  styleUrls: ['./details-action-list.component.css'],
})
export class DetailsActionListComponent implements OnInit, OnChanges {
  @Input()
  actions: any[] = [];
  actionList: any;
  constructor() {}

  ngOnInit(): void {
    this.actionList = this.actions;
  }
  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    let change: SimpleChange = changes['actions'];
    if (change && change.currentValue) this.actionList = this.actions;
  }
  doNothing() {}
}
