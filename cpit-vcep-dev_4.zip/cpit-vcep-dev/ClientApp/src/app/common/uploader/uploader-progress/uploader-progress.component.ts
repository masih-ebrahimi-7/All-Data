import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-uploader-progress',
  templateUrl: './uploader-progress.component.html',
  styleUrls: ['./uploader-progress.component.scss'],
})
export class UploaderProgressComponent {
  @Input() progress = 0;
  constructor() {}
}
