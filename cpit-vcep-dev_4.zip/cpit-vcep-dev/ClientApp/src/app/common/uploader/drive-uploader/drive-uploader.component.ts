import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RequestService } from 'src/app/services/request.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-drive-uploader',
  templateUrl: './drive-uploader.component.html',
  styleUrls: ['./drive-uploader.component.scss'],
})
export class DriveUploaderComponent implements OnInit {
  documentCategories: any[];
  driveFiles: any[] = [];
  processedFiles: any[] = [];
  canUpload: boolean = false;

  constructor(
    private request: RequestService,
    private notify: NotificationService,
    public dialogRef: MatDialogRef<DriveUploaderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.loadCategories();
    this.prepareFiles();
  }

  loadCategories() {
    this.request.getDocumentCategories(1, 9999, '').subscribe((data: any) => {
      this.documentCategories = data.records;
    });
  }

  prepareFiles() {
    this.driveFiles = this.data.documents.map((doc: any) => ({
      name: doc.name,
      size: doc.sizeBytes,
      progress: 100,
      id: doc.id,
      url: doc.url,
      isGoogleDrive: true
    }));
  }

  fileUploadHandler(files: any[]) {
    this.processedFiles = files.map(file => ({
      id: file.id,
      name: file.name,
      url: file.url,
      categoryId: file.documentCategoryId
    }));
    this.canUpload = this.processedFiles.every(file => file.categoryId);
  }
} 