import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-uploader',
  templateUrl: './uploader.component.html',
  styleUrls: ['./uploader.component.scss'],
})
export class UploaderComponent {
  @Output() uploadedFiles: EventEmitter<string[]> = new EventEmitter<string[]>();
  @Input() filesToUpload: number;
  @Input() documentCategories: any[];
  @Input() subClaims: any[];
  @Input() preloadedFiles: any[];
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  acceptedFileTypes: string;
  acceptedFileTypesDisplay: string;
  sizeLimit: number = 250 * 1024 * 1024; // 250 MB in bytes
  selectedCategory: number;
  selectedSubClaim: number;

  constructor(private notificationService: NotificationService) {
    const fileTypes = this.getAcceptedFileTypes();
    this.acceptedFileTypes = fileTypes.map((ft) => ft.mime).join(',');
    this.acceptedFileTypesDisplay = fileTypes.map((ft) => ft.display).join(', ');
  }

  ngOnInit() {
    if (this.preloadedFiles) {
      this.files = [...this.preloadedFiles];
      this.uploadedFiles.emit(this.files);
    }
  }

  getAcceptedFileTypes() {
    return [
      { mime: 'application/pdf', display: 'PDF' },
      { mime: 'image/jpeg', display: 'JPEG' },
      { mime: 'image/png', display: 'PNG' },
      { mime: 'image/svg+xml', display: 'SVG' },
      { mime: 'image/gif', display: 'GIF' },
      { mime: 'image/bmp', display: 'BMP' },
      { mime: 'image/webp', display: 'WEBP' },
      { mime: 'image/tiff', display: 'TIFF' },
      { mime: 'application/msword', display: 'DOC' },
      { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', display: 'DOCX' },
      { mime: 'application/vnd.ms-excel', display: 'XLS' },
      { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', display: 'XLSX' },
      { mime: 'application/vnd.ms-powerpoint', display: 'PPT' },
      { mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', display: 'PPTX' },
      { mime: "application/vnd.ms-outlook", display: "Outlook Email Message (.msg)" },
      { mime: "message/rfc822", display: "Email Message (.eml)" },
      { mime: "application/mbox", display: "MBOX File (.mbox)" }
    ];
  }
  /**
   * on file drop handler
   */
  onFileDropped($event: any) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files: any) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    if (this.files[index].progress < 100) {
      return;
    }
    this.files.splice(index, 1);
    this.uploadedFiles.emit(this.files);
  }

  /**
   * Simulate the upload process
   */
  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files?.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            this.uploadedFiles.emit(this.files);
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 10;
          }
        }, 5);
      }
    }, 5);
  }

  onCategoryChange(event: any): void {
    const categoryId = event.value;
    this.files.forEach(file => {
      file.documentCategoryId = categoryId;
    });
    this.uploadedFiles.emit(this.files);
  }

  onSubClaimChange(event: any): void {
    const subClaimId = event.value;
    this.files.forEach(file => {
      file.subClaimId = subClaimId;
    });
    this.uploadedFiles.emit(this.files);
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    if (this.files?.length >= this.filesToUpload || files?.length > this.filesToUpload) {
      return this.notificationService.showError(`You can select maximum ${this.filesToUpload} file(s).`);
    }
    
    for (const item of files) {
      if (item.size > this.sizeLimit)
        return this.notificationService.showError(`You can select files with a size of maximum ${this.formatBytes(this.sizeLimit)}.`);

      item.progress = 0;
      if (this.selectedCategory) {
        item.documentCategoryId = this.selectedCategory;
      }
      this.files.push(item);
    }
    this.fileDropEl.nativeElement.value = '';
    this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes = 0, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
}
