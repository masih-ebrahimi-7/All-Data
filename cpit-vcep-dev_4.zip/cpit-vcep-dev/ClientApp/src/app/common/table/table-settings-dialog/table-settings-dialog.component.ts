import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-table-settings-dialog',
  templateUrl: './table-settings-dialog.component.html',
  styleUrls: ['./table-settings-dialog.component.css']
})
export class TableSettingsDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<TableSettingsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onSave(): void {
    this.dialogRef.close(this.data);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}