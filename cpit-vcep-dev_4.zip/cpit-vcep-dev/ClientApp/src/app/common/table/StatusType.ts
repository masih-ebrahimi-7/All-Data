export class StatusType {
  static readonly Warning = 'warning';
  static readonly Danger = 'danger';
  static readonly Success = 'success';
  static readonly Ok = 'ok';
  static readonly Default = 'default';
}
