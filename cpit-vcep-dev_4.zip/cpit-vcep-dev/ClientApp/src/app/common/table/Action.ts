export class ActionList {
  actions: Action[];
  type: ActionListType;

  constructor(actions: Action[], type?: ActionListType) {
    this.actions = actions;
    this.type = type ? type : ActionListType.List;
  }
}

export class Action {
  class?: string;
  iconName?: string;
  toolTip: string;
  color?: string;
  onClick?: any;
  type?: string;
  iconLabel?: string;
  link?: string;
  htmlLabel?: string;
  constructor(config: ActionConfig) {
    this.class = config.class;
    this.iconName = config.iconName;
    this.toolTip = config.toolTip ?? '';
    this.color = config.color;
    this.onClick = config.onClick;
    this.type = config.type;
    this.iconLabel = config.iconLabel;
    this.link = config.link;
    this.htmlLabel = config.htmlLabel;
  }
}

export enum ActionListType {
  List = 'list',
  More = 'more'
}

export class ActionConfig {
  class?: string;
  type?: string;
  iconName?: string;
  iconLabel?: string;
  toolTip?: string;
  color?: string;
  onClick?: any;
  link?: string;
  htmlLabel?: string;
}

export class OrPDFAction extends Action {
  type: string = 'orPDF';
  reference: string;
  constructor(reference: string, className: string) {
    super({ class: className });
    this.reference = reference;
  }
}

export class MenuAction extends Action {
  type: string = 'menu';
  menuItems: any;
  class: string;
  iconName: string;
  toolTip: string;
  color: string;
  onClick: string;
  constructor(config: any, menuItems: any) {
    super(config);
    this.menuItems = menuItems;
  }
}
