export class Column {
  header: string;
  value: any;
  type: string; // ColumnType
  columnName: string;
  sortableColumnName?: string;
  hidden: boolean;
  size?: string;
  tooltip: string;
  isSticky: boolean = false;

  constructor(header: string, columnName: string, config?: ColumnConfig) {
    this.header = header;
    this.value = config?.value;
    this.type = config?.type ?? ColumnType.Text;
    this.columnName = columnName;
    this.hidden = config?.hidden ?? false;
    this.size = config?.size ?? '';
    this.tooltip = config?.tooltip ?? '';
    this.sortableColumnName = config?.disableSorting ? undefined : columnName;
    if (config?.value == null) {
      this.value = (e: any) => e[this.columnName];
    }
  }
}

export class ColumnType {
  static readonly Text = 'text';
  static readonly TruncatedText = 'truncatedText';
  static readonly Number = 'number';
  static readonly Link = 'link';
  static readonly PDFFile = 'pdfFile';
  static readonly Status = 'status';
  static readonly Html = 'html';
  static readonly Actions = 'actions';
  static readonly DetailsActions = 'detailsActions';
  static readonly ErpIntegrator = 'erpIntegrator';
  static readonly LinkList = 'linkList';
  static readonly Boolean = 'bool';
  static readonly Date = 'date';
  static readonly DateTime = 'dateTime';
  static readonly OrPDF = 'orPDF';
  static readonly Dictionary = 'dictionary';
  static readonly Icon = 'icon';
}

export class ColumnConfig {
  value?: any;
  type?: string;
  disableSorting?: boolean;
  hidden?: boolean;
  size?: string;
  tooltip?: string;
}