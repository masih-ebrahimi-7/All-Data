import { SelectionModel } from '@angular/cdk/collections';
import {
  AfterViewInit, Component, EventEmitter, HostListener, Input, OnChanges, Output, SimpleChange, ViewChild
} from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { setUrlQuery } from '../helpers';
import { AppInput } from '../inputs/input';
import { Column } from './Column';
import { MatDialog } from '@angular/material/dialog';
import { TableSettingsDialogComponent } from './table-settings-dialog/table-settings-dialog.component';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements AfterViewInit, OnChanges {
  permissions: any;
  @Input()
  actions: any;
  @Input()
  addPagination: boolean = true;
  onPaginate = false;
  @Input()
  title: string;
  @Input()
  totalSize: number;
  @Input()
  headers: Array<string>;
  @Input()
  displayedColumns: Array<Column> = [];
  displayedColumnsWithSelect: Array<string>;
  @Input()
  data: Array<Object>;
  @Input()
  getData: any;
  @Input()
  bulkActions: any;

  @Input()
  addCheckBox: boolean;
  @Input()
  expandable: boolean = true;
  @Output()
  selectionChanged = new EventEmitter<any>();

  @Output()
  setDataSource = new EventEmitter<any>();
  moment = moment;
  dataSource: MatTableDataSource<Object>;
  selected: any;
  pageEvent: PageEvent;
  @Input()
  selection = new SelectionModel<Object>(true, []);

  @Input()
  filters: AppInput[];
  filterForm: UntypedFormGroup;
  isExpanded: boolean = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private router: Router, private activatedRoute: ActivatedRoute, public dialog: MatDialog) {
    this.setColumns();
  }
  setTableDataSource(data: Object[]) {
    if (data) {
      this.dataSource = new MatTableDataSource(data);
    }
  }

  applyFilter() {
    var value = this.getFiltersValue();
    setUrlQuery(this.activatedRoute, this.router, value);
    this.setDataSource.emit({
      pageIndex: this.paginator.pageIndex + 1,
      pageSize: this.paginator.pageSize,
      orderBy: this.sort.active,
      direction: this.sort.direction === 'asc',
      filter: value,
    });
    this.selection.clear();
    this.selectionChanged.emit(this.selection.selected);
  }

  setFormValue(value: any) {
    this.filterForm = value;
  }

  public sortData(): void {
    switch (this.sort.direction) {
      case 'asc':
        this.sort.direction = 'asc';
        break;
      case 'desc':
        this.sort.direction = 'desc';
        break;
      default:
        this.sort.direction = 'asc';
    }
    this.FetchData();
  }
  FetchData() {
    let pageIndex = this.paginator ? this.paginator.pageIndex + 1 : 1;
    let pageSize = this.paginator ? this.paginator.pageSize : 9999;
    if (this.getData) {
      this.getData({ pageIndex: pageIndex, pageSize: pageSize }).subscribe((data: any) => {
        this.data = data.records;
        this.totalSize = data.totalCount;
        this.setTableDataSource(this.data);
      });
    }
    var value = this.paginator ? this.getFiltersValue() : '';
    this.setDataSource.emit({
      pageIndex: pageIndex,
      pageSize: pageSize,
      orderBy: this.sort.active,
      direction: this.sort.direction === 'asc',
      filter: value,
    });
  }

  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    this.setColumns();
    let change: SimpleChange = changes['data'];
    if (change && change.currentValue) this.setTableDataSource(change.currentValue);
  }

  setColumns() {
    let extraCols = [];
    if (this.addCheckBox)
      extraCols.push('select');
    if (this.expandable)
      extraCols.push('expand');

    this.displayedColumnsWithSelect = extraCols.concat(this.displayedColumns.map((a) => a.columnName))
  }

  ngAfterViewInit() {
    this.FetchData();
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
    }
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected?.length;
    const numRows = this.dataSource.data?.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.dataSource.data.forEach((row) => this.selection.select(row));
    this.selectionChanged.emit(this.selection.selected);
  }

  onSelectionChange(row: any) {
    this.selection.toggle(row);
    this.selectionChanged.emit(this.selection.selected);
  }

  onPaginateChange(e: any) {
    this.paginator.pageIndex = e.pageIndex;
    this.paginator.pageSize = e.pageSize;
    this.FetchData();
    this.selection.clear();
  }

  isActionAllowed(action: any, element: any) {
    return action['isVisible'] == null || (action['isVisible'] != null && action['isVisible'](element));
  }

  isDate(value: any) {
    return value instanceof Date;
  }

  getFiltersValue() {
    var value = this.filterForm?.value || {};
    value.pageIndex = this.paginator.pageIndex + 1;
    value.pageSize = this.paginator.pageSize;
    value.orderBy = this.sort.active;
    value.direction = this.sort.direction === 'asc';
    return value;
  }

  stickyHeader: boolean = false;
  toggleStickyHeader() {
    this.stickyHeader = !this.stickyHeader;
  }

  toggleSticky(column: Column) {
    column.isSticky = !column.isSticky;
  }

  openSettingsDialog(): void {
    const filteredColumns = this.displayedColumns.filter((column) => column.header !== 'actions');
    const dialogRef = this.dialog.open(TableSettingsDialogComponent, {
      width: '25em',
      data: {
        columns: filteredColumns,
        stickyHeader: this.stickyHeader,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.displayedColumns = result.columns;
      this.stickyHeader = result.stickyHeader;
    });
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex);
    this.setColumns();
  }

  onExpandRow(event: any, row: Element) {
    // add any custom implementation if needed :)
  }
}
