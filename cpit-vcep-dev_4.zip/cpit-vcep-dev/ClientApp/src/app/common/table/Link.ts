export class Link {
  label: string;
  link: string;
  description?: string;
  openInNewTab: boolean;
  callback?: any;

  constructor(label: string, link: string, openInNewTab: boolean = true, description?: string, callback?: any) {
    this.label = label;
    this.link = link;
    this.description = description;
    this.callback = callback;
    this.openInNewTab = openInNewTab;
  }
}
