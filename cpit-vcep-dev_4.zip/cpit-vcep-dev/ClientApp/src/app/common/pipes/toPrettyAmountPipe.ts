import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ToPrettyAmountNumber',
})
export class ToPrettyAmountNumberPipe implements PipeTransform {
  transform(value: any): any {
    if (value == null || value == undefined) return '';
    var config = {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    };
    if (typeof value == 'number') return Number(value).toLocaleString('en-US', config);
    const withoutCommas = value.replace(/,/g, '');
    let retNumber = Number(withoutCommas);
    if (isNaN(retNumber)) return '';
    return retNumber.toLocaleString('en-US', config);
  }
}
