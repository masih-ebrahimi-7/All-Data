import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ToPrettyAmountNumberMXN',
})
export class ToPrettyAmountNumberPipeMXN implements PipeTransform {
  transform(value: any): any {
    if (value == null || value == undefined) return '';
    var config = {
      style: 'currency',
      currency: 'MXN',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    };
    if (typeof value == 'number') return Number(value).toLocaleString('en-US', config);
    const withoutCommas = value.replace(/,/g, '');
    let retNumber = Number(withoutCommas);
    if (isNaN(retNumber)) return '';
    return retNumber.toLocaleString('en-US', config);
  }
}
