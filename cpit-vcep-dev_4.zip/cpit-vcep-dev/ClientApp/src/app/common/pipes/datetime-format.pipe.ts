import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';
@Pipe({
  name: 'dateTimeFormat',
})
export class DateTimeFormatPipe implements PipeTransform {
  transform(value: any, ...args: unknown[]): unknown {
    return value && moment(value).isValid() ? moment(value).format('DD-MM-YYYY, h:mm:ss a') : '';
  }
}
