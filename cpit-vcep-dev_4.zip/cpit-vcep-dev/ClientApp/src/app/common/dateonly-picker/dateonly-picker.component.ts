import { Component, forwardRef, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import * as _moment from 'moment';
import { default as _rollupMoment } from 'moment';
const moment = _rollupMoment || _moment;

@Component({
  selector: 'app-dateonly-picker',
  templateUrl: './dateonly-picker.component.html',
  styleUrls: ['./dateonly-picker.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DateonlyPickerComponent),
      multi: true,
    },
  ],
})
export class DateonlyPickerComponent implements ControlValueAccessor {
  @Input()
  _dateValue: any; // notice the '_'

  @Input() title: any;
  @Input() max: any;
  @Input() required: any;

  get dateValue() {
    return moment(this._dateValue, 'MM/DD/YYYY');
  }

  set dateValue(val) {
    var date = moment(val);

    var newDate = moment.utc();
    newDate.set('year', date.year());
    newDate.set('month', date.month());
    newDate.set('date', date.date());

    this._dateValue = newDate;

    this.propagateChange(this._dateValue);
  }

  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.dateValue = moment(event.value, 'MM/DD/YYYY');
  }

  writeValue(value: any) {
    if (value !== undefined && value !== '') {
      this.dateValue = value;
    }
  }
  propagateChange = (_: any) => {};

  registerOnChange(fn: any) {
    this.propagateChange = fn;
  }

  registerOnTouched() {}
}
