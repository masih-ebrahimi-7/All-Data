import { UserAssignmentType } from "../models/enums/server-enums";
import { Grant } from "../models/grant.model";

export interface IModifiableEntity {
  id: number;
  createdBy: string;
  createdDate: Date;
  lastModifiedBy?: Date;
  lastModifiedDate?: string;
}

export interface ProjectAgreement {
  reference: string;
  priority: string;
  priorityLabel: string;
  sector?: string;
  agreementDate?: Date;
  grant?: Grant;
  grantId: Number;
  signedWith?: string;
}
export interface IDocumentRequestModel {
  claimId?: number,
  documentId: number;
  categoryId?: number;
  documentName?: string;
  documentSource?: number;
}

export interface IAssignUserEmailsToIds {
  ids: number[];
  email: string;
  userAssignmentType: UserAssignmentType
}

export interface ExternalEntity {
  id: number;
  name: string;
  nationality?: string;
  externalEntityType: number;
  externalEntityTypeString: string;
}

export interface IRemark extends IModifiableEntity {
  remarkText: string;
  avatar?: string;
  entityId: number;
  parentId?: number;
  replies: IRemark[];
  showReplies?: boolean;
  canEdit?: boolean;
  canDelete?: boolean;
}
