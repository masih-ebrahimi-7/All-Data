import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AppInput } from '../inputs/input';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css'],
})
export class FiltersComponent {
  @Input()
  inputs: AppInput[];
  @Input()
  name: string;

  @Output()
  setFormValue = new EventEmitter<any>();

  panelOpenState = false;

  @Output()
  applyFilters = new EventEmitter<any>();

  constructor() {}

  submit() {
    this.applyFilters.emit();
  }

  setFilterValue($event: any) {
    this.setFormValue.emit($event);
  }
}
