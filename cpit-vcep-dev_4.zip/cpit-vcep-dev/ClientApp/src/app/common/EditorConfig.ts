import { AngularEditorConfig } from '@kolkov/angular-editor';

let EditorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '15rem',
    minHeight: '5rem',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'no',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: 'p',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [],
    customClasses: [],
    sanitize: false, // Set to false to allow proper HTML formatting including headings
    toolbarHiddenButtons: [
        [
            // Keep essential formatting buttons visible by NOT listing them here
            // 'undo', 'redo', 'bold', 'italic', 'underline' - these will be visible
            // 'insertUnorderedList', 'insertOrderedList' - list buttons will be visible  
            // 'heading' - heading button will be visible (IMPORTANT for paragraph/heading functionality)
            'subscript',
            'superscript',
            'fontName'
        ],
        [
            'fontSize',
            'textColor',
            'backgroundColor',
            'customClasses',
            'insertHorizontalRule',
            'removeFormat',
            'toggleEditorMode'
        ]
    ]
};

export { EditorConfig };
