import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css'],
})
export class LoaderComponent implements OnInit {
  public currentPath: string = '';
  constructor(private cd: ChangeDetectorRef, private loaderService: LoaderService, private router: ActivatedRoute) {
    this.router.snapshot.url.forEach((url) => {
      this.currentPath += '/' + url.path;
    });
  }
  public loading: any = false;
  ngOnInit(): void {
    setInterval(() => {
      this.loading = this.loaderService.getLoading();
      this.cd.detectChanges();
    }, 100);
  }

  getStoredPaths() {
    return localStorage.getItem('path')?.split(',');
  }
}
