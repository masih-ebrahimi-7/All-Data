import { Component, EventEmitter, Input, OnChanges, Output, SimpleChange } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AppInput, InputType } from '../inputs/input';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
})
export class FormComponent implements OnChanges {
  @Input()
  inputs: AppInput[];
  @Input()
  name: string;

  @Input()
  submitButtonLabel?: string;

  @Output()
  setFormValue = new EventEmitter<any>();

  panelOpenState = false;

  @Output()
  submitFunction = new EventEmitter<any>();
  form: UntypedFormGroup;

  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnChanges(changes: { [property: string]: SimpleChange }) {
    let change: SimpleChange = changes['inputs'];
    if (change && change.currentValue) this.initializeForm(change.currentValue);
  }

  initializeForm(inputs: any) {
    this.form = new UntypedFormGroup({});
    var queryParam = this.getQueryParams();
    inputs.forEach((input: AppInput) => {
      this.form.addControl(input.name, new UntypedFormControl(queryParam[input.name] ?? input.defaultValue));
      if (input.toInputName != null) {
        this.form.addControl(
          input.toInputName,
          new UntypedFormControl(queryParam[input.toInputName] ?? input.defaultValue)
        );
      }
    });
    this.setFormValue.emit(this.form);
  }

  clearForm() {
    this.form.reset();
  }

  submit() {
    this.submitFunction.emit();
  }

  getQueryParams(): any {
    return getQueryParams(this.activatedRoute, this.inputs);
  }
}

export function getQueryParams(activatedRoute: ActivatedRoute, inputs: AppInput[]) {
  const queryParamMap = activatedRoute.snapshot.queryParamMap;
  var result: any = {};
  inputs.forEach((input: AppInput) => {
    if (input.type === InputType.Multiselect)
      result[input.name] = queryParamMap.getAll(input.name)?.length === 0 ? null : queryParamMap.getAll(input.name);
    else {
      if (input.type === InputType.DateRange)
        result[input.name] = queryParamMap.get(input.name) ? new Date(queryParamMap.get(input.name) as any) : null;
      else result[input.name] = queryParamMap.get(input.name);
    }

    if (input.toInputName != null) {
      if (input.type === InputType.DateRange)
        result[input.toInputName] = queryParamMap.get(input.toInputName)
          ? new Date(queryParamMap.get(input.toInputName) as any)
          : null;
      else result[input.toInputName] = queryParamMap.get(input.toInputName);
    }
  });
  return result;
}
