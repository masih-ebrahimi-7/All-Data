import { Component, Input, OnInit } from '@angular/core';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';

export interface Location {
  id?: number;
  geographicalLocation: string;
  latitude: number;
  longitude: number;
}

@Component({
  selector: 'app-google-map',
  templateUrl: './google-map.component.html',
  styleUrls: ['./google-map.component.css'],
})
export class GoogleMapComponent implements OnInit {
  @Input() claimId: number;
  zoom = 8;
  center: google.maps.LatLngLiteral = { lat: 33.9391, lng: 67.71 };
  markers: any[] = [];
  newLocation: Location = { id: 0, geographicalLocation: '', latitude: 0, longitude: 0 };
  notificationService: any;
  newLocationIsValid: boolean = false;
  permissions: any | null;
  constructor(private request: RequestService, 
    notificationService: NotificationService, 
    private permissionService: PermissionsService
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {
    this.loadLocations();
  }

  loadLocations(): void {
    this.request.getClaimLocations(this.claimId).subscribe((locations) => {
      this.markers = locations.map((location) => ({
        position: {
          lat: location.latitude,
          lng: location.longitude,
        },
        label: location.geographicalLocation,
        id: location.id,
      }));
    });
  }

  addMarker(): void {
    if (!this.permissions?.CanUpdateLocationsOnClaimMap)
      return;
    if (!this.validateCoordinates(this.newLocation.latitude, this.newLocation.longitude))
      this.notificationService.showError(
        'Invalid coordinates. Latitude must be between -90 and 90. Longitude must be between -180 and 180.'
      );

    const newMarker = {
      geographicalLocation: this.newLocation.geographicalLocation,
      latitude: this.newLocation.latitude,
      longitude: this.newLocation.longitude,
    };
    this.request.addClaimLocation(this.claimId, newMarker).subscribe((location) => {
      this.markers.push({
        position: {
          lat: location.latitude,
          lng: location.longitude,
        },
        label: location.geographicalLocation,
      });
      this.newLocation = { id: 0, geographicalLocation: '', latitude: 0, longitude: 0 };
    });

    this.loadLocations();
  }

  removeMarker(marker: any): void {
    if (this.permissions?.CanUpdateLocationsOnClaimMap)
      this.request.removeClaimLocation(this.claimId, marker.id).subscribe(() => {
        this.markers = this.markers.filter((m) => m.id !== marker.id);
      });
    else 
      return;
  }

  mapClick(event: google.maps.MapMouseEvent): void {
    if (this.permissions?.CanUpdateLocationsOnClaimMap) {
      if (event.latLng && event.latLng) {
        this.newLocation.latitude = event.latLng.lat();
        this.newLocation.longitude = event.latLng.lng();
      }
    } 
  }

  validateCoordinates(latitude: number, longitude: number): boolean {
    return latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180;
  }

  checkNewLocationIsValid() {
    this.newLocationIsValid = this.newLocation.latitude != null && this.newLocation.longitude != null && this.newLocation.geographicalLocation != null;
  }
}
