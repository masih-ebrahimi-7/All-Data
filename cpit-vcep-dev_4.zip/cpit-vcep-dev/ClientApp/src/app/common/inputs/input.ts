export class AppInput {
  label: string;
  name: string;
  type: string; // InputType
  source: any;
  defaultValue: any;
  toInputName: any;
  showAll: boolean;

  constructor(label: string, name: string, type?: string, config?: InputConfig) {
    this.label = label;
    this.name = name;
    this.type = type ?? InputType.Text;
    this.source = config?.source;
    this.toInputName = config?.toInputName;
    this.defaultValue = config?.defaultValue;
    this.showAll = config?.showAll ?? true;
  }
}

export class InputConfig {
  source?: any;
  toInputName?: string;
  defaultValue?: any;
  showAll?: boolean;
}

export class InputType {
  static readonly Text = 'text';
  static readonly Number = 'number';
  static readonly TextArea = 'textarea';
  static readonly Multiselect = 'multiselect';
  static readonly DateRange = 'dateRange';
  static readonly Dropdown = 'dropdown';
  static readonly Date = 'date';
}
