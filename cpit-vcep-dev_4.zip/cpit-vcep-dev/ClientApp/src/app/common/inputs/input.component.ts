import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css'],
})
export class InputComponent implements OnInit {
  @Input()
  label: string;
  @Input()
  name: string;

  @Input()
  type: string;

  @Input() public form: UntypedFormGroup;

  @Input() public source: any;
  @Input() public toInputName: string;
  @Input() public showAll: boolean;

  filterInput: UntypedFormControl = new UntypedFormControl();
  selectList: any;

  constructor(private typeaheadService: TypeaheadService) {}

  ngOnInit(): void {
    if (this.source) {
      if (Array.isArray(this.source)) {
        this.selectList = this.typeaheadService.filterData(this.filterInput, this.source);
      } else {
        this.source().subscribe((data: any) => {
          this.selectList = this.typeaheadService.filterData(this.filterInput, data);
        });
      }
    }
  }
}
