import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { getQueryParams } from 'src/app/common/form/form.component';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';

import { RequestService } from 'src/app/services/request.service';
import { GrantsService } from './grants.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-grants',
  templateUrl: './grants.component.html',
  styleUrls: ['./grants.component.css'],
})
export class GrantsComponent implements OnInit {
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id'),
    new Column('label.shortReference', 'reference', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.reference, `grants/${e.id}`);
      },
    }),
    new Column('Grant Name', 'name'),
    new Column('Sector', 'sector', {
      type: ColumnType.Text,
      value: (e: any) => {
        return e.sectorLabel;
      },
    }),
    new Column('Priority', 'priority', {
      type: ColumnType.Status,
      value: (e: any) => {
        let type = StatusType.Default;
        let label = e.priorityLabel || 'N/A';
        switch (e.priority) {
          case '1':
            type = StatusType.Danger;
            label = 'Priority #1';
            break;
          case '2':
            type = StatusType.Warning;
            label = 'Priority #2';
            break;
          case '3':
            type = StatusType.Warning;
            label = 'Priority #3';
            break;
          case '4':
            type = StatusType.Default;
            label = 'Priority #4';
            break;
          default:
            type = StatusType.Default;
            break;
        }
        return {
          label: label,
          type: type,
        };
      },
    }),
    new Column('Contracts', 'contracts', {
      disableSorting: true,
      size: 'xxl',
      type: ColumnType.LinkList,
      value: (e: any) => {
        return e.contracts.map(
          (r: any) =>
            new Link(r.reference, `/contracts/${r.id}`)
        );
      },
    }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;
  permissions: any | null;
  config: any;
  private _grantServiceSubscription;

  filters: AppInput[] = [
    new AppInput('Grant Name', 'grantName'),
    new AppInput('Grant Reference/Number', 'grantReference'),
    new AppInput('Priorities', 'priorities', InputType.Multiselect, {
      source: () => this.request.getEnumValues('PriorityType'),
    }),
    new AppInput('Sectors', 'sectors', InputType.Multiselect, {
      source: () => this.request.getEnumValues('SectorType'),
    }),
    new AppInput('Description', 'description'),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private grantsService: GrantsService,
    private notify: NotificationService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this.path = this.activatedRoute.snapshot.url[0].path;
    this._grantServiceSubscription = this.grantsService.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    })
  }
  ngOnInit(): void {
    if (this.path == 'list-energy-grants') this.setDataSource({ filter: { sectors: [2] } });
    if (this.path == 'list-transport-grants') this.setDataSource({ filter: { sectors: [1] } });
    if (this.path == 'list-health-grants') this.setDataSource({ filter: { sectors: [3] } });
    if (this.path == 'list-anr-grants') this.setDataSource({ filter: { sectors: [4] } });
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    if (this.path == 'list-energy-grants') this.config['sectors'] = [2];
    if (this.path == 'list-transport-grants') this.config['sectors'] = [1];
    if (this.path == 'list-health-grants') this.config['sectors'] = [3];
    if (this.path == 'list-anr-grants') this.config['sectors'] = [4];

    this.request.getGrants(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageGrants) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.grantsService.openGrantsModal(),
          iconLabel: 'New Grant',
          color: 'accent',
          type: 'button',
          toolTip: 'New Grant',
        })
      );
    }

    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
        toolTip: 'button.edit',
        onClick: () => this.grantsService.openGrantsModal(e),
        color: 'primary',
      })
    );
    return actions;
  }

  exportToExcel() {
    this.request.getGrants(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'grants.xlsx', exportedColumns);
      }
    });
  }
}
