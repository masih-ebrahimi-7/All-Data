import { Component } from '@angular/core';

@Component({
  selector: 'app-grant-details',
  templateUrl: './grant-details.component.html',
  styleUrls: ['./grant-details.component.css']
})
export class GrantDetailsComponent {

}
