import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { TypeaheadInput } from 'src/app/common/typehead-input';
import { Grant, IGrantRequestModel } from 'src/app/models/grant.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';

@Injectable({
    providedIn: 'root'
})
export class GrantsService {
    priorities: TypeaheadInput[] = [];
    sectors: TypeaheadInput[] = [];
    @Output() onChangeSubmitted = new EventEmitter<boolean>();

    constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
        this.getPrioritiesForFilter();
        this.getSectorsForFilter();
    }

    openGrantsModal(grant?: Grant) {
        const data = {
            pageTitle: grant ? 'Edit Grant Details' : 'Insert a new Grant',
            fields: [
                {
                    name: 'reference',
                    label: 'Grant Number',
                    type: 'text',
                    value: grant?.reference ?? '',
                    required: true,
                    hint: "Will be used to create a Reference with the pattern: G0000",
                    suffix: "pin"
                },
                {
                    name: 'name',
                    label: 'Name',
                    type: 'text',
                    value: grant?.name ?? '',
                    required: true,
                },
                {
                    name: 'description',
                    label: 'Write a short Description',
                    type: 'textarea',
                    value: grant?.description ?? '',
                    required: false,
                },
                {
                    name: 'priority',
                    label: 'Select a Priority',
                    type: 'select',
                    value: grant?.priority?.toString(),
                    required: true,
                    options: this.priorities,
                },
                {
                    name: 'sector',
                    label: 'Select a Sector',
                    type: 'select',
                    value: grant?.sector?.toString(),
                    required: true,
                    options: this.sectors,
                },
            ],
        };

        const dialogRef = this.dialog.open(UpdateDialogComponent, {
            width: '50rem',
            data: data,
        });

        dialogRef.afterClosed().subscribe((result) => {
            if (result) {
                if (grant) {
                    let grantEditRequest: IGrantRequestModel = {
                        name: result.name ?? grant.name,
                        reference: result.reference ?? grant.reference,
                        description: result.description ?? grant.description,
                        priority: result.priority ?? grant.priority,
                        sector: result.sector ?? grant.sector,
                    };
                    return this.request.editGrant(grantEditRequest, grant.id).subscribe((data: any) => {
                        if (data) {
                            this.notify.showSuccess(`Grant edited successfully.`);
                            this.onChangeSubmitted.emit(true);
                        }
                        else this.notify.showError(`Unable to create grant.`);
                    });
                } else {
                    let grantCreateRequest: IGrantRequestModel = {
                        name: result.name ?? null,
                        reference: result.reference ?? null,
                        description: result.description ?? null,
                        priority: result.priority ?? null,
                        sector: result.sector ?? null,
                    };
                    return this.request.createGrant(grantCreateRequest).subscribe((data: any) => {
                        if (data) {
                            this.notify.showSuccess(`Grant created successfully.`);
                            this.onChangeSubmitted.emit(true);
                        }
                        else this.notify.showError(`Unable to create grant.`);
                    });
                }
            } else {
                return;
            }
        });
    }

    getPrioritiesForFilter() {
        this.request.getEnumValues('PriorityType').subscribe((data: any) => {
            this.priorities = data;
        });
    }

    getSectorsForFilter() {
        this.request.getEnumValues('SectorType').subscribe((data: any) => {
            this.sectors = data;
        });
    }
}


