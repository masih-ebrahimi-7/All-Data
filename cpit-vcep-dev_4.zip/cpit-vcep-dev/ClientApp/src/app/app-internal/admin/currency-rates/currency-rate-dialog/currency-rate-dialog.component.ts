import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-currency-rate-dialog',
  templateUrl: './currency-rate-dialog.component.html',
  styleUrls: ['./currency-rate-dialog.component.css'],
})
export class CurrencyRateDialogComponent implements OnInit {
  fromCurrencyForm = new UntypedFormControl();
  toCurrencyForm = new UntypedFormControl();
  currencySource = new UntypedFormControl();
  currencies: any;

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<CurrencyRateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }

  ngOnInit(): void {
    this.request.getEnumValues('CurrencyCode').subscribe((resp: any) => {
      this.currencies = resp;
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
