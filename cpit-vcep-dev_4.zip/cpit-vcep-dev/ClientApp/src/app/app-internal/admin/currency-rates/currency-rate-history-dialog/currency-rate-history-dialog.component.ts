import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-currency-rate-history-dialog',
  templateUrl: './currency-rate-history-dialog.component.html',
  styleUrls: ['./currency-rate-history-dialog.component.css'],
})
export class CurrencyRateHistoryDialogComponent implements OnInit {
  permissions: any | null;
  historyData: any[] = [];
  totalSize: any;
  displayedColumns: any;

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    permissionService: PermissionsService,
    public dialogRef: MatDialogRef<CurrencyRateHistoryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {
    this.displayedColumns = this.getDisplayedColumns();
  }

  setDataSource(config?: any) {
    var filters = config?.filter ?? {};
    this.request.showRateHistory(this.data.fromCurrencyCode, this.data.toCurrencyCode, filters.pageIndex, filters.pageSize).subscribe((data: any) => {
      this.historyData = data.records;
      this.totalSize = data.totalCount;
    });
  }

  getDisplayedColumns(): Column[] {
    return [
      new Column('From', 'fromCurrencyCodeDesc'),
      new Column('To', 'toCurrencyCodeDesc'),
      new Column('Rate', 'rate'),
      new Column('Currency Source', 'currencySource'),
      new Column('label.createdDate', 'createdDate', {
        type: ColumnType.DateTime,
      }),
      new Column('Created By', 'createdBy')
    ];
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
