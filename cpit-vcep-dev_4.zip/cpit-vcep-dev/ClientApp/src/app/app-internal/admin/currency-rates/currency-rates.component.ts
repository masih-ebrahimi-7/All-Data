import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Action, ActionList } from "src/app/common/table/Action";
import { Column, ColumnType } from "src/app/common/table/Column";
import { PermissionsService } from "src/app/services/auth/permissions.service";
import { NotificationService } from "src/app/services/notification.service";
import { RequestService } from "src/app/services/request.service";
import { CurrencyRateDialogComponent } from "./currency-rate-dialog/currency-rate-dialog.component";
import { CurrencyRateHistoryDialogComponent } from "./currency-rate-history-dialog/currency-rate-history-dialog.component";
import { AppInput } from "src/app/common/inputs/input";

@Component({
    selector: 'app-currency-rates',
    templateUrl: './currency-rates.component.html',
    styleUrls: ['./currency-rates.component.css'],
})
export class CurrencyRatesComponent implements OnInit {
    permissions: any | null;
    bulkActions: any;
    totalSize: number;
    data: any;
    displayedColumns = [
        new Column(' ', 'actions', {
            size: 'sm',
            type: ColumnType.DetailsActions,
            value: (e: any) => {
                return new ActionList(this.getActions(e));
            },
            disableSorting: true,
        }),
        new Column('From', 'fromCurrencyCodeDesc'),
        new Column('To', 'toCurrencyCodeDesc'),
        new Column('Rate', 'rate'),
        new Column('Currency Source', 'currencySource'),
        new Column('label.createdDate', 'createdDate', {
            type: ColumnType.DateTime,
        }),
        new Column('Created By', 'createdBy')
    ];
    filters: AppInput[] = [];

    constructor(
        private request: RequestService,
        public dialog: MatDialog,
        private permissionsService: PermissionsService,
        private notify: NotificationService
    ) {
        this.permissions = this.permissionsService.get();
    }

    ngOnInit(): void {
        this.setDataSource({ filter: { pageIndex: 1, pageSize: 10 } });
        this.bulkActions = this.getBulkActions();
    }

    setDataSource(config?: any) {
        var filters = config?.filter ?? {};
        return this.request.getCurrentCurrencyExchangeRates(filters.pageIndex, filters.pageSize).subscribe((data: any) => {
            this.data = data.records;
            this.totalSize = data.totalCount;
        });
    }

    createOrUpdateConversion(rate: any) {
        this.dialog.open(CurrencyRateDialogComponent, { width: '25em', data: rate }).afterClosed()
            .subscribe((ratemodel: any) => {
                if (ratemodel) {
                    this.request.createOrUpdateConversion(ratemodel).subscribe(() => {
                        this.setDataSource({ filter: { pageIndex: 1, pageSize: 10 } });
                        this.notify.showSuccess("Currency rate saved successfully");
                    })
                }
            });
    }

    showRateHistory(rate: any) {
        this.dialog.open(CurrencyRateHistoryDialogComponent, {
            data: rate
        });
    }

    getBulkActions() {
        var actions: Action[] = [];
        actions.push(
            new Action({
                iconName: 'add',
                onClick: () => this.createOrUpdateConversion({}),
                iconLabel: 'New rate',
                color: 'accent',
                type: 'button',
                toolTip: 'New currency conversion rate',
            })
        );

        return actions;
    }

    getActions(row: any): Action[] {
        var actions = [];
        var className = 'link ML10';

        actions.push(
            new Action({
                iconName: 'open_in_new',
                toolTip: 'Update rate',
                onClick: () => this.createOrUpdateConversion(row),
                class: className,
            })
        );

        actions.push(
            new Action({
                iconName: 'history',
                toolTip: 'View history',
                onClick: () => this.showRateHistory(row),
                class: className,
            })
        );

        return actions;
    }

}