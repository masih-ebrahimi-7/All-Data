import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { EditDocumentCategoryComponent } from './edit-document-category/edit-document-category.component';

@Component({
  selector: 'app-document-categories',
  templateUrl: './document-categories.component.html',
  styleUrls: ['./document-categories.component.css'],
})
export class DocumentCategoriesComponent implements OnInit {
  displayedColumns: Column[] = [
    new Column('', 'action', {
      type: ColumnType.DetailsActions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList([
          new Action({
            iconName: 'edit',
            toolTip: 'Edit',
            onClick: () => this.showEdit(e),
            class: 'link ML10',
          }),
          new Action({
            iconName: 'delete',
            toolTip: 'Delete',
            onClick: () => this.delete(e),
            class: 'link ML10',
          }),
        ]);
      },
    }),
    new Column('Name', 'name'),
    new Column('Description', 'description'),
    new Column('Created Date', 'createdDate', {
      type: ColumnType.DateTime,
    }),
  ];

  moment = moment;
  filterValue: string;
  loading: boolean = true;
  totalSize: number;
  data: any;
  showAddForm: boolean = false;
  form: any;
  bulkActions: any;
  config: any;

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private notify: NotificationService
  ) {
    const queryParamMap = this.activatedRoute.snapshot.queryParamMap;
    this.filterValue = queryParamMap.get('query') ? (queryParamMap.get('query') as any) : '';
  }
  ngOnInit(): void {
    this.bulkActions = this.getBulkActions();
  }

  getBulkActions() {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconName: 'add',
        onClick: () => this.showEdit({}),
        iconLabel: 'Add a Category',
        color: 'primary',
        type: 'button',
        toolTip: 'Add a Category',
      })
    );

    return actions;
  }

  setDataSource(config: any) {
    this.config = config;
    this.request.getDocumentCategories(config.pageIndex, config.pageSize, config.orderBy, config.direction, this.filterValue).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  applyFilter() {
    let currentPath: any = '';
    this.activatedRoute.snapshot.url.forEach((url) => {
      currentPath += '/' + url.path;
    });
    this.router.navigate([currentPath], { queryParams: { query: this.filterValue } });
    this.setDataSource(this.config);
  }

  showEdit(row: any) {
    const dialogRef = this.dialog.open(EditDocumentCategoryComponent, {
      width: '400px',
      data: { documentCategory: row },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.documentCategory && result.documentCategory.name) {
        this.request.updateDocumentCategory(result.documentCategory).subscribe((data: any) => {
          this.notify.showSuccess('Changes saved successfully');
          this.setDataSource(this.config);
        });
      }
    });
  }
  delete(row: any) {
    this.notify.showConfirm({
      title: 'Delete Document Category',
      message: 'Are you sure you want to delete this item?',
      confirmText: 'Delete',
      cancelText: 'Cancel'
    }).subscribe(result => {
      if (result) {
        row.isDeleted = true;
        this.request.updateDocumentCategory(row).subscribe((data: any) => {
          this.notify.showSuccess('Changes saved successfully');
          this.setDataSource(this.config);
        });
      }
    });
  }
}


export interface DocumentCategoryDialog {
  documentCategory: any;
}