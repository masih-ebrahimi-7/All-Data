import { Component, Inject, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, UntypedFormControl, ValidationErrors, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RequestService } from 'src/app/services/request.service';
import { DocumentCategoryDialog } from '../document-categories.component';
import { TokenService } from 'src/app/services/auth/token.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-edit-document-category',
  templateUrl: './edit-document-category.component.html',
  styleUrls: ['./edit-document-category.component.css'],
})
export class EditDocumentCategoryComponent implements OnInit {
  form: any;
  documentCategory:any;
  constructor(
    private request: RequestService,
    private formBuilder: FormBuilder,
    private notify: NotificationService,
    public dialogRef: MatDialogRef<EditDocumentCategoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DocumentCategoryDialog
  ) {}

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      name: new FormControl(this.data.documentCategory.name),
      description: new FormControl(this.data.documentCategory.description)
    });

  }
  
}
