import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ClaimStageService } from '../../../../services/claim-stage.service';
import { ClaimStageResponseModel, CreateClaimStageRequestModel, EditClaimStageRequestModel } from '../../../../models/claim-stage.models';

export interface EditClaimStageDialogData {
  stage: ClaimStageResponseModel | null;
  parentStage: ClaimStageResponseModel | null;
  allStages: ClaimStageResponseModel[];
}

@Component({
  selector: 'app-edit-claim-stage-dialog',
  templateUrl: './edit-claim-stage-dialog.component.html',
  styleUrls: ['./edit-claim-stage-dialog.component.css']
})
export class EditClaimStageDialogComponent implements OnInit {
  form: FormGroup;
  loading = false;
  isEdit = false;
  availableParentStages: ClaimStageResponseModel[] = [];

  constructor(
    private fb: FormBuilder,
    private claimStageService: ClaimStageService,
    private dialogRef: MatDialogRef<EditClaimStageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: EditClaimStageDialogData
  ) {
    this.isEdit = !!data.stage;
    this.form = this.createForm();
    this.setupAvailableParentStages();
  }

  ngOnInit(): void {
    if (this.isEdit && this.data.stage) {
      this.populateForm(this.data.stage);
    } else if (this.data.parentStage) {
      this.form.patchValue({
        parentStageId: this.data.parentStage.id
      });
    }
  }

  private createForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(200)]],
      description: ['', [Validators.maxLength(1000)]],
      weightPercentage: [0, [Validators.required, Validators.min(0), Validators.max(100)]],
      estimatedDurationWeeks: [1, [Validators.required, Validators.min(1), Validators.max(520)]],
      sortOrder: [1, [Validators.required, Validators.min(1)]],
      isActive: [true],
      parentStageId: [null],
      estimatedDeliveryTimeline: ['', [Validators.maxLength(500)]]
    });
  }

  private setupAvailableParentStages(): void {
    this.availableParentStages = this.data.allStages.filter(stage => 
      !stage.parentStageId && (!this.isEdit || stage.id !== this.data.stage?.id)
    );
  }

  private populateForm(stage: ClaimStageResponseModel): void {
    this.form.patchValue({
      name: stage.name,
      description: stage.description,
      weightPercentage: stage.weightPercentage,
      estimatedDurationWeeks: stage.estimatedDurationWeeks,
      sortOrder: stage.sortOrder,
      isActive: stage.isActive,
      parentStageId: stage.parentStageId,
      estimatedDeliveryTimeline: stage.estimatedDeliveryTimeline
    });
  }

  onSubmit(): void {
    if (this.form.valid) {
      this.loading = true;
      
      if (this.isEdit) {
        const editRequest: EditClaimStageRequestModel = {
          id: this.data.stage!.id,
          ...this.form.value
        };
        
        this.claimStageService.updateStage(editRequest).subscribe({
          next: () => {
            this.loading = false;
            this.dialogRef.close(true);
          },
          error: (error) => {
            console.error('Error updating stage:', error);
            this.loading = false;
          }
        });
      } else {
        const createRequest: CreateClaimStageRequestModel = this.form.value;
        
        this.claimStageService.createStage(createRequest).subscribe({
          next: () => {
            this.loading = false;
            this.dialogRef.close(true);
          },
          error: (error) => {
            console.error('Error creating stage:', error);
            this.loading = false;
          }
        });
      }
    }
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }

  getDialogTitle(): string {
    if (this.isEdit) {
      return 'Edit Claim Stage';
    } else if (this.data.parentStage) {
      return `Add Child Stage to "${this.data.parentStage.name}"`;
    } else {
      return 'Add Parent Stage';
    }
  }

  isParentStage(): boolean {
    return !this.form.get('parentStageId')?.value;
  }
}
