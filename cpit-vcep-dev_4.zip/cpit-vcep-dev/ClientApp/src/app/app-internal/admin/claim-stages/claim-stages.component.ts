import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ClaimStageService } from '../../../services/claim-stage.service';
import { ClaimStageResponseModel, CreateClaimStageRequestModel, EditClaimStageRequestModel } from '../../../models/claim-stage.models';
import { EditClaimStageDialogComponent } from './edit-claim-stage-dialog/edit-claim-stage-dialog.component';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-claim-stages',
  templateUrl: './claim-stages.component.html',
  styleUrls: ['./claim-stages.component.css']
})
export class ClaimStagesComponent implements OnInit {
  stages: ClaimStageResponseModel[] = [];
  loading = false;
  expandedStages: Set<number> = new Set();

  constructor(
    private claimStageService: ClaimStageService,
    private dialog: MatDialog,
    private notificationService: NotificationService
  ) { }

  ngOnInit(): void {
    this.loadStages();
  }

  loadStages(): void {
    this.loading = true;
    this.claimStageService.getAllStages().subscribe({
      next: (stages) => {
        this.stages = stages;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading stages:', error);
        this.notificationService.showError('Error loading stages');
        this.loading = false;
      }
    });
  }

  toggleExpanded(stageId: number): void {
    if (this.expandedStages.has(stageId)) {
      this.expandedStages.delete(stageId);
    } else {
      this.expandedStages.add(stageId);
    }
  }

  isExpanded(stageId: number): boolean {
    return this.expandedStages.has(stageId);
  }

  addStage(parentStage?: ClaimStageResponseModel): void {
    const dialogRef = this.dialog.open(EditClaimStageDialogComponent, {
      width: '600px',
      data: { 
        stage: null, 
        parentStage: parentStage,
        allStages: this.stages 
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadStages();
        this.notificationService.showSuccess('Stage created successfully');
      }
    });
  }

  editStage(stage: ClaimStageResponseModel): void {
    const dialogRef = this.dialog.open(EditClaimStageDialogComponent, {
      width: '600px',
      data: { 
        stage: stage, 
        parentStage: null,
        allStages: this.stages 
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadStages();
        this.notificationService.showSuccess('Stage updated successfully');
      }
    });
  }

  deleteStage(stage: ClaimStageResponseModel): void {
    this.notificationService.showConfirm({
      title: 'Delete Stage',
      message: `Are you sure you want to delete the stage "${stage.name}"? This action cannot be undone.`,
      confirmText: 'Delete',
      cancelText: 'Cancel'
    }).subscribe(result => {
      if (result) {
        this.claimStageService.deleteStage(stage.id).subscribe({
          next: () => {
            this.loadStages();
            this.notificationService.showSuccess('Stage deleted successfully');
          },
          error: (error) => {
            console.error('Error deleting stage:', error);
            this.notificationService.showError('Error deleting stage');
          }
        });
      }
    });
  }

  canDelete(stage: ClaimStageResponseModel): boolean {
    return stage.children.length === 0;
  }

  getIndentClass(level: number): string {
    return `indent-${Math.min(level, 3)}`;
  }
}
