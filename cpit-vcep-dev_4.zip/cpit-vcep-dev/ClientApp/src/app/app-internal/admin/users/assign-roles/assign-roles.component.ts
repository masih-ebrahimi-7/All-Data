import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RequestService } from 'src/app/services/request.service';
import { AssignUserRoleDialog } from '../users.component';

@Component({
  selector: 'app-assign-roles',
  templateUrl: './assign-roles.component.html',
  styleUrls: ['./assign-roles.component.css'],
})
export class AssignRolesComponent implements OnInit {
  constructor(
    private request: RequestService,
    public dialogRef: MatDialogRef<AssignRolesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AssignUserRoleDialog
  ) {}

  roles = new UntypedFormControl();
  rolesList: string[] = [];

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.request.getSystemRoles().subscribe((data: any) => {
      this.rolesList = data;
    });
  }
}
