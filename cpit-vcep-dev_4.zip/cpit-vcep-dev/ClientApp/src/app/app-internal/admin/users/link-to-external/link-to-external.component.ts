import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-link-to-external',
  templateUrl: './link-to-external.component.html',
  styleUrls: ['./link-to-external.component.css'],
})
export class LinkUserToExternalComponent implements OnInit {
  constructor(
    private request: RequestService,
    private typeaheadService: TypeaheadService,
    public dialogRef: MatDialogRef<LinkUserToExternalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  externalEntity = new UntypedFormControl();
  externalEntityFilter = new UntypedFormControl();
  externalEntitiesList: any[] = [];
  filteredExternalEntities: Observable<TypeaheadInput[]>;

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    if (this.data.externalEntities) {
      this.filteredExternalEntities = this.typeaheadService.filterData(this.externalEntityFilter, this.data.externalEntities);
    } else {
      this.request.getExternalEntitiesForFilter().subscribe((data: any) => {
        this.filteredExternalEntities = this.typeaheadService.filterData(this.externalEntityFilter, data);
      });
    }
  }
}
