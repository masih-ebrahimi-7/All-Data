import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AddExternalUserDialog } from 'src/app/app-internal/external-entities/models/external-user-models';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-add-external-entity-user',
  templateUrl: './add-external-entity-user.component.html',
  styleUrls: ['./add-external-entity-user.component.css'],
})
export class AddExternalEntityUserComponent implements OnInit {
  constructor(
    private request: RequestService,
    public dialogRef: MatDialogRef<AddExternalEntityUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddExternalUserDialog
  ) { }

  user: any;
  filesToUpload: number = 1;
  roles = new UntypedFormControl();
  rolesList: string[] = [];

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    if (this.data.user.id && this.data.user.id > 0) {
      this.request.getExternalEntityUser(this.data.user.id).subscribe((data: any) => {
        this.data.user = data;
      });
    }

    // Get roles for the entity type attached
    this.request.getSystemRoles().subscribe((data: any) => {
      this.rolesList = data;
    });

  }

  filterRoles(entityType: string) {
    let roleType: string = "";
    if (entityType == 'Contractor' || entityType == 'Consultant' || entityType == 'Claimant') roleType = 'Claimant';
    else if (entityType == 'MoF') roleType = 'MoF';
    else if (entityType == 'Donor') roleType = 'Donor';
    else if (entityType == 'MPW') roleType = 'MPW';
    else if (entityType == 'MoPH') roleType = 'MoPH';
    else if (entityType == 'MRRD') roleType = 'MRRD';
    else if (entityType == 'MAIL') roleType = 'MAIL';
    else if (entityType == 'DABS') roleType = 'DABS';
    else if (entityType == 'MEW') roleType = 'MEW';
    return this.rolesList.filter((item: string) => item === roleType);
  }

  fileUploadHandler(event: any[]) {
    this.data.user.userFile = event;
  }

  isUploadButtonDisabled() {
    let isDisabled = false;
    if (!this.data.user.userFile || this.data.user.userFile?.length > this.filesToUpload) {
      isDisabled = true;
    }
    return isDisabled;
  }
}
