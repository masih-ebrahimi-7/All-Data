import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { Action, ActionList, ActionListType } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { AssignRolesComponent } from './assign-roles/assign-roles.component';
import { LinkUserToExternalComponent } from './link-to-external/link-to-external.component';
import { exportDataToSheet } from 'src/app/common/helpers';
import { UserManagementPageType } from 'src/app/models/enums/ui-enums';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent {
  displayedColumns: Column[] = [
    new Column('', 'action', {
      type: ColumnType.DetailsActions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e), ActionListType.More);
      },
    }),
    new Column('Name', 'userName'),
    new Column('Email', 'email'),
    new Column('Roles', 'roles', { disableSorting: true }),
    new Column('Phone Number', 'phoneNumber'),
    new Column('Active', 'isActive', {
      disableSorting: true,
      type: ColumnType.Status,
      value: (e: any) => {
        return {
          label: e.isActive ? 'Active' : 'Activation Pending',
          type: e.isActive ? StatusType.Success : StatusType.Warning,
        };
      },
    }),

    new Column('Last Login Date', 'lastLoginDate'),
    new Column('Contractors', 'contractorNames', { disableSorting: true }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  config: any;
  bulkActions: any;
  userType: UserManagementPageType;
  filters: AppInput[] = [];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private notify: NotificationService
  ) {
    this.bulkActions = this.getBulkActions();
    this.userType = this.getUserType();
  }

  ngOnInit(): void {
    this.filters = this.getFilters();
  }

  getFilters(): AppInput[] {
    let filters = [];
    filters.push(
      new AppInput('Email', 'email'), 
      new AppInput('Name', 'name')
    );

    if (this.userType == UserManagementPageType.External || this.userType == UserManagementPageType.All)
      filters.push(
        new AppInput('External Entity Types', 'externalEntityTypes', InputType.Multiselect, {
          source: () => this.request.getEnumValues('ExternalEntityType'),
        })
      );
    return filters;
  }

  setDataSource(config?: any) {
    this.config = config?.filter ?? {};

    this.request.getUsers(this.config, this.userType).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getActions(row: any): Action[] {
    var actions = [];
    var className = 'link ML10';
    if (row.isActive) {
      actions.push(
        new Action({
          iconName: 'person_off',
          toolTip: 'Deactivate',
          onClick: () => this.deactivateUser(row.userId),
          class: className,
        })
      );
      actions.push(
        new Action({
          iconName: 'admin_panel_settings',
          toolTip: 'Assign roles',
          onClick: () => this.openAssignRolesDialog(row.userId, row.roles, false),
        })
      );
    } else {
      actions.push(
        new Action({
          iconName: 'person_check',
          toolTip: 'Activate',
          onClick: () => this.openAssignRolesDialog(row.userId, row.roles, true),
          class: className,
        })
      );
    }

    actions.push(
      new Action({
        iconName: 'link',
        toolTip: 'Link to external entity',
        onClick: () => this.linkToExternalEntity(row.userId),
        class: className,
      })
    );

    if (row.contractors?.length > 0) {
      actions.push(
        new Action({
          iconName: 'link_off',
          toolTip: 'Unlink from external entity',
          onClick: () => this.unlinkToExternalEntity(row),
          class: className,
        })
      );
    }

    actions.push(
      new Action({
        iconName: 'visibility',
        toolTip: 'Impersonate',
        onClick: () => this.impersonateUser(row.userId),
        class: className + ' color-warning',
      })
    );

    actions.push(
      new Action({
        iconName: 'edit',
        toolTip: 'Edit',
        onClick: () => this.editUser(row),
        class: className + ' color-warning',
      })
    );

    return actions;
  }

  getBulkActions() {
    var actions: Action[] = [];

    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getUserType(): UserManagementPageType {
    if (this.activatedRoute.snapshot.url[0].path == 'internal-users') return UserManagementPageType.Internal;
    if (this.activatedRoute.snapshot.url[0].path == 'external-users') return UserManagementPageType.External;

    return UserManagementPageType.All;
  }

  openAssignRolesDialog(userId: string, roles: any, isActivateAccount: boolean): void {
    const dialogRef = this.dialog.open(AssignRolesComponent, {
      width: '400px',
      data: { userId: userId, roles: roles, isActivateAccount: isActivateAccount },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (isActivateAccount) {
        if (Array.isArray(result.value) && result.value?.length > 0) {
          this.request.activateAndAssignUser(userId, result.value).subscribe((data: any) => {
            this.notify.showSuccess(`User ${userId} was successfully activated.`);
            this.setDataSource(this.config);
          });
        } else {
          this.notify.showError('Please select at least one user role.');
        }
      } else {
        this.request.assignRoles(userId, result.value).subscribe((data: any) => {
          this.setDataSource(this.config);
        });
      }
    });
  }

  deactivateUser(userId: string): void {
    this.request.deactivateUser(userId).subscribe((data: any) => {
      this.notify.showSuccess(`User ${userId} was deactivated.`);
      this.setDataSource(this.config);
    });
  }

  impersonateUser(userId: string): void {
    this.request.impersonateUser(userId).subscribe((res: any) => {
      this.tokenService.set(res.token);
      this.permissionsService.set(res.permissions);
      localStorage.setItem('impersonator', res.impersonator);
      window.location.href = '/';
    });
  }

  editUser(user: any): void {
    debugger;
    const data = {
      pageTitle: 'Edit User',
      fields: [
        {
          name: 'email',
          label: 'Email',
          type: 'readonly',
          value: user.email?.toString(),
          required: false
        },
        {
          name: 'phoneNumber',
          label: 'Phone Number',
          type: 'text',
          value: user.phoneNumber?.toString(),
          required: false
        }
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.request.editUser(user.userId, { phoneNumber: result.phoneNumber }).subscribe((data: any) => {
          this.notify.showSuccess(`User ${user.userId} was edited.`);
          this.setDataSource(this.config);
        });
      }
    });
  }

  linkToExternalEntity(userId: string): void {
    const dialogRef = this.dialog.open(LinkUserToExternalComponent, {
      width: '400px',
      data: { userId: userId, isLink: true },
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.request.linkUserToExternalEntity(userId, result.value).subscribe((data: any) => {
        this.notify.showSuccess(`User ${userId} was linked to entity ${result.value}.`);
        this.setDataSource(this.config);
      });
    });
  }

  unlinkToExternalEntity(user: any): void {
    const dialogRef = this.dialog.open(LinkUserToExternalComponent, {
      width: '400px',
      data: { userId: user.userId, isLink: false, contractors: user.contractors },
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.request.unlinkUserToExternalEntity(user.userId, result.value).subscribe((data: any) => {
        this.notify.showSuccess(`User ${user.email} was unlinked from entity ${result.value}.`);
        this.setDataSource(this.config);
      });
    });
  }

  exportToExcel() {
    this.request.getUsers(this.config, this.userType).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'users.xlsx', exportedColumns);
      }
    });
  }
}

interface User {
  userName: string;
  email: string;
  userId: string;
  roles: string[];
}
export interface AssignUserRoleDialog {
  userId: string;
  roles: any;
  isActivateAccount: boolean;
}
