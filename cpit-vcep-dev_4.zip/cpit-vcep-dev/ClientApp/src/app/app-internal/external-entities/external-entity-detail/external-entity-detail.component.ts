import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { RequestService } from 'src/app/services/request.service';
import { AddExternalEntityDialog } from '../models/external-entity-models';

@Component({
  selector: 'app-external-entity-detail',
  templateUrl: './external-entity-detail.component.html',
  styleUrls: ['./external-entity-detail.component.css'],
})
export class ExternalEntityDetailComponent implements OnInit {
  permissions: any | null;
  enternalEntityTypes = new UntypedFormControl();
  entityTypes: any[] = [];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    permissionService: PermissionsService,
    public dialogRef: MatDialogRef<ExternalEntityDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddExternalEntityDialog
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {

    if (this.data.externalEntityId && this.data.externalEntityId > 0) {
      this.request.getExternalEntity(this.data.externalEntityId).subscribe((data: any) => {
        this.data.externalEntity = data;
      });
    }
    this.request.getExternalEntityTypes().subscribe((data:any)=>{
      this.entityTypes = data;
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
