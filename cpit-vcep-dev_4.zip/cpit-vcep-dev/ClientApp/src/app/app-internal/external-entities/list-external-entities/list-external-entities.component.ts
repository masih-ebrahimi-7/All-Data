import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { ActivatedRoute } from '@angular/router';
import { AppInput } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { UserProfileService } from 'src/app/services/auth/user-profile.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { AddExternalEntityUserComponent } from '../../admin/users/add-external-entity-user/add-external-entity-user.component';
import { ExternalEntityDetailComponent } from '../external-entity-detail/external-entity-detail.component';
import { exportDataToSheet } from 'src/app/common/helpers';
@Component({
  selector: 'app-list-external-entities',
  templateUrl: './list-external-entities.component.html',
  styleUrls: ['./list-external-entities.component.css'],
})
export class ListExternalEntitiesComponent {
  columnsList: Array<Column> = [
    new Column('', 'actions', {
      type: ColumnType.DetailsActions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id'),
    new Column('label.name', 'name'),
    new Column('label.nationality', 'nationality'),
    new Column('Red Flag Alert', 'fraudulent', {
      type: ColumnType.Icon,
      value: (e: any) => {
        switch (e.fraudulent) {
          case true:
            return { color: 'warn', fontIcon: 'warning' };
          default:
            return { color: 'primary', fontIcon: 'gpp_good' };
        }
      },
    }),
    new Column('label.externalEntityType', 'externalEntityTypeString', {
      disableSorting: true,
    }),

    new Column('label.invitedUsers', 'externalEntityUsers', {
      type: ColumnType.Actions,
      disableSorting: true,
      value: (v: any) => {
        var actions: Action[] = [];
        if (Array.isArray(v.externalEntityUsers)) {
          v.externalEntityUsers.map((r: any) => {
            actions.push(
              new Action({
                htmlLabel: r.name,
                class: 'like-link',
                onClick: () => this.addExternalEntityUser({ id: v.id }, r),
              })
            );
          });
        }
        return new ActionList(actions);
      },
    }),
  ];

  config: any;
  data: any;
  pageEvent: PageEvent;
  permissions: any | null;
  queryParams: any;
  filters: AppInput[] = [new AppInput('label.name', 'name')];
  tableactions: any;
  issueTypeList: any[] = [];
  priorityList: any[] = [];
  totalSize: number;
  panelOpenState = false;
  displayingAll = true;
  userInfo: any;
  public selected: any;
  public users: any = [];
  constructor(
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private notify: NotificationService,
    permissionService: PermissionsService,
    private userProfileService: UserProfileService
  ) {
    this.queryParams = this.getQueryParams();
    this.permissions = permissionService.get();
    this.userInfo = this.userProfileService.get();
    this.tableactions = this.getBulkActions();
  }

  getBulkActions() {
    var actions: Action[] = [];
    actions.push(
      new Action({
        onClick: () => this.openDetail('new'),
        iconLabel: 'button.createNew',
        color: 'primary',
        type: 'button',
        iconName: 'add_circle',
        toolTip: 'tooltip.createNewExternalEntity',
      })
    );

    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  setDataSource(config: any) {
    this.config = config;
    this.request
      .getAllExternalEntities(config.filter || {})
      .subscribe((data: any) => {
        this.totalSize = data.totalCount;
        this.data = data.records;
      });
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconName: 'remove_red_eye',
        toolTip: 'Open details',
        onClick: () => this.openDetail(e.id),
        class: 'link ML10',
      })
    );
    actions.push(
      new Action({
        iconName: 'person_add_alt',
        toolTip: 'Invite user',
        onClick: () => this.addExternalEntityUser(e, {}),
        class: 'link ML10',
      })
    );
    return actions;
  }

  addExternalEntityUser(externalEntity: any, user: any): void {
    const dialogRef = this.dialog.open(AddExternalEntityUserComponent, {
      width: '400px',
      data: { externalEntity: externalEntity, user: user },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.userFile && result.userFile?.length > 0) {
          var formData = new FormData();
          formData.append('file', <File>result.userFile[0]);
          formData.append('externalEntityId', externalEntity.id);
          this.request.uploadExternalUsers(formData).subscribe((data: any) => {
            this.setDataSource(this.config);
          });
        } else {
          var toPost = {
            id: result.id,
            name: result.name,
            email: result.email,
            externalEntityId: externalEntity.id,
            role: result.role
          };
          this.request.createExternalEntityUser(toPost).subscribe((data: any) => {
            this.setDataSource(this.config);
          });
        }
      }
    });
  }

  getQueryParams() {
    const queryParamMap = this.activatedRoute.snapshot.queryParamMap;
    return {
      statuses: queryParamMap.getAll('statuses')?.length === 0 ? null : queryParamMap.getAll('statuses'),
    };
  }

  openDetail(id: string) {

    const dialogRef = this.dialog.open(ExternalEntityDetailComponent, {
      width: '400px',
      data: { externalEntityId: id, externalEntity: {} },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.request.createOrUpdateExternalEntity(result).subscribe((data: any) => {
          this.notify.showSuccess('External entity created successfully');
          this.setDataSource(this.config);
        });
      }
    });
  }

  exportToExcel() {
    this.request.getAllExternalEntities(this.config).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.columnsList.map(a => a.columnName);
        exportDataToSheet(data.records, 'external-entities.xlsx', exportedColumns);
      }
    });
  }
}
