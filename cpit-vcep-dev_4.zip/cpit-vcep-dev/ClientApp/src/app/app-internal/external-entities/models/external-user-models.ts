export interface AssignExternalUserToProjectDialog {
    externalUserId: string;
    projects: any;
}

export interface AddExternalUserDialog {
    externalEntity: any;
    user: any;
}