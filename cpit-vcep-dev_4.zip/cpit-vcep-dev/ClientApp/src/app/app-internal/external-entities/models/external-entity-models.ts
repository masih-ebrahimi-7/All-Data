export interface AddExternalEntityDialog {
    externalEntityId: number;
    externalEntity: any;
}