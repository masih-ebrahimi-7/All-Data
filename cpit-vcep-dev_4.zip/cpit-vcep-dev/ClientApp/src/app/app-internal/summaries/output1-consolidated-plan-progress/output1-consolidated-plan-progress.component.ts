import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { RequestService } from '../../../services/request.service';
import { 
  Output1ConsolidatedPlanProgressStatusReportModel, 
  Output1ConsolidatedPlanProgressStatusReportRequest,
  ClaimStageProgressModel 
} from '../../../models/output1-consolidated-plan-progress-status-report.model';
import { TypeaheadInput } from '../../../common/typehead-input';

@Component({
  selector: 'app-output1-consolidated-plan-progress',
  templateUrl: './output1-consolidated-plan-progress.component.html',
  styleUrls: ['./output1-consolidated-plan-progress.component.css']
})
export class Output1ConsolidatedPlanProgressComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns: string[] = [
    'number',
    'wbs',
    'priority',
    'donor',
    'grantNumber',
    'contractNumber',
    'contractTitle',
    'claimant',
    'countryOfRegistration',
    'claimedAmount',
    'unopsRecommendation',
    'unopsRecommendationAugust2025USD',
    'progressPercentageComplete',
    'stages'
  ];

  dataSource = new MatTableDataSource<Output1ConsolidatedPlanProgressStatusReportModel>();
  isLoading = false;
  totalCount = 0;
  pageSize = 25;
  currentPage = 1;
  searchTerm = '';
  priorityFilter = '';
  donorFilter = '';
  progressMin?: number;
  progressMax?: number;
  filtersExpanded = true;
  priorities: TypeaheadInput[] = [];
  fundSources: TypeaheadInput[] = [];
  isLoadingFilters = true;

  stageHeaders: string[] = [
    'Initial Review (2%)',
    'Documents Request From claimant (1%)',
    'Documents Request From MoF (1%)',
    'Documents Review (6%)',
    'Site Visit (15%)',
    'Analysis, Verification and DD (45%)',
    'Payment Certificate & QA (4%)',
    'Payment Certificate & Verification Report Sent (1%)',
    'Feedback Received from ADB',
    'Comments addressed (1%)',
    'ADB Due Diligence (1%)',
    'Official notification and Abr. Report prepared and sent (2%)',
    'Consultation meetings (18%)',
    'Acknowledgment Certificate Signed (1%)',
    'Confirmation Letter Signed (1%)',
    'Final Submission to ADB and Case Closed (1%)'
  ];

  constructor(
    private requestService: RequestService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadFilterOptions();
    this.loadData();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  loadData(): void {
    this.isLoading = true;
    
    const request: Output1ConsolidatedPlanProgressStatusReportRequest = {
      pageIndex: this.currentPage,
      pageSize: this.pageSize,
      searchTerm: this.searchTerm || undefined,
      priorityFilter: this.priorityFilter || undefined,
      donorFilter: this.donorFilter || undefined,
      progressMin: this.progressMin,
      progressMax: this.progressMax
    };

    this.requestService.getOutput1ConsolidatedPlanProgressStatusReport(request)
      .subscribe({
        next: (response) => {
          this.dataSource.data = response.records;
          this.totalCount = response.totalCount;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error loading report data:', error);
          this.isLoading = false;
        }
      });
  }

  onPageChange(event: any): void {
    this.currentPage = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.loadData();
  }

  onSearchChange(): void {
    this.currentPage = 1;
    this.loadData();
  }

  onFilterChange(): void {
    this.currentPage = 1;
    this.loadData();
  }

  private loadFilterOptions(): void {
    this.isLoadingFilters = true;
    
    this.requestService.getEnumValues('PriorityType').subscribe({
      next: (data: any) => {
        this.priorities = data;
      },
      error: (error) => {
        console.error('Error loading priorities:', error);
      }
    });

    this.requestService.getEnumValues('FundSourceType').subscribe({
      next: (data: any) => {
        this.fundSources = data;
        this.isLoadingFilters = false;
      },
      error: (error) => {
        console.error('Error loading fund sources:', error);
        this.isLoadingFilters = false;
      }
    });
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.priorityFilter = '';
    this.donorFilter = '';
    this.progressMin = undefined;
    this.progressMax = undefined;
    this.currentPage = 1;
    this.loadData();
  }

  toggleFilters(): void {
    this.filtersExpanded = !this.filtersExpanded;
  }

  exportToExcel(): void {
    const request: Output1ConsolidatedPlanProgressStatusReportRequest = {
      pageIndex: 1,
      pageSize: 9999,
      searchTerm: this.searchTerm || undefined,
      priorityFilter: this.priorityFilter || undefined,
      donorFilter: this.donorFilter || undefined,
      progressMin: this.progressMin,
      progressMax: this.progressMax
    };

    this.requestService.exportOutput1ConsolidatedPlanProgressStatusReport(request)
      .subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `Output1_Consolidated_Plan_Progress_Report_${new Date().toISOString().split('T')[0]}.xlsx`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        },
        error: (error) => {
          console.error('Error exporting to Excel:', error);
        }
      });
  }

  formatCurrency(amount: number, currency?: string): string {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD',
      minimumFractionDigits: 2
    });
    return formatter.format(amount);
  }

  getProgressBarColor(progress: number): string {
    if (progress >= 80) return 'accent';
    if (progress >= 50) return 'primary';
    if (progress >= 25) return 'warn';
    return 'basic';
  }

  getStageStatusColor(stage: ClaimStageProgressModel): string {
    if (stage.isCompleted) return 'completed';
    if (stage.isCurrentStage) return 'current';
    return 'pending';
  }

  getStageIcon(stage: ClaimStageProgressModel): string {
    if (stage.isCompleted) return 'check_circle';
    if (stage.isCurrentStage) return 'radio_button_checked';
    return 'radio_button_unchecked';
  }

  trackByStageId(index: number, stage: ClaimStageProgressModel): number {
    return stage.stageId;
  }

  trackByClaim(index: number, claim: Output1ConsolidatedPlanProgressStatusReportModel): number {
    return claim.number;
  }

  getUniqueStages(): ClaimStageProgressModel[] {
    const stageMap = new Map<number, ClaimStageProgressModel>();
    
    this.dataSource.data.forEach(claim => {
      claim.stages.forEach(stage => {
        if (!stageMap.has(stage.stageId)) {
          stageMap.set(stage.stageId, stage);
        }
        stage.children.forEach(child => {
          if (!stageMap.has(child.stageId)) {
            stageMap.set(child.stageId, child);
          }
        });
      });
    });

    return Array.from(stageMap.values())
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }

  getParentStages(): ClaimStageProgressModel[] {
    const stageMap = new Map<number, ClaimStageProgressModel>();
    
    this.dataSource.data.forEach(claim => {
      claim.stages.forEach(stage => {
        if (!stageMap.has(stage.stageId)) {
          stageMap.set(stage.stageId, stage);
        }
      });
    });

    return Array.from(stageMap.values())
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }

  getAllChildStages(): ClaimStageProgressModel[] {
    const childStages: ClaimStageProgressModel[] = [];
    
    this.dataSource.data.forEach(claim => {
      claim.stages.forEach(stage => {
        childStages.push(...stage.children);
      });
    });

    const uniqueChildren = childStages.filter((stage, index, self) => 
      index === self.findIndex(s => s.stageId === stage.stageId)
    );

    return uniqueChildren.sort((a, b) => a.sortOrder - b.sortOrder);
  }

  getStageTooltip(stage: ClaimStageProgressModel): string {
    const status = stage.isCompleted ? 'Completed' : 
                   stage.isCurrentStage ? 'In Progress' : 'Pending';
    const completionInfo = stage.actualCompletionDate 
      ? `Completed: ${this.formatDateSafe(stage.actualCompletionDate)}`
      : stage.estimatedCompletionDate 
        ? `Est. Completion: ${this.formatDateSafe(stage.estimatedCompletionDate)}`
        : '';
    
    return `${stage.stageName} - ${status}\n${stage.stageDescription}\nWeight: ${stage.weightPercentage}%\n${completionInfo}`;
  }

  getStageProgressWidth(stage: ClaimStageProgressModel): number {
    if (stage.isCompleted) return 100;
    if (stage.isCurrentStage) return 50;
    return 0;
  }

  formatDate(dateString: string | null): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  }

  formatDateSafe(dateInput: string | null | undefined): string {
    if (!dateInput) return '';
    const date = new Date(dateInput);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  }

  getTotalClaimedAmount(): number {
    return this.dataSource.data.reduce((total, claim) => total + claim.claimedAmount, 0);
  }

  getTotalUnopsRecommendation(): number {
    return this.dataSource.data.reduce((total, claim) => total + claim.unopsRecommendation, 0);
  }

  getTotalUnopsRecommendationUSD(): number {
    return this.dataSource.data.reduce((total, claim) => total + claim.unopsRecommendationAugust2025USD, 0);
  }

  getAverageProgress(): number {
    if (this.dataSource.data.length === 0) return 0;
    const totalProgress = this.dataSource.data.reduce((total, claim) => total + claim.progressPercentageComplete, 0);
    return Math.round(totalProgress / this.dataSource.data.length * 100) / 100;
  }

  getStageHeaderClass(stage: ClaimStageProgressModel): string {
    return 'stage-' + stage.stageName.toLowerCase().replace(/[^a-z0-9]/g, '-');
  }

  getWeekDisplay(weeks: number): string {
    return `${weeks} Week${weeks !== 1 ? 's' : ''}`;
  }

  getClaimWbs(wbs: string): string {
    return wbs || 'N/A';
  }

  getCompletionDate(stage: ClaimStageProgressModel): string {
    const dateToUse = stage.actualCompletionDate || stage.estimatedCompletionDate || null;
    return this.formatDateSafe(dateToUse);
  }

  getTotalClaimedAmountFormatted(): string {
    return this.formatCurrency(this.getTotalClaimedAmount(), 'USD');
  }

  getTotalUnopsRecommendationFormatted(): string {
    return this.formatCurrency(this.getTotalUnopsRecommendation(), 'USD');
  }

  getTotalUnopsRecommendationUSDFormatted(): string {
    return this.formatCurrency(this.getTotalUnopsRecommendationUSD(), 'USD');
  }

  getCurrentStageName(stages: ClaimStageProgressModel[]): string {
    const currentStage = stages.find(stage => stage.isCurrentStage);
    return currentStage ? currentStage.stageName : 'N/A';
  }

  getClaimDetailsLink(claimId: number): string {
    return `/claims/${claimId}`;
  }

  getSortedStages(stages: ClaimStageProgressModel[]): ClaimStageProgressModel[] {
    return stages.slice().sort((a, b) => a.sortOrder - b.sortOrder);
  }

  getStageForClaim(claim: Output1ConsolidatedPlanProgressStatusReportModel, stageId: number): ClaimStageProgressModel | null {
    const topLevelStage = claim.stages.find(s => s.stageId === stageId);
    if (topLevelStage) return topLevelStage;

    for (const stage of claim.stages) {
      const childStage = stage.children.find(c => c.stageId === stageId);
      if (childStage) return childStage;
    }

    return null;
  }

  getChildStageForClaim(claim: Output1ConsolidatedPlanProgressStatusReportModel, childStageId: number): ClaimStageProgressModel | null {
    for (const stage of claim.stages) {
      const childStage = stage.children.find(c => c.stageId === childStageId);
      if (childStage) return childStage;
    }
    return null;
  }

  getParentColumnSpan(parentStage: ClaimStageProgressModel): number {
    return parentStage.hasChildren ? parentStage.children.length : 1;
  }

  getChildStagesForDisplay(parentStage: ClaimStageProgressModel): ClaimStageProgressModel[] {
    return parentStage.hasChildren ? parentStage.children : [parentStage];
  }
}
