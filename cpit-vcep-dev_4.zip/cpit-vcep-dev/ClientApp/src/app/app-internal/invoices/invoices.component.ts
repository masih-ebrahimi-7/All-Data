import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { getQueryParams } from 'src/app/common/form/form.component';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';

import { RequestService } from 'src/app/services/request.service';
@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.css'],
})
export class InvoicesComponent {
  displayedColumns: Column[] = [
    new Column('label.reference', 'reference', {
      type: ColumnType.Link,
      value: (e: any) => {
        return new Link(e.reference, `invoices/${e.id}`);
      },
    }),
    new Column('label.amount', 'amount', { type: ColumnType.Number }),
    new Column('label.currency', 'currencyCode', {
      disableSorting: true
    }),
    new Column('label.invoice', 'path', { type: ColumnType.PDFFile, disableSorting: true }),
    new Column('label.status', 'status', {
      type: ColumnType.Status,
      value: (e: any) => {
        let type = StatusType.Success;
        switch (e.status) {
          case 'Rejected':
            type = StatusType.Danger;
            break;
          case 'Pending Review':
            type = StatusType.Warning;
        }
        return {
          label: e.status,
          type: type,
        };
      },
    }),
    new Column('label.assignedTo', 'assignedTo'),
    new Column('label.createdDate', 'createdDate', {
      type: ColumnType.DateTime
    }),
    new Column('label.createdBy', 'createdBy'),
    new Column('label.lastModifiedBy', 'lastModifiedBy'),
    new Column('label.lastModifiedDate', 'lastModifiedDate', {
      type: ColumnType.DateTime
    }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;
  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Statuses', 'statuses', InputType.Multiselect, {
      source: () => this.request.getEnumValues('StatusType'),
    }),
    new AppInput('Amount', 'amount'),
    new AppInput('Currency', 'currency'),
    new AppInput('AssignedTo', 'assignedTo'),
    new AppInput('InvoiceDate', 'startInvoiceDate', InputType.DateRange, {
      toInputName: 'endInvoiceDate',
    }),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService
  ) {
    this.bulkActions = this.getBulkActions();
    this.path = this.activatedRoute.snapshot.url[0].path;
  }

  setDataSource(config: any) {
    var filters = config?.filter ?? {};
    this.request.getInvoices(filters).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    return [];
  }

  displayAll() {
    this.setDataSource({ filter: {} });
  }

  displayLatest() {
    let lastMonthDate = new Date();
    lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
    this.setDataSource({ filter: { startInvoiceDate: lastMonthDate, endInvoiceDate: new Date() } });
  }

  displayPending() {
    this.setDataSource({ filter: { statuses: ['Pending Review'] } });
  }

  exportToExcel() {
    var filters = getQueryParams(this.activatedRoute, this.filters);
    this.request.getInvoices(filters).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'invoices.xlsx', exportedColumns);
      }
    });
  }
}