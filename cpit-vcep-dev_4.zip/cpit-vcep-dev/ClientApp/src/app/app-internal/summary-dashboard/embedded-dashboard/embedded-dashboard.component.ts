import { Component, OnInit } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { SafePipe } from 'src/app/common/pipes/safe.pipe';
import { PermissionsService } from 'src/app/services/auth/permissions.service';


@Component({
  selector: 'app-embedded-dashboard',
  templateUrl: './embedded-dashboard.component.html',
  styleUrls: ['./embedded-dashboard.component.css'],
})
export class EmbeddedDashboardComponent {
  permissions: any | null;

  constructor(private permissionsService: PermissionsService, private safePipe: SafePipe) {
    this.permissions = this.permissionsService.get();
  }

}
