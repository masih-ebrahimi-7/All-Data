import { EventEmitter, Injectable, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { forkJoin } from 'rxjs/internal/observable/forkJoin';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { Contract, IContractRequestModel } from 'src/app/models/contract.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class ContractsService {
  priorities: TypeaheadInput[] = [];
  contractTypes: TypeaheadInput[] = [];
  currencies: TypeaheadInput[] = [];

  grants$ = new BehaviorSubject([]);
  grants = this.grants$.asObservable();

  externalEntities$ = new BehaviorSubject([]);
  externalEntities = this.externalEntities$.asObservable();

  loading: boolean = true;

  @Output() onChangeSubmitted = new EventEmitter<boolean>();

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.setup();
  }

  setup(): void {
    this.getPrioritiesForFilter();
    this.getContractTypesForFilter();
    this.getCurrenciesForFilter();
    this.getExternalEntitiesForFilter();
    this.getGrantsForFilter();
  }

  openContractModal(contract?: Contract) {
    this.setup();
    const data = {
      pageTitle: contract ? 'Edit Contract Details' : 'Insert a new Contract',
      fields: [
        {
          name: 'reference',
          label: 'Contract Number',
          type: 'text',
          value: contract?.reference ?? '',
          required: true,
          hint: "Will be used to create a Reference with the pattern: C-0000",
          suffix: "pin"
        },
        {
          name: 'name',
          label: 'Name',
          type: 'text',
          value: contract?.name ?? '',
          required: true,
        },
        {
          name: 'description',
          label: 'Description',
          type: 'text',
          value: contract?.description ?? '',
          required: false,
        },
        {
          name: 'fundSource',
          label: 'Fund Source',
          type: 'text',
          value: contract?.fundSource ?? '',
          required: true,
        },
        {
          name: 'pcssNumber',
          label: 'Pcss Number',
          type: 'text',
          value: contract?.pcssNumber ?? '',
          required: false,
        },
        {
          name: 'contractForDates',
          label: 'Contract Dates',
          startLabel: 'Contract start date',
          endLabel: 'Contract end date',
          type: 'date-range',
          value: {
            start: contract?.startDate,
            end: contract?.endDate,
          },
        },
        {
          name: 'revisedEndDate',
          label: 'Revised End Date',
          type: 'date',
          value: contract?.revisedEndDate ?? null,
          required: false,
        },
        {
          name: 'priority',
          label: 'Select Contract Priority',
          type: 'select',
          value: contract?.priorityType?.toString(),
          required: true,
          options: this.priorities,
        },
        {
          name: 'contractType',
          label: 'Select the Contract Type',
          type: 'select',
          value: contract?.contractType?.toString(),
          required: true,
          options: this.contractTypes,
        },
        {
          name: 'amount',
          label: 'Enter Contract Amount',
          type: 'number',
          value: contract?.amount,
          required: true,
          suffix: "payments"
        },
        {
          name: 'currencyId',
          label: 'Select Contract Currency',
          type: 'select',
          value: contract?.currencyId?.toString(),
          required: true,
          options: this.currencies,
          hint: "If the currency is not USD, then the USD amount will be calculated with the rates available in the Currency Conversion page."
        },
        {
          name: 'disbursement',
          label: 'Enter disbursed amount (if applicable)',
          type: 'number',
          value: contract?.disbursement,
          required: false,
        },
        {
          name: 'undisbursedAmount',
          label: 'Enter amount not disbursed (if applicable)',
          type: 'number',
          value: contract?.undisbursedAmount,
          required: false,
        },
        {
          name: 'externalEntityId',
          label: 'Link Contract to an External Entity',
          type: 'select-async',
          value: contract?.externalEntityId?.toString(),
          required: true,
          options: this.externalEntities$,
        },
        {
          name: 'grantIds',
          label: 'Link Contract to Grants',
          type: 'select-async',
          value: contract?.grants?.map(a => a.id.toString()),
          allowMultiple: true,
          required: true,
          options: this.grants$,
        },
        {
          name: 'geographicalLocation',
          label: 'Geographical Location',
          type: 'text',
          value: contract?.location?.geographicalLocation ?? '',
          suffix: "public",
          required: false,
        },
        {
          name: 'latitude',
          label: 'Geographical Location (Latitude)',
          type: 'number',
          value: contract?.location?.latitude ?? '',
          required: false,
        },
        {
          name: 'longitude',
          label: 'Geographical Location (Longitude)',
          type: 'number',
          value: contract?.location?.longitude ?? '',
          required: false,
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let contractRequest: IContractRequestModel = {
          name: result.name ?? contract?.name,
          reference: result.reference ?? contract?.reference,
          description: result.description ?? contract?.description,
          pcssNumber: result.pcssNumber ?? contract?.pcssNumber,
          fundSource: result.fundSource ?? contract?.fundSource,
          startDate: result.contractForDates.start ?? contract?.startDate,
          endDate: result.contractForDates.end ?? contract?.endDate,
          revisedEndDate: result.revisedEndDate ?? contract?.revisedEndDate,
          priorityType: result.priorityType ?? contract?.priorityType,
          contractType: result.contractType ?? contract?.contractType,
          amount: result.amount ?? contract?.amount,
          currencyId: result.currencyId ?? contract?.currencyId,
          disbursement: result.disbursement ?? contract?.disbursement,
          undisbursedAmount: result.undisbursedAmount ?? contract?.undisbursedAmount,
          externalEntityId: result.externalEntityId ?? contract?.externalEntityId,
          grantIds: result.grantIds ?? contract?.grantIds,
          location: {
            geographicalLocation: result.geographicalLocation ?? contract?.location?.geographicalLocation,
            latitude: result.latitude ?? contract?.location?.latitude,
            longitude: result.longitude ?? contract?.location?.longitude,
          }
        };
        if (contract) {
          return this.request.editContract(contractRequest, contract.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Contract edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create contract.`);
          });
        } else {
          return this.request.createContract(contractRequest).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Contract created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create contract.`);
          });
        }
      } else {
        return;
      }
    });
  }

  getPrioritiesForFilter() {
    return this.request.getEnumValues('PriorityType').subscribe((data: any) => {
      this.priorities = data;
    });
  }

  getContractTypesForFilter() {
    return this.request.getEnumValues('ContractType').subscribe((data: any) => {
      this.contractTypes = data;
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  getExternalEntitiesForFilter() {
    return this.request.getExternalEntitiesForFilter().subscribe((data: any) => {
      this.externalEntities$.next(data);
    });
  }

  getGrantsForFilter() {
    return this.request.getGrantsForFilter().subscribe((data: any) => {
      this.grants$.next(data);
    });
  }
}
