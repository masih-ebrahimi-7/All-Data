import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { RequestService } from 'src/app/services/request.service';
import { ContractsService } from './contracts.service';
import { OutputType } from 'src/app/models/enums/ui-enums';

@Component({
  selector: 'app-contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.css'],
})
export class ContractsComponent implements OnInit {
  outputType: string;
  permissions: any | null;
  config: any;
  private _contractsServiceSubscription;
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id'),
    new Column('label.shortReference', 'reference', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.reference, `contracts/${e.id}`);
      },
    }),
    new Column('PCSS Number', 'pcssNumber'),
    new Column('Contract Name', 'name', {
      type: ColumnType.TruncatedText,
    }),
    new Column('Contract Type', 'contractType', {
      type: ColumnType.Text,
      value: (e: any) => {
        return e.contractTypeLabel ?? "N/A"
      },
    }),
    new Column('Contractor', 'contractor.name', {
      type: ColumnType.Link,
      value: (e: any) => {
        return new Link(e.contractor?.name, `list-external-entities?name=${e.contractor?.name}`);
      },
    }),
    new Column('Location', 'geographicalLocation', {
      disableSorting: true
    }),
    new Column('Sector', 'grant.sector', {
      type: ColumnType.Text,
      value: (e: any) => {
        let sectors: any[] = [];
         e.grants.map(
          (r: any) =>
            sectors.push(r.sector)
        );
        return sectors.join(", ");
      },
    }),
    new Column('Grants', 'grants', {
      disableSorting: true,
      type: ColumnType.LinkList,
      value: (e: any) => {
        return e.grants.map(
          (r: any) =>
            new Link(r.reference, `/grants/${r.id}`)
        );
      },
    }),
    new Column('Amount', 'amount', { type: ColumnType.Number }),
    new Column('label.currency', 'currencyCode', {
      disableSorting: true
    }),
    new Column('Amount (USD)', 'amountUsd', { 
      type: ColumnType.Number,
      disableSorting: true,
      tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page"
    }),
    new Column('label.currencyRate', 'currencyRate', {
      disableSorting: true
    }),
    new Column('Priority', 'priorityType', {
      type: ColumnType.Status,
      value: (e: any) => {
        let type = StatusType.Default;
        let label;
        switch (e.priorityType.toString()) {
          case '1':
            type = StatusType.Danger;
            label = 'Priority #1';
            break;
          case '2':
            type = StatusType.Warning;
            label = 'Priority #2';
            break;
          case '3':
            type = StatusType.Warning;
            label = 'Priority #3';
            break;
          case '4':
            type = StatusType.Default;
            label = 'Priority #4';
            break;
          default:
            type = StatusType.Default;
            break;
        }
        return {
          label: label,
          type: type,
        };
      },
    }),
    new Column('Start Date', 'startDate', {
      type: ColumnType.Date,
    }),
    new Column('End Date', 'endDate', {
      type: ColumnType.Date,
    }),
    new Column('Revised End Date', 'revisedEndDate', {
      type: ColumnType.Date,
    }),
    new Column('Fund Source', 'fundSource'),
    new Column('Disbursement', 'disbursement', { type: ColumnType.Number }),
    new Column('Undisbursed Amount', 'undisbursedAmount', { type: ColumnType.Number }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Name', 'name'),
    new AppInput('PCSS Number', 'PCSSNumber'),
    new AppInput('Grant Reference', 'grantReference'),
    new AppInput('Fund Source', 'fundSource'),
    new AppInput('Sectors', 'sectors', InputType.Multiselect, {
      source: () => this.request.getEnumValues('SectorType'),
    }),
    new AppInput('Priorities', 'priorities', InputType.Multiselect, {
      source: () => this.request.getEnumValues('PriorityType'),
    }),
    new AppInput('Contract Types', 'contractTypes', InputType.Multiselect, {
      source: () => this.request.getEnumValues('ContractType'),
    }),
    new AppInput('Location', 'location'),
    new AppInput('Contract Dates', 'contractStartDate', InputType.DateRange, {
      toInputName: 'contractEndDate',
    }),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private contractsService: ContractsService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this._contractsServiceSubscription = this.contractsService.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    })
  }

  ngOnInit() {
    this.path = this.activatedRoute.snapshot.url[0].path;
    this.isOutputOnePage() ? (this.outputType = OutputType.OutputOne) : (this.outputType = OutputType.OutputTwo);
    this.loading = false;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getContracts(this.config || {}, this.outputType).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  shouldDisplayCol(column: string) {
    if (column == 'grantReference' && this.isOutputOnePage()) return true;
    if (column == 'projectAgreementReference' && !this.isOutputOnePage()) return true;
    return false;
  }

  isOutputOnePage() {
    return this.activatedRoute.snapshot.url[0].path == 'list-output-one-contracts';
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageContracts) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.contractsService.openContractModal(),
          iconLabel: 'New Contract',
          color: 'accent',
          type: 'button',
          toolTip: 'New Contract',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
        toolTip: 'button.edit',
        onClick: () => this.contractsService.openContractModal(e),
        color: 'primary',
      })
    );
    return actions;
  }

  exportToExcel() {
    this.request.getContracts(this.config || {}, this.outputType).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'contracts.xlsx', exportedColumns);
      }
    });
  }
}
