import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { getQueryParams } from 'src/app/common/form/form.component';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';

import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-project-agreements',
  templateUrl: './project-agreements.component.html',
  styleUrls: ['./project-agreements.component.css'],
})
export class ProjectAgreementsComponent {
  displayedColumns: Column[] = [
    new Column('Id', 'id'),
    new Column('Reference', 'reference'),
    new Column('Signed With', 'signedWith'),
    new Column('Agreement Date', 'agreementDate', {
      type: ColumnType.Date
    }),
    new Column('Sector', 'sector', {
      disableSorting: true
    }),
    new Column('Priority', 'priority', {
      type: ColumnType.Status,
      value: (e: any) => {
        if (!e.priority) {
          return {};
        }
        let type = StatusType.Default;
        let label = e.priorityLabel;
        switch (e.priority) {
          case 'First':
            type = StatusType.Danger;
            label = 'Priority #1';
            break;
          case 'Second':
            type = StatusType.Warning;
            label = 'Priority #2';
            break;
        }
        return {
          label: label,
          type: type,
        };
      },
    }),
  ];

  moment = moment;
  filterValue: string;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;
  config: any;
  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Priorities', 'priorities', InputType.Multiselect, {
      source: () => this.request.getEnumValues('PriorityType'),
    }),
    new AppInput('Sectors', 'sectors', InputType.Multiselect, {
      source: () => this.request.getEnumValues('SectorType'),
    }),
  ];
  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService
  ) {
    this.bulkActions = this.getBulkActions();
    this.path = this.activatedRoute.snapshot.url[0].path;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request
      .getProjectAgreements(this.config || {})
      .subscribe((data: any) => {
        this.totalSize = data.totalCount;
        this.data = data.records;
      });
  }

  getBulkActions() {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  exportToExcel() {
    this.request.getProjectAgreements(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, `ProjectAgreements-${new Date()}.xlsx`, exportedColumns);
      }
    });
  }
}

export interface IProjectAgreement {
  id: string;
  reference: string;
  signedWith?: string;
  agreementDate?: string;
  sector: string;
}
