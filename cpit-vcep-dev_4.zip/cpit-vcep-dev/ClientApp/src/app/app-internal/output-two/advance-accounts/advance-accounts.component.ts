import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';

import { RequestService } from 'src/app/services/request.service';
import { AdvanceAccountsService } from './advance-accounts.service';

@Component({
  selector: 'app-advance-accounts',
  templateUrl: './advance-accounts.component.html',
  styleUrls: ['./advance-accounts.component.css'],
})
export class AdvanceAccountsComponent {
  private _serviceSubscription;
  config: any;
  moment = moment;
  filterValue: string;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  displayedColumns: Column[] = [
    new Column('', 'actions', {
      size: 'sm',
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id', {
      type: ColumnType.Link,
      size: 'xs',
      value: (e: any) => {
        return new Link(e.id, `advance-accounts/${e.id}`);
      },
    }),
    new Column('label.grant', 'grant.reference', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.grant?.reference, `grants/${e.grant?.id}`);
      },
    }),
    new Column('label.advanceAccounts.accountName', 'accountName'),
    new Column('label.advanceAccounts.accountNumber', 'accountNumber'),
    new Column('label.sector', 'sector', {
      value: (a:any) => a.sectorLabel,
      type: ColumnType.Text
    }),
    new Column('label.advanceAccounts.fundSource', 'fundSource', {
      value: (a:any) => a.fundSourceLabel,
      type: ColumnType.Text
    }),
    new Column('label.advanceAccounts.latestWithdrawalApplication.withdrawalApplicationNumber', 'latestWithdrawalApplication.withdrawalApplicationNumber', {
      value: (a:any) => a.latestWithdrawalApplication?.withdrawalApplicationNumber,
      type: ColumnType.Text
    }),
    new Column('label.advanceAccounts.latestWithdrawalApplication.withdrawalApplicationDate', 'latestWithdrawalApplication.withdrawalApplicationDate', {
      value: (a:any) => a.latestWithdrawalApplication?.withdrawalApplicationDate,
      type: ColumnType.Date
    }),
    new Column('label.currency', 'currencyCode', {
      disableSorting: true
    }),
    new Column('label.advanceAccounts.lastDistributionAmount', 'lastDistributionAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.lastDistributionAmountUsd', 'lastDistributionAmountUsd', { 
      type: ColumnType.Number,
      disableSorting: true,
      tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page" 
    }),
    new Column('label.advanceAccounts.refundableAmount', 'refundableAmount', {
      type: ColumnType.Number,
      disableSorting: true
    }),
    new Column('label.advanceAccounts.refundableAmountUsd', 'refundableAmountUsd', { 
      type: ColumnType.Number,
      disableSorting: true,
      tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page" 
    }),
    new Column('label.advanceAccounts.distributionDate', 'distributionDate', {
      type: ColumnType.Date,
    }),
    new Column('label.advanceAccounts.latestDisbursementDate', 'latestDisbursementDate', {
      type: ColumnType.Date,
    }),
    new Column('label.advanceAccounts.unliquidatedAmountUsd', 'unliquidatedAmountUsd', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.bankBalanceAccountCurrency', 'bankBalanceAccountCurrency', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.uncreditedAmount', 'uncreditedAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.newOtherReceiptsAmount', 'newOtherReceiptsAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.newExpensesPaymentsAmount', 'newExpensesPaymentsAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.verifiedExpensesPaymentsAmount', 'verifiedExpensesPaymentsAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.rejectedExpensesPaymentsAmount', 'rejectedExpensesPaymentsAmount', {
      type: ColumnType.Number 
    }),
    new Column('label.advanceAccounts.differenceUsd', 'differenceUsd', {
      type: ColumnType.Number,
      disableSorting: true
    }),
    new Column('label.advanceAccounts.unreconciledAmountUsd', 'unreconciledAmountUsd', {
      type: ColumnType.Number,
      disableSorting: true
    }),
  ];
  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Account Name', 'accountName'),
    new AppInput('Account Number', 'accountNumber', InputType.Number),
    new AppInput('Implementing Agency', 'implementingAgency'),
    new AppInput('Sectors', 'sectors', InputType.Multiselect, {
      source: () => this.request.getEnumValues('SectorType'),
    }),
    new AppInput('Fund Source', 'fundSources', InputType.Multiselect, {
      source: () => this.request.getEnumValues('FundSourceType'),
    }),
    new AppInput('Contract Types', 'contractTypes', InputType.Multiselect, {
      source: () => this.request.getEnumValues('ContractType'),
    }),
    new AppInput('Last Distribution Amount', 'lastDistributionAmount', InputType.Number),
  ];
  permissions: any | null;

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private advanceAccountsService: AdvanceAccountsService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this.path = this.activatedRoute.snapshot.url[0].path;
    this._serviceSubscription = this.advanceAccountsService.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    })
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getAdvanceAccounts(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageAdvanceAccounts) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.advanceAccountsService.openAdvanceAccountsModal(),
          iconLabel: 'New Advance Account',
          color: 'accent',
          type: 'button',
          toolTip: 'New Advance Account',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    if (this.permissions?.CanManageAdvanceAccounts) {
      actions.push(
        new Action({
          iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
          toolTip: 'button.edit',
          onClick: () => this.advanceAccountsService.openAdvanceAccountsModal(e),
          color: 'primary',
        })
      );
    }
    return actions;
  }


  exportToExcel() {
    this.request.getAdvanceAccounts(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'advance-accounts.xlsx', exportedColumns);
      }
    });
  }
}

