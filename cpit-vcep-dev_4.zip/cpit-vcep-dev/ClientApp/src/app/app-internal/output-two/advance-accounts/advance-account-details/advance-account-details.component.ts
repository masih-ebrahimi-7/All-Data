import { Component } from '@angular/core';

@Component({
  selector: 'app-advance-account-details',
  templateUrl: './advance-account-details.component.html',
  styleUrls: ['./advance-account-details.component.css']
})
export class AdvanceAccountDetailsComponent {

}
