import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { IAdvanceAccountCreateRequest, IAdvanceAccountEditRequest, IAdvanceAccountResponse } from 'src/app/models/advance-account.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class AdvanceAccountsService {
  currencies: TypeaheadInput[] = [];
  sectors: TypeaheadInput[] = [];
  fundSources: TypeaheadInput[] = [];
  withdrawalApplicationTypes: TypeaheadInput[] = [];

  withdrawalApplications$ = new BehaviorSubject([]);
  withdrawalApplications = this.withdrawalApplications$.asObservable();

  grants$ = new BehaviorSubject([]);
  grants = this.grants$.asObservable();

  loading: boolean = true;

  @Output() onChangeSubmitted = new EventEmitter<boolean>();

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.setup();
  }

  setup(): void {
    this.getCurrenciesForFilter();
    this.getWithdrawalApplicationsForFilter();
    this.getFundSourcesForFilter();
    this.getSectorsForFilter();
    this.getWATypesForFilter();
    this.getGrantsForFilter();
  }

  openAdvanceAccountsModal(existingAdvanceAccount?: IAdvanceAccountResponse) {
    this.setup();
    const data = {
      pageTitle: existingAdvanceAccount ? 'Edit Advance Account Details' : 'Insert a new Advance Account',
      fields: [
        {
          name: 'accountName',
          label: 'Account Name',
          type: 'text',
          value: existingAdvanceAccount?.accountName ?? '',
          required: true,
        },
        {
          name: 'accountNumber',
          label: 'Account Number',
          type: 'text',
          value: existingAdvanceAccount?.accountNumber,
          required: true,
          suffix: "pin"
        },
        {
          name: 'sector',
          label: 'Sector',
          type: 'select',
          value: existingAdvanceAccount?.sector?.toString(),
          required: true,
          options: this.sectors,
        },
        {
          name: 'grantId',
          label: 'Grant',
          type: 'select-async',
          value: existingAdvanceAccount?.grantId?.toString(),
          required: false,
          options: this.grants$,
        },
        {
          name: 'currencyId',
          label: 'Select Currency',
          type: 'select',
          value: existingAdvanceAccount?.currencyId?.toString(),
          required: true,
          options: this.currencies,
          hint: "If the currency is not USD, then the USD amount will be calculated with the rates available in the Currency Conversion page."
        },
        {
          name: 'fundSource',
          label: 'Fund Source',
          type: 'select',
          value: existingAdvanceAccount?.fundSource?.toString(),
          required: true,
          options: this.fundSources,
        },
        {
          name: 'implementingAgency',
          label: 'Implementing Agency',
          type: 'textarea',
          value: existingAdvanceAccount?.implementingAgency ?? '',
          required: true,
        },
        {
          name: 'distributionDate',
          label: 'Distribution Date',
          type: 'date',
          value: existingAdvanceAccount?.distributionDate,
          required: true,
          suffix: "date"
        },
        {
          name: 'latestDisbursementDate',
          label: 'Latest Disbursement Date',
          type: 'date',
          value: existingAdvanceAccount?.latestDisbursementDate,
          required: false,
          suffix: "date"
        },
        {
          name: 'lastDistributionAmount',
          label: 'Last Distribution Amount',
          type: 'number',
          value: existingAdvanceAccount?.lastDistributionAmount,
          required: true,
          suffix: "payments"
        },
        {
          name: 'unliquidatedAmountUsd',
          label: 'Unliquidated Amount (USD)',
          type: 'number',
          value: existingAdvanceAccount?.unliquidatedAmountUsd,
          required: true,
          suffix: "payments"
        },
        {
          name: 'bankBalanceAccountCurrency',
          label: 'Bank Balance',
          type: 'number',
          value: existingAdvanceAccount?.bankBalanceAccountCurrency,
          required: true,
          suffix: "payments"
        },
        {
          name: 'uncreditedAmount',
          label: 'Uncredited Amount',
          type: 'number',
          value: existingAdvanceAccount?.uncreditedAmount,
          required: false,
          suffix: "payments"
        },
        {
          name: 'newOtherReceiptsAmount',
          label: 'New Other Receipts',
          type: 'number',
          value: existingAdvanceAccount?.newOtherReceiptsAmount,
          required: false,
          suffix: "payments"
        },
        {
          name: 'newExpensesPaymentsAmount',
          label: 'New Expenses / Payments',
          type: 'number',
          value: existingAdvanceAccount?.newExpensesPaymentsAmount,
          required: false,
          suffix: "payments"
        },
        {
          name: 'verifiedExpensesPaymentsAmount',
          label: 'Verified Exp. / Payments',
          type: 'number',
          value: existingAdvanceAccount?.verifiedExpensesPaymentsAmount,
          required: false,
          suffix: "payments"
        },
        {
          name: 'rejectedExpensesPaymentsAmount',
          label: 'Rejected Exp. / Payments',
          type: 'number',
          value: existingAdvanceAccount?.rejectedExpensesPaymentsAmount,
          required: false,
          suffix: "payments"
        },
        {
          name: 'latestWithdrawalApplicationWithdrawalApplicationNumber',
          label: 'Latest WA Number',
          type: 'text',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.withdrawalApplicationNumber,
          required: true,
        },
        {
          name: 'latestWithdrawalApplicationWithdrawalApplicationDate',
          label: 'Latest WA Date',
          type: 'date',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.withdrawalApplicationDate,
          required: true,
          suffix: "date"
        },
        {
          name: 'latestWithdrawalApplicationCurrencyId',
          label: 'Select Currency',
          type: 'select',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.currencyId?.toString(),
          required: true,
          options: this.currencies,
          hint: "If the currency is not USD, then the USD amount will be calculated with the rates available in the Currency Conversion page."
        },
        {
          name: 'latestWithdrawalApplicationType',
          label: 'Latest WA Type',
          type: 'select',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.type.toString(),
          required: true,
          options: this.withdrawalApplicationTypes,
        },
        {
          name: 'latestWithdrawalApplicationUnliquidatedBalance',
          label: 'Latest WA Unliquidated Balance',
          type: 'number',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.unliquidatedBalance,
          required: true,
          suffix: "pin"
        },
        {
          name: 'latestWithdrawalApplicationNotCreditedAmount',
          label: 'Latest WA Not Credited Amount',
          type: 'number',
          value: existingAdvanceAccount?.latestWithdrawalApplication?.notCreditedAmount,
          required: true,
          suffix: "pin"
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let advanceAccountRequestModel: IAdvanceAccountCreateRequest = {
          accountName: result.accountName ?? existingAdvanceAccount?.accountName,
          accountNumber: result.accountNumber ?? existingAdvanceAccount?.accountNumber,
          grantId: result.grantId ?? existingAdvanceAccount?.grantId ?? null,
          currencyId: result.currencyId ?? existingAdvanceAccount?.currencyId,
          fundSource: parseInt(result.fundSource) ?? existingAdvanceAccount?.fundSource,
          sector: parseInt(result.sector) ?? existingAdvanceAccount?.sector,
          implementingAgency: result.implementingAgency ?? existingAdvanceAccount?.implementingAgency,
          distributionDate: result.distributionDate ?? existingAdvanceAccount?.distributionDate ?? null,
          latestDisbursementDate: result.latestDisbursementDate ?? existingAdvanceAccount?.latestDisbursementDate ?? null,
          lastDistributionAmount: result.lastDistributionAmount ?? existingAdvanceAccount?.lastDistributionAmount ?? null,
          unliquidatedAmountUsd: result.unliquidatedAmountUsd ?? existingAdvanceAccount?.unliquidatedAmountUsd ?? null,
          bankBalanceAccountCurrency: result.bankBalanceAccountCurrency ?? existingAdvanceAccount?.bankBalanceAccountCurrency ?? null,
          uncreditedAmount: result.uncreditedAmount ?? existingAdvanceAccount?.uncreditedAmount ?? null,
          newOtherReceiptsAmount: result.newOtherReceiptsAmount ?? existingAdvanceAccount?.newOtherReceiptsAmount ?? null,
          newExpensesPaymentsAmount: result.newExpensesPaymentsAmount ?? existingAdvanceAccount?.newExpensesPaymentsAmount ?? null,
          verifiedExpensesPaymentsAmount: result.verifiedExpensesPaymentsAmount ?? existingAdvanceAccount?.verifiedExpensesPaymentsAmount ?? null,
          rejectedExpensesPaymentsAmount: result.rejectedExpensesPaymentsAmount ?? existingAdvanceAccount?.rejectedExpensesPaymentsAmount ?? null,

          latestWithdrawalApplication: {
            withdrawalApplicationNumber: result.latestWithdrawalApplicationWithdrawalApplicationNumber ?? existingAdvanceAccount?.latestWithdrawalApplication?.withdrawalApplicationNumber ?? null,
            withdrawalApplicationDate: result.latestWithdrawalApplicationWithdrawalApplicationDate ?? existingAdvanceAccount?.latestWithdrawalApplication?.withdrawalApplicationDate ?? null,
            type: parseInt(result.latestWithdrawalApplicationType) ?? existingAdvanceAccount?.latestWithdrawalApplication?.type ?? null,
            currencyId: result.latestWithdrawalApplicationCurrencyId ?? existingAdvanceAccount?.latestWithdrawalApplication?.currencyId ?? null,
            unliquidatedBalance: result.latestWithdrawalApplicationUnliquidatedBalance ?? existingAdvanceAccount?.latestWithdrawalApplication?.unliquidatedBalance ?? null,
            notCreditedAmount: result.latestWithdrawalApplicationNotCreditedAmount ?? existingAdvanceAccount?.latestWithdrawalApplication?.notCreditedAmount ?? null,
          }
        };
        if (existingAdvanceAccount) {
          return this.request.editAdvanceAccount(advanceAccountRequestModel, existingAdvanceAccount.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Advance Account edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Advance Account.`);
          });
        } else {
          return this.request.createAdvanceAccount(advanceAccountRequestModel).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Advance Account created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Advance Account.`);
          });
        }
      } else {
        return;
      }
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  getSectorsForFilter() {
    return this.request.getEnumValues('SectorType').subscribe((data: any) => {
      this.sectors = data;
    });
  }

  getFundSourcesForFilter() {
    return this.request.getEnumValues('FundSourceType').subscribe((data: any) => {
      this.fundSources = data;
    });
  }

  getWATypesForFilter() {
    return this.request.getEnumValues('WithdrawalApplicationType').subscribe((data: any) => {
      this.withdrawalApplicationTypes = data;
    });
  }

  getWithdrawalApplicationsForFilter() {
    return this.request.getGrantsForFilter().subscribe((data: any) => {
      this.withdrawalApplications$.next(data);
    });
  }

  getGrantsForFilter() {
    return this.request.getGrantsForFilter().subscribe((data: any) => {
      this.grants$.next(data);
    });
  }
}
