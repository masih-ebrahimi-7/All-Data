import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import moment from 'moment';
import { getQueryParams } from 'src/app/common/form/form.component';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { RequestService } from 'src/app/services/request.service';
import { StaffContractsService } from './staff-contracts.service';

@Component({
  selector: 'app-staff-contracts',
  templateUrl: './staff-contracts.component.html',
  styleUrls: ['./staff-contracts.component.css']
})
export class StaffContractsComponent implements OnInit {
  permissions: any | null;
  config: any;
  private _serviceSubscription;
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      size: 'sm',
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id', {      
      size: 'sm',
      value: (a: any) => a.id
    }),
    new Column('label.salaries.staffContract.reference', 'reference', {
      type: ColumnType.Text,
      size: 'sm',
    }),
    new Column('label.salaries.staffContract.contractStartDate', 'contractStartDate', {
      type: ColumnType.Date
    }),
    new Column('label.salaries.staffContract.contractEndDate', 'contractEndDate', {
      type: ColumnType.Date
    }),
    new Column('label.salaries.staffContract.contractCurrency', 'contractCurrencyCode', {
      type: ColumnType.Text,
      disableSorting: true
    }),
    new Column('label.salaries.staffContract.basicSalary', 'basicSalary', {
      type: ColumnType.Number
    }),
    new Column('label.salaries.staffContract.allowances', 'allowances', {
      type: ColumnType.Number
    }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private activatedRoute: ActivatedRoute,
    private permissionsService: PermissionsService,
    private service: StaffContractsService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this._serviceSubscription = this.service.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    })
  }

  ngOnInit() {
    this.path = this.activatedRoute.snapshot.url[0].path;
    this.loading = false;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getAllStaffContracts(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageSalaries) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.service.openModal(),
          iconLabel: 'New Staff Contract',
          color: 'accent',
          type: 'button',
          toolTip: 'New Staff Contract',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    if (this.permissions?.CanManageSalaries) {
      actions.push(
        new Action({
          iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
          toolTip: 'button.edit',
          onClick: () => this.service.openModal(e),
          color: 'primary',
        })
      );
    }
    return actions;
  }

  exportToExcel() {
    this.request.getAllStaffContracts(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'staff-contracts.xlsx', exportedColumns);
      }
    });
  }
}