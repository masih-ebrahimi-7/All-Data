import { Component } from '@angular/core';

@Component({
  selector: 'app-pmo-salaries-details',
  templateUrl: './pmo-salaries-details.component.html',
  styleUrls: ['./pmo-salaries-details.component.css']
})
export class PmoSalariesDetailsComponent {

}
