import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { RequestService } from 'src/app/services/request.service';
import { StatusType } from 'src/app/common/table/StatusType';
import { ADBSanctionStatus } from 'src/app/models/enums/server-enums';
import { PmoSalariesService } from './pmo-salaries.service';
import { ISalaryResponseModel } from 'src/app/models/staff-salary.model';


@Component({
  selector: 'app-pmo-salaries',
  templateUrl: './pmo-salaries.component.html',
  styleUrls: ['./pmo-salaries.component.css']
})
export class PmoSalariesComponent {
  private _serviceSubscription;
  config: any;
  moment = moment;
  filterValue: string;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  displayedColumns: Column[] = [
    new Column('', 'actions', {
      size: 'sm',
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.id, `salaries/${e.id}`);
      },
    }),
    // staff details
    new Column('label.salaries.staff.fullName', 'staff.fullName', {
      value: (e: ISalaryResponseModel) => e.staff?.fullName,
    }),
    new Column('label.salaries.staff.staffType', 'staff.staffType', {
      value: (e: ISalaryResponseModel) => e.staff?.staffTypeLabel,
    }),
    new Column('label.salaries.staff.designation', 'staff.designation', {
      value: (e: ISalaryResponseModel) => e.staff?.designation,
    }),
    new Column('label.salaries.staff.nationality', 'staff.nationality', {
      value: (e: ISalaryResponseModel) => e.staff?.nationality,
    }),
    new Column('label.salaries.staff.accountNumber', 'staff.accountNumber', {
      value: (e: ISalaryResponseModel) => e.staff?.accountNumber,
    }),
    new Column('label.salaries.staff.employer', 'staff.employer', {
      value: (e: ISalaryResponseModel) => e.staff?.employer,
    }),
    // staff-contract details
    new Column('label.salaries.staffContract.reference', 'staffContract.reference', {
      value: (a: ISalaryResponseModel) => a.staffContract?.reference,
      type: ColumnType.Text
    }),
    new Column('label.salaries.staffContract.contractStartDate', 'staffContract.contractStartDate', {
      value: (a: ISalaryResponseModel) => a.staffContract?.contractStartDate,
      type: ColumnType.Date
    }),
    new Column('label.salaries.staffContract.contractEndDate', 'staffContract.contractEndDate', {
      value: (a: ISalaryResponseModel) => a.staffContract?.contractEndDate,
      type: ColumnType.Date
    }),
    new Column('label.salaries.staffContract.contractCurrency', 'staffContract.contractCurrency', {
      value: (a: ISalaryResponseModel) => a.staffContract?.contractCurrencyCode,
      type: ColumnType.Text
    }),
    new Column('label.salaries.staffContract.basicSalary', 'staffContract.basicSalary', {
      value: (e: ISalaryResponseModel) => e.staffContract?.basicSalary,
    }),
    new Column('label.salaries.staffContract.allowances', 'staffContract.allowances', {
      value: (e: ISalaryResponseModel) => e.staffContract?.allowances,
    }),
    // grant detailsContract
    new Column('label.grant', 'grant.reference', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.grant?.reference, `grants/${e.grant?.id}`);
      },
    }),
    // all pending
    new Column('label.salaries.pendingForJanuary21', 'pendingForJanuary21', {
      value: (a: any) => a.pendingForJanuary21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForFebruary21', 'pendingForFebruary21', {
      value: (a: any) => a.pendingForFebruary21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForMarch21', 'pendingForMarch21', {
      value: (a: any) => a.pendingForMarch21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForApril21', 'pendingForApril21', {
      value: (a: any) => a.pendingForApril21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForMay21', 'pendingForMay21', {
      value: (a: any) => a.pendingForMay21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForJune21', 'pendingForJune21', {
      value: (a: any) => a.pendingForJune21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForJuly21', 'pendingForJuly21', {
      value: (a: any) => a.pendingForJuly21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.pendingForAugust21', 'pendingForAugust21', {
      value: (a: any) => a.pendingForAugust21,
      type: ColumnType.Number
    }),
    new Column('label.salaries.totalPendingSalary', 'totalPendingSalary', {
      value: (a: any) => a.totalPendingSalary,
      type: ColumnType.Number
    }),
    new Column('label.salaries.advance', 'advance', {
      value: (a: any) => a.advance,
      type: ColumnType.Number
    }),
    new Column('label.salaries.taxDeductible', 'taxDeductible', {
      value: (a: any) => a.taxDeductible,
      type: ColumnType.Number
    }),
    new Column('label.salaries.netAmountPayable', 'netAmountPayable', {
      value: (a: any) => a.netAmountPayable,
      disableSorting: true,
      type: ColumnType.Number
    }),
    new Column('label.salaries.contractDocumentUrl', 'contractDocumentUrl', {
      value: (a: any) => a.contractDocumentUrl,
      type: ColumnType.Text
    }),
    new Column('label.salaries.previousRecord', 'previousRecord', {
      value: (a: any) => a.previousRecord,
      type: ColumnType.Text
    }),
    new Column('label.salaries.nonPaymentConfirmation', 'nonPaymentConfirmation', {
      value: (a: any) => a.nonPaymentConfirmation,
      type: ColumnType.Boolean
    }),
    new Column('label.salaries.adbSanctionStatus', 'adbSanctionStatus', {
      type: ColumnType.Status,
      value: (e: any) => {
        let type = StatusType.Default;
        let label = e.adbSanctionStatusLabel
        switch (e.adbSanctionStatus) {
          case ADBSanctionStatus.Rejected:
            type = StatusType.Danger;
            break;
          case ADBSanctionStatus.Cleared:
            type = StatusType.Default;
            break;
          default:
            type = StatusType.Default;
            break;
        }
        return {
          label: label,
          type: type,
        };
      },
    }),
    new Column('label.salaries.screeningDate', 'screeningDate', {
      type: ColumnType.Date,
    }),
    new Column('label.remarks', 'remarks', {
      type: ColumnType.Text,
    }),
  ];
  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Staff Employer', 'staffEmployer', InputType.Multiselect, {
      source: () => this.request.getEnumValues('StaffEmployerType'),
    }),
    new AppInput('Staff Account Number', 'staffAccountNumber'),
    new AppInput('Grant Reference', 'grantReference'),
    new AppInput('Staff Contract Reference', 'contractReference'),
  ];
  permissions: any | null;

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private service: PmoSalariesService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this.path = this.activatedRoute.snapshot.url[0].path;
    this._serviceSubscription = this.service.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
        if (event)
          this.setDataSource(this.config);
      }
    })
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getSalaries(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageAdvanceAccounts) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.service.openModal(),
          iconLabel: 'New PMO Salary',
          color: 'accent',
          type: 'button',
          toolTip: 'New PMO Salary',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    if (this.permissions?.CanManageSalaries) {
      actions.push(
        new Action({
          iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
          toolTip: 'button.edit',
          onClick: () => this.service.openModal(e),
          color: 'primary',
        })
      );
    }
    return actions;
  }


  exportToExcel() {
    this.request.getSalaries(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'pmo-salaries.xlsx', exportedColumns);
      }
    });
  }
}


