import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { StaffType, StaffEmployerType } from 'src/app/models/enums/server-enums';
import { IStaffBaseModel, IStaffResponseModel } from 'src/app/models/staff-salary.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  @Output() onChangeSubmitted = new EventEmitter<boolean>();
  staffTypes: TypeaheadInput[] = [];
  employerTypes: TypeaheadInput[] = [];

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.getStaffTypesForFilter();
    this.getEmployerTypesForFilter();
  }

  getStaffTypesForFilter() {
    return this.request.getEnumValues('StaffType').subscribe((data: any) => {
      this.staffTypes = data;
    });
  }

  getEmployerTypesForFilter() {
    return this.request.getEnumValues('StaffEmployerType').subscribe((data: any) => {
      this.employerTypes = data;
    });
  }

  openModal(existingEntity?: IStaffResponseModel) {
    const data = {
      pageTitle: existingEntity ? 'Edit Staff Details' : 'Insert a Staff Details',
      fields: [
        {
          name: 'fullName',
          label: 'Full Name',
          type: 'text',
          value: existingEntity?.fullName ?? '',
          required: true,
          hint: 'Enter the full name of the staff member.',
      },
      {
          name: 'designation',
          label: 'Designation',
          type: 'text',
          value: existingEntity?.designation ?? '',
          required: true,
          hint: 'Enter the designation of the staff member.',
      },
      {
          name: 'nationality',
          label: 'Nationality',
          type: 'text',
          value: existingEntity?.nationality ?? '',
          required: true,
          hint: 'Enter the nationality of the staff member.',
      },
      {
        name: 'accountNumber',
        label: 'Account Number',
        type: 'text',
        value: existingEntity?.accountNumber ?? '',
        required: false,
        hint: 'Enter the Account Number of the staff member.',
      },
      {
          name: 'employer',
          label: 'Employer',
          type: 'select',
          value: existingEntity?.employer ? existingEntity.employer.toString() : '',
          required: true,
          options: this.employerTypes,
          hint: 'Select the employer of the staff member.',
      },
      {
        name: 'staffType',
        label: 'Staff Type',
        type: 'select',
        value: existingEntity?.staffType?.toString(),
        required: true,
        options: this.staffTypes,
      },
      ]
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let requestModel: IStaffBaseModel = {
          fullName: result.fullName ?? existingEntity?.fullName,
          designation: result.designation ?? existingEntity?.designation,
          nationality: result.nationality ?? existingEntity?.nationality,
          employer: result.employer ? parseInt(result.employer) : existingEntity?.employer ?? StaffEmployerType.Other,
          accountNumber: result.accountNumber ?? existingEntity?.accountNumber,
          staffType: result.staffType ? parseInt(result.staffType) : existingEntity?.staffType ?? StaffType.Other,
        };
        if (existingEntity) {
            return this.request.editStaff(requestModel, existingEntity.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Entity edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Entity.`);
          });
        } else {
          return this.request.createStaff(requestModel).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Entity created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Entity.`);
          });
        }
      } else {
        return;
      }
    });
  }
}
