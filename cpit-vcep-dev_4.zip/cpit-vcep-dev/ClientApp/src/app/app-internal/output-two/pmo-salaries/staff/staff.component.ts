import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { RequestService } from 'src/app/services/request.service';
import { StaffService } from './staff.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {
  permissions: any | null;
  config: any;
  private _serviceSubscription;
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      size: 'sm',
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id', {      
      size: 'sm',
      value: (a: any) => a.id
    }),
    new Column('label.salaries.staff.fullName', 'fullName', {
      type: ColumnType.Text,
      size: 'sm',
    }),
    new Column('label.salaries.staff.staffType', 'staffType', {
      value: (a: any) => a.staffTypeLabel
    }),
    new Column('label.salaries.staff.designation', 'designation'),
    new Column('label.salaries.staff.nationality', 'nationality'),
    new Column('label.salaries.staff.accountNumber', 'accountNumber'),
    new Column('label.salaries.staff.employer', 'employer', {
      value: (a: any) => a.employerLabel
    }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  filters: AppInput[] = [
    new AppInput('Name', 'fullName'),
    new AppInput('Designation', 'designation'),
    new AppInput('Nationality', 'nationality'),
    new AppInput('Employer', 'employer', InputType.Multiselect, {
      source: () => this.request.getEnumValues('StaffEmployerType'),
      showAll: true
    }),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private service: StaffService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this._serviceSubscription = this.service.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    });
  }

  ngOnInit() {
    this.path = this.activatedRoute.snapshot.url[0].path;
    this.loading = false;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getAllStaff(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageSalaries) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.service.openModal(),
          iconLabel: 'New Staff',
          color: 'accent',
          type: 'button',
          toolTip: 'New Staff',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    if (this.permissions?.CanManageSalaries) {
      actions.push(
        new Action({
          iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
          toolTip: 'button.edit',
          onClick: () => this.service.openModal(e),
          color: 'primary',
        })
      );
    }
    return actions;
  }

  exportToExcel() {
    this.request.getAllStaff(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'staff.xlsx', exportedColumns);
      }
    });
  }
}