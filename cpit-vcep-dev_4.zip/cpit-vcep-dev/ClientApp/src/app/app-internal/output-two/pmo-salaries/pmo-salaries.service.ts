import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject } from 'rxjs';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { ISalaryBaseModel, ISalaryResponseModel, IStaffBaseModel } from 'src/app/models/staff-salary.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class PmoSalariesService {
  currencies: TypeaheadInput[] = [];
  adbSanctionStatuses: TypeaheadInput[] = [];

  grants$ = new BehaviorSubject([]);
  grants = this.grants$.asObservable();

  staffContracts$ = new BehaviorSubject([]);
  staffContracts = this.staffContracts$.asObservable();

  staff$ = new BehaviorSubject([]);
  staff = this.staff$.asObservable();

  loading: boolean = true;

  @Output() onChangeSubmitted = new EventEmitter<boolean>();

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.setup();
  }

  setup(): void {
    this.getCurrenciesForFilter();
    this.getGrantsForFilter();
    this.getStaffContractsForFilter();
    this.getStaffForFilter();
    this.getADBSanctionStatusesForFilter();
  }

  openModal(existingSalary?: ISalaryResponseModel) {
    this.setup();
    const data = {
      pageTitle: existingSalary ? 'Edit' : 'Create',
      fields: [
        {
          name: 'staffId',
          label: 'Staff',
          type: 'select-async',
          value: existingSalary?.staffId.toString(),
          required: true,
          hint: 'Select the staff associated with this salary record.',
          options: this.staff$,
        },
        {
          name: 'grantId',
          label: 'Grant',
          type: 'select-async',
          value: existingSalary?.grantId?.toString(),
          required: false,
          hint: 'Select the grant associated with this salary record.',
          options: this.grants$,
        },
        {
          name: 'staffContractId',
          label: 'Staff Contract',
          type: 'select-async',
          value: existingSalary?.staffContractId.toString(),
          required: true,
          hint: 'Select the staff contract associated with this salary record.',
          options: this.staffContracts$,
        },
        {
          name: 'pendingForJanuary21',
          label: 'January 21',
          type: 'number',
          value: existingSalary?.pendingForJanuary21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForFebruary21',
          label: 'February 21',
          type: 'number',
          value: existingSalary?.pendingForFebruary21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForMarch21',
          label: 'March 21',
          type: 'number',
          value: existingSalary?.pendingForMarch21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForApril21',
          label: 'April 21',
          type: 'number',
          value: existingSalary?.pendingForApril21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForMay21',
          label: 'May 21',
          type: 'number',
          value: existingSalary?.pendingForMay21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForJune21',
          label: 'June 21',
          type: 'number',
          value: existingSalary?.pendingForJune21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForJuly21',
          label: 'July 21',
          type: 'number',
          value: existingSalary?.pendingForJuly21 ?? 0,
          required: false,
        },
        {
          name: 'pendingForAugust21',
          label: 'August 21',
          type: 'number',
          value: existingSalary?.pendingForAugust21 ?? 0,
          required: false,
        },
        {
          name: 'totalPendingSalary',
          label: 'Total Pending Salary',
          type: 'number',
          value: existingSalary?.totalPendingSalary ?? 0,
          required: false,
        },
        {
          name: 'taxDeductible',
          label: 'Tax Deductible',
          type: 'number',
          value: existingSalary?.taxDeductible ?? 0,
          required: false,
        },
        {
          name: 'advance',
          label: 'Advance',
          type: 'number',
          value: existingSalary?.advance ?? 0,
          required: false,
        },
        {
          name: 'contractDocumentUrl',
          label: 'Contract Document',
          type: 'text',
          value: existingSalary?.contractDocumentUrl,
          required: false,
        },
        {
          name: 'timeSheetUrl',
          label: 'Time Sheet URL',
          type: 'text',
          value: existingSalary?.timeSheetUrl,
          required: false,
        },
        {
          name: 'previousRecord',
          label: 'Previous Record',
          type: 'text',
          value: existingSalary?.previousRecord ?? '',
          required: false,
        },
        {
          name: 'nonPaymentConfirmation',
          label: 'Non-Payment Confirmation',
          type: 'checkbox',
          value: existingSalary?.nonPaymentConfirmation ?? false,
          required: false,
        },
        {
          name: 'adbSanctionStatus',
          label: 'ADB Sanction Status',
          type: 'select',
          value: existingSalary?.adbSanctionStatus?.toString(),
          required: true,
          options: this.adbSanctionStatuses,
        },
        {
          name: 'screeningDate',
          label: 'Screening Date',
          type: 'date',
          value: existingSalary?.screeningDate ?? '',
          required: false,
        },
        {
          name: 'remarks',
          label: 'Remarks',
          type: 'textarea',
          value: existingSalary?.remarks ?? '',
          required: false,
          hint: 'Enter any additional remarks relevant to the salary record.',
        },
      ]
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let requestModel: ISalaryBaseModel = {
          staffId: result.staffId ?? existingSalary?.staffId,
          grantId: result.grantId ?? existingSalary?.grantId,
          staffContractId: result.staffContractId ?? existingSalary?.staffContractId,
          pendingForJanuary21: result.pendingForJanuary21 ?? existingSalary?.pendingForJanuary21,
          pendingForFebruary21: result.pendingForFebruary21 ?? existingSalary?.pendingForFebruary21,
          pendingForMarch21: result.pendingForMarch21 ?? existingSalary?.pendingForMarch21,
          pendingForApril21: result.pendingForApril21 ?? existingSalary?.pendingForApril21,
          pendingForMay21: result.pendingForMay21 ?? existingSalary?.pendingForMay21,
          pendingForJune21: result.pendingForJune21 ?? existingSalary?.pendingForJune21,
          pendingForJuly21: result.pendingForJuly21 ?? existingSalary?.pendingForJuly21,
          pendingForAugust21: result.pendingForAugust21 ?? existingSalary?.pendingForAugust21,
          totalPendingSalary: result.totalPendingSalary ?? existingSalary?.totalPendingSalary,
          taxDeductible: result.taxDeductible ?? existingSalary?.taxDeductible,
          advance: result.advance ?? existingSalary?.advance,
          contractDocumentUrl: result.contractDocumentUrl ?? existingSalary?.contractDocumentUrl,
          timeSheetUrl: result.timeSheetUrl ?? existingSalary?.timeSheetUrl,
          previousRecord: result.previousRecord ?? existingSalary?.previousRecord,
          nonPaymentConfirmation: result.nonPaymentConfirmation ?? existingSalary?.nonPaymentConfirmation,
          adbSanctionStatus: result.adbSanctionStatus ? parseInt(result.adbSanctionStatus) : existingSalary?.adbSanctionStatus,
          screeningDate: result.screeningDate ?? existingSalary?.screeningDate,
          remarks: result.remarks ?? existingSalary?.remarks,
        };
        if (existingSalary) {
          return this.request.editSalary(requestModel, existingSalary.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Salary edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Salary.`);
          });
        } else {
          return this.request.createSalary(requestModel).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Salary created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Salary.`);
          });
        }
      } else {
        return;
      }
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  getStaffForFilter() {
    return this.request.getStaffForFilter().subscribe((data: any) => {
      this.staff$.next(data);
    });
  }

  getGrantsForFilter() {
    return this.request.getGrantsForFilter().subscribe((data: any) => {
      this.grants$.next(data);
    });
  }

  getADBSanctionStatusesForFilter() {
    return this.request.getEnumValues('ADBSanctionStatus').subscribe((data: any) => {
      this.adbSanctionStatuses = data;
    });
  }

  getStaffContractsForFilter() {
    return this.request.getStaffContractsForFilter().subscribe((data: any) => {
      this.staffContracts$.next(data);
    });
  }
}

