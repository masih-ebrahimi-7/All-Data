import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { IStaffContractResponseModel, IStaffContractBaseModel } from 'src/app/models/staff-salary.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class StaffContractsService {
  @Output() onChangeSubmitted = new EventEmitter<boolean>();
  currencies: TypeaheadInput[] = [];

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.getCurrenciesForFilter();
  }

  openModal(existingContract?: IStaffContractResponseModel) {
    const data = {
      pageTitle: existingContract ? 'Edit Staff Details' : 'Insert a Staff Details',
      fields: [
        {
            name: 'reference',
            label: 'Contract Reference',
            type: 'text',
            value: existingContract?.reference ?? '',
            required: true,
            hint: 'Enter the reference number for the contract.',
        },
        {
            name: 'contractStartDate',
            label: 'Contract Start Date',
            type: 'date',
            value: existingContract?.contractStartDate ?? '',
            required: true,
            hint: 'Select the start date of the contract.',
        },
        {
            name: 'contractEndDate',
            label: 'Contract End Date',
            type: 'date',
            value: existingContract?.contractEndDate ?? '',
            required: true,
            hint: 'Select the end date of the contract.',
        },
        {
            name: 'contractCurrencyId',
            label: 'Contract Currency',
            type: 'select',
            value: existingContract?.contractCurrencyId ?? '',
            required: true,
            options: this.currencies,
            hint: 'Select the currency used for the contract.',
        },
        {
            name: 'basicSalary',
            label: 'Basic Salary',
            type: 'number',
            value: existingContract?.basicSalary ?? 0,
            required: true,
            hint: 'Enter the basic salary for the contract.',
        },
        {
            name: 'allowances',
            label: 'Allowances',
            type: 'number',
            value: existingContract?.allowances ?? 0,
            required: true,
            hint: 'Enter the allowances for the contract.',
        }
      ]
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let requestModel: IStaffContractBaseModel = {
          reference: result.reference ?? existingContract?.reference,
          contractStartDate: result.contractStartDate ?? existingContract?.contractStartDate,
          contractEndDate: result.contractEndDate ?? existingContract?.contractEndDate,
          contractCurrencyId: result.contractCurrencyId ?? existingContract?.contractCurrencyId,
          basicSalary: result.basicSalary ?? existingContract?.basicSalary,
          allowances: result.allowances ?? existingContract?.allowances,
        };
        if (existingContract) {
            return this.request.editStaffContract(requestModel, existingContract.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Entity edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Entity.`);
          });
        } else {
          return this.request.createStaffContract(requestModel).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Entity created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Entity.`);
          });
        }
      } else {
        return;
      }
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }
}
