import { EventEmitter, Injectable, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { AuthorityType } from 'src/app/models/enums/server-enums';
import { ExpenseEditRequestModel, ExpenseRequestModel } from 'src/app/models/expense.model';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput } from 'src/app/services/typeahead.service';

@Injectable({
  providedIn: 'root'
})
export class ExpensesService {
  currencies: TypeaheadInput[] = [];
  adbSanctionStatuses: TypeaheadInput[] = [];
  sectors: TypeaheadInput[] = [];
  authorities: TypeaheadInput[] = [];

  grants$ = new BehaviorSubject([]);
  grants = this.grants$.asObservable();

  externalEntities$ = new BehaviorSubject([]);
  externalEntities = this.externalEntities$.asObservable();

  loading: boolean = true;

  @Output() onChangeSubmitted = new EventEmitter<boolean>();

  constructor(private request: RequestService, public dialog: MatDialog, private notify: NotificationService) {
    this.setup();
  }

  setup(): void {
    this.getCurrenciesForFilter();
    this.getGrantsForFilter();
    this.getExternalEntitiesForFilter();
    this.getADBSanctionStatusesForFilter();
    this.getSectorsForFilter();
    this.getAuthoritiesForFilter();
  }

  openExpensesModal(existingExpense?: ExpenseEditRequestModel) {
    this.setup();
    const data = {
      pageTitle: existingExpense ? 'Edit Expense Details' : 'Insert a new Expense',
      fields: [
        {
          name: 'description',
          label: 'Description',
          type: 'textarea',
          value: existingExpense?.description ?? '',
          required: true,
        },
        {
            name: 'currencyId',
            label: 'Select expense Currency',
            type: 'select',
            value: existingExpense?.currencyId?.toString(),
            required: true,
            options: this.currencies,
            hint: "If the currency is not USD, then the USD amount will be calculated with the rates available in the Currency Conversion page."
        },
        {
            name: 'monthlyCost',
            label: 'Enter expense Monthly Cost',
            type: 'number',
            value: existingExpense?.monthlyCost,
            required: true,
            suffix: "payments"
        },
        {
            name: 'numberOfMonths',
            label: 'Number Of Months',
            type: 'number',
            value: existingExpense?.numberOfMonths,
            required: true,
        },
        {
            name: 'pendingClaimsAmount',
            label: 'Pending Claims Amount',
            type: 'number',
            value: existingExpense?.pendingClaimsAmount,
            required: true,
            suffix: "payments"
        },
        {
            name: 'grantIds',
            label: 'Link expense to Grants',
            type: 'select-async',
            value: existingExpense?.grants?.map(a => a.id?.toString()),
            allowMultiple: true,
            required: false,
            options: this.grants$,
        },
        {
            name: 'externalEntityId',
            label: 'Link expense to an External Entity',
            type: 'select-async',
            value: existingExpense?.externalEntityId?.toString(),
            required: false,
            options: this.externalEntities$,
        },
        {
            name: 'screeningDate',
            label: 'Screening Date',
            type: 'date',
            value: existingExpense?.screeningDate ?? null,
            required: false,
        },
        {
            name: 'datesOfExpenditure',
            label: 'Date Of Expenditure',
            startLabel: 'Date Of Expenditure start',
            endLabel: 'Date Of Expenditure end',
            type: 'date-range',
            value: {
              start: existingExpense?.dateOfExpenditureStart ?? null,
              end: existingExpense?.dateOfExpenditureEnd ?? null,
            },
            required: false,
        },
        {
            name: 'adbSanctionStatus',
            label: 'ADB Sanction Status',
            type: 'select',
            value: existingExpense?.adbSanctionStatus?.toString(),
            required: true,
            options: this.adbSanctionStatuses,
        },
        {
            name: 'nationality',
            label: 'Nationality',
            type: 'text',
            value: existingExpense?.nationality ?? '',
            required: false,
        },
        {
            name: 'remarks',
            label: 'Remarks',
            type: 'textarea',
            value: existingExpense?.remarks ?? '',
            required: false,
        },
        {
            name: 'sector',
            label: 'Sector',
            type: 'select',
            value: existingExpense?.sector?.toString(),
            required: false,
            options: this.sectors,
        },
        {
            name: 'contractAuthority',
            label: 'Contract Authority',
            type: 'select',
            value: existingExpense?.contractAuthority?.toString(),
            required: false,
            options: this.authorities,
        },
        {
            name: 'expenditureType',
            label: 'Expenditure Type',
            type: 'text',
            value: existingExpense?.expenditureType ?? '',
            required: false,
        },
        {
            name: 'contractReference',
            label: 'Contract Reference',
            type: 'text',
            value: existingExpense?.contractReference ?? '',
            required: false,
        },
        {
            name: 'documentUploadUrl',
            label: 'Document Upload URL',
            type: 'text',
            value: existingExpense?.documentUploadUrl ?? '',
            required: false,
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let expenseRequestModel: ExpenseRequestModel = {
          description: result.description ?? existingExpense?.description,
          currencyId: result.currencyId ?? existingExpense?.currencyId,
          monthlyCost: result.monthlyCost ?? existingExpense?.monthlyCost,
          numberOfMonths: result.numberOfMonths ?? existingExpense?.numberOfMonths,
          pendingClaimsAmount: result.pendingClaimsAmount ?? existingExpense?.pendingClaimsAmount,
          grantIds: Array.isArray(result.grantIds) ?  result.grantIds : existingExpense?.grantIds ?? [],
          externalEntityId: parseInt(result.externalEntityId) ?? existingExpense?.externalEntityId ?? null,
          screeningDate: result.screeningDate ?? existingExpense?.screeningDate,
          dateOfExpenditureStart: result.datesOfExpenditure.start ?? existingExpense?.dateOfExpenditureStart,
          dateOfExpenditureEnd: result.datesOfExpenditure.end ?? existingExpense?.dateOfExpenditureEnd,
          adbSanctionStatus: parseInt(result.adbSanctionStatus) ?? existingExpense?.adbSanctionStatus,
          nationality: result.nationality ?? existingExpense?.nationality,
          remarks: result.remarks ?? existingExpense?.remarks,
          sector: parseInt(result.sector) ?? existingExpense?.sector,
          contractAuthority: parseInt(result.contractAuthority) ?? existingExpense?.contractAuthority,
          expenditureType: result.expenditureType ?? existingExpense?.expenditureType,
          contractReference: result.contractReference ?? existingExpense?.contractReference,
          documentUploadUrl: result.documentUploadUrl ?? existingExpense?.documentUploadUrl,
          expenseType: AuthorityType.PMO
        };
        if (existingExpense) {
          let editExpenseRequestModel: ExpenseEditRequestModel = expenseRequestModel as ExpenseEditRequestModel;
          editExpenseRequestModel.id = existingExpense.id;
          return this.request.editExpense(editExpenseRequestModel, existingExpense.id).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Expense edited successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Expense.`);
          });
        } else {
          return this.request.createExpense(expenseRequestModel).subscribe((data: any) => {
            if (data) {
              this.notify.showSuccess(`Expense created successfully.`);
              this.onChangeSubmitted.emit(true);
            }
            else this.notify.showError(`Unable to create Expense.`);
          });
        }
      } else {
        return;
      }
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  getExternalEntitiesForFilter() {
    return this.request.getExternalEntitiesForFilter().subscribe((data: any) => {
      this.externalEntities$.next(data);
    });
  }

  getGrantsForFilter() {
    return this.request.getGrantsForFilter().subscribe((data: any) => {
      this.grants$.next(data);
    });
  }

  getADBSanctionStatusesForFilter() {
    return this.request.getEnumValues('ADBSanctionStatus').subscribe((data: any) => {
      this.adbSanctionStatuses = data;
    });
  }

  getSectorsForFilter() {
    return this.request.getEnumValues('SectorType').subscribe((data: any) => {
      this.sectors = data;
    });
  }

  getAuthoritiesForFilter() {
    return this.request.getEnumValues('AuthorityType').subscribe((data: any) => {
      this.authorities = data;
    });
  }
}
