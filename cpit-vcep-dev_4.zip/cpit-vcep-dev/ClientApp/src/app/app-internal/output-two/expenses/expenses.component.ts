import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { StatusType } from 'src/app/common/table/StatusType';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { RequestService } from 'src/app/services/request.service';
import { ExpensesService } from './expenses.service';
import { ADBSanctionStatus } from 'src/app/models/enums/server-enums';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.component.html',
  styleUrls: ['./expenses.component.css'],
})
export class ExpensesComponent implements OnInit {
  permissions: any | null;
  config: any;
  private _expensesServiceSubscription;
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      size: 'sm',
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('#', 'id', {      
      size: 'sm',
      value: (a: any) => a.id
    }),
    new Column('label.shortReference', 'reference', {
      type: ColumnType.Link,
      size: 'sm',
      value: (e: any) => {
        return new Link(e.reference, `expenses/${e.id}`);
      },
    }),
    new Column('label.description', 'description'),
    new Column('label.expenses.monthlyCost', 'monthlyCost', { type: ColumnType.Number }),
    new Column('label.currency', 'currencyCode', {
      disableSorting: true
    }),
    new Column('label.currencyRate', 'currencyRate', {
      disableSorting: true
    }),
    new Column('label.expenses.numberOfMonths', 'numberOfMonths', {
      type: ColumnType.Number 
    }),
    new Column('label.expenses.monthlyCostUsd', 'monthlyCostUsd', { 
      type: ColumnType.Number,
      disableSorting: true,
      tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page" 
    }),
    new Column('label.expenses.pendingClaimsAmount', 'pendingClaimsAmount', { type: ColumnType.Number }),
    new Column('label.expenses.pendingClaimsUsd', 'pendingClaimsAmountUsd', { 
      type: ColumnType.Number,
      disableSorting: true,
      tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page" 
    }),
    new Column('label.expenses.remarks', 'remarks', {
      type: ColumnType.Text,
    }),
    new Column('label.expenses.contractAuthority', 'contractAuthority', {
      type: ColumnType.Text,
      value: (e: any) => e.contractAuthorityLabel ?? '',
    }),
    new Column('label.expenses.expenditureType', 'expenditureType'),
    new Column('label.expenses.contractReference', 'contractReference'),
    new Column('label.expenses.documentUpload', 'documentUploadUrl', {
      type: ColumnType.Link,
      value: (e: any) => {
        return e.documentUploadUrl ? new Link('View Document', e.documentUploadUrl) : null;
      },
    }),
    new Column('label.expenses.sector', 'sector', {
      type: ColumnType.Text,
      value: (e: any) => e.sectorLabel ?? '',
    }),
    new Column('label.sector', 'grant.sector', {
      type: ColumnType.Text,
      value: (e: any) => {
        let sectors: any[] = [];
         e.grants.map(
          (r: any) =>
            sectors.push(r.sector)
        );
        return sectors.join(", ");
      },
    }),
    new Column('label.grants', 'grants', {
      disableSorting: true,
      type: ColumnType.LinkList,
      value: (e: any) => {
        return e.grants.map(
          (r: any) =>
            new Link(r.reference, `/grants/${r.id}`)
        );
      },
    }),
    new Column('label.contractor', 'externalEntity.name', {
      type: ColumnType.Link,
      value: (e: any) => {
        return new Link(e.externalEntity?.name, `list-external-entities?name=${e.externalEntity?.name}`);
      },
    }),
    new Column('label.expenses.nationality', 'nationality', {
      type: ColumnType.Text,
    }),
    new Column('label.nationality', 'externalEntity.nationality', {
      type: ColumnType.Text,
      value: (e: any) => e.externalEntity?.nationality ?? '',
    }),
    new Column('label.expenses.screeningDate', 'screeningDate', {
      type: ColumnType.Date,
    }),
    new Column('label.expenses.dateOfExpenditureStart', 'dateOfExpenditureStart', {
      type: ColumnType.Date,
    }),
    new Column('label.expenses.dateOfExpenditureEnd', 'dateOfExpenditureEnd', {
      type: ColumnType.Date,
    }),
    new Column('label.expenses.expenseType', 'expenseType', {
      type: ColumnType.Text,
      size: 'sm',
      value: (e: any) => e.expenseTypeLabel ?? '',
    }),
    new Column('label.expenses.adbSanctionStatus', 'adbSanctionStatus', {
      type: ColumnType.Status,
      value: (e: any) => {
        let type = StatusType.Default;
        let label = e.adbSanctionStatusLabel
        switch (e.adbSanctionStatus) {
          case ADBSanctionStatus.Rejected:
            type = StatusType.Danger;
            break;
          case ADBSanctionStatus.Cleared:
            type = StatusType.Default;
            break;
          default:
            type = StatusType.Default;
            break;
        }
        return {
          label: label,
          type: type,
        };
      },
    }),
  ];

  moment = moment;
  loading: boolean = true;
  totalSize: number;
  data: any;
  path: string;
  bulkActions: any;

  filters: AppInput[] = [
    new AppInput('Reference', 'reference'),
    new AppInput('Monthly Cost', 'monthlyCost', InputType.Number),
    new AppInput('Pending Claims Amount', 'pendingClaimsAmount', InputType.Number),
    new AppInput('Number Of Months', 'NumberOfMonths', InputType.Number),
    new AppInput('Screening Date', 'startScreeningDate', InputType.DateRange, {
      toInputName: 'endScreeningDate',
    }),
    new AppInput('Date Of Expenditure', 'startDateOfExpenditure', InputType.DateRange, {
      toInputName: 'endDateOfExpenditure',
    }),
    new AppInput('ADB Sanction Status', 'adbSanctionStatus', InputType.Multiselect, {
      source: () => this.request.getEnumValues('ADBSanctionStatus'),
    }),
    new AppInput('Expense Type', 'expenseType', InputType.Multiselect, {
      source: () => this.request.getEnumValues('AuthorityType'),
    }),
    new AppInput('Nationality', 'nationality'),
    new AppInput('Sector', 'sector', InputType.Multiselect, {
      source: () => this.request.getEnumValues('SectorType'),
    }),
    new AppInput('Contract Authority', 'contractAuthority', InputType.Multiselect, {
      source: () => this.request.getEnumValues('AuthorityType'),
    }),
    new AppInput('Expenditure Type', 'expenditureType'),
    new AppInput('Contract Reference', 'contractReference'),
  ];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private expensesService: ExpensesService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
    this._expensesServiceSubscription = this.expensesService.onChangeSubmitted.subscribe({
      next: (event: boolean) => {
          if (event)
            this.setDataSource(this.config);
      }
    })
  }

  ngOnInit() {
    this.path = this.activatedRoute.snapshot.url[0].path;
    this.loading = false;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};
    this.request.getExpenses(this.config || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanManageExpenses) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.expensesService.openExpensesModal(),
          iconLabel: 'New Expense',
          color: 'accent',
          type: 'button',
          toolTip: 'New Expense',
        })
      );
    }
    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    if (this.permissions?.CanManageExpenses) {
      actions.push(
        new Action({
          iconLabel: '<i class="bx bxs-edit medium-icon primary-color" ></i>',
          toolTip: 'button.edit',
          onClick: () => this.expensesService.openExpensesModal(e),
          color: 'primary',
        })
      );
    }
    return actions;
  }

  exportToExcel() {
    this.request.getExpenses(this.config || {}).subscribe((data: any) => {
      if (Array.isArray(data.records)) {
        let exportedColumns = this.displayedColumns.map(a => a.columnName);
        exportDataToSheet(data.records, 'expenses.xlsx', exportedColumns);
      }
    });
  }
}