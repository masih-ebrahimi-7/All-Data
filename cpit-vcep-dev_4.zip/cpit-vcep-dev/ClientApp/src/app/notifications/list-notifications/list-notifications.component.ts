import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import moment from 'moment';
import { BulkNotificationAction } from 'src/app/models/enums/ui-enums';
import { AppInput } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { NotificationType } from 'src/app/models/enums/server-enums';
import { PermissionsService } from 'src/app/services/auth/permissions.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './list-notifications.component.html',
  styleUrls: ['./list-notifications.component.css'],
})
export class NotificationsComponent {
  displayedColumns: Column[] = [
    new Column('', 'actions', {
      type: ColumnType.Actions,
      disableSorting: true,
      value: (e: any) => {
        return new ActionList(this.getActions(e));
      },
    }),
    new Column('label.Read', 'isRead', {
      type: ColumnType.Boolean
    }),
    new Column('label.notificationHeadline', 'headline', {
      type: ColumnType.Text,
      size: 'xl'
    }),
    new Column('label.description', 'description', {
      type: ColumnType.Text,
      size: 'xl'
    }),
    new Column('label.createdBy', 'createdBy'),
    new Column('label.createdOn', 'createdDate', {
      type: ColumnType.DateTime
    })
  ];
  config: any;
  moment = moment;
  filters: AppInput[] = [
    new AppInput('label.search', 'searchQuery')
  ];
  loading: boolean = true;
  totalSize: number;
  data: any;
  selected: any[];
  bulkActions: any[];
  permissions: any | null;
  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private notify: NotificationService,
    private translate: TranslateService,
    private permissionsService: PermissionsService,
  ) {
    this.permissions = this.permissionsService.get();
    this.bulkActions = this.getBulkActions();
  }

  setDataSource(config: any) {
    this.config = config;
    this.request.searchNotifications(config.pageIndex, config.pageSize, config.orderBy, config.direction, config.filter || {}).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.data = data.records;
    });
  }

  getBulkActions(): Action[] {
    var bulkActions: Action[] = [];

    bulkActions.push(
      new Action({
        onClick: () => this.markNotificationsAsReadOrUnread(BulkNotificationAction.MarkAsRead),
        iconLabel: 'label.markAsRead',
        iconName: 'mark_email_read',
        color: 'primary',
        type: 'button'
      })
    );

    bulkActions.push(
      new Action({
        onClick: () => this.markNotificationsAsReadOrUnread(BulkNotificationAction.MarkAsUnread),
        iconLabel: 'label.markAsUnread',
        iconName: 'mark_email_unread',
        color: 'primary',
        type: 'button'
      })
    );

    return bulkActions;
  }

  markNotificationsAsReadOrUnread(action: BulkNotificationAction) {
    if (this.selected && this.selected?.length > 0) {
      var notificationIds = this.selected.map(function (a: any) { return a.id });
      this.request.markNotificationsAsReadOrUnread({ entityIds: notificationIds, read: (action == BulkNotificationAction.MarkAsRead) }).subscribe((data: any) => {
        this.setDataSource(this.config);
      });
    }
    else {
      this.notify.showError(this.translate.instant('notify.selectNotifications'));
    }
  }

  getActions(e: any): Action[] {
    var actions: Action[] = [];
    actions.push(
      new Action({
        iconLabel: e.isRead ? '<i class="bx bxs-envelope-open medium-icon primary-color" ></i>' : '<i class="bx bxs-envelope medium-icon primary-color" ></i>',
        toolTip: e.isRead ? 'label.markAsUnread' : 'label.markAsRead',
        onClick: () => this.markNotificationAsReadOrUnread(e),
        color: 'primary',
      })
    );
    return actions;
  }

  selectionChanged(selected: any) {
    this.selected = selected;
  }

  markNotificationAsReadOrUnread(notification: any, isRead?: boolean): void {
    this.request.markNotificationsAsReadOrUnread({ entityIds: [notification.id], read: isRead || !notification.isRead }).subscribe((data: any) => {
      this.setDataSource(this.config);
    });
  }

  getLink(e: any): string {
    if (e.notificationType == NotificationType.Claim)
      return this.getClaimDetailsPageLink(e.entityId);
    else return e.url;  
  }

  getClaimDetailsPageLink(claimId: number) {
    if (this.permissions?.CanAccessAsClaimant || this.permissions?.CanAccessAsDonor) 
      return `submission-details/${claimId}`;
    else
      return `claims/${claimId}`;
  }
  
}
