import { Component } from '@angular/core';
import { SafePipe } from 'src/app/common/pipes/safe.pipe';
import { PermissionsService } from 'src/app/services/auth/permissions.service';

@Component({
  selector: 'app-user-guide',
  templateUrl: './user-guide.component.html',
  styleUrls: ['./user-guide.component.css']
})
export class UserGuideComponent {
  permissions: any | null;

  constructor(private permissionsService: PermissionsService, private safePipe: SafePipe) {
    this.permissions = this.permissionsService.get();
  }

  ngOnInit() {}
}
