import { Component, OnInit } from '@angular/core';
import { FormGroup, UntypedFormBuilder, UntypedFormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-issue-detail',
  templateUrl: './issue-detail.component.html',
  styleUrls: ['./issue-detail.component.css'],
})
export class IssueDetailComponent implements OnInit {
  actions = [];
  totalSize: number;
  title = 'label.issueDetail';
  statusList: any[] = [];
  priorityList: any[] = [];
  issueTypeList: any[] = [];
  permissions: any | null;
  helpdeskIssueId: string;
  path: string;
  data: any;
  comment: string;
  commentInput: any;
  editingAmount: boolean;
  loading: boolean;
  isNew: boolean;
  selection: Array<Object>;
  userInfo: any;

  public issueForm: FormGroup;
  public commentForm: FormGroup;

  public editorConfig = EditorConfig;
  constructor(
    private router: Router,
    private activatedRouter: ActivatedRoute,
    private request: RequestService,
    private fb: UntypedFormBuilder,
    private notify: NotificationService,
    public dialog: MatDialog,
    permissionService: PermissionsService
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {
    this.issueForm = this.fb.group({});
    this.commentForm = this.fb.group({});

    this.helpdeskIssueId = this.activatedRouter.snapshot.params['helpdeskIssueId'];

    let promises: Promise<void>[] = [];

    Promise.all(promises).then((_) => {
      this.request.getEnumValues('HelpdeskIssueStatus').subscribe((data: any) => {
        this.statusList = data;
      });
      this.request.getEnumValues('HelpdeskPriority').subscribe((data: any) => {
        this.priorityList = data;
      });
      this.request.getEnumValues('HelpdeskIssueType').subscribe((data: any) => {
        this.issueTypeList = data;
      });
      this.getIssue();
    });
  }

  getIssue() {
    if (parseInt(this.helpdeskIssueId, 10)) {
      this.isNew = false;
      this.loading = true;
      this.request.getHelpdeskIssue(this.helpdeskIssueId).subscribe((data: any) => {
        this.initData(data);
        this.loading = false;
      });
    } else {
      this.isNew = true;
      var data = {
        status: 'New',
        summary: '',
        description: '',
        priority: '',
        type: '',
      };
      this.initData(data);
    }
  }

  initData(data: any) {
    this.data = data;
    data.summaryInput = new UntypedFormControl(data.summary);
    data.descriptionInput = new UntypedFormControl(data.description);
    data.statusInput = new UntypedFormControl(data.status);
    data.priorityInput = new UntypedFormControl(data.priority);
    data.typeInput = new UntypedFormControl(data.type);
    this.commentInput = new UntypedFormControl(this.comment);
  }

  submit() {
    if (!this.data.descriptionInput.value) {
      this.notify.showError('Please add a description.');
      return;
    }
    var postObject = {
      id: this.data.id,
      summary: this.data.summaryInput.value,
      description: this.data.descriptionInput.value,
      status: this.data.statusInput.value,
      priority: this.data.priorityInput.value,
      type: this.data.typeInput.value,
    };
    if (this.data.id == null) {
      this.request.createHelpdeskIssue(postObject).subscribe((data: any) => {
        this.router.navigate(['/list-issues'], {});
        this.notify.showSuccess('Updated successfully');
      });
    } else {
      this.request.updateHelpdeskIssue(postObject).subscribe((data: any) => {
        if (this.isNew) {
          this.router.navigate(['/list-issues'], {});
        } else {
          this.initData(data);
        }
        this.notify.showSuccess('Updated successfully');
      });
    }
  }

  submitComment() {
    if (!this.commentInput.value) {
      this.notify.showError('This property is mandatory.');
      return;
    }
    var postObject = {
      helpdeskIssueId: this.data.id,
      text: this.commentInput.value,
    };
    this.loading = true;
    this.request.createHelpdeskIssueComment(postObject).subscribe((data: any) => {
      this.initData(data);
      this.loading = false;
      this.notify.showSuccess('Updated successfully');
    });
  }
}
