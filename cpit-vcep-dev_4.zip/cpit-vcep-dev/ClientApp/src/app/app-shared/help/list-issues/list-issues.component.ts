import { SelectionModel } from '@angular/cdk/collections';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from '../../../services/auth/permissions.service';
import { UserProfileService } from '../../../services/auth/user-profile.service';
import { NotificationService } from '../../../services/notification.service';

@Component({
  selector: 'app-list-issues',
  templateUrl: './list-issues.component.html',
  styleUrls: ['./list-issues.component.scss'],
})
export class ListIssuesComponent implements OnInit, AfterViewInit {
  displayedColumns = [
    'view',
    'summary',
    'status',
    'priority',
    'type',
    'jiraTicketNumber',
    'createdDate',
    'createdBy',
  ];

  dataSource: MatTableDataSource<Object>;
  pageEvent: PageEvent;
  path: string;
  permissions: any | null;
  queryParams: any;
  filter: any;
  statusList: any[] = [];
  issueTypeList: any[] = [];
  priorityList: any[] = [];
  totalSize: number;
  panelOpenState = false;
  filterFormInput: any = {
    statuses: new UntypedFormControl(),
    priorities: new UntypedFormControl(),
    issueTypes: new UntypedFormControl(),
  };
  displayingAll = true;
  userInfo: any;
  public selected: any;
  public users: any = [];
  selection = new SelectionModel<Object>(true, []);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private notify: NotificationService,
    permissionService: PermissionsService,
    private userProfileService: UserProfileService
  ) {
    this.queryParams = this.getQueryParams();

    this.filter = new UntypedFormGroup({
      statuses: new UntypedFormControl(this.queryParams.statuses),
      priorities: new UntypedFormControl(this.queryParams.priorities),
      issueTypes: new UntypedFormControl(this.queryParams.issueTypes),
    });

    this.path = this.activatedRoute.snapshot.url[0].path;
    this.permissions = permissionService.get();
    this.userInfo = this.userProfileService.get();
  }

  ngOnInit(): void {
    this.applyFilter();
    this.request.getEnumValues('HelpdeskIssueStatus').subscribe((data: any) => {
      this.statusList = data;
    });
    this.request.getEnumValues('HelpdeskIssueType').subscribe((data: any) => {
      this.issueTypeList = data;
    });
    this.request.getEnumValues('HelpdeskPriority').subscribe((data: any) => {
      this.priorityList = data;
    });
  }

  setDataSource(
    pageIndex: number,
    pageSize: number,
    orderBy: string = 'createdDate',
    ascending: boolean = false,
    filters: any = null
  ) {
    filters = filters ? filters : this.getQueryParams();
    this.request.getHelpdeskIssues(filters).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.dataSource = new MatTableDataSource(data.records);
      this.dataSource.sort = this.sort;
      this.dataSource.sortData = (data: Object[], sort: MatSort) => {
        const active = sort.active;
        const direction = sort.direction;
        this.setDataSource(this.paginator.pageIndex + 1, this.paginator.pageSize, active, direction === 'asc');
        return data.sort((a: any, b: any) => {
          return 0;
        });
      };
    });
  }

  getTextContent(htmlContent: string) {
    if (!htmlContent) return '';
    var d = document.createElement('div');
    d.innerHTML = htmlContent;
    return d.textContent || d.innerText;
  }

  ngAfterViewInit() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  clearForm() {
    this.filter.reset();
  }

  applyFilter() {
    this.router.navigate(['/list-issues'], { queryParams: this.filter.value });
    this.setDataSource(1, 10, '', true, this.filter.value);
    this.selection.clear();
    if (this.paginator) {
      this.paginator.pageSize = 10;
      this.paginator.pageIndex = 0;
    }
  }

  onPaginateChange(e: any) {
    this.setDataSource(e.pageIndex + 1, e.pageSize, '', true, this.filter.value);
    this.selection.clear();
  }

  public sortData(): void {
    switch (this.sort.direction) {
      case 'asc':
        this.sort.direction = 'asc';
        break;
      case 'desc':
        this.sort.direction = 'desc';
        break;
      default:
        this.sort.direction = 'asc';
    }
  }

  getQueryParams() {
    const queryParamMap = this.activatedRoute.snapshot.queryParamMap;
    return {
      statuses: queryParamMap.getAll('statuses')?.length === 0 ? null : queryParamMap.getAll('statuses'),
      priorities: queryParamMap.getAll('priorities')?.length === 0 ? null : queryParamMap.getAll('priorities'),
      issueTypes: queryParamMap.getAll('issueTypes')?.length === 0 ? null : queryParamMap.getAll('issueTypes'),
    };
  }

  displayMy() {
    this.displayingAll = false;
    this.filter.value.createdByUsers = [this.userInfo.email];
    this.applyFilter();
  }

  displayAll() {
    this.displayingAll = true;
    this.filter.value.createdByUsers = [];
    this.applyFilter();
  }

  openIssue(reference: string) {
    this.router.navigate([`/issue-detail/${reference}`]);
  }

  openTicketInJira(ticketNumber: string) {
    const jiraBaseUrl = 'https://unops.atlassian.net/browse/';
    const url = `${jiraBaseUrl}${ticketNumber}`;

    window.open(url, '_blank');
  }

  createJiraIssue(issueId: any): void {
    this.request.createJiraTicketForHelpdeskIssue(issueId).subscribe((data: any) => {
      if (data && data.jiraTicketNumber)
        this.openTicketInJira(data.jiraTicketNumber)
        this.notify.showSuccess('Jira issue created successfully.');
        this.applyFilter(); 
    });
  }

  manuallyAddJiraIssueRef(issueId: any): void {
    this.request.linkHelpdeskIssueToJiraStatus(issueId, "VCEP-1").subscribe((data: any) => {
      if (data && data.jiraTicketNumber)
        this.notify.showSuccess('Jira issue linked successfully.');
        this.applyFilter(); 
    });
  }

  syncIssueStatusWithJiraTicketLatestStatus(issueId: any): void {
    this.request.getLatestJiraStatusForHelpdeskIssue(issueId).subscribe((data: any) => {
      if (data && data.jiraTicketNumber)
        this.notify.showSuccess('Issue status updated.');
        this.applyFilter();
    });
  }

  syncOpenIssuesStatusesWithJiraTicketLatestStatus(): void {
    this.request.getLatestJiraStatusForHelpdeskIssues().subscribe((data: any) => {
      if (data && data.jiraTicketNumber)
        this.notify.showSuccess('All issues statuses updated.');
        this.applyFilter();
    });
  }
}
