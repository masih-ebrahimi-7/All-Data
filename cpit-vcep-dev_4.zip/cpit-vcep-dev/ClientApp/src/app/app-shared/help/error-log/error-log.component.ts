import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from '../../../services/auth/permissions.service';
import { UserProfileService } from '../../../services/auth/user-profile.service';

@Component({
  selector: 'app-error-log',
  templateUrl: './error-log.component.html',
  styleUrls: ['./error-log.component.css'],
})
export class ErrorLogComponent implements OnInit {
  displayedColumns = ['date', 'message', 'stack'];

  dataSource: MatTableDataSource<Object>;
  pageEvent: PageEvent;
  path: string;
  permissions: any | null;
  queryParams: any;
  filter: any;
  statusList: string[] = [];
  totalSize: number;
  panelOpenState = false;
  filterFormInput: any = {
    statuses: new UntypedFormControl(),
  };
  displayingAll = true;
  userInfo: any;
  public selected: any;
  public users: any = [];
  selection = new SelectionModel<Object>(true, []);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    permissionService: PermissionsService,
    private userProfileService: UserProfileService
  ) {
    this.queryParams = this.getQueryParams();

    this.filter = new UntypedFormGroup({
      statuses: new UntypedFormControl(this.queryParams.statuses),
    });

    this.path = this.activatedRoute.snapshot.url[0].path;
    this.permissions = permissionService.get();
    this.userInfo = this.userProfileService.get();
  }

  ngOnInit(): void {
    this.applyFilter();
  }

  setDataSource(
    pageIndex: number,
    pageSize: number,
    orderBy: string = 'date',
    ascending: boolean = false,
    filters: any = null
  ) {
    filters = filters ? filters : this.getQueryParams();
    this.request.getErrorLogs(pageIndex, pageSize).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.dataSource = new MatTableDataSource(data.records);
      this.dataSource.sort = this.sort;
      this.dataSource.sortData = (data: Object[], sort: MatSort) => {
        const active = sort.active;
        const direction = sort.direction;
        this.setDataSource(this.paginator.pageIndex + 1, this.paginator.pageSize, active, direction === 'asc');
        return data.sort((a: any, b: any) => {
          return 0;
        });
      };
    });
  }

  clearForm() {
    this.filter.reset();
  }

  applyFilter() {
    this.router.navigate(['/error-log'], { queryParams: this.filter.value });
    this.setDataSource(1, 10, '', true, this.filter.value);
    this.selection.clear();
    if (this.paginator) {
      this.paginator.pageSize = 10;
      this.paginator.pageIndex = 0;
    }
  }

  onPaginateChange(e: any) {
    this.setDataSource(e.pageIndex + 1, e.pageSize, '', true, this.filter.value);
    this.selection.clear();
  }

  public sortData(): void {
    switch (this.sort.direction) {
      case 'asc':
        this.sort.direction = 'asc';
        break;
      case 'desc':
        this.sort.direction = 'desc';
        break;
      default:
        this.sort.direction = 'asc';
    }
  }

  getQueryParams() {
    const queryParamMap = this.activatedRoute.snapshot.queryParamMap;
    return {
      statuses: queryParamMap.getAll('statuses')?.length === 0 ? null : queryParamMap.getAll('statuses'),
    };
  }

  openDetail(id: any) {
    //TODO Error detail page component
  }
}
