import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { DateTimeFormatPipe } from 'src/app/common/pipes/datetime-format.pipe';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from '../../services/auth/permissions.service';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action } from 'src/app/common/table/Action';

@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.scss'],
})
export class TasksListComponent {
  totalSize: number;
  data: any;
  config: any;
  permissions: any | null;
  path: string;
  bulkActions: any;

  displayedColumns: Column[] = [];

  filters: AppInput[] = [
    new AppInput('Query', 'query'),
    new AppInput('Statuses', 'statuses', InputType.Multiselect, {
      source: () => this.request.getEnumValues('TaskStatus'),
    }),
    new AppInput('Deadline', 'deadlineStartDate', InputType.DateRange, {
      toInputName: 'deadlineEndDate',
    }),
    new AppInput('Description', 'description'),
  ];

  constructor(
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    permissionService: PermissionsService,
  ) {
    this.permissions = permissionService.get();
    this.displayedColumns = this.getColumns();
    this.path = this.activatedRoute.snapshot.url[0].path;
    this.bulkActions = this.getBulkActions();
  }

  getBulkActions() {
    var actions: Action[] = [];
    return actions;
  }

  setDataSource(config: any) {
    this.config = config?.filter ?? {};

    if (this.path == 'my-tasks') {
      this.request.getMyTasks(this.config || {}).subscribe((data: any) => {
        this.totalSize = data.totalCount;
        this.data = data.records;
      });
    } else {
      this.request.getMyCreatedTasks(this.config || {}).subscribe((data: any) => {
        this.totalSize = data.totalCount;
        this.data = data.records;
      });
    }
  }

  getColumns(): Column[] {
    return [
      new Column('Id', 'id', {
        type: ColumnType.Link,
        value: (e: any) => {
          return new Link('Task details', `task/${e.id}`);
        },
      }),
      new Column('Claim', 'entityId', {
        type: ColumnType.Link,
        value: (e: any) => {
          return new Link(
            e.claim?.reference ?? e.entityId,
            !this.permissions?.CanAccessAsDonor &&
              !this.permissions?.CanAccessAsClaimant &&
              !this.permissions?.CanAccessAsMinistry
              ? `claims/${e.entityId}`
              : `submission-details/${e.entityId}`
          );
        },
      }),
      new Column('Status', 'taskStatus', {
        type: ColumnType.Html,
        size: 'md',
        value: (e: any) => {
          let chipClass: string = '';
          switch (e.taskStatusString) {
            case 'New':
              chipClass = 'noFile';
              break;
            case 'InProgress':
              chipClass = 'pending';
              break;
            case 'ForReview':
              chipClass = 'for-review';
              break;
            case 'Done':
              chipClass = 'done';
              break;
          }
          return `<span class='task-status chip-${chipClass} '>${e.taskStatusString}</span>`;
        },
      }),
      new Column('Task', 'shortText', { size: 'xl', disableSorting: true, type: ColumnType.Html }),
      new Column('Last Updated', 'daysSinceLastModified', {
        disableSorting: true,
        type: ColumnType.Text,
        value: (r: any) => `${r.daysSinceLastModified} days, ${r.hoursSinceLastModified} hours`,
      }),
      new Column('Created Date', 'createdDate', {
        type: ColumnType.Text,
        value: (e: any) => {
          let s: string = new DateTimeFormatPipe().transform(e.createdDate) as string;
          return s;
        },
      }),
      new Column('Created By', 'createdBy',
        {
          hidden: this.permissions?.CanAccessAsDonor || this.permissions?.CanAccessAsClaimant || this.permissions?.CanAccessAsMinistry,
        }
      ),
      new Column('Last Modified', 'lastModifiedDate', {
        type: ColumnType.Text,
        value: (e: any) => {
          let s: string = new DateTimeFormatPipe().transform(e.lastModifiedDate) as string;
          return s;
        },
      }),
      new Column('Last Modified By', 'lastModifiedBy', {
        hidden: this.permissions?.CanAccessAsDonor || this.permissions?.CanAccessAsClaimant || this.permissions?.CanAccessAsMinistry,
      }),
      new Column('Deadline', 'deadline', {
        type: ColumnType.Html,
        size: 'md',
        value: (e: any) => {
          var dateString = e.deadline ? new DatePipe('en-gb').transform(e.deadline) : '';
          var days = e.deadline ? Math.round(e.daysUntilDeadline) : null;
          var cssClass = days && days < 0 && e.taskStatusString != 'Done' ? 'chip-rejected' : '';
          var htmlString = `<span class="${cssClass}">${dateString}<span>`;
          if (days && e.taskStatusString != 'Done') htmlString += `<br/><small>(${days} days)<small></span>`;
          return htmlString;
        },
      }),
    ];
  }
}