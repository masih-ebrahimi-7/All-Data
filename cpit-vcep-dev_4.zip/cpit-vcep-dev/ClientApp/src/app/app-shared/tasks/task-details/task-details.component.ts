import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AddRemarkDialogComponent } from 'src/app/common/dialogs/add-remark-dialog/add-remark-dialog.component';
import { UserDialogComponent } from 'src/app/common/dialogs/user-dialog/user-dialog.component';
import { RemarkType, TaskUserType } from 'src/app/models/enums/server-enums';
import { Column } from 'src/app/common/table/Column';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from '../../../services/auth/permissions.service';
import { UserProfileService } from '../../../services/auth/user-profile.service';
import { NotificationService } from '../../../services/notification.service';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { getRandomAvatarUrl } from 'src/app/common/helpers';

@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss'],
})
export class TaskDetailsComponent implements OnInit {
  public editorConfig = { ...EditorConfig };
  displayedColumns = [
    new Column('Created Date', 'createdDate'),
    new Column('Created By', 'createdBy'),
    new Column('Status', 'status'),
    new Column('Task', 'shortText', { size: 'xl' }),
  ];
  totalSize: number;
  data: any;
  loading: boolean = false;
  taskId: number;
  task: any;
  taskStatuses: any;
  filterValue: string;
  statuses: any;
  canReassign: boolean = false;
  canChangeStatus: boolean = false;
  userInfo: any;
  permissions: any | null;
  entityDetailsLink: any;

  Math: any = Math;
  constructor(
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private notify: NotificationService,
    permissionService: PermissionsService,
    private userProfileService: UserProfileService
  ) {
    this.userInfo = this.userProfileService.get();
    this.permissions = permissionService.get();
    this.editorConfig.editable = false;
    this.editorConfig.showToolbar = false;
    this.editorConfig.height = 'auto';
  }

  ngOnInit(): void {
    this.loading = true;
    this.taskId = this.activatedRoute.snapshot.params['id'];
    this.statuses = this.request.getEnumValues('TaskStatus');
    this.loadTask();
    this.loadStatuses();
  }

  loadTask(): void {
    this.request.getTask(this.taskId).subscribe((data: any) => {
      this.totalSize = data.totalCount;
      this.task = data;
      this.task.replies.forEach((reply: any) => {
        reply.avatar = getRandomAvatarUrl();
      })
      this.task.avatar = getRandomAvatarUrl();
      this.canReassign = (this.task.createdBy == this.userInfo.email || this.task.assignedTo == this.userInfo.email) && !this.permissions?.CanAccessAsDonor && this.permissions?.CanAccessAsMinistry;
      this.canChangeStatus =
        this.task.assignedTo == this.userInfo.email ||  this.task.createdBy == this.userInfo.email || (this.task.taskUserType == 3 && this.permissions?.CanAccessAsDonor);
      
      this.entityDetailsLink = (!this.permissions?.CanAccessAsDonor && 
        !this.permissions?.CanAccessAsClaimant && 
          !this.permissions?.CanAccessAsMinistry) 
          ? `claims/${this.task.entityId}` 
          : `submission-details/${this.task.entityId}`;
    });
  }

  loadStatuses() {
    this.request.getEnumValues('TaskStatus').subscribe((data: any) => {
      this.taskStatuses = data;
    });
  }

  onStatusClicked(statusEnum: any) {
    this.updateStatus(parseInt(statusEnum.value, 10));
  }

  updateStatus(newStatus: number) {
    this.request.updateTaskStatus(this.taskId, newStatus).subscribe((data) => {
      this.notify.showSuccess('Status changed successfully.');
      this.loadTask();
    });
  }

  openAddRemarkDialog(remarkId: number = this.taskId) {
    this.dialog
      .open(AddRemarkDialogComponent, {
        width: '60em',
        data: { taskUserType: this.task.taskUserType, parentRemarkId: remarkId, isExternalCommunication: this.task.isExternal, claimId: this.task.entityId },
      })
      .afterClosed()
      .subscribe(({ remarkText, usersTagged, isTask, assignedTo }) => {
        this.request
          .addRemark(
            RemarkType.Claim,
            this.task.entityId,
            remarkText.value,
            usersTagged ?? [],
            isTask,
            assignedTo,
            this.task.taskUserType,
            this.task.isExternal,
            new Date(), // deadline (should be ignored),
            remarkId
          )
          .subscribe((a) => {
            this.notify.showSuccess('Remark added successfully.');
            this.loadTask();
          });
      });
  }

  openAssignUserDialog() {
    this.request.getTaskAssignableUsers(TaskUserType.Internal).subscribe((users: any) => {
      this.dialog
        .open(UserDialogComponent, {
          width: '25em',
          data: { users: users },
        })
        .afterClosed()
        .subscribe((assignedUser: any) => {
          this.assignUser(assignedUser.value);
        });
    });
  }

  assignUser(assignedTo: string) {
    this.request.reassignTask(this.taskId, assignedTo).subscribe((data) => {
      this.loadTask();
      return this.notify.showSuccess('Task reassigned successfully');
    });
  }

  getStatusChipClass(status: string): string {
    let pendingStatuses = ['New', 'ForReview'];
    if (pendingStatuses.includes(status))
      return 'chip-pending';
    if (status == 'Done')
      return 'chip-done';
    return 'chip-in-progress'
  }
}
