import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import AOS from 'aos';
import 'boxicons';
import { NgcCookieConsentService, NgcStatusChangeEvent } from 'ngx-cookieconsent';
import { Subscription } from 'rxjs';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { environment as env } from '../../../environments/environment';

import { Router } from '@angular/router';
import { AuthService } from '@auth0/auth0-angular';
import { RequestService } from 'src/app/services/request.service';
import { UserProfileService } from '../../services/auth/user-profile.service';
import { ErrorDialogComponent } from '../error-page/error-dialog/error-dialog.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  isLoggedIn: boolean;
  loading: boolean;
  clientId: any;
  permissions: any | null;

  // cookies policy subscriptions
  private initializedSubscription: Subscription;
  private statusChangeSubscription: Subscription;
  private revokeChoiceSubscription!: Subscription;
  private popupOpenSubscription: Subscription;

  constructor(
    private tokenService: TokenService,
    private cd: ChangeDetectorRef,
    private service: RequestService,
    private permissionsService: PermissionsService,
    private userProfileService: UserProfileService,
    private translateService: TranslateService,
    public authService: AuthService,
    private cookieService: NgcCookieConsentService,
    private router: Router,
    public dialog: MatDialog,
    @Inject('APP_CONFIG') config: any
  ) {
    this.isLoggedIn = this.tokenService.loggedIn();
    this.clientId = config.clientId;

    if (config.environment === 'Development') {
      localStorage.setItem('isCookieAccepted', 'true');
    }
    this.initializeCookieContent();
    this.permissions = permissionsService.get();
  }

  ngOnInit(): void {
    AOS.init();
    this.handleCookieSubscriptions();
    this.authService.isAuthenticated$.subscribe((loggedIn: boolean) => {
      if (loggedIn && !this.tokenService.isValid()) {
        this.handleCredentialResponse();
      }
    });
  }

  ngOnDestroy(): void {
    this.initializedSubscription?.unsubscribe();
    this.statusChangeSubscription?.unsubscribe();
    this.revokeChoiceSubscription?.unsubscribe();
    this.popupOpenSubscription?.unsubscribe();
  }

  loginWithRedirect() {
    this.authService.loginWithRedirect();
  }

  handleCredentialResponse() {
    var toPost: ExternalAuthDto = {
      provider: 'Auth0',
      audience: env.authority,
    };
    this.validateExternalAuth(toPost);
    this.isLoggedIn = this.tokenService.loggedIn();
  }

  validateExternalAuth(externalAuth: ExternalAuthDto) {
    this.service.login(externalAuth).subscribe(
      (res: any) => {
        if (res != null && res.token != null) {
          this.tokenService.set(res.token);
          this.permissionsService.set(res.permissions);
          this.permissions = res.permissions;
          this.userProfileService.set(res.email, res.photoUrl, res.externalUserName, res.institutionName);
          window.location.href = '/';
          this.loading = false;
        } else {
          this.showErrorPopUp('The user has been registered successfully, please contact system administrator to activate your account.');
        }
      },
      (error: any) => {
        this.loading = false;
        this.showErrorPopUp(error.error.Message);
      }
    );
  }

  public signOut(): void {
    this.tokenService.clear();
    this.authService.logout();
  }

  raiseClaim() {
    this.router.navigate([`/claims/create`]);
  }

  manageClaims(outputType: string) {
    this.router.navigate([`list-${outputType}-claims`]);
  }

  initializeCookieContent() {
    const lang = localStorage.getItem('lang') || 'en';
    this.translateService.getTranslation(lang).subscribe((data) => {
      this.cookieService.getConfig().content = {
        ...this.cookieService.getConfig().content,
        deny: '',
        allow: 'Accept',
        message: data.policy?.consentMessage,
        href: 'https://unops.org/privacy',
        link: data.policy.consenteDetailLink,
      };
      this.cookieService.destroy();
      this.cookieService.init(this.cookieService.getConfig());
    });
  }

  showErrorPopUp(message: string): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message },
    }).afterClosed().subscribe((result: any) => {
      this.signOut();
    });
  }

  handleCookieSubscriptions() {
    this.popupOpenSubscription = this.cookieService.popupOpen$.subscribe(
      () => {});

    this.statusChangeSubscription = this.cookieService.statusChange$.subscribe(
      (event: NgcStatusChangeEvent) => {
        let isCookieAccepted = event.status === 'allow';
        localStorage.setItem('isCookieAccepted', `${isCookieAccepted}`);
      }
    );

    this.initializedSubscription = this.cookieService.initialized$.subscribe(
      () => {});

    this.revokeChoiceSubscription = this.cookieService.revokeChoice$.subscribe(
      () => {
        localStorage.removeItem('isCookieAccepted')
      });
  }
}
export interface ExternalAuthDto {
  provider: string;
  audience: string;
}
