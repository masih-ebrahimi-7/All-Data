import { AfterContentInit, Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { UserDialogComponent } from 'src/app/common/dialogs/user-dialog/user-dialog.component';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';
import { RelatedEntitiesModalComponent } from './related-entities-modal/related-entities-modal.component';
import { ExternalEntity } from 'src/app/common/interfaces';
import { IClaim, IClaimEditDetailsModel, IClaimEditModel } from 'src/app/models/claim.model';
import { Contract } from 'src/app/models/contract.model';
import { ISubClaim, ISubClaimSummary, EligibilityStatus } from 'src/app/models/subclaim.model';
import { BehaviorSubject } from 'rxjs';
import { UserAssignmentType } from 'src/app/models/enums/server-enums';
import { FullNoteDialogComponent } from './full-note-dialog/full-note-dialog.component';

@Component({
  selector: 'app-claim-details',
  templateUrl: './claim-details.component.html',
  styleUrls: ['./claim-details.component.css'],
})
export class ClaimDetailsComponent implements OnInit, AfterContentInit {
  loading: boolean = true;
  timelineLoading: boolean = true;
  tabLoadTimes: Date[] = [];
  currentClaimId: number;
  permissions: any | null;
  claim: IClaim;
  contractDetails?: Contract;
  externalEntityDetails?: ExternalEntity;
  panelOpenState = false;
  contractPanelOpenState = true;
  claimDocsTotal: number;
  priorities: TypeaheadInput[] = [];
  claimTypes: TypeaheadInput[] = [];
  sources: TypeaheadInput[] = [];
  fundSources: TypeaheadInput[] = [];
  currencies: TypeaheadInput[] = [];
  documentCategories: any[] = [];
  selectedDocuments: any;
  documentsCategoryCount: any = {};
  showFullNote = false;

  // SubClaims data for warning validation
  subClaims: ISubClaim[] = [];
  subClaimSummary: ISubClaimSummary | null = null;

  contractingAuthorities$ = new BehaviorSubject([]);
  contractingAuthorities = this.contractingAuthorities$.asObservable();

  constructor(
    private activatedRouter: ActivatedRoute,
    private router: Router,
    private request: RequestService,
    private fb: UntypedFormBuilder,
    private notify: NotificationService,
    public dialog: MatDialog,
    permissionService: PermissionsService,
    private typeaheadService: TypeaheadService,
  ) {
    this.permissions = permissionService.get();
  }

  ngAfterContentInit(): void {
    this.loading = false;
  }

  ngOnInit(): void {
    this.currentClaimId = this.activatedRouter.snapshot.params['claimId'];
    this.getPrioritiesForFilter();
    this.getClaimTypesForFilter();
    this.getSourcesForFilter();
    this.getFundSourcesForFilter();
    this.getCurrenciesForFilter();
    this.getContractingAuthoritiesForFilter();
    this.loadDocumentCategories();
    this.setDocDataSource();

    this.getClaimDetails().subscribe((data) => {
      this.claim = data as IClaim;
      if (this.claim.contract && this.claim.contract.externalEntityId)
        this.getExternalEntityDetails(this.claim.contract.externalEntityId);
      
      if (this.claim.contractId) {
        this.request.getContract(this.claim.contractId).subscribe((contractData) => {
          this.contractDetails = contractData as Contract;
        });
      }

      this.loadSubClaimsForWarning();
    });
  }

  openAssignUserDialog() {
    this.request.getClaimReviewers().subscribe((users: any) => {
      this.dialog
        .open(UserDialogComponent, {
          width: '25em',
          data: { users: users },
        })
        .afterClosed()
        .subscribe((result: any) => {
          if (!result.assignedUser || !result.assignedUser.value) {
            return this.notify.showError('Please select a user.');
          }
          if (!result.userAssignmentType || !result.userAssignmentType.value) {
            return this.notify.showError('Please select a user type.');
          }
          this.assignUsersToClaims([this.currentClaimId], result.assignedUser.value, result.userAssignmentType.value);
        });
    });
  }

  assignUsersToClaims(ids: number[], email: string, assignmentType: UserAssignmentType) {
    this.request.assignUsersToClaims({ ids: ids, email: email, userAssignmentType: assignmentType }).subscribe((data) => {
      if (assignmentType == UserAssignmentType.SectorLead) {
        this.claim.assignedToSectorLead = email;
      }
      else if (assignmentType == UserAssignmentType.Finance) {
        this.claim.assignedToFinance = email;
      }
      else if (assignmentType == UserAssignmentType.Legal) {
        this.claim.assignedToLegal = email;
      }
      else if (assignmentType == UserAssignmentType.CMS) {
        this.claim.assignedToCMS = email;
      }

      if (this.claim.claimStatus !== 1) {
        return this.notify.showSuccess('User successfully assigned to claim.');
      }
      else {
        window.location.reload();
      }
    });
  }

  openEditRelatedEntitiesModal() {
    this.dialog
      .open(RelatedEntitiesModalComponent, {
        width: '60em',
        data: { claim: this.claim },
      })
      .afterClosed()
      .subscribe((editClaimRequest: any) => {
        if (editClaimRequest) {
          this.request.editClaim(editClaimRequest).subscribe((data: any) => {
            this.claim = data;
            this.getExternalEntityDetails(data.contract.externalEntityId);
            
            // Reload contract details with grants
            if (data.contractId) {
              this.request.getContract(data.contractId).subscribe((contractData) => {
                this.contractDetails = contractData as Contract;
              });
            }
            
            this.notify.showSuccess(`Claim details updated successfully.`);
          });
        }
      });
  }

  getClaimDetails() {
    return this.request.getClaim(this.currentClaimId);
  }

  onStageChanged() {
    this.getClaimDetails().subscribe((data) => {
      this.claim = data as IClaim;
      if (this.claim.contract && this.claim.contract.externalEntityId)
        this.getExternalEntityDetails(this.claim.contract.externalEntityId);
    });
  }

  getExternalEntityDetails(id: number) {
    this.request.getExternalEntity(id).subscribe((data: any) => {
      this.externalEntityDetails = data;
    });
  }

  openContractorDetails() {
    let path = `list-external-entities?name=${this.externalEntityDetails?.name?.toString()}`;
    window.open(path, '_blank');
  }

  setDocDataSource(categoryId?: number, onlyNew?: boolean) {
    let filter = { claimId: this.currentClaimId, categoryId: categoryId, onlyNew: onlyNew };
    
    this.request.getClaimDocuments(filter).subscribe((data: any) => {
      if (categoryId)
        this.documentsCategoryCount[categoryId] = data.totalCount;
      else
        this.claimDocsTotal = data.totalCount;
    });
  }

  claimEdited(event: any) {
    if (event) {
      this.claim = event;
    }
  }

  timelineLoadEvent(event: boolean) {
    this.timelineLoading = event;
  }

  onRemarksChanges() {
    this.getClaimDetails().subscribe((data) => {
      this.claim = data as IClaim;
    });
  }

  getPrioritiesForFilter() {
    this.request.getEnumValues('PriorityType').subscribe((data: any) => {
      this.priorities = data;
    });
  }

  getClaimTypesForFilter() {
    this.request.getEnumValues('ContractType').subscribe((data: any) => {
      this.claimTypes = data;
    });
  }

  getSourcesForFilter() {
    this.request.getEnumValues('ClaimSource').subscribe((data: any) => {
      this.sources = data;
    });
  }

  getFundSourcesForFilter() {
    this.request.getEnumValues('FundSourceType').subscribe((data: any) => {
      this.fundSources = data;
    });
  }

  getCurrenciesForFilter() {
    return this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  openClaimDetailsModal(): void {
    const data = {
      pageTitle: 'Edit Claim Details',
      fields: [
        {
          name: 'title',
          label: 'Claim Title',
          type: 'text',
          value: this.claim.title ?? '',
          required: true,
        },
        {
          name: 'internalReferenceCode',
          label: 'Internal Reference Code',
          type: 'text',
          value: this.claim.internalReferenceCode ?? '',
          required: false,
        },
        {
          name: 'description',
          label: 'Claim description',
          type: 'text',
          value: this.claim.description ?? '',
          required: true,
        },
        {
          name: 'claimantPhoneNumber',
          label: 'Claimant Phone Number',
          type: 'text',
          value: this.claim.claimantPhoneNumber ?? '',
          required: false,
        },
        {
          name: 'claimForDates',
          label: 'Claim For Dates',
          type: 'date-range',
          startLabel: 'Claim Contract start date',
          endLabel: 'Claim Contract end date',
          value: {
            start: this.claim.claimForStartDate,
            end: this.claim.claimForEndDate,
          },
        },
        {
          name: 'claimType',
          label: 'Contract Type',
          type: 'select',
          value: this.claim.type?.toString(),
          required: false,
          options: this.claimTypes,
        },
        {
          name: 'priority',
          label: 'Priority',
          type: 'select',
          value: this.claim.priority?.toString(),
          required: false,
          options: this.priorities,
        },
        {
          name: 'source',
          label: 'Claim Source',
          type: 'select',
          value: this.claim.source?.toString(),
          required: false,
          options: this.sources,
        },
        {
          name: 'fundSource',
          label: 'Fund Source',
          type: 'select',
          value: this.claim.fundSource?.toString(),
          required: false,
          options: this.fundSources,
        },
        {
          name: 'contractingAuthorities',
          label: 'Contracting Authorities',
          type: 'select-async',
          value: this.claim?.claimContractingAuthorityTypes?.map(a => a.toString()),
          allowMultiple: true,
          required: true,
          options: this.contractingAuthorities$,
        },
        {
          name: 'province',
          label: 'Province',
          type: 'text',
          value: this.claim.province ?? '',
          required: false,
        },
        {
          name: 'district',
          label: 'District',
          type: 'text',
          value: this.claim.district ?? '',
          required: false,
        },
        {
          name: 'note',
          label: 'Claim Remark',
          type: 'editor',
          value: this.claim.note ?? '',
          required: false,
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let claimEditRequest: IClaimEditDetailsModel = {
          id: this.currentClaimId,
          priority: result.priority ?? null,
          type: result.claimType ?? null,
          title: result.title ?? null,
          internalReferenceCode: result.internalReferenceCode ?? null,
          note: result.note ?? null,
          description: result.description ?? null,
          source: result.source ?? null,
          fundSource: result.fundSource ?? null,
          claimForStartDate: result.claimForDates.start ?? null,
          claimForEndDate: result.claimForDates.end ?? null,
          contractingAuthorities: result.contractingAuthorities ?? null,
          claimantPhoneNumber: result.claimantPhoneNumber ?? null,
          province: result.province ?? null,
          district: result.district ?? null,
        };

        this.request.editClaim(claimEditRequest).subscribe((data: any) => {
          this.claim = data;
          this.notify.showSuccess(`Claim details updated successfully.`);
        });
      }
    });
  }

  openEditAmountModal(): void {
    const data = {
      pageTitle: 'Edit Claim Amounts',
      fields: [
        {
          name: 'currencyId',
          label: 'Select Claim Currency',
          type: 'select',
          value: this.claim?.currencyId?.toString(),
          required: true,
          options: this.currencies,
          hint: "If the currency is not USD, then the USD amount will be calculated with the rates available in the Currency Conversion page."
        },
        {
          name: 'claimedAmount',
          label: 'Claimed Amount',
          type: 'number',
          value: this.claim.claimedAmount ?? '',
          required: true,
        },
        {
          name: 'verifiedAmount',
          label: 'Verified Amount',
          type: 'number',
          value: this.claim.verifiedAmount ?? '',
          required: false,
        },
        {
          name: 'officialEstimatedAmount',
          label: 'Official Estimated Amount',
          type: 'number',
          value: this.claim.officialEstimatedAmount ?? '',
          required: false,
        },
        {
          name: 'ineligibleEstimatedAmount',
          label: 'Ineligible Estimated Amount',
          type: 'number',
          value: this.claim.ineligibleEstimatedAmount ?? '',
          required: false,
        },
        {
          name: 'verifiedAmountToBeReclaimed',
          label: 'Verified Amount to be Reclaimed (Final report accepted by ADB)',
          type: 'number',
          value: this.claim.verifiedAmountToBeReclaimed ?? '',
          required: false,
        },
        {
          name: 'estimatedAmountToBeReclaimed',
          label: 'Estimated Amount to be Reclaimed (Preliminary report issued)',
          type: 'number',
          value: this.claim.estimatedAmountToBeReclaimed ?? '',
          required: false,
        },
        {
          name: 'cdcContribution',
          label: "CDC's Contribution",
          type: 'number',
          value: this.claim.cdcContribution ?? '',
          required: false,
        },
        {
          name: 'adbContribution',
          label: "ADB's Contribution",
          type: 'number',
          value: this.claim.adbContribution ?? '',
          required: false,
        },
        {
          name: 'disbursedAmount',
          label: 'Disbursed Amount',
          type: 'number',
          value: this.claim.disbursedAmount ?? '',
          required: false,
        },
        {
          name: 'spentAmount',
          label: 'Spent Amount',
          type: 'number',
          value: this.claim.spentAmount ?? '',
          required: false,
        },
        {
          name: 'bankAccountNo',
          label: 'Bank Account No',
          type: 'text',
          value: this.claim.bankAccountNo ?? '',
          required: false,
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        let claimEditRequest: IClaimEditModel = {
          id: this.currentClaimId,
          sector: this.claim?.sector,
          currencyId: result.currencyId ?? null,
          claimedAmount: result.claimedAmount ?? null,
          verifiedAmount: result.verifiedAmount ?? null,
          officialEstimatedAmount: result.officialEstimatedAmount ?? null,
          ineligibleEstimatedAmount: result.ineligibleEstimatedAmount ?? null,
          verifiedAmountToBeReclaimed: result.verifiedAmountToBeReclaimed ?? null,
          estimatedAmountToBeReclaimed: result.estimatedAmountToBeReclaimed ?? null,
          cdcContribution: result.cdcContribution ?? null,
          adbContribution: result.adbContribution ?? null,
          disbursedAmount: result.disbursedAmount ?? null,
          spentAmount: result.spentAmount ?? null,
          bankAccountNo: result.bankAccountNo ?? null,
        };

        if (this.permissions.CanEditClaimAmounts) {
          this.request.editClaimAmounts(claimEditRequest).subscribe((data: any) => {
            this.claim = data;
            this.notify.showSuccess(`Claim amounts updated successfully.`);
          });
        } else {
          this.notify.showError(`User does not have permissions to update claim amounts.`);
        }
      }
    });
  }

  loadDocumentCategories() {
    this.request.getDocumentCategories(1, 9999, '').subscribe((data: any) => {
      this.documentCategories = data.records;
      this.documentCategories.unshift({ id: -2, onlyNew: true, name: 'New Uploads', description: "Documents uploaded during the past 3 days." });
      this.documentCategories.unshift({ name: 'All Uploads', description: "All documents." });
      this.documentCategories.push({ id: -1, name: 'Uncategorized', description: "Documents which were uploaded with no category attached." });
      this.documentCategories.forEach((category: any) => {
        this.setDocDataSource(category.id, category.onlyNew);
      });
    });
  }

  handleChangeOnDocuments(count: number, categoryId: number) {
    this.documentsCategoryCount[categoryId] = count;
    this.setDocDataSource();
  }

  handleChangeOnCategory(categoryId: number) {
    this.setDocDataSource(categoryId);
  }

  getContractingAuthoritiesForFilter() {
    return this.request.getEnumValues('ContractingAuthorityType').subscribe((data: any) => {
      this.contractingAuthorities$.next(data);
    });
  }

  truncatedNote() {
    if (!this.claim || !this.claim.note) {
      return '';
    }
    
    const maxLength = 300;
    return this.claim.note.length > maxLength ? 
      this.claim.note.substring(0, maxLength) + '...' : 
      this.claim.note;
  }
  
  isNoteTruncated() {
    return this.claim && this.claim.note && this.claim.note.length > 300;
  }
  
  toggleNoteDisplay() {
    this.showFullNote = !this.showFullNote;
  }
  
  openFullNoteDialog() {
    this.dialog.open(FullNoteDialogComponent, {
      width: '80%',
      maxWidth: '1000px',
      data: { 
        note: this.claim.note,
        claimId: this.claim.id,
        canEdit: this.permissions.CanEditClaimDetails
      }
    });
  }

  onFraudAlertToggle(event: any) {
    if (event.checked) {
      const data = {
        pageTitle: 'Red Flag Alert',
        fields: [
          {
            name: 'reason',
            label: 'Please provide a reason for red-flagging this claim',
            type: 'textarea',
            value: this.claim.fraudulentReason || '',
            required: true,
          }
        ],
      };

      const dialogRef = this.dialog.open(UpdateDialogComponent, {
        width: '30rem',
        data: data,
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          this.request.toggleClaimFraudAlert(this.currentClaimId, result.reason).subscribe((data: any) => {
            this.getClaimDetails().subscribe((updatedClaim) => {
              this.claim = updatedClaim as IClaim;
              this.notify.showSuccess('Red flag alert added successfully.');
            });
          });
        } else {
          this.claim.fraudulent = false;
        }
      });
    } else {
      this.request.toggleClaimFraudAlert(this.currentClaimId).subscribe((data: any) => {
        this.getClaimDetails().subscribe((updatedClaim) => {
          this.claim = updatedClaim as IClaim;
          this.notify.showSuccess('Red flag alert removed successfully.');
        });
      });
    }
  }

  /**
   * Load subclaims immediately for warning and counter display
   */
  private loadSubClaimsForWarning(): void {
    if (!this.currentClaimId) return;
    
    this.request.getSubClaimsByClaimId(this.currentClaimId).subscribe({
      next: (data: any) => {
        this.subClaims = data as ISubClaim[];
        if (this.claim) {
          this.claim.subClaimCount = this.subClaims.length;
        }
      },
      error: (error) => {
        console.error('Failed to load subclaims for warning:', error);
      }
    });
  }

  /**
   * Handle subclaims data loaded from child component
   */
  onSubClaimsLoaded(subClaims: ISubClaim[]): void {
    this.subClaims = subClaims;
    // Update the subclaim count for the tab badge
    if (this.claim) {
      this.claim.subClaimCount = subClaims.length;
    }
  }

  onSubClaimSummaryLoaded(summary: ISubClaimSummary | null): void {
    this.subClaimSummary = summary;
  }

  getEligibleSubClaimsAmount(): number {
    if (!this.subClaims || this.subClaims.length === 0) {
      return 0;
    }

    return this.subClaims
      .filter(sc => sc.eligibilityStatus === EligibilityStatus.Eligible)
      .reduce((sum, sc) => sum + (sc.claimAmount || 0), 0);
  }

  shouldShowAmountMismatchWarning(): boolean {
    if (!this.claim || !this.subClaims || this.subClaims.length === 0) {
      return false;
    }
    const eligibleSubClaimsAmount = this.getEligibleSubClaimsAmount();
    
    if (eligibleSubClaimsAmount === 0) {
      return false;
    }

    const verifiedAmount = this.claim.verifiedAmount || 0;
    const claimedAmount = this.claim.claimedAmount || 0;
    const tolerance = 0.01;
    const verifiedMatch = Math.abs(eligibleSubClaimsAmount - verifiedAmount) <= tolerance;
    const claimedMatch = Math.abs(eligibleSubClaimsAmount - claimedAmount) <= tolerance;
    return !verifiedMatch && !claimedMatch;
  }

  getAmountMismatchTooltip(): string {
    if (!this.claim) return '';
    
    const eligibleSubClaimsAmount = this.getEligibleSubClaimsAmount();
    const verifiedAmount = this.claim.verifiedAmount || 0;
    const claimedAmount = this.claim.claimedAmount || 0;
    const currencyCode = this.claim.claimCurrencyCode || '';

    return `Amount Review Needed\n\nEligible subclaims total: ${eligibleSubClaimsAmount.toLocaleString()} ${currencyCode}\nClaim amounts:\n• Verified: ${verifiedAmount.toLocaleString()} ${currencyCode}\n• Claimed: ${claimedAmount.toLocaleString()} ${currencyCode}\n\nConsider reviewing these amounts for consistency.`;
  }
}
