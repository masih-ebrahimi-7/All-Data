import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-full-note-dialog',
  templateUrl: './full-note-dialog.component.html',
  styleUrls: ['./full-note-dialog.component.css']
})
export class FullNoteDialogComponent {
  
  constructor(
    public dialogRef: MatDialogRef<FullNoteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  
  get permissions() {
    return {
      CanEditClaimDetails: this.data.canEdit
    };
  }
}