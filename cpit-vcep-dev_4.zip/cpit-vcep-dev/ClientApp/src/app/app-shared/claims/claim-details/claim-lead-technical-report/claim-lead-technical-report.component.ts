import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { Observable } from 'rxjs';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-claim-lead-technical-report',
  templateUrl: './claim-lead-technical-report.component.html',
  styleUrls: ['./claim-lead-technical-report.component.css']
})
export class ClaimLeadTechnicalReportComponent implements OnInit, AfterViewInit {
  @Input() claim: any;
  @Input() opened: void;
  @Input() closed: void;
  @Input() panelOpenState: boolean;
  permissions: any;
  technicalActions: any;
  newStatus: any;

  status: UntypedFormControl = new UntypedFormControl();
  statuses: UntypedFormControl = new UntypedFormControl();
  filteredTechnicalStatuses: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  public editorConfig = { ...EditorConfig };

  constructor(private request: RequestService,
    private notify: NotificationService,
    private permissionService: PermissionsService,
    private typeaheadService: TypeaheadService,
    public dialog: MatDialog) {
    this.permissions = this.permissionService.get();
  }

  ngAfterViewInit(): void {
    this.setupEditor();
  }

  setupEditor(): void {
    this.editorConfig.editable = (this.permissions.CanEditClaimReport && this.technicalActions?.length > 0) ?? false;
    this.editorConfig.showToolbar = (this.permissions.CanEditClaimReport && this.technicalActions?.length > 0) ?? false;
    this.editorConfig.height = 'auto';
    this.editorConfig.minHeight = '400px';
  }

  getTechnicalReportStatuses() {
    this.request.getTechnicalReportStatuses(this.claim.id).subscribe((claimActionsResponse: any) => {
      this.technicalActions = Array.from(claimActionsResponse as any).map((action: any) => {
        return {
          value: action.value,
          label: action.description
        };
      });
      this.filteredTechnicalStatuses = this.typeaheadService.filterData(this.status, this.technicalActions);
      this.setupEditor();
    });
  }

  ngOnInit(): void {
    if (this.permissions.CanEditClaimReport) {
      this.getTechnicalReportStatuses();
    }
  }

  onSaveReport() {
    this.request.updateTechnicalLeadReport({ claimId: this.claim.id, reportData: this.claim.technicalFunctionalLeadReport, reportStatus: this.statuses.value }).subscribe(() => {
      this.getTechnicalReportStatuses();
      this.claim.technicalFunctionalLeadReportStatusDesc = this.newStatus ?? this.claim.technicalFunctionalLeadReportStatusDesc;
      return this.notify.showSuccess('Report successfully updated.');
    });
  }

  onTechnicalStatusSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.statuses.setValue((event.source.selected as MatOption).value);
      this.newStatus = (event.source.selected as MatOption).viewValue;
    }
  }

}