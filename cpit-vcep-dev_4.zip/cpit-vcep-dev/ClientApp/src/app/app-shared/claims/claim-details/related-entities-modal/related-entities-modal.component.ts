import { Component, ElementRef, Inject, Input, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { CreateClaimComponent } from '../../create-claim/create-claim.component';

@Component({
  selector: 'app-related-entities-modal',
  templateUrl: './related-entities-modal.component.html',
  styleUrls: ['./related-entities-modal.component.css']
})
export class RelatedEntitiesModalComponent {
  claim: any;
  permissions: any;

  @ViewChild(CreateClaimComponent) child: CreateClaimComponent;

  constructor(
    private permissionsService: PermissionsService,
    public dialogRef: MatDialogRef<RelatedEntitiesModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.permissions = permissionsService.get();
  }

  ngOnInit(): void {
    this.claim = this.data.claim;
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    let editClaimRequest = {
      id: this.claim.id,
      contractId: this.child.contracts.value ?? this.claim.contractId,
      contractorId: this.child.contractors.value,
      linkedClaimantUserId: this.child.contractorUsers.value ?? this.claim.linkedClaimantUser?.id,
    };

    this.dialogRef.close(editClaimRequest);
  }

}
