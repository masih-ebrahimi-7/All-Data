import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, UntypedFormControl } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatSelectChange } from '@angular/material/select';
import { forkJoin, Observable, of } from 'rxjs';
import { IClaimEditModel } from 'src/app/models/claim.model';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-claim-timeline',
  templateUrl: './claim-timeline.component.html',
  styleUrls: ['./claim-timeline.component.css'],
})
export class ClaimTimelineComponent implements OnInit {
  @Input()
  dataSource: any;
  claimWorkflowsteps: any;
  claimActions: any;
  form: FormGroup;
  priorityChanged: boolean = false;
  @Output() claimChanged = new EventEmitter<any>();
  @Output() timelineLoading = new EventEmitter<boolean>();

  status: UntypedFormControl = new UntypedFormControl();
  statuses: UntypedFormControl = new UntypedFormControl('');
  filteredStatuses: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  priority: UntypedFormControl = new UntypedFormControl();
  priorities: UntypedFormControl = new UntypedFormControl();
  filteredPriorities: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  priorityList: any;
  permissions: any;

  constructor(
    private request: RequestService,
    private formBuilder: FormBuilder,
    private typeaheadService: TypeaheadService,
    private notify: NotificationService,
    private permissionService: PermissionsService,
    private dialog: MatDialog
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {
    this.loadPage();
    this.preparePrioritiesForm();
  }

  loadPage() {
    forkJoin([
      this.request.getClaimWorkflowSteps(this.dataSource?.id),
      (this.permissions.CanChangeClaimStatus) ? this.request.getClaimActions(this.dataSource?.id) : of([]),
      (this.permissions.CanEditClaimDetails) ? this.getPrioritiesForFilter() : of([]),
    ]).subscribe(([claimWorkflowStepsResponse, claimActionsResponse, prioritiesFilterResponse]) => {
      this.claimWorkflowsteps = claimWorkflowStepsResponse;
      this.claimActions = Array.from(claimActionsResponse as any).map((action: any) => {
        return {
          value: action.value,
          label: action.description,
          description: action.longDescription,
          icon: action.icon,
          style: action.style,
        };
      });

      this.filteredStatuses = this.typeaheadService.filterData(this.status, this.claimActions);

      this.filteredPriorities = this.typeaheadService.filterData(this.priority, prioritiesFilterResponse);
      this.priorityList = prioritiesFilterResponse;

      this.timelineLoading.next(true);
    });
  }

  triggerStatusChange(action: any) {
    this.request
      .changeClaimStatus({
        claimId: this.dataSource?.id,
        toStatus: action.value,
        reference: this.dataSource?.reference,
      })
      .subscribe((data: any) => {
        this.loadPage();
      });
  }

  preparePrioritiesForm(): void {
    if (this.permissions.CanEditClaimDetails) {
      this.form = this.formBuilder.group({
        statuses: new UntypedFormControl(''),
      });

      this.form = this.formBuilder.group({
        priorities: new UntypedFormControl(''),
      });
    }
  }

  onFraudAlertToggle(event: any) {
    if (event.checked) {
      const data = {
        pageTitle: 'Red Flag Alert',
        fields: [
          {
            name: 'reason',
            label: 'Please provide a reason for red-flagging this claim',
            type: 'textarea',
            value: '',
            required: true,
          }
        ],
      };

      const dialogRef = this.dialog.open(UpdateDialogComponent, {
        width: '30rem',
        data: data,
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          this.request.toggleClaimFraudAlert(this.dataSource.id, result.reason).subscribe((data: any) => {
            this.claimChanged.next(this.dataSource);
            this.notify.showSuccess('Red flag alert added successfully.');
          });
        } else {
          this.dataSource.fraudulent = false;
        }
      });
    } else {
      this.request.toggleClaimFraudAlert(this.dataSource.id).subscribe((data: any) => {
        this.claimChanged.next(this.dataSource);
        this.notify.showSuccess('Red flag alert removed successfully.');
      });
    }
  }

  onSubmit(): void {
    if (this.form.invalid) {
      return;
    }

    let claimRequest: IClaimEditModel = {
      priority: this.priorities.value,
      id: this.dataSource?.id,
      grantId: this.dataSource?.grantId,
      sector: this.dataSource?.sector,
    };

    this.request.editClaim(claimRequest).subscribe((data: any) => {
      this.claimChanged.next(data);
      this.priorityChanged = false;
      this.notify.showSuccess(`Claim priority updated successfully.`);
    });
  }

  getPrioritiesForFilter() {
    return this.request.getEnumValues('PriorityType');
  }

  getPriority(value: any) {
    return this.priorityList.find((a: any) => a.value == value)?.label || '';
  }

  onPrioritiesSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.priorities.setValue((event.source.selected as MatOption).value);
      this.priorityChanged = true;
    }
  }

  changeStatus() {
    this.request
      .changeClaimStatus({
        claimId: this.dataSource?.id,
        toStatus: this.statuses.value,
        reference: this.dataSource?.reference,
      })
      .subscribe((data: any) => {
        this.loadPage();
        this.notify.showSuccess(`Claim status updated successfully.`);
      });
  }

  onStatusSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.statuses.setValue((event.source.selected as MatOption).value);
    }
  }

  getClaimWorkflowIcon(workflowStatus: number): string {
    var icon = this.claimActions.find((a: any) => a.value == workflowStatus);
    return icon;
  }
}
