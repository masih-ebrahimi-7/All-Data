import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RequestService } from 'src/app/services/request.service';
import { NotificationService } from 'src/app/services/notification.service';
import { ISubClaim } from 'src/app/models/subclaim.model';

interface DialogData {
  selectedDocuments: any[];
  claimId: number;
}

@Component({
  selector: 'app-bulk-subclaim-link-dialog',
  templateUrl: './bulk-subclaim-link-dialog.component.html',
  styleUrls: ['./bulk-subclaim-link-dialog.component.css']
})
export class BulkSubClaimLinkDialogComponent implements OnInit {
  subClaims: ISubClaim[] = [];
  selectedSubClaim: number | null = null;
  loading = false;

  constructor(
    public dialogRef: MatDialogRef<BulkSubClaimLinkDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private request: RequestService,
    private notify: NotificationService
  ) { }

  ngOnInit(): void {
    this.loadSubClaims();
  }

  loadSubClaims(): void {
    this.loading = true;
    this.request.getSubClaimsByClaimId(this.data.claimId).subscribe({
      next: (data: any) => {
        this.subClaims = data;
        this.loading = false;
      },
      error: (error) => {
        this.notify.showError('Failed to load subclaims');
        this.loading = false;
      }
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onConfirm(): void {
    if (this.selectedSubClaim !== null || this.selectedSubClaim === null) {
      const documentLinks = this.data.selectedDocuments.map(doc => ({
        DocumentAttachmentId: doc.id,
        SubClaimId: this.selectedSubClaim
      }));

      const model = {
        DocumentLinks: documentLinks
      };

      this.loading = true;
      this.request.bulkLinkDocumentsToSubClaims(model).subscribe({
        next: () => {
          this.notify.showSuccess('Documents linked to subclaim successfully');
          this.dialogRef.close(true);
        },
        error: (error) => {
          this.notify.showError('Failed to link documents to subclaim');
          this.loading = false;
        }
      });
    }
  }
}
