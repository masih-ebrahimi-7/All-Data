import { Component, Input } from '@angular/core';
import { IRemark } from 'src/app/common/interfaces';
import { getRandomAvatarUrl } from 'src/app/common/helpers';
 
@Component({
  selector: 'app-claim-reply',
  templateUrl: './claim-reply.component.html',
  styleUrls: ['./claim-reply.component.css']
})
export class ClaimReplyComponent {
  @Input() reply: IRemark;
}
