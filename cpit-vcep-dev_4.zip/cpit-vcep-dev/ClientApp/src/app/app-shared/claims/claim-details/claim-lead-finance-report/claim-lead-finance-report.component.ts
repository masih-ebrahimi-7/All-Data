import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { Observable } from 'rxjs';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-claim-lead-finance-report',
  templateUrl: './claim-lead-finance-report.component.html',
  styleUrls: ['./claim-lead-finance-report.component.css']
})
export class ClaimLeadFinanceReportComponent implements OnInit, AfterViewInit {
  @Input() claim: any;
  @Input() opened: void;
  @Input() closed: void;
  @Input() panelOpenState: boolean;
  permissions: any;
  financeActions: any;
  newStatus: any;

  status: UntypedFormControl = new UntypedFormControl();
  statuses: UntypedFormControl = new UntypedFormControl();
  filteredFinanceStatuses: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  public editorConfig = { ...EditorConfig };

  constructor(private request: RequestService,
    private notify: NotificationService,
    private permissionService: PermissionsService,
    private typeaheadService: TypeaheadService,
    public dialog: MatDialog) {
    this.permissions = this.permissionService.get();
  }

  ngAfterViewInit(): void {
    this.setupEditor();
  }

  setupEditor(): void {
    this.editorConfig.editable = (this.permissions.CanEditClaimReport && this.financeActions?.length > 0) ?? false;
    this.editorConfig.showToolbar = (this.permissions.CanEditClaimReport && this.financeActions?.length > 0) ?? false;
    this.editorConfig.height = 'auto';
    this.editorConfig.minHeight = '400px';
  }

  getFinanceReportStatuses() {
    this.request.getFinanceReportStatuses(this.claim.id).subscribe((claimActionsResponse: any) => {
      this.financeActions = Array.from(claimActionsResponse as any).map((action: any) => {
        return {
          value: action.value,
          label: action.description
        };
      });
      this.filteredFinanceStatuses = this.typeaheadService.filterData(this.status, this.financeActions);
      this.setupEditor();
    });
  }
  ngOnInit(): void {
    if (this.permissions.CanEditClaimReport) {
      this.getFinanceReportStatuses();
    }
  }

  onSaveReport() {
    this.request.updateFinanceLeadReport({ claimId: this.claim.id, reportData: this.claim.financeFunctionalLeadReport, reportStatus: this.statuses.value }).subscribe(() => {
      this.getFinanceReportStatuses();
      this.claim.financeFunctionalLeadReportStatusDesc = this.newStatus ?? this.claim.financeFunctionalLeadReportStatusDesc;
      return this.notify.showSuccess('Report successfully updated.');
    });
  }

  onFinanceStatusSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.statuses.setValue((event.source.selected as MatOption).value);
      this.newStatus = (event.source.selected as MatOption).viewValue;
    }
  }

}