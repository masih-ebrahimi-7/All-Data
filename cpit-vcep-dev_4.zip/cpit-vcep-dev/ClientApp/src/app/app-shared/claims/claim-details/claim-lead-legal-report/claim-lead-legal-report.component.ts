import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { Observable } from 'rxjs';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-claim-lead-legal-report',
  templateUrl: './claim-lead-legal-report.component.html',
  styleUrls: ['./claim-lead-legal-report.component.css']
})
export class ClaimLeadLegalReportComponent implements OnInit, AfterViewInit {
  @Input() claim: any;
  @Input() opened: void;
  @Input() closed: void;
  @Input() panelOpenState: boolean;
  permissions: any;
  legalActions: any;
  newStatus: any;

  status: UntypedFormControl = new UntypedFormControl();
  statuses: UntypedFormControl = new UntypedFormControl();
  filteredLegalStatuses: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  public editorConfig = { ...EditorConfig };

  constructor(private request: RequestService,
    private notify: NotificationService,
    private permissionService: PermissionsService,
    private typeaheadService: TypeaheadService,
    public dialog: MatDialog) {
    this.permissions = this.permissionService.get();
  }

  ngAfterViewInit(): void {
    this.setupEditor();
  }

  setupEditor(): void {
    this.editorConfig.editable = (this.permissions.CanEditClaimReport && this.legalActions?.length > 0) ?? false;
    this.editorConfig.showToolbar = (this.permissions.CanEditClaimReport && this.legalActions?.length > 0) ?? false;
    this.editorConfig.height = 'auto';
    this.editorConfig.minHeight = '400px';
  }

  getLegalReportStatuses() {
    this.request.getLegalReportStatuses(this.claim.id).subscribe((claimActionsResponse: any) => {
      this.legalActions = Array.from(claimActionsResponse as any).map((action: any) => {
        return {
          value: action.value,
          label: action.description
        };
      });
      this.filteredLegalStatuses = this.typeaheadService.filterData(this.status, this.legalActions);
      this.setupEditor();
    });
  }

  ngOnInit(): void {
    if (this.permissions.CanEditClaimReport) {
      this.getLegalReportStatuses();
    }
  }

  onSaveReport() {
    this.request.updateLegalLeadReport({ claimId: this.claim.id, reportData: this.claim.legalFunctionalLeadReport, reportStatus: this.statuses.value }).subscribe(() => {
      this.getLegalReportStatuses();
      this.claim.legalFunctionalLeadReportStatusDesc = this.newStatus ?? this.claim.legalFunctionalLeadReportStatusDesc;
      return this.notify.showSuccess('Report successfully updated.');
    });
  }

  onLegalStatusSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.statuses.setValue((event.source.selected as MatOption).value);
      this.newStatus = (event.source.selected as MatOption).viewValue;
    }
  }

}