import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { RequestService } from 'src/app/services/request.service';
import { MatDialog } from '@angular/material/dialog';
import { NotificationService } from 'src/app/services/notification.service';
import { UploadEntityDocumentComponent } from 'src/app/upload-entity-document/upload-entity-document.component';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { GoogleDrivePickerService } from 'src/app/services/google-drive-picker.service';
import { BehaviorSubject } from 'rxjs';
import { TypeaheadInput } from 'src/app/services/typeahead.service';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { IDocumentRequestModel } from 'src/app/common/interfaces';
import { WarningDialogComponent } from 'src/app/common/dialogs/warning-dialog/warning-dialog.component';
import { DriveUploaderComponent } from 'src/app/common/uploader/drive-uploader/drive-uploader.component';
import { BulkSubClaimLinkDialogComponent } from './bulk-subclaim-link-dialog/bulk-subclaim-link-dialog.component';

@Component({
  selector: 'app-claim-documents',
  templateUrl: './claim-documents.component.html',
  styleUrls: ['./claim-documents.component.css'],
})
export class ClaimDocumentsComponent implements OnInit {
  @Input() category: any;
  @Input() currentClaimId: number;
  @Output() documentsCountChanged = new EventEmitter<number>();
  @Output() changesUnderAnotherCategory = new EventEmitter<number>();
  private _driveIntegrationServiceSubscription;
  documentsCount: number = 0;
  documentConfig: any = {};
  documents: any = {};
  documentTableActions: Action[];
  permissions: any | null;
  documentCategories$ = new BehaviorSubject([]);
  documentCategories = this.documentCategories$.asObservable();
  documentSources: TypeaheadInput[] = [];
  claimDocsFilters: AppInput[] = [];
  selected: any[] = [];

  constructor(
    private request: RequestService,
    public dialog: MatDialog,
    private notify: NotificationService,
    permissionService: PermissionsService,
    private GoogleDrivePickerService: GoogleDrivePickerService
  ) {
    this.permissions = permissionService.get();
    this.documentTableActions = this.getBulkActions();
    this._driveIntegrationServiceSubscription = this.GoogleDrivePickerService.onFilesSelectedEmitter.subscribe({
      next: (event: any) => {
        var files = event.files;
        if (event.processed == false && Array.isArray(files)) {
          this.onDriveFileSelected(files);
          event.processed = true;
        }
      },
    });
  }

  ngOnInit(): void {
    this.setupDocumentEditModal();
    if (this.category) this.setDocDataSource({});
    this.claimDocsFilters = this.getFilters();
    this.documentColumnsList = this.getColumns();
  }

  selectionChanged(selectedItems: any[]): void {
    this.selected = selectedItems;
  }

  setupDocumentEditModal(): void {
    this.getDocumentSourcesForFilter();
    this.getDocumentCategoriesForFilter();
  }

  getDocumentSourcesForFilter() {
    return this.request.getEnumValues('DocumentSource').subscribe((data: any) => {
      this.documentSources = data;
    });
  }

  getDocumentCategoriesForFilter() {
    return this.request.getDocumentCategoriesForFilter().subscribe((data: any) => {
      this.documentCategories$.next(data);
    });
  }

  documentColumnsList: Array<Column> = []

  getFilters(): AppInput[] {
    return [
      new AppInput('label.documentName', 'documentName'),
      new AppInput('label.originalName', 'originalName'),
      new AppInput('label.documentSource', 'documentSource', InputType.Dropdown, {
        source: () => this.request.getEnumValues('DocumentSource'),
      }),
      new AppInput('label.createdBy', 'createdBy'),
      new AppInput('label.createdDate', 'createdDate', InputType.DateRange, {
        toInputName: 'createdDateEnd'
      }),
      new AppInput('label.lastModifiedBy', 'lastModifiedBy'),
      new AppInput('label.linkedFromGoogleDrive', 'linkedFromGoogleDrive', InputType.Dropdown, {
        source: [
          { value: true, label: 'label.yes' },
          { value: false, label: 'label.no' }
        ],
      })
    ];
  }

  setDocDataSource(config: any) {
    if (!config)
      config = {
        filter: {
          pageIndex: 1,
          pageSize: 10,
          orderBy: 'createdDate',
          direction: false,
          claimId: this.currentClaimId,
          categoryId: this.category.id ?? null,
        },
      };

    if (config.filter) {
      config.filter.claimId = this.currentClaimId;
      config.filter.categoryId = this.category?.id ?? null;
    } else {
      config.filter = {
        claimId: this.currentClaimId,
        categoryId: this.category?.id ?? null,
      };
    }

    this.documentConfig = config.filter;

    this.request.getClaimDocuments(this.documentConfig || {}).subscribe((data: any) => {
      this.documents = data.records;
      this.documentsCount = data.totalCount;
      this.documentsCountChanged.emit(this.documentsCount);
    });
  }

  getColumns(): Column[] {
    return [
      new Column(' ', 'actions', {
        size: 'sm',
        type: ColumnType.DetailsActions,
        value: (e: any) => {
          return new ActionList(this.getActions(e));
        },
        disableSorting: true,
      }),
      new Column('label.isExternalUpload', 'isExternalUpload', {
        disableSorting: true,
        type: ColumnType.Boolean,
        value: (e: any) => e.isExternalUpload
      }),
      new Column('label.name', 'document.name', {
        type: ColumnType.Link,
        size: 'l',
        value: (e: any) => {
          return new Link(e.document.name, `${e.document.url}`, true);
        },
      }),
      new Column('label.originalName', 'document.originalName', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.document.originalName;
        },
      }),
      new Column('label.documentSource', 'document.documentSource', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.document.documentSourceLabel;
        },
      }),
      new Column('label.documentCategoryName', 'document.documentCategoryId', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.document.documentCategoryName;
        },
      }),
      new Column('SubClaim', 'subClaim', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.subClaim ? `${e.subClaim.referenceCode} - ${e.subClaim.invoiceIpcNumber}` : 'Not linked';
        },
      }),
      new Column('label.createdBy', 'document.createdBy', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.document.createdBy;
        },
      }),
      new Column('label.createdDate', 'document.createdDate', {
        type: ColumnType.Date,
        value: (e: any) => {
          return new DatePipe('en-us').transform(e.document.createdDate);
        },
      }),

      new Column('label.lastModifiedBy', 'document.lastModifiedBy', {
        type: ColumnType.Text,
        hidden: this.permissions?.CanAccessAsDonor || this.permissions?.CanAccessAsClaimant || this.permissions?.CanAccessAsMinistry,
        value: (e: any) => {
          return e.document.lastModifiedBy;
        },
      }),
      new Column('label.lastModifiedDate', 'document.lastModifiedDate', {
        type: ColumnType.Date,
        value: (e: any) => {
          return new DatePipe('en-us').transform(e.document.lastModifiedDate);
        },
      }),
      new Column('label.linkedFromGoogleDrive', 'linkedFromGoogleDrive', {
        type: ColumnType.Boolean,
        value: (e: any) => e.document.linked
      }),
    ];
  }

  getActions(row: any): Action[] {
    var actions = [];
    var className = 'link ML10';

    actions.push(
      new Action({
        iconName: 'edit',
        toolTip: 'Edit Document',
        onClick: () => {
          this.openClaimDocumentDetails(row.document, true);
        },
        class: className,
      }),
    );
    if (this.permissions?.CanArchiveDocuments && !row.isExternalUpload) {
      actions.push(
        new Action({
          iconName: 'delete',
          toolTip: 'Archive Document',
          onClick: () => {
            this.archiveDocument(row.document);
          },
          class: className,
        })
      )
    }
    return actions;
  }

  openClaimDocumentDetails(selectedDocument: any, isUpdate: boolean, index?: number, total?: number) {
    const data = {
      pageTitle: isUpdate ? 'Edit Document Details' : `${index}/${total} Drive file upload`,
      fields: [
        {
          name: 'documentName',
          label: 'Document Name',
          type: 'text',
          value: selectedDocument?.name ?? 'Claim document',
          required: true,
          hint: 'Original name is always saved.',
        },
        {
          name: 'documentSource',
          label: 'Select Document Source',
          type: 'select',
          value: selectedDocument?.documentSource?.toString(),
          required: true,
          options: this.documentSources,
        },
        {
          name: 'categoryId',
          label: 'Pick Document Category',
          type: 'select-async',
          value: selectedDocument?.categoryId?.toString(),
          required: true,
          options: this.documentCategories$,
        },
      ],
    };
    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
      hasBackdrop: false,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (isUpdate) {
          let editedDocuments: IDocumentRequestModel = {
            claimId: this.currentClaimId,
            documentId: selectedDocument.id,
            categoryId: result.categoryId ?? selectedDocument?.categoryId,
            documentSource: result.documentSource ?? selectedDocument?.documentSource,
            documentName: result.documentName ?? selectedDocument?.documentName,
          };

          this.request.editDocuments([editedDocuments]).subscribe((dataResponse) => {
            this.setDocDataSource(this.documentConfig);
            this.changesUnderAnotherCategory.emit(selectedDocument.categoryId);
            this.notify.showSuccess('Documents edited successfully.');
          });
        } else {
          var claimDocument = {
            documentId: selectedDocument.id,
            url: selectedDocument.url,
            isLinked: true,
            categoryId: result.categoryId ?? selectedDocument?.categoryId,
            documentSource: result.documentSource ?? selectedDocument?.documentSource,
            documentName: result.documentName ?? selectedDocument?.documentName,
            claimId: this.currentClaimId,
          };

          this.request.linkEntityToGoogleDriveDocument([claimDocument]).subscribe((dataResponse) => {
            this.setDocDataSource(this.documentConfig);
            this.changesUnderAnotherCategory.emit(result.categoryId);
            this.notify.showSuccess(`Document ${result.documentName ?? selectedDocument?.documentName} edited successfully.`);
          });
        };
      }
    });
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions.CanAddDocumentsToClaims) {
      actions.push(
        new Action({
          onClick: () => this.openUploadDocumentDialog(),
          iconLabel: 'label.upload',
          color: 'primary',
          type: 'button',
          iconName: 'cloud_upload',
          toolTip: 'label.upload',
        })
      );
    }

    // do not allow claimant nor MoF to upload from drive
    if (this.permissions?.CanAddDriveDocumentsToClaims) {
      actions.push(
        new Action({
          onClick: async () => await this.GoogleDrivePickerService.openPicker(),
          iconLabel: 'label.Attach',
          color: 'primary',
          type: 'button',
          iconName: 'attach_file',
          toolTip: 'label.Attach',
        })
      );
    }

    // Add bulk subclaim linking action
    if (this.permissions.CanAddDocumentsToClaims) {
      actions.push(
        new Action({
          onClick: () => this.openBulkSubClaimLinkDialog(),
          iconLabel: 'Link to SubClaim',
          color: 'accent',
          type: 'button',
          iconName: 'link',
          toolTip: 'Link selected documents to a subclaim',
        })
      );
    }

    return actions;
  }

  openUploadDocumentDialog() {
    const dialogRef = this.dialog.open(UploadEntityDocumentComponent, {
      width: '60em',
      data: { output: {}, claimId: this.currentClaimId },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.files && result?.files?.length > 0) {
          var fileNames = [];
          var formData = new FormData();
          for (let i = 0; i < result.files?.length; i++) {
            formData.append('files', result.files[i], result.files[i].name);
            fileNames.push(result.files[i].name);
          }
          formData.append('claimId', this.currentClaimId?.toString());

          // [AB] The files from the app-uploaded arrive as objects of Type file, but we want an extra property for CategoryId
          // As I don't know how to adapt the File interfaces to work on both client/server side, creating a key value pair
          // for 'mapping' each filename to its chosen category
          let mappingPairs: any[] = [];
          let changedCategories: Set<number> = new Set();
          for (var i = 0; i < result?.files?.length; i++) {
            let fileObject = result?.files[i] as any;
            mappingPairs.push({ 
              Filename: fileObject.name, 
              DocumentCategoryId: fileObject['documentCategoryId'],
              SubClaimId: fileObject['subClaimId']
            });
            changedCategories.add(fileObject['documentCategoryId']);
          }
          formData.append('mappingPairString', JSON.stringify(mappingPairs));

          // Call backend to check file names:
          // fileNames, claimId
          this.request.checkExistingFiles({ fileNames: fileNames, claimId: this.currentClaimId?.toString() }).subscribe((data: any) => {
            if (data && data.length > 0) {
              var message = `Your upload contains file(s): [ ${data.join(",")} ] that already exist for this claim. <br> Are you sure you want to upload this?`;
              this.dialog.open(WarningDialogComponent, {
                data: { message: message },
              }).afterClosed().subscribe((continueUpload: any) => {
                if (continueUpload) {
                  this.uploadDocument(formData, result, changedCategories);
                }
              });
            }
            else {
              this.uploadDocument(formData, result, changedCategories);
            }
          });
        }
      }
    });
  }

  openBulkSubClaimLinkDialog(): void {
    if (!this.selected || this.selected.length === 0) {
      this.notify.showError('Please select documents to link');
      return;
    }

    const dialogRef = this.dialog.open(BulkSubClaimLinkDialogComponent, {
      width: '500px',
      data: {
        selectedDocuments: this.selected,
        claimId: this.currentClaimId
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        // Refresh the documents list
        this.setDocDataSource(this.documentConfig);
      }
    });
  }

  uploadDocument(formData: FormData, result: any, changedCategories: any) {
    this.request.uploadEntityDocuments(formData).subscribe((data: any) => {
      changedCategories.forEach((category: any) => {
        this.changesUnderAnotherCategory.emit(category);
      });
      this.setDocDataSource(this.documentConfig);
      this.notify.showSuccess(`${result.files.length} Document(s) uploaded successfully.`);
    });
  }

  archiveDocument(document: any): void {
    if (this.permissions?.CanArchiveDocuments)
      this.request.archiveClaimDocument(document.id).subscribe(() => {
        this.notify.showSuccess(`Document archived successfully.`);
      });
    else
      return;
  }

  onDriveFileSelected(selectedDocuments: any) {
    this.dialog
      .open(DriveUploaderComponent, {
        width: '600px',
        data: { documents: selectedDocuments },
        disableClose: true
      })
      .afterClosed()
      .subscribe((processedFiles: any) => {
        if (processedFiles && processedFiles.length > 0) {
          const googleDocuments = processedFiles.map((file: any) => ({
            documentId: file.id,
            documentName: file.name.replace(/\.[^/.]+$/, ''),
            url: file.url,
            claimId: this.currentClaimId,
            categoryId: file.categoryId
          }));

          this.request.linkEntityToGoogleDriveDocument(googleDocuments).subscribe((dataResponse) => {
            this.setDocDataSource(this.documentConfig);
            this.notify.showSuccess(`${processedFiles.length} Document(s) uploaded successfully.`);
          });
        }
      });
  }
}
