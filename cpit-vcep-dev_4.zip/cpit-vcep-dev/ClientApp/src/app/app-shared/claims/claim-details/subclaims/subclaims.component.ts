import { Component, Input, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTable } from '@angular/material/table';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { 
  ISubClaim, 
  ISubClaimSummary, 
  SubClaimType, 
  EligibilityStatus, 
  SubClaimTypeLabels, 
  EligibilityStatusLabels 
} from 'src/app/models/subclaim.model';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { ConfirmDialogComponent } from 'src/app/common/confirm-dialog/confirm-dialog.component';
import { ICreateSubClaimRequest, IEditSubClaimRequest } from 'src/app/models/subclaim.model';

@Component({
  selector: 'app-subclaims',
  templateUrl: './subclaims.component.html',
  styleUrls: ['./subclaims.component.css']
})
export class SubClaimsComponent implements OnInit {
  @Input() claimId!: number;
  @Input() currencyId!: string;
  @Input() currencyCode!: string;
  @ViewChild(MatTable) table!: MatTable<ISubClaim>;
  
  @Output() subClaimsLoaded = new EventEmitter<ISubClaim[]>();
  @Output() summaryLoaded = new EventEmitter<ISubClaimSummary | null>();

  subClaims: ISubClaim[] = [];
  summary: ISubClaimSummary | null = null;
  loading = true;
  permissions: any;
  currencies: any[] = [];

  displayedColumns: string[] = [
    'subSeqNo',
    'referenceCode',
    'type',
    'invoiceIpcDate',
    'invoiceIpcNumber',
    'invoiceIpcDescription',
    'claimAmount',
    'claimAmountUsd',
    'verifiedAmount',
    'verifiedAmountUsd',
    'eligibilityStatus',
    'remarks',
    'actions'
  ];

  SubClaimType = SubClaimType;
  EligibilityStatus = EligibilityStatus;
  SubClaimTypeLabels = SubClaimTypeLabels;
  EligibilityStatusLabels = EligibilityStatusLabels;

  constructor(
    private request: RequestService,
    private dialog: MatDialog,
    private notify: NotificationService,
    private permissionsService: PermissionsService
  ) {
    this.permissions = this.permissionsService.get();
  }

  ngOnInit(): void {
    this.loadCurrencies();
    this.loadSubClaims();
    this.loadSummary();
  }

  loadCurrencies(): void {
    this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.currencies = data;
    });
  }

  private buildSubClaimFields(subClaim?: ISubClaim): any[] {
    const subClaimTypes = [
      { value: SubClaimType.Invoice, label: 'Invoice' },
      { value: SubClaimType.IPC, label: 'IPC' }
    ];

    const fields = [];

    if (subClaim) {
      fields.push(
        {
          name: 'subSeqNo',
          label: 'Sub Sequence No',
          type: 'readonly',
          value: subClaim.subSeqNo,
          required: false
        },
        {
          name: 'referenceCode',
          label: 'Reference Code',
          type: 'readonly',
          value: subClaim.referenceCode,
          required: false
        }
      );
    }

    fields.push(
      {
        name: 'type',
        label: 'Type',
        type: 'select',
        value: subClaim?.type || SubClaimType.Invoice,
        options: subClaimTypes,
        required: true
      },
      {
        name: 'invoiceIpcDate',
        label: 'Invoice/IPC Date',
        type: 'date',
        value: subClaim?.invoiceIpcDate ? new Date(subClaim.invoiceIpcDate) : null,
        required: true
      },
      {
        name: 'invoiceIpcNumber',
        label: 'Invoice/IPC Number',
        type: 'text',
        value: subClaim?.invoiceIpcNumber || '',
        required: true
      },
      {
        name: 'invoiceIpcDescription',
        label: 'INV/IPC Description',
        type: 'textarea',
        value: subClaim?.invoiceIpcDescription || '',
        required: false
      },
      {
        name: 'currencyId',
        label: 'Currency',
        type: 'select',
        value: subClaim?.currencyId || this.currencyId || '',
        options: this.currencies,
        required: true
      },
      {
        name: 'claimAmount',
        label: 'Claim Amount',
        type: 'number',
        value: subClaim?.claimAmount || null,
        required: true
      },
      {
        name: 'verifiedAmount',
        label: 'Verified Amount',
        type: 'number',
        value: subClaim?.verifiedAmount || null,
        required: false
      },
      {
        name: 'remarks',
        label: 'Remarks',
        type: 'textarea',
        value: subClaim?.remarks || '',
        required: false
      }
    );

    return fields;
  }

  loadSubClaims(): void {
    this.loading = true;
    this.request.getSubClaimsByClaimId(this.claimId).subscribe({
      next: (data: any) => {
        this.subClaims = data;
        this.subClaimsLoaded.emit(this.subClaims);
        this.loading = false;
      },
      error: (error) => {
        this.notify.showError('Failed to load subclaims');
        this.loading = false;
      }
    });
  }

  loadSummary(): void {
    this.request.getSubClaimSummary(this.claimId).subscribe({
      next: (data: any) => {
        this.summary = data;
        this.summaryLoaded.emit(this.summary);
      },
      error: (error) => {
        console.error('Failed to load subclaim summary', error);
      }
    });
  }

  openCreateDialog(): void {
    const data = {
      pageTitle: 'Add New SubClaim',
      fields: this.buildSubClaimFields()
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '900px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.createSubClaim(result);
      }
    });
  }

  private createSubClaim(formValue: any): void {
    const createModel: ICreateSubClaimRequest = {
      claimId: this.claimId,
      type: formValue.type,
      invoiceIpcDate: formValue.invoiceIpcDate,
      invoiceIpcNumber: formValue.invoiceIpcNumber,
      invoiceIpcDescription: formValue.invoiceIpcDescription,
      currencyId: formValue.currencyId,
      claimAmount: formValue.claimAmount,
      verifiedAmount: formValue.verifiedAmount,
      remarks: formValue.remarks
    };

    this.request.createSubClaim(createModel).subscribe({
      next: () => {
        this.notify.showSuccess('SubClaim created successfully');
        this.loadSubClaims();
        this.loadSummary();
      },
      error: (error: any) => {
        console.error('Error creating sub claim:', error);
        this.notify.showError('Failed to create subclaim');
      }
    });
  }

  openEditDialog(subClaim: ISubClaim): void {
    const data = {
      pageTitle: 'Edit SubClaim',
      fields: this.buildSubClaimFields(subClaim)
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '900px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.updateSubClaim(subClaim, result);
      }
    });
  }

  private updateSubClaim(subClaim: ISubClaim, formValue: any): void {
    const updateModel: IEditSubClaimRequest = {
      id: subClaim.id!,
      type: formValue.type,
      invoiceIpcDate: formValue.invoiceIpcDate,
      invoiceIpcNumber: formValue.invoiceIpcNumber,
      invoiceIpcDescription: formValue.invoiceIpcDescription,
      currencyId: formValue.currencyId,
      claimAmount: formValue.claimAmount,
      verifiedAmount: formValue.verifiedAmount,
      remarks: formValue.remarks
    };

    this.request.updateSubClaim(updateModel).subscribe({
      next: () => {
        this.notify.showSuccess('SubClaim updated successfully');
        this.loadSubClaims();
        this.loadSummary();
      },
      error: (error: any) => {
        console.error('Error updating sub claim:', error);
        this.notify.showError('Failed to update subclaim');
      }
    });
  }

  deleteSubClaim(subClaim: ISubClaim): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Delete SubClaim',
        message: `Are you sure you want to delete subclaim "${subClaim.referenceCode}"?`,
        confirmText: 'Delete',
        cancelText: 'Cancel'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.request.deleteSubClaim(subClaim.id!).subscribe({
          next: () => {
            this.loadSubClaims();
            this.loadSummary();
            this.notify.showSuccess('SubClaim deleted successfully');
          },
          error: (error) => {
            this.notify.showError('Failed to delete subclaim');
          }
        });
      }
    });
  }

  getEligibilityStatusColor(status: EligibilityStatus): string {
    switch (status) {
      case EligibilityStatus.Eligible:
        return 'accent';
      case EligibilityStatus.Ineligible:
        return 'warn';
      default:
        return '';
    }
  }

  getTypeIcon(type: SubClaimType): string {
    switch (type) {
      case SubClaimType.Invoice:
        return 'receipt';
      case SubClaimType.IPC:
        return 'business_center';
      default:
        return 'category';
    }
  }

  getTypeLabel(type: any): string {
    return this.SubClaimTypeLabels[type as SubClaimType] || 'Unknown';
  }

  getEligibilityStatusLabel(status: any): string {
    return this.EligibilityStatusLabels[status as EligibilityStatus] || 'Unknown';
  }
}
