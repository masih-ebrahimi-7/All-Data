import { Component, Input, OnInit } from '@angular/core';
import { AppInput } from 'src/app/common/inputs/input';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-claim-audit',
  templateUrl: './claim-audit.component.html',
  styleUrls: ['./claim-audit.component.css'],
})
export class ClaimAuditComponent {
  @Input()
  dataSource: any;

  claimAuditLogs: any;
  claimAuditLogsTotal: any;
  claimAuditLogsFilters: AppInput[] = [
    new AppInput('Performed by', 'query')
  ];
  claimAuditLogsTableActions = [];
  claimAuditLogsColumnsList = [
    new Column('SessionUser', 'createdBy'),
    new Column('Performed Date', 'createdDate', {
      type: ColumnType.DateTime,
    }),
    new Column("Changes", "changes", {
      disableSorting: true,
      type: ColumnType.Dictionary,
      size: 'audit-table'
    })
  ];

  constructor(private request: RequestService) {
  }

  setDataSource(config: any) {
    var filters = config?.filter ?? {};
    this.request.getClaimAuditLogs(this.dataSource, filters).subscribe((data: any) => {
      this.claimAuditLogsTotal = data.totalCount;
      this.claimAuditLogs = data.records;
    });
  }

}
