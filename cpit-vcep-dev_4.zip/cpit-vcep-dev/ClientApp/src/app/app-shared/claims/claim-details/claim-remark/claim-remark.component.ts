import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddRemarkDialogComponent } from 'src/app/common/dialogs/add-remark-dialog/add-remark-dialog.component';
import { EditorConfig } from 'src/app/common/EditorConfig';
import { RemarkType, TaskUserType } from 'src/app/models/enums/server-enums';
import { getRandomAvatarUrl } from 'src/app/common/helpers';
import { IRemark } from 'src/app/common/interfaces';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { UserProfileService } from 'src/app/services/auth/user-profile.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TaskUserType as ServerTaskUserType } from 'src/server-code-sync';
import { MatMenuModule } from '@angular/material/menu';

@Component({
  selector: 'app-claim-remark',
  templateUrl: './claim-remark.component.html',
  styleUrls: ['./claim-remark.component.css']
})
export class ClaimRemarkComponent implements OnInit {
  @Input() claimId: number;
  @Input() set remarks(value: any) {
    this._remarks = value;
    this.generateAvatars();
  }
  get remarks() {
    return this._remarks;
  }
  private _remarks: any;
  
  @Input() opened: void;
  @Input() closed: void;
  @Input() panelOpenState: boolean;
  @Input() isExternalCommunication: boolean = false;
  @Output() remarksChanged = new EventEmitter<any>();

  permissions: any | null;
  userInfo: any | null;
  public editorConfig = { ...EditorConfig };
  TaskUserType = ServerTaskUserType;

  constructor(private request: RequestService,
    private notify: NotificationService,
    public dialog: MatDialog,
    private permissionService: PermissionsService,
    private userProfileService: UserProfileService) {
    this.editorConfig.editable = false;
    this.editorConfig.showToolbar = false;
    this.editorConfig.height = 'auto';
    this.permissions = permissionService.get();
    this.userInfo = userProfileService.get();
  }

  reloadRemarks() {
    this.remarksChanged.emit();
  }

  openAddRemarkModal(taskUserType: TaskUserType, remarkId?: number) {
    this.dialog
      .open(AddRemarkDialogComponent, {
        width: '60em',
        data: { taskUserType: taskUserType, parentRemarkId: remarkId, isExternalCommunication: this.isExternalCommunication, claimId: this.claimId },
      })
      .afterClosed()
      .subscribe((result) => {
                if (result && result.remarkText && result.remarkText.value && result.remarkText.value.trim().length >= 30) {
          const { remarkText, usersTagged, isTask, assignedTo, taskUserType, deadline } = result;
          
          this.request
            .addRemark(
              RemarkType.Claim,
              this.claimId,
              remarkText.value,
              usersTagged ?? [],
              isTask,
              assignedTo,
              taskUserType,
              this.isExternalCommunication,
              deadline,
              remarkId
            )
            .subscribe({
              next: () => {
                this.notify.showSuccess('Remark added successfully.');
                this.remarksChanged.emit();
                this.reloadRemarks();
              },
              error: (error) => {
                console.error('Error adding remark:', error);
                this.notify.showError('Failed to add remark. Please try again.');
              }
            });
        } else if (result && result.remarkText) {
          const remarkLength = result.remarkText.value ? result.remarkText.value.trim().length : 0;
          if (remarkLength < 30) {
            this.notify.showError(`Remark must be at least 30 characters long. Current length: ${remarkLength}`);
          }
        }
      });
  }

  toggleReplies(remark: IRemark) {
    remark.showReplies = !remark.showReplies;
  }

  ngOnInit() {
  }

  generateAvatars() {
    if (this._remarks && Array.isArray(this._remarks)) {
      this._remarks.forEach((remark: any) => {
        if (!remark.avatar) {
          const seed = this.generateSeedFromString(remark.createdBy || 'anonymous');
          remark.avatar = `https://api.dicebear.com/8.x/shapes/svg?seed=${seed}`;
        }
        remark.replies?.forEach((reply: any) => {
          if (!reply.avatar) {
            const seed = this.generateSeedFromString(reply.createdBy || 'anonymous');
            reply.avatar = `https://api.dicebear.com/8.x/shapes/svg?seed=${seed}`;
          }
        });
      });
    }
  }

  private generateSeedFromString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString();
  }

  editRemark(remark: any) {
    this.dialog
      .open(AddRemarkDialogComponent, {
        width: '60em',
        data: { 
          taskUserType: TaskUserType.Internal,
          claimId: this.claimId,
          isExternalCommunication: this.isExternalCommunication,
          isEditMode: true,
          remarkId: remark.id, 
          currentText: remark.remarkText 
        },
      })
      .afterClosed()
      .subscribe((result) => {
        if (result && result.remarkText) {
          this.request
            .updateRemark(result.remarkId, result.remarkText)
            .subscribe({
              next: () => {
                this.notify.showSuccess('Remark updated successfully.');
                this.remarksChanged.emit();
                this.reloadRemarks();
              },
              error: (error) => {
                console.error('Error updating remark:', error);
                this.notify.showError('Failed to update remark. Please try again.');
              }
            });
        }
      });
  }

  deleteRemark(remark: any) {
    this.notify.showConfirm({
      title: 'Delete Remark',
      message: 'Are you sure you want to delete this remark? This action cannot be undone.',
      confirmText: 'Delete',
      cancelText: 'Cancel'
    }).subscribe(result => {
      if (result) {
        this.request
          .deleteRemark(remark.id)
          .subscribe({
            next: () => {
              this.notify.showSuccess('Remark deleted successfully.');
              this.remarksChanged.emit();
              this.reloadRemarks();
            },
            error: (error) => {
              console.error('Error deleting remark:', error);
              this.notify.showError('Failed to delete remark. Please try again.');
            }
          });
      }
    });
  }
}