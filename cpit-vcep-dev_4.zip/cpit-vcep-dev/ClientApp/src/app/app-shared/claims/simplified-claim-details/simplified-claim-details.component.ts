import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IClaim } from 'src/app/models/claim.model';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { RequestService } from 'src/app/services/request.service';
import { Column } from 'src/app/common/table/Column';
import { MatDialog } from '@angular/material/dialog';
import { NotificationService } from 'src/app/services/notification.service';
import { UpdateDialogComponent } from 'src/app/common/dialogs/update-dialog/update-dialog.component';
import { TypeaheadInput } from 'src/app/common/typehead-input';
import { MatTabGroup } from '@angular/material/tabs';
import { WarningDialogComponent } from 'src/app/common/dialogs/warning-dialog/warning-dialog.component';

@Component({
  selector: 'app-simplified-claim-details',
  templateUrl: './simplified-claim-details.component.html',
  styleUrls: ['./simplified-claim-details.component.css'],
})
export class SimplifiedClaimDetailsComponent implements OnInit, AfterViewInit {
  @ViewChild('tabGroup', {static: false}) tabGroup: MatTabGroup;

  claim: any;
  currentClaimId: number;
  permissions: any | null;
  loading: boolean = true;
  documentsLoading: boolean = true;
  claimDocsTotal: number = 0;
  claimTypes: TypeaheadInput[] = [];
  remarks: any;
  filesSubmitted: boolean = false;
  isNewClaim: any = false;
  // Documents
  filesToUpload: number = 200;
  claimFiles: File[] = [];
  documentsCategoryCount: any = {};

  displayedDocCategoryColumns: Column[] = [
    new Column('Name', 'name'),
    new Column('Description', 'description', { size: 'xxl' }),
  ];
  documentCategories: any[] = [];
  documentCategoriesForTable: any[] = [];

  detailsConfig = [
    { label: 'Reference', value: 'reference' },
    { label: 'Rejection Note', value: 'externalRejectionNote', condition: (claim: any) => !!claim?.externalRejectionNote },
    { 
      label: 'Internal Rejection Note', 
      value: 'internalRejectionNote', 
      condition: (claim: any, permissions: any) => permissions?.CanViewClaimsClearance && claim?.internalRejectionNote 
    },
    { label: 'Title', value: 'title' },
    { label: 'Description', value: (claim: any) => `${claim?.description}` },
    { label: 'Date Submitted', value: (claim: any) => `${claim?.createdDate}` },
    { 
      label: 'Submitted By', 
      value: 'createdBy', 
      condition: (claim: any, permissions: any) => !permissions?.CanAccessAsMinistry && !permissions?.CanAccessAsClaimant
    },
    { label: 'Amount', value: (claim: any) => `${claim?.claimedAmount} ${claim?.claimCurrencyCode}` },
    { label: 'Sector', value: 'sectorName' },
    { label: 'Grant', value: 'grantReference', fallback: 'N/A' },
    { label: 'Contract', value: 'contractReference', fallback: 'N/A' },
    { 
      label: 'Submission period', 
      value: (claim: any) => `${claim?.claimForStartDate} - ${claim?.claimForEndDate}`, 
      condition: (claim: any) => claim?.claimForStartDate && claim?.claimForEndDate 
    }
  ];

  constructor(
    private activatedRouter: ActivatedRoute,
    private request: RequestService,
    permissionService: PermissionsService,
    private notify: NotificationService,
    private router: Router,
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {
    this.permissions = permissionService.get();
  }

  ngOnInit(): void {
    this.currentClaimId = this.activatedRouter.snapshot.params['id'];
    this.getClaimTypesForFilter();
    this.getRemarks();
    this.loadDocumentCategories();
    this.setDocDataSource();

    this.getClaimDetails();
    this.isNewClaim = this.activatedRouter.snapshot.queryParamMap.get('created');
    this.cdr.detectChanges();
  }

  ngAfterViewInit(): void {
    this.cdr.detectChanges();
    if (this.isNewClaim)
      this.tabGroup.selectedIndex = 1;
  }

  getClaimDetails() {
    if (this.permissions?.CanAccessAsDonor)
      return this.request.getDonorClaim(this.currentClaimId).subscribe((resp) => {
        this.claim = resp as IClaim;
        this.loading = false;
      });
    else if (this.permissions?.CanAccessAsClaimant)
      return this.request.getClaimantClaim(this.currentClaimId).subscribe((resp) => {
        this.claim = resp as IClaim;
        this.loading = false;
      });
    else if (this.permissions?.CanViewLimitedClaims || this.permissions?.CanViewClaimsClearance)
      return this.request.getClaim(this.currentClaimId).subscribe((resp) => {
        this.claim = resp as IClaim;
        this.loading = false;
      });
    else {
      this.claim = {};
      this.loading = false;
      return;
    };
  }

  getEntityName(): string {
    if (this.permissions?.CanAccessAsClaimant) return "claimant-claims"
    else if (this.permissions?.CanAccessAsDonor) return "donor-claims";
    else return "claims"; 
  }

  setDocDataSource(categoryId?: number) {
    if (this.permissions?.CanAddDocumentsToClaims || this.permissions?.CanAddDriveDocumentsToClaims) {
      this.request.getClaimDocuments({claimId: this.currentClaimId, categoryId: categoryId}).subscribe((data: any) => {    
          if (categoryId)
            this.documentsCategoryCount[categoryId] = data.totalCount;
          else  {
            this.documentsLoading = false;
            this.claimDocsTotal = data.totalCount;
          }
      });
    }
  }

  loadDocumentCategories() {
    if (this.permissions?.CanAddDocumentsToClaims || this.permissions?.CanAddDriveDocumentsToClaims) {
      this.request.getDocumentCategories(1, 9999, '').subscribe((data: any) => {
        this.documentCategories = data.records;
        this.documentCategories.unshift({ id: -2, onlyNew: true, name: 'New Uploads', description: "Documents uploaded during the past 3 days." });
        this.documentCategories.unshift({ name: 'All Uploads', description: "All documents." });
        this.documentCategories.push({id: -1, name: 'Uncategorized', description: "Documents which were uploaded with no category attached."});
        this.documentCategories.forEach((category: any) => {
          this.setDocDataSource(category.id);
        });
      });
    }
  }

  getRemarks() {
    if (this.permissions?.CanManageExternalRemarks) {
      this.request.getExternalClaimRemarks(this.currentClaimId).subscribe((data: any) => {
        this.remarks = data;
      });
    }
  }

  clearClaim(claimType: number) {
    this.request
      .changeClaimStatus({
        claimId: this.currentClaimId,
        toStatus: 2,
        reference: this.claim?.reference,
        claimType: claimType
      })
      .subscribe((data: any) => {
        this.getClaimDetails();
        this.notify.showSuccess(`Claim status updated successfully.`);
      });
  }

  rejectClaim(externalRejectionNote: string, internalRejectionNote?: string) {
    this.request
      .changeClaimStatus({
        claimId: this.currentClaimId,
        toStatus: 98,
        reference: this.claim?.reference,
        internalRejectionNote: internalRejectionNote,
        externalRejectionNote: externalRejectionNote
      })
      .subscribe((data: any) => {
        this.getClaimDetails();
        this.notify.showSuccess(`Claim rejected.`);
      });
  }

  openRejectionReasonModal(): void {
    const data = {
      pageTitle: 'Claim Clearance (Rejection)',
      fields: [
        {
          name: 'externalRejectionNote',
          label: 'Please write a short rejection reason. This note will be displayed to the claimant.',
          type: 'textarea',
          value: '',
          required: true,
        },
        {
          name: 'internalRejectionNote',
          label: 'Additional details for internal users (if applicable).',
          type: 'textarea',
          value: '',
          required: false,
        },
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.notify.showSuccess("Claim rejected.");
        this.rejectClaim(result.externalRejectionNote, result.internalRejectionNote);
      }
    });
  }

  openClearanceModal(): void {
    const data = {
      pageTitle: 'Claim Clearance (Approval)',
      fields: [
        {
          name: 'claimType',
          label: 'Contract Type',
          type: 'select',
          value: this.claim.type?.toString(),
          required: false,
          options: this.claimTypes,
        }
      ],
    };

    const dialogRef = this.dialog.open(UpdateDialogComponent, {
      width: '50rem',
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.clearClaim(result.claimType);
        this.notify.showSuccess("Claim successfully cleared.");
        this.router.navigate([`/claims/${this.currentClaimId}`]);
      }
    });
  }

  
  toggleReplies(remark: any) {
    remark.showReplies = !remark.showReplies;
  }

  getClaimTypesForFilter() {
    if (this.permissions?.CanViewClaimsClearance)
      this.request.getEnumValues('ContractType').subscribe((data: any) => {
        this.claimTypes = data;
      });
  }

  fileUploadHandler(event: any[]) {
    this.claimFiles = event;
  }

  setDocCategoryDataSource(config: any) {
    this.request.getDocumentCategories(1, 9999, '').subscribe((data: any) => {
      this.documentCategoriesForTable = data.records;
    });
  }

  isUploadButtonDisabled() {
    let isDisabled = false;
    if (!this.claimFiles || this.claimFiles?.length > this.filesToUpload) {
      isDisabled = true;
    }
    return isDisabled;
  }

  onSubmitDocuments(files: any = this.claimFiles) {
    this.filesSubmitted = true;
    if (files && files?.length > 0) {
      var formData = new FormData();
      var fileNames = [];
      for (let i = 0; i < files?.length; i++) {
        formData.append('files', files[i], files[i].name);
        fileNames.push(files[i].name);
      }
      formData.append('claimId', this.currentClaimId?.toString());

      // [AB] The files from the app-uploaded arrive as objects of Type file, but we want an extra property for documentCategoryId
      // As I don't know how to adapt the File interfaces to work on both client/server side, creating a key value pair
      // for 'mapping' each filename to its chosen category
      let mappingPairs: any[] = [];
      for (var i = 0; i < files?.length; i++) {
        let fileObject = files[i] as any;
        mappingPairs.push({ Filename: fileObject.name, DocumentCategoryId: fileObject['documentCategoryId'] });
      }
      
      if (this.permissions?.CanAccessAsClaimant)
        formData.append('documentSource', '3'); //claimant

      formData.append('mappingPairString', JSON.stringify(mappingPairs));

      // Call backend to check file names:
      // fileNames, claimId
      this.request.checkExistingFiles({ fileNames: fileNames, claimId: this.currentClaimId?.toString() }).subscribe((data: any) => {
        if (data && data.length > 0) {
          var message = `Your upload contains file(s): [ ${data.join(",")} ] that already exist for this claim. <br> Are you sure you want to upload this?`;
          this.dialog.open(WarningDialogComponent, {
            data: { message: message },
          }).afterClosed().subscribe((continueUpload: any) => {
            if (continueUpload) {
              this.uploadDocument(formData, files);
            } else {
              this.filesSubmitted = false;
              this.tabGroup.selectedIndex = 2;
            }
          });
        }
        else {
          this.uploadDocument(formData, files);
        }
      });
    }
  }

  uploadDocument(formData: FormData, files: any) {
    this.request.uploadEntityDocuments(formData).subscribe((data: any) => {
      this.setDocDataSource();
      this.filesSubmitted = false;
      this.notify.showSuccess(`${files.length} Document(s) uploaded successfully.`);
      this.tabGroup.selectedIndex = 2;
    });
  }

  handleChangeOnDocuments(count: number, categoryId: number) {
    this.documentsCategoryCount[categoryId] = count;
    this.setDocDataSource();
  }

  handleChangeOnCategory(categoryId: number) {
    this.setDocDataSource(categoryId);
  }

  getValue(detail: any): string {
    if (typeof detail.value === 'function') {
      return detail.value(this.claim);
    }
  
    const value = this.claim?.[detail.value];
    return value !== undefined && value !== null ? value : detail.fallback || '';
  }
}
