import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { exportDataToSheet } from 'src/app/common/helpers';
import { AppInput, InputType } from 'src/app/common/inputs/input';
import { Action, ActionList } from 'src/app/common/table/Action';
import { Column, ColumnType } from 'src/app/common/table/Column';
import { Link } from 'src/app/common/table/Link';
import { StatusType } from 'src/app/common/table/StatusType';
import { UserAssignmentType } from 'src/app/models/enums/server-enums';
import { OutputType } from 'src/app/models/enums/ui-enums';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { TokenService } from 'src/app/services/auth/token.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
  styleUrls: ['./claims.component.css'],
})

export class ClaimsComponent implements OnInit {
  path: string;
  outputType: string;
  permissions: any | null;
  bulkActions: any;
  totalSize: number;
  data: any;
  selected: any;
  moment = moment;
  displayedColumns: Column[] = [];
  filters: AppInput[] = [];
  config: any = null;

  constructor(
    private activatedRoute: ActivatedRoute,
    private request: RequestService,
    public dialog: MatDialog,
    private router: Router,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private notify: NotificationService
  ) {
    this.permissions = this.permissionsService.get();
    this.path = this.activatedRoute.snapshot.url[0].path;
    if (this.path == 'list-output-one-claims') this.outputType = OutputType.OutputOne;
    if (this.path == 'list-output-two-claims') this.outputType = OutputType.OutputTwo;
    if (this.path == 'claims-clearance') this.outputType = OutputType.AwaitingClearance;
    if (this.path == 'claims-rejected') this.outputType = OutputType.Rejected;
  }

  ngOnInit(): void {
    this.displayedColumns = this.getDisplayedColumns();
    this.bulkActions = this.getBulkActions();
    if (this.permissions)
      this.filters = this.getFilters();
  }

  setDataSource(config?: any) {
    var filters = config?.filter ?? {};
    this.config = filters;
    if (this.permissions?.CanAccessAsClaimant) {
      return this.request.getClaimantClaims(filters).subscribe((data: any) => {
        this.data = data.records;
        this.totalSize = data.totalCount;
      });
    } else {
      return this.request.getClaims(filters, this.outputType).subscribe((data: any) => {
        this.data = data.records;
        this.totalSize = data.totalCount;
      });
    }
  }

  assignUsersToClaims(ids: number[], email: string) {
    this.request.assignUsersToClaims({ ids: ids, email: email, userAssignmentType: UserAssignmentType.SectorLead }).subscribe((data) => {
      this.setDataSource({});
      return this.notify.showSuccess('User successfully assigned to selected claims.');
    });
  }

  exportToExcel() {
    var filters = this.config ?? {};
    if (this.permissions?.CanAccessAsClaimant) {
      return this.request.getClaimantClaims(filters).subscribe((data: any) => {
        if (Array.isArray(data.records)) {
          let exportedColumns = this.getDisplayedColumns().map(a => a.columnName);
          exportDataToSheet(data.records, 'claims.xlsx', exportedColumns);
        }
      });
    } else {
      return this.request.getClaims(filters, this.outputType).subscribe((data: any) => {
        if (Array.isArray(data.records)) {
          let exportedColumns = this.getDisplayedColumns().map(a => a.columnName);
          exportDataToSheet(data.records, 'claims.xlsx', exportedColumns);
        }
      });
    }
  }

  raiseClaim() {
    this.router.navigate([`/claims/create`]);
  }

  selectionChanged(selected: any) {
    this.selected = selected;
  }

  getFilters(): AppInput[] {
    let filters = [];
    filters.push(
      new AppInput('Reference', 'reference'),
      new AppInput('Title', 'title'),
      new AppInput('Sectors', 'sectors', InputType.Multiselect, {
        source: () => this.request.getEnumValues('SectorType'),
      }),
    )
    if (this.permissions?.CanAssignClaims) {
      filters.push(
        new AppInput('Assigned Users', 'Users', InputType.Multiselect, {
          source: () => this.request.getClaimReviewers()
        }))
    }
    if (this.permissions?.CanViewAllClaims) {
      filters.push(
        new AppInput('Current Stages', 'CurrentStageIds', InputType.Multiselect, {
          source: () => this.request.getClaimStagesForFilter(),
        }),
        new AppInput('Internal Reference Code', 'internalReferenceCode'),
        new AppInput('Grant Reference', 'grantReference'),
        new AppInput('Contract Reference', 'contractReference'),
        new AppInput('Claim Contract Types', 'Types', InputType.Multiselect, {
          source: () => this.request.getEnumValues('ContractType'),
        }),
        new AppInput('Priorities', 'Priorities', InputType.Multiselect, {
          source: () => this.request.getEnumValues('PriorityType'),
        }),
        new AppInput('Claim Sources', 'ClaimSources', InputType.Multiselect, {
          source: () => this.request.getEnumValues('ClaimSource'),
        }),
        new AppInput('Fund Sources', 'FundSources', InputType.Multiselect, {
          source: () => this.request.getEnumValues('FundSourceType'),
        }),
        new AppInput('Contracting Authorities', 'ContractingAuthorities', InputType.Multiselect, {
          source: () => this.request.getEnumValues('ContractingAuthorityType'),
        })
        
      )
    }

    return filters;
  }

  getBulkActions() {
    var actions: Action[] = [];
    if (this.permissions?.CanSubmitClaims) {
      actions.push(
        new Action({
          iconName: 'add',
          onClick: () => this.raiseClaim(),
          iconLabel: 'New submission',
          color: 'primary',
          type: 'button',
          toolTip: 'New Submission',
        })
      );
    }

    actions.push(
      new Action({
        iconName: 'download',
        onClick: () => this.exportToExcel(),
        iconLabel: 'Export',
        color: 'primary',
        type: 'button',
        toolTip: 'Export',
      })
    );

    return actions;
  }

  getDisplayedColumns(): Column[] {
    if (this.permissions?.CanAccessAsClaimant) return this.getDisplayedColumnsForClaimant();
    else if (this.permissions?.CanAccessAsDonor) return this.getDisplayedColumnsForDonor();
    else
      return [
        new Column('label.shortReference', 'reference', {
          type: ColumnType.Link,
          size: 'sm',
          value: (e: any) => {
            let link = this.getClaimDetailsPageLink(e.id)
            return new Link(e.reference, link);
          },
        }),
        new Column('Int. Ref. Code', 'internalReferenceCode'),
        new Column('Title', 'title'),
        new Column('Grant', 'grant.reference', {
          type: ColumnType.Link,
          value: (e: any) => {
            if (e.grant && e.grant.reference)
              return new Link(e.grant.reference, `grants/${e.grant.id}`);
            else return 'N/A'
          },
        }),
        new Column('Sector', 'grant.sector', {
          type: ColumnType.Text,
          value: (e: any) => {
            return e.sectorName;
          },
        }),
        new Column('All Contract Grants', 'contractGrantReferences', {
          type: ColumnType.Text,
          disableSorting: true
        }),
        new Column('Claimed Amount', 'claimedAmount', {
          type: ColumnType.Number,
        }),
        new Column('label.currency', 'claimCurrencyCode', {
          disableSorting: true,
          size: 'sm'
        }),
        new Column('Claimed Amount (USD)', 'claimedAmountUsd', {
          type: ColumnType.Number,
          disableSorting: true,
          tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page"
        }),
        new Column('label.currencyRate', 'currencyRate', {
          disableSorting: true,
        }),
        new Column('Claim Source', 'source', {
          type: ColumnType.Text,
          size: 'sm',
          value: (e: any) => e.sourceLabel
        }),
        new Column('Fund Source', 'fundSource', {
          type: ColumnType.Text,
          size: 'sm',
          value: (e: any) => e.fundSourceLabel
        }),
        new Column('Contracting Authorities', 'claimContractingAuthorities', {
          type: ColumnType.Text,
          disableSorting: true,
          size: 'sm',
          value: (e: any) => e.claimContractingAuthorities
        }),
        new Column('Type', 'type', {
          type: ColumnType.Status,
          value: (e: any) => {
            return {
              label: e.typeLabel,
              type: StatusType.Default,
            };
          },
        }),
        new Column('Priority', 'priority', {
          type: ColumnType.Status,
          value: (e: any) => {
            let type = StatusType.Default;
            let label = 'N/A';
            switch (e.priorityLabel) {
              case 'First':
                type = StatusType.Danger;
                label = 'Priority #1';
                break;
              case 'Second':
                type = StatusType.Warning;
                label = 'Priority #2';
                break;
              case 'Third':
                type = StatusType.Ok;
                label = 'Priority #3';
                break;
              case 'Fourth':
                type = StatusType.Default;
                label = 'Priority #4';
                break;
              default:
                type = StatusType.Default;
                break;
            }
            return {
              label: label,
              type: type,
            };
          },
        }),
        new Column('Red Flag Alert', 'fraudulent', {
          type: ColumnType.Icon,
          size: 'sm',
          hidden: this.outputType == OutputType.AwaitingClearance || this.outputType == OutputType.Rejected,
          value: (e: any) => {
            return {
              color: e.fraudulent ? 'warn' : 'primary',
              fontIcon: e.fraudulent ? 'flag' : 'check_circle',
              tooltip:  e.fraudulent ? (e.fraudulentReason ? `Red-flagged: ${e.fraudulentReason}` : 'Red-flagged') : 'No red-flag',
            };
          },
        }),
        new Column('Current Stage', 'currentStage', {
          type: ColumnType.Text,
          size: 'md',
          disableSorting: true,
          value: (e: any) => {
            return e.currentStageName || 'Not Started';
          },
        }),
        new Column('label.contract', 'contractReference', {
          type: ColumnType.Link,
          disableSorting: true,
          value: (e: any) => {
            if (e.contractReference)
              return new Link(e.contractReference, `contracts/${e.contractId}`);
            else
              return 'N/A';
          },
        }),
        new Column('Contractor', 'contractor.name', {
          type: ColumnType.Link,
          disableSorting: true,
          value: (e: any) => {
            if (e.contractor && e.contractor.name)
              return new Link(e.contractor.name, `list-external-entities?name=${e.contractor.name}`);
            else return 'N/A';
          },
        }),
        new Column('Sector Lead', 'assignedToSectorLeaad'),
        new Column('Finance', 'assignedToFinance'),
        new Column('Legal', 'assignedToLegal'),
        new Column('CMS', 'assignedToCMS'),
        new Column('label.createdDate', 'createdDate', {
          type: ColumnType.DateTime,
        }),
        new Column('Created By', 'createdBy'),
        new Column('Last Modified By', 'lastModifiedBy'),
        new Column('Last Modified Date', 'lastModifiedDate', {
          type: ColumnType.DateTime,
        }),
      ];
  }

  getDisplayedColumnsForClaimant(): Column[] {
    return [
      new Column('label.reference', 'reference', {
        type: ColumnType.Link,
        value: (e: any) => {
          return new Link(e.reference, `submission-details/${e.id}`);
        },
      }),
      new Column('Title', 'title'),
      new Column('Sector', 'sector', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.sectorName;
        },
      }),
      new Column('Grant', 'grantReference', {
        type: ColumnType.Text,
        disableSorting: true
      }),
      new Column('Contract', 'contractReference', {
        type: ColumnType.Text,
        disableSorting: true
      }),
      new Column('All Contract Grants', 'contractGrantReferences', {
        type: ColumnType.Text,
        disableSorting: true
      }),
      new Column('label.createdDate', 'createdDate', {
        type: ColumnType.DateTime,
      }),
      new Column('Claimed Amount', 'claimedAmount', { type: ColumnType.Number }),
      new Column('label.currency', 'claimCurrencyCode', {
        disableSorting: true
      }),
      new Column('Type', 'type'),
      new Column('Current Stage', 'currentStage', {
        type: ColumnType.Text,
        size: 'md',
        disableSorting: true,
        value: (e: any) => {
          return e.currentStageName || 'Not Started';
        },
      }),
    ];
  }

  getDisplayedColumnsForDonor(): Column[] {
    return [
      new Column(' ', 'actions', {
        size: 'sm',
        type: ColumnType.Actions,
        value: (e: any) => {
          return new ActionList(this.getActions(e));
        },
        disableSorting: true,
      }),
      new Column('label.reference', 'reference', {
        type: ColumnType.Link,
        value: (e: any) => {
          return new Link(e.reference, this.getClaimDetailsPageLink(e.id));
        },
      }),
      new Column('Grant', 'grant.reference', {
        type: ColumnType.Link,
        value: (e: any) => {
          if (e.grant && e.grant.reference)
            return new Link(e.grant.reference, `grants/${e.grant.id}`);
          else return 'N/A'
        },
      }),
      new Column('Sector', 'grant.sector', {
        type: ColumnType.Text,
        value: (e: any) => {
          return e.sectorName;
        },
      }),
      new Column('All Contract Grants', 'contractGrantReferences', {
        type: ColumnType.Text,
        disableSorting: true
      }),
      new Column('Title', 'title'),
      new Column('label.createdDate', 'createdDate', {
        type: ColumnType.DateTime,
      }),
      new Column('Claimed Amount', 'claimedAmount', { type: ColumnType.Number }),
      new Column('label.currency', 'claimCurrencyCode', {
        disableSorting: true
      }),
      new Column('Claimed Amount (USD)', 'claimedAmountUsd', {
        type: ColumnType.Number,
        disableSorting: true,
        tooltip: "Amount (USD) - Calculated using conversion rates from Conversion Page"
      }),
      new Column('label.currencyRate', 'currencyRate', {
        disableSorting: true,
      }),
      new Column('Type', 'type'),
      new Column('Priority', 'priorityLabel', {
        type: ColumnType.Status,
        value: (e: any) => {
          let type = StatusType.Default;
          let label = 'N/A';
          switch (e.priorityLabel) {
            case 'First':
              type = StatusType.Danger;
              label = 'Priority #1';
              break;
            case 'Second':
              type = StatusType.Warning;
              label = 'Priority #2';
              break;
            case 'Third':
              type = StatusType.Warning;
              label = 'Priority #3';
              break;
            case 'Fourth':
              type = StatusType.Default;
              label = 'Priority #4';
              break;
            default:
              type = StatusType.Default;
              break;
          }
          return {
            label: label,
            type: type,
          };
        },
      }),
      new Column('Status', 'status'),
      new Column('Current Stage', 'currentStage', {
        type: ColumnType.Text,
        size: 'md',
        disableSorting: true,
        value: (e: any) => {
          return e.currentStageName || 'Not Started';
        },
      }),
    ];
  }

  getActions(row: any): Action[] {
    var actions: Action[] = [];
    return actions;
  }

  openClaimDetails(claimId: number) {
    let claimDetailsLink = this.getClaimDetailsPageLink(claimId);
    this.router.navigate([claimDetailsLink]);
  }

  getClaimDetailsPageLink(claimId: number) {
    if (this.permissions?.CanAccessAsClaimant || this.permissions?.CanAccessAsDonor) return `submission-details/${claimId}`;
    else if (this.outputType == OutputType.AwaitingClearance || this.outputType == OutputType.Rejected)
      return `submission-details/${claimId}`;
    else
      return `claims/${claimId}`;
  }

  isOutputOnePage() {
    return this.activatedRoute.snapshot.url[0].path == 'list-output-one-claims';
  }

  isOutputTwoPage() {
    return this.activatedRoute.snapshot.url[0].path == 'list-output-two-claims';
  }
}
