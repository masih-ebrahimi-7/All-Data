import { AfterContentInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  UntypedFormControl,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MessageModalComponent } from 'src/app/common/dialogs/message-modal/message-modal.component';
import { IDropdownSettings } from 'src/app/common/reusable-form-components/FormInterfaces';
import { Contract } from 'src/app/models/contract.model';
import { Grant } from 'src/app/models/grant.model';
import { PermissionsService } from 'src/app/services/auth/permissions.service';
import { NotificationService } from 'src/app/services/notification.service';
import { RequestService } from 'src/app/services/request.service';
import { TypeaheadInput, TypeaheadService } from 'src/app/services/typeahead.service';

@Component({
  selector: 'app-create-claim',
  templateUrl: './create-claim.component.html',
  styleUrls: ['./create-claim.component.css'],
})
export class CreateClaimComponent implements OnInit, AfterContentInit {
  form: FormGroup;
  @Input() claimDetails: any = null;

  isEditRelatedEntitiesForm: boolean = false;
  loading: boolean = false;
  grantDetails?: Grant;
  contractDetails?: Contract;
  claimsForSelectedContract?: any;
  permissions: any | null;
  displayContractorUsersDropdown: boolean = false;

  submitted = false;
  filteredSectors: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  allGrants: TypeaheadInput[];
  filteredGrants: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  allContracts: TypeaheadInput[];
  filteredContracts: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  filteredPriorities: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  filteredSources: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  filteredFundSources: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  filteredCurrencies: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  allContractors: TypeaheadInput[];
  filteredContractors: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  allContractorUsers: TypeaheadInput[];
  filteredContractorUsers: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  filteredClaimTypes: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();
  filteredClaimStatuses: Observable<TypeaheadInput[]> = new Observable<TypeaheadInput[]>();

  sector: UntypedFormControl = new UntypedFormControl();
  sectors: UntypedFormControl = new UntypedFormControl();

  grant: UntypedFormControl = new UntypedFormControl();
  grants: UntypedFormControl = new UntypedFormControl();

  contract: UntypedFormControl = new UntypedFormControl();
  contracts: UntypedFormControl = new UntypedFormControl();

  priority: UntypedFormControl = new UntypedFormControl();
  priorities: UntypedFormControl = new UntypedFormControl();

  source: UntypedFormControl = new UntypedFormControl();
  sources: UntypedFormControl = new UntypedFormControl();

  fundSource: UntypedFormControl = new UntypedFormControl();
  fundSources: UntypedFormControl = new UntypedFormControl();

  currency: UntypedFormControl = new UntypedFormControl();
  currencies: UntypedFormControl = new UntypedFormControl();

  contractor: UntypedFormControl = new UntypedFormControl();
  contractors: UntypedFormControl = new UntypedFormControl();

  contractorUser: UntypedFormControl = new UntypedFormControl();
  contractorUsers: UntypedFormControl = new UntypedFormControl();

  claimType: UntypedFormControl = new UntypedFormControl();
  claimTypes: UntypedFormControl = new UntypedFormControl();

  claimStatus: UntypedFormControl = new UntypedFormControl();
  claimStatuses: UntypedFormControl = new UntypedFormControl();

  dropdowns: IDropdownSettings[] = [];

  constructor(
    private request: RequestService,
    private typeaheadService: TypeaheadService,
    private formBuilder: FormBuilder,
    private notify: NotificationService,
    private activatedRouter: ActivatedRoute,
    private router: Router,
    private permissionsService: PermissionsService,
    private dialog: MatDialog
  ) {
    this.permissions = this.permissionsService.get();
  }

  ngAfterContentInit(): void {
    this.loading = false;
  }

  prepareForm(): void {
    if (this.isEditRelatedEntitiesForm) {
      this.form = this.formBuilder.group({
        contracts: new UntypedFormControl(''),
        contractors: new UntypedFormControl(''),
        contractorUsers: new UntypedFormControl(''),
      });
    } else {
      this.form = this.formBuilder.group({
        sectors: new UntypedFormControl(''),
        title: new FormControl('', Validators.required),
        internalReferenceCode: new FormControl(''),
        note: new FormControl(''),
        grants: new UntypedFormControl(''),
        contracts: new UntypedFormControl(''),
        priorities: new UntypedFormControl(''),
        sources: new UntypedFormControl(''),
        fundSources: new UntypedFormControl(''),
        claimedAmount: new FormControl('', Validators.required),
        currencies: new UntypedFormControl(),
        contractors: new UntypedFormControl(),
        contractorUsers: new UntypedFormControl(''),
        statuses: new UntypedFormControl(),
        claimForStartDate: new FormControl<Date | null>(null),
        claimForEndDate: new FormControl<Date | null>(null),
        description: new FormControl(''),
        claimTypes: new UntypedFormControl(''),
        claimStatus: new UntypedFormControl(''),
      });
    }
  }

  ngOnInit(): void {
    if (this.claimDetails) {
      this.isEditRelatedEntitiesForm = true;
      this.getValuesForEditDropdowns();
    } else {
      this.getValuesForDropdowns();
    }

    this.prepareForm();
  }

  getSectorsForFilter() {
    this.request.getEnumValues('SectorType').subscribe((data: any) => {
      this.filteredSectors = this.typeaheadService.filterData(this.sector, data);
    });
  }

  getGrantsForFilter(sector?: number) {
    this.request.getGrantsForFilter(sector).subscribe((data: any) => {
      this.allGrants = data;
      this.filteredGrants = this.typeaheadService.filterData(this.grant, this.allGrants);
    });
  }

  getContractsForFilter(sector?: number, grantId?: number) {
    this.request.getContractsForFilter(sector, grantId).subscribe((data: any) => {
      this.allContracts = data;
      this.filteredContracts = this.typeaheadService.filterData(this.contract, this.allContracts);
    });
  }

  getExternalEntitiesForFilter(sector?: number, grantId?: number, contractId?: number) {
    this.request.getExternalEntitiesForFilter(sector, grantId, contractId).subscribe((data: any) => {
      this.allContractors = data;
      this.filteredContractors = this.typeaheadService.filterData(this.contractor, this.allContractors);
    });
  }

  getExternalEntityUsersForFilter(externalEntityId: number) {
    this.request.getExternalEntityUsersForFilter(externalEntityId).subscribe((data: any) => {
      this.allContractorUsers = data;
      this.filteredContractorUsers = this.typeaheadService.filterData(this.contractorUser, this.allContractorUsers);
      this.displayContractorUsersDropdown = true;
    });
  }

  getPrioritiesForFilter() {
    this.request.getEnumValues('PriorityType').subscribe((data: any) => {
      this.filteredPriorities = this.typeaheadService.filterData(this.priority, data);
    });
  }

  getClaimTypesForFilter() {
    this.request.getEnumValues('ContractType').subscribe((data: any) => {
      this.filteredClaimTypes = this.typeaheadService.filterData(this.claimType, data);
    });
  }

  getSourcesForFilter() {
    this.request.getEnumValues('ClaimSource').subscribe((data: any) => {
      this.filteredSources = this.typeaheadService.filterData(this.source, data);
    });
  }

  getFundSourcesForFilter() {
    this.request.getEnumValues('FundSourceType').subscribe((data: any) => {
      this.filteredFundSources = this.typeaheadService.filterData(this.source, data);
    });
  }

  getCurrenciesForFilter() {
    this.request.getEnumValues('CurrencyCode').subscribe((data: any) => {
      this.filteredCurrencies = this.typeaheadService.filterData(this.currency, data);
    });
  }

  getClaimStatusesForFilter() {
    this.request.getEnumValues('ClaimStatus').subscribe((data: any) => {
      this.filteredClaimStatuses = this.typeaheadService.filterData(this.claimStatus, data);
    });
  }

  private async getValuesForDropdowns() {
    this.getSectorsForFilter();
    this.getGrantsForFilter();
    this.getContractsForFilter();
    this.getExternalEntitiesForFilter();
    this.getPrioritiesForFilter();
    this.getClaimTypesForFilter();
    this.getSourcesForFilter();
    this.getCurrenciesForFilter();
    this.getFundSourcesForFilter();
    this.loading = false;
  }

  private async getValuesForEditDropdowns() {
    // For edit related entities form, we only need contracts and related dropdowns
    // Load all contracts initially, then filtering will happen via search
    this.getContractsForFilter();
    this.getExternalEntitiesForFilter(
      undefined,
      undefined,
      this.claimDetails.contractId ?? undefined
    );
    if (this.claimDetails.contract?.externalEntityId)
      this.getExternalEntityUsersForFilter(this.claimDetails.contract?.externalEntityId);
    
    if (this.claimDetails.contractId) {
      this.request.getContract(this.claimDetails.contractId).subscribe((resp) => {
        this.contractDetails = resp as Contract;
      });
    }
    
    this.loading = false;
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  getFormValidationErrors() {
    if (this.form.invalid) {
      this.notify.showError('Please fill in all required fields correctly.');
      return;
    }
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.getFormValidationErrors();
      return;
    }
    if (!this.sectors.value) {
      this.notify.showError('Please select a sector.');
      return;
    }

    if (!this.currencies.value) {
      this.notify.showError('Please select a currency.');
      return;
    }

    if (!this.grants.value) {
      this.notify.showError('Please select a grant.');
      return;
    }

    if (!this.contracts.value) {
      this.notify.showError('Please select a contract.');
      return;
    }

    let claimRequest: any;

    if (this.permissions?.CanAccessAsClaimant) {
      if (this.claimsForSelectedContract) {
        this.notify.showError('Please select a contract with no claims assigned.');
        return;
      }
  
      claimRequest = {
        title: this.form.controls['title'].value,
        sector: this.sectors.value,
        claimedAmount: this.form.controls['claimedAmount'].value,
        currencyId: this.currencies.value,
        description: this.form.controls['description'].value,
        claimForStartDate:
          this.form.controls['claimForStartDate'].value === null
            ? null
            : this.form.controls['claimForStartDate'].value.toISOString(),
        claimForEndDate:
          this.form.controls['claimForEndDate'].value === null
            ? null
            : this.form.controls['claimForEndDate'].value.toISOString(),
        claimDataToValidate: {
          grantDetails: this.grants.value,
          contractDetails: this.contracts.value,
        },
      };
    } else {
      if (!this.sources.value) {
        this.notify.showError('Please select claim source.');
        return;
      }

      claimRequest = {
        title: this.form.controls['title'].value,
        internalReferenceCode: this.form.controls['internalReferenceCode'].value,
        note: this.form.controls['note'].value,
        sector: this.sectors.value,
        grantId: this.grants.value,
        linkedClaimantUserId: this.contractorUsers.value,
        contractId: this.contracts.value,
        priority: this.priorities.value,
        source: this.sources.value,
        claimedAmount: this.form.controls['claimedAmount'].value,
        currencyId: this.currencies.value,
        description: this.form.controls['description'].value,
        status: this.claimStatuses.value,
        claimForStartDate:
          this.form.controls['claimForStartDate'].value === null
            ? null
            : this.form.controls['claimForStartDate'].value.toISOString(),
        claimForEndDate:
          this.form.controls['claimForEndDate'].value === null
            ? null
            : this.form.controls['claimForEndDate'].value.toISOString(),
        type: this.claimTypes.value,
      };
    }

    if (this.permissions?.CanAccessAsClaimant) {
      this.loading = true;
      this.request.createClaimantClaim(claimRequest).subscribe((data: any) => {
        if (data) {
          this.notify.showSuccess(`Claim ${data.reference} created successfully! You can now upload documents.`);
          const queryParams = { created: true };
          this.router.navigate([`submission-details/${data.id}`], { queryParams });
        }
      });
    } else {
      this.loading = true;
      this.request.createClaim(claimRequest).subscribe((data: any) => {
        if (data) {
          this.notify.showSuccess(`Claim ${data.reference} created successfully!`);
          this.router.navigate([`claims/${data.id}`]);
        }
      });
    }
  }

  onReset(): void {
    window.location.reload();
  }

  onSectorSelectionChanged(event: any) {
    if (event.source.selected) {
      let sectorValue = (event.source.selected as MatOption).value;

      this.sectors.setValue(sectorValue);
      this.getGrantsForFilter(sectorValue);
      this.getContractsForFilter(sectorValue);
      this.getExternalEntitiesForFilter(sectorValue);
    } else {
      this.getGrantsForFilter();
      this.getContractsForFilter();
      this.getExternalEntitiesForFilter();
    }
    this.grantDetails = undefined;
    this.contractDetails = undefined;
    this.displayContractorUsersDropdown = false;
    this.grants.setValue(null);
    this.contracts.setValue(null);
    this.contractors.setValue(null);
    this.contractorUsers.setValue(null);
    this.claimsForSelectedContract = null;
  }

  onGrantSelectionChanged(event: any) {
    let newGrantValue = event.source?.selected ? (event.source.selected as MatOption).value : event.value;

    if (newGrantValue) {
      this.grants.setValue(newGrantValue);

      if (!this.permissions?.CanAccessAsClaimant) {
        this.request.getGrant(newGrantValue).subscribe((resp) => {
          this.grantDetails = resp as Grant;
        });
      }

      this.getContractsForFilter(undefined, newGrantValue);
      this.getExternalEntitiesForFilter(undefined, newGrantValue);
    } else {
      this.getContractsForFilter();
      this.grantDetails = undefined;
      this.contractDetails = undefined;
    }
    this.claimsForSelectedContract = null;
    this.contracts.setValue(null);
    this.contractors.setValue(null);
    this.contractorUsers.setValue(null);
  }

  onContractSelectionChanged(event: any) {
    let contractValue = event.source?.selected ? (event.source.selected as MatOption).value : event.value;
    
    if (!this.isEditRelatedEntitiesForm) {
      this.checkIfClaimExistsForContract(contractValue);
    }

    if (contractValue) {
      this.contracts.setValue(contractValue);
      if (!this.permissions?.CanAccessAsClaimant) {
        this.request.getContract(contractValue).subscribe((resp) => {
          this.contractDetails = resp as Contract;
        });
        this.getExternalEntitiesForFilter(undefined, undefined, contractValue);
      }
    } else {
      this.getExternalEntitiesForFilter();
      this.contractDetails = undefined;
    }
    this.contractors.setValue(null);
    this.contractorUsers.setValue(null);
  }

  checkIfClaimExistsForContract(contractId: number) {
    this.request.getClaimsByContract(contractId).subscribe((resp: any) => {
      this.claimsForSelectedContract = resp && resp.length ? resp : null;
      if (this.checkIfClaimExistsForContract.length) {
        var message = '';
        if (this.permissions.CanAccessAsClaimant) {
          message = `You already have at least one other claim for the selected contract: ${this.claimsForSelectedContract
            .map((claim: any) => claim.reference)
            .join(', ')}. 
            New claims can only be submitted for contracts without existing claims.`;
        } else {
          message = `There are claims linked to the selected contract, please check the claims before submitting a new one: ${this.claimsForSelectedContract
            .map((claim: any) => claim.reference)
            .join(', ')}`;
        }

        this.dialog.open(MessageModalComponent, {
          width: '25em',
          data: {
            type: 'warn',
            title: 'Existing claims',
            message: message,
          },
        });
      }
    });
  }

  onExternalEntitySelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      let contractorValue = (event.source.selected as MatOption).value;
      if (contractorValue) {
        if (!this.permissions?.CanAccessAsClaimant) {
          this.getExternalEntityUsersForFilter(contractorValue);
        }
      }
    }
  }

  onStatusSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.claimStatuses.setValue((event.source.selected as MatOption).value);
    }
  }

  onContractorUserSelectionChanged(event: MatSelectChange | any) {
    if (event.source.selected) {
      this.contractorUsers.setValue((event.source.selected as MatOption).value);
    }
  }

  onPrioritiesSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.priorities.setValue((event.source.selected as MatOption).value);
    }
  }

  onClaimTypeSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.claimTypes.setValue((event.source.selected as MatOption).value);
    }
  }

  onSourcesSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.sources.setValue((event.source.selected as MatOption).value);
    }
  }

  onFundSourcesSelectionChanged(event: MatSelectChange) {
    if (event.source.selected) {
      this.fundSources.setValue((event.source.selected as MatOption).value);
    }
  }

  onCurrencySelectionChanged(ev: MatSelectChange) {
    if (ev.source.selected) {
      this.currencies.setValue((ev.source.selected as MatOption).value);
    }
  }
}
