import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { forkJoin } from 'rxjs';
import { ClaimStageService } from '../../services/claim-stage.service';
import { 
  ClaimStageHistoryResponseModel, 
  ClaimStageResponseModel, 
  MoveClaimStageRequestModel 
} from '../../models/claim-stage.models';
import { MoveClaimStageDialogComponent } from './move-claim-stage-dialog/move-claim-stage-dialog.component';

@Component({
  selector: 'app-claim-stage-tracker',
  templateUrl: './claim-stage-tracker.component.html',
  styleUrls: ['./claim-stage-tracker.component.css']
})
export class ClaimStageTrackerComponent implements OnInit, OnChanges {
  @Input() claimId!: number;
  @Input() readonly = false;
  @Output() stageChanged = new EventEmitter<void>();

  stageHistory: ClaimStageHistoryResponseModel[] = [];
  currentStage: ClaimStageHistoryResponseModel | null = null;
  availableStages: ClaimStageResponseModel[] = [];
  loading = false;
  expandedHistory = false;

  constructor(
    private claimStageService: ClaimStageService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.loadData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['claimId'] && !changes['claimId'].firstChange) {
      this.loadData();
    }
  }

  loadData(): void {
    if (!this.claimId) return;
    
    this.loading = true;
    
    forkJoin({
      history: this.claimStageService.getClaimStageHistory(this.claimId),
      stages: this.claimStageService.getActiveStages()
    }).subscribe({
      next: ({ history, stages }) => {
        this.stageHistory = history || [];
        this.availableStages = stages || [];
        this.currentStage = this.stageHistory.find(h => h.isCurrentStage) || null;
        this.calculateStageProgressPercentages();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading stage data:', error);
        this.snackBar.open('Error loading stage information', 'Close', { duration: 3000 });
        this.loading = false;
      }
    });
  }

  moveToNextStage(): void {
    if (this.readonly) return;

    let availableStages: ClaimStageResponseModel[];

    if (!this.currentStage) {
      availableStages = this.getRootStages();
    } else {
      const currentStageInfo = this.findStageInfo(this.currentStage.claimStageId);
      if (!currentStageInfo) return;
      availableStages = this.getNextAvailableStages(currentStageInfo);
    }
    
    if (availableStages.length === 0) {
      const message = !this.currentStage 
        ? 'No stages available for assignment' 
        : 'No next stages available';
      this.snackBar.open(message, 'Close', { duration: 3000 });
      return;
    }

    const dialogRef = this.dialog.open(MoveClaimStageDialogComponent, {
      width: '500px',
      data: {
        claimId: this.claimId,
        currentStage: this.currentStage,
        availableStages: availableStages
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadData();
        this.stageChanged.emit();
        const message = !this.currentStage 
          ? 'Initial stage assigned successfully' 
          : 'Claim moved to next stage successfully';
        this.snackBar.open(message, 'Close', { duration: 3000 });
      }
    });
  }

  toggleHistoryExpansion(): void {
    this.expandedHistory = !this.expandedHistory;
  }

  private getRootStages(): ClaimStageResponseModel[] {
    return this.availableStages.filter(stage => !stage.parentStageId);
  }

  getStageProgress(): number {
    if (this.stageHistory.length === 0) return 0;
    
    const completedWeight = this.getCompletedWeight();
    const totalWeight = this.getTotalLeafWeight();
    
    return totalWeight > 0 ? Math.round((completedWeight / totalWeight) * 1000) / 10 : 0;
  }

  private getCompletedWeight(): number {
    let completedWeight = 0;
    
    for (const history of this.stageHistory.filter(h => h.completedDate)) {
      const stageInfo = this.findStageInfo(history.claimStageId);
      if (stageInfo && this.isLeafStage(stageInfo)) {
        completedWeight += stageInfo.weightPercentage || 0;
      }
    }
    
    return completedWeight;
  }

  private getTotalLeafWeight(): number {
    let totalWeight = 0;
    
    const addWeightRecursive = (stage: ClaimStageResponseModel) => {
      if (this.isLeafStage(stage)) {
        totalWeight += stage.weightPercentage || 0;
      } else {
        stage.children.forEach(child => addWeightRecursive(child));
      }
    };
    
    this.availableStages
      .filter(stage => !stage.parentStageId)
      .forEach(stage => addWeightRecursive(stage));
    
    return totalWeight;
  }

  private isLeafStage(stage: ClaimStageResponseModel): boolean {
    return !stage.hasChildren || stage.children.length === 0;
  }

  private calculateStageProgressPercentages(): void {
    const totalWeight = this.getTotalLeafWeight();
    let cumulativeWeight = 0;
    
    for (let i = 0; i < this.stageHistory.length; i++) {
      const history = this.stageHistory[i];
      const stageInfo = this.findStageInfo(history.claimStageId);
      
      if (stageInfo && this.isLeafStage(stageInfo)) {
        if (history.completedDate) {
          cumulativeWeight += stageInfo.weightPercentage || 0;
        }
        
        history.progressPercentage = totalWeight > 0 ? Math.round((cumulativeWeight / totalWeight) * 1000) / 10 : 0;
        
        if (history.isCurrentStage && !history.completedDate) {
          const stageWeight = stageInfo.weightPercentage || 0;
          const timeProgress = this.calculateTimeBasedProgress(history);
          
          history.progressPercentage = totalWeight > 0 ? 
            Math.round(((cumulativeWeight + (stageWeight * timeProgress)) / totalWeight) * 1000) / 10 : 0;
        }
      } else {
        history.progressPercentage = totalWeight > 0 ? Math.round((cumulativeWeight / totalWeight) * 1000) / 10 : 0;
      }
    }
  }

  private calculateTimeBasedProgress(history: ClaimStageHistoryResponseModel): number {
    if (!history.estimatedCompletionDate) return 0;
    
    const startTime = new Date(history.startDate).getTime();
    const estimatedEndTime = new Date(history.estimatedCompletionDate).getTime();
    const currentTime = Date.now();
    
    if (estimatedEndTime <= startTime) return 0;
    
    const elapsed = currentTime - startTime;
    const total = estimatedEndTime - startTime;
    
    return Math.min(Math.max(elapsed / total, 0), 1);
  }

  private findStageInfo(stageId: number): ClaimStageResponseModel | null {
    const parentStage = this.availableStages.find(s => s.id === stageId);
    if (parentStage) return parentStage;

    for (const parent of this.availableStages) {
      const childStage = parent.children.find(c => c.id === stageId);
      if (childStage) return childStage;
    }

    return null;
  }

  private getNextAvailableStages(currentStageInfo: ClaimStageResponseModel): ClaimStageResponseModel[] {
    const nextStages: ClaimStageResponseModel[] = [];

    if (currentStageInfo.parentStageId) {
      const parentStage = this.availableStages.find(s => s.id === currentStageInfo.parentStageId);
      if (parentStage) {
        const currentIndex = parentStage.children.findIndex(c => c.id === currentStageInfo.id);
        if (currentIndex >= 0 && currentIndex < parentStage.children.length - 1) {
          nextStages.push(parentStage.children[currentIndex + 1]);
        } else {
          const parentIndex = this.availableStages.findIndex(s => s.id === parentStage.id);
          if (parentIndex >= 0 && parentIndex < this.availableStages.length - 1) {
            const nextParent = this.availableStages[parentIndex + 1];
            if (nextParent.children.length > 0) {
              nextStages.push(nextParent.children[0]);
            } else {
              nextStages.push(nextParent);
            }
          }
        }
      }
    } else {
      const currentIndex = this.availableStages.findIndex(s => s.id === currentStageInfo.id);
      if (currentIndex >= 0) {
        if (currentStageInfo.children.length > 0) {
          nextStages.push(currentStageInfo.children[0]);
        } else if (currentIndex < this.availableStages.length - 1) {
          const nextParent = this.availableStages[currentIndex + 1];
          if (nextParent.children.length > 0) {
            nextStages.push(nextParent.children[0]);
          } else {
            nextStages.push(nextParent);
          }
        }
      }
    }

    return nextStages.filter(stage => stage.isActive);
  }

  getStageStatusClass(stage: ClaimStageHistoryResponseModel): string {
    if (stage.isCurrentStage) return 'current';
    if (stage.completedDate) return 'completed';
    return 'pending';
  }

  formatDuration(stage: ClaimStageHistoryResponseModel): string {
    if (stage.completedDate) {
      const days = stage.actualDurationDays || 0;
      return days === 1 ? '1 day' : `${days} days`;
    } else if (stage.isCurrentStage) {
      const startDate = new Date(stage.startDate);
      const now = new Date();
      const timeDiff = now.getTime() - startDate.getTime();
      const daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
      
      if (daysDiff === 0) {
        const hoursDiff = Math.floor(timeDiff / (1000 * 60 * 60));
        if (hoursDiff === 0) {
          const minutesDiff = Math.floor(timeDiff / (1000 * 60));
          return minutesDiff <= 1 ? 'Just started' : `${minutesDiff} minutes (ongoing)`;
        }
        return hoursDiff === 1 ? '1 hour (ongoing)' : `${hoursDiff} hours (ongoing)`;
      }
      
      return daysDiff === 1 ? '1 day (ongoing)' : `${daysDiff} days (ongoing)`;
    }
    return '';
  }
}
