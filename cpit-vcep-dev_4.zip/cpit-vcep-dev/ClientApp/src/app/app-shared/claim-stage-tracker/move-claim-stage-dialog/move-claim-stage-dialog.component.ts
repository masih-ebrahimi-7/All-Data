import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ClaimStageService } from '../../../services/claim-stage.service';
import { 
  ClaimStageHistoryResponseModel, 
  ClaimStageResponseModel, 
  MoveClaimStageRequestModel 
} from '../../../models/claim-stage.models';

export interface MoveClaimStageDialogData {
  claimId: number;
  currentStage: ClaimStageHistoryResponseModel | null;
  availableStages: ClaimStageResponseModel[];
}

@Component({
  selector: 'app-move-claim-stage-dialog',
  templateUrl: './move-claim-stage-dialog.component.html',
  styleUrls: ['./move-claim-stage-dialog.component.css']
})
export class MoveClaimStageDialogComponent implements OnInit {
  form: FormGroup;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private claimStageService: ClaimStageService,
    private dialogRef: MatDialogRef<MoveClaimStageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: MoveClaimStageDialogData
  ) {
    this.form = this.createForm();
  }

  ngOnInit(): void {
    if (this.data.availableStages.length === 1) {
      this.form.patchValue({
        toStageId: this.data.availableStages[0].id
      });
    }

    this.form.get('toStageId')?.valueChanges.subscribe(stageId => {
      if (stageId) {
        const selectedStage = this.data.availableStages.find(s => s.id === stageId);
        if (selectedStage) {
          const estimatedDate = new Date();
          if (selectedStage.estimatedDurationWeeks)
            estimatedDate.setDate(estimatedDate.getDate() + ((selectedStage.estimatedDurationWeeks || 1) * 7));
          this.form.patchValue({
            estimatedCompletionDate: estimatedDate
          });
        }
      }
    });
  }

  private createForm(): FormGroup {
    return this.fb.group({
      toStageId: [null, [Validators.required]],
      notes: ['', [Validators.maxLength(2000)]],
      estimatedCompletionDate: [null]
    });
  }

  onSubmit(): void {
    if (this.form.valid) {
      this.loading = true;
      
      const request: MoveClaimStageRequestModel = {
        claimId: this.data.claimId,
        toStageId: this.form.value.toStageId,
        notes: this.form.value.notes || undefined,
        estimatedCompletionDate: this.form.value.estimatedCompletionDate || undefined
      };

      this.claimStageService.moveClaimToStage(request).subscribe({
        next: () => {
          this.loading = false;
          this.dialogRef.close(true);
        },
        error: (error) => {
          console.error('Error moving claim to stage:', error);
          this.loading = false;
        }
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }

  getSelectedStageInfo(): ClaimStageResponseModel | null {
    const stageId = this.form.get('toStageId')?.value;
    return stageId ? this.data.availableStages.find(s => s.id === stageId) || null : null;
  }

  getEstimatedDuration(): string {
    const selectedStage = this.getSelectedStageInfo();
    if (selectedStage) {
      const weeks = selectedStage.estimatedDurationWeeks;
      return weeks === 1 ? '1 week' : `${weeks} weeks`;
    }
    return '';
  }
}
