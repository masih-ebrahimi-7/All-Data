import {
  HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor,
  HttpRequest, HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoaderService } from '../services/loader.service';
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  count = 0;
  constructor(private loadingService: LoaderService, private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (req.url != "/api/user-notifications" && req.url != "/api/my-tasks" && req.url != "/api/claims?outputType=awaiting-clearance") {
      this.loadingService.setLoading('true');
    }
    this.count++;
    let path = window.location.pathname.substring(0);
    let storedPath: any = localStorage.getItem('path') || '';
    if (!storedPath?.split(',').includes(path)) {
      storedPath ? localStorage.setItem('path', path + ',' + storedPath) : localStorage.setItem('path', path);
    }

    const token = localStorage.getItem('token');
    let nextHandle = next.handle(req);
    if (token) {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', 'Bearer ' + token),
      });
      nextHandle = next.handle(cloned);
    }
    return nextHandle.pipe(
      tap(
        (response: any) => {
          if (response instanceof HttpResponse && response.ok) {
            this.count--;
            if (this.count <= 0) this.loadingService.setLoading('false');

            this.setPath(storedPath, path);
          }
          return response;
        },
        (err: any) => {
          if (err instanceof HttpErrorResponse && (err.status === 403 || err.status === 401)) {
            this.router.navigate(['']);
            this.setPath(storedPath, path);
          } else if (err.status === 500) {
            this.setPath(storedPath, path);
          } else {
            this.setPath(storedPath, path);
          }
          this.count--;
          if (this.count <= 0) this.loadingService.setLoading('false');
        }
      )
    );
  }

  setPath(storedPath: string, path: string) {
    if (storedPath) {
      localStorage.setItem('path', this.removeValue(storedPath, path));
    }
  }

  removeValue(list: string, value: string) {
    return list.replace(new RegExp(',?' + value + ',?'), function (match) {
      var first_comma = match.charAt(0) === ',',
        second_comma;

      if (first_comma && (second_comma = match.charAt(match?.length - 1) === ',')) {
        return ',';
      }
      return '';
    });
  }
}
