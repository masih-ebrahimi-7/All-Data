import {
  ChangeDetectionStrategy, ChangeDetectorRef, Component, Input,
  OnInit, QueryList, ViewChildren
} from '@angular/core';
import { Router } from '@angular/router';
import { UserProfileService } from 'src/app/services/auth/user-profile.service';
import { LoaderService } from 'src/app/services/loader.service';
import { RequestService } from 'src/app/services/request.service';
import { PermissionsService } from '../../services/auth/permissions.service';
import { TokenService } from '../../services/auth/token.service';
import { AuthService } from '@auth0/auth0-angular';
@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopnavComponent implements OnInit {
  @Input()
  isLoggedIn: boolean;
  isImpersonation: boolean;
  lang: any;
  permissions: any | null;
  @Input()
  menuItems: any;
  selectedMenuItem: string;
  userInfo: any;
  @Input() deviceXs: boolean;
  @ViewChildren('subMenusActive') subMenusActive: QueryList<any>;
  notifications: any[];
  unread: number;
  isPageLoaded: boolean = false;

  constructor(
    private tokenService: TokenService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private permissionService: PermissionsService,
    private request: RequestService,
    private userProfileService: UserProfileService,
    private loaderService: LoaderService,
    private authService: AuthService,
  ) {
    this.isLoggedIn = this.tokenService.loggedIn();
    this.permissions = permissionService.get();
    this.isImpersonation = permissionService.isImpersonation();
    this.selectedMenuItem = 'nav.allORs';
    this.userInfo = userProfileService.get();
  }
  isExpanded: boolean = false;

  onClickMenuItem(item: any) {
    this.selectedMenuItem = item.label;
  }
  logOut() {
    this.tokenService.clear();
    this.authService.logout({ logoutParams: { returnTo: window.location.origin } });
  }
  manageNotification() {
    this.router.navigate(['/manage-profile']);
  }
  ngOnInit() {
    this.lang = localStorage.getItem('lang') || 'en';
    this.isPageLoaded = true;
    this.cd.detach();
    setInterval(() => {
      this.isLoggedIn = this.tokenService.loggedIn();
      this.cd.detectChanges();
    }, 1000);

    setInterval(async () => {
      if (this.isLoggedIn) {
        return new Promise<void>((resolve, reject) => {
          var files: any = [];
          this.request.getUserNotifications().subscribe((data: any) => {
            this.unread = data.totalCount;
            this.notifications = data.records;
            return resolve();
          });
        });
      }
    }, 15000);
  }

  onNotificationClick(notification: any) {
    this.request.markNotificationsAsReadOrUnread({ entityIds: [notification.id], read: true }).subscribe((data: any) => {
      this.router.navigate([notification.url]);
    });
  }

  changeLang(lang: any) {
    localStorage.setItem('lang', lang);
    window.location.reload();
  }

  stopImpersonation() {
    this.loaderService.setLoading('true');
    this.request.stopImpersonation().subscribe((res: any) => {
      this.tokenService.set(res.token);
      this.permissionService.set(res.permissions);
      localStorage.removeItem('impersonator');
      this.router.navigate(['/']);
      window.location.reload();
    });
  }

  isChildActive(menuItem: any) {
    return (
      this.subMenusActive != null &&
      this.subMenusActive.filter((a) => a.isActive && menuItem.label == a.element.nativeElement.getAttribute('parent'))
        ?.length > 0
    );
  }
}
