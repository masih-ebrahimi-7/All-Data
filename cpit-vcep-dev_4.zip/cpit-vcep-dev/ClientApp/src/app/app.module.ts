import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, ErrorHandler, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GoogleMapsModule } from '@angular/google-maps';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MAT_RADIO_DEFAULT_OPTIONS } from '@angular/material/radio';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatStepperModule } from '@angular/material/stepper';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { MentionModule } from 'angular-mentions';
import { NgChartsModule } from 'ng2-charts';
import { NgcCookieConsentConfig, NgcCookieConsentModule } from 'ngx-cookieconsent';
import {
  MatSelectSearchOptions, MAT_SELECTSEARCH_DEFAULT_OPTIONS, NgxMatSelectSearchModule
} from 'ngx-mat-select-search';
import { environment as env } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DropzoneCdkModule } from '@ngx-dropzone/cdk';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { AuthHttpInterceptor, AuthModule } from '@auth0/auth0-angular';
// admin
import { AddExternalEntityUserComponent } from './app-internal/admin/users/add-external-entity-user/add-external-entity-user.component';
import { AssignRolesComponent } from './app-internal/admin/users/assign-roles/assign-roles.component';
import { LinkUserToExternalComponent } from './app-internal/admin/users/link-to-external/link-to-external.component';
import { UsersComponent } from './app-internal/admin/users/users.component';
import { ExternalEntityDetailComponent } from './app-internal/external-entities/external-entity-detail/external-entity-detail.component';
import { ListExternalEntitiesComponent } from './app-internal/external-entities/list-external-entities/list-external-entities.component';

import { ErrorLogComponent } from './app-shared/help/error-log/error-log.component';
import { IssueDetailComponent } from './app-shared/help/issue-detail/issue-detail.component';
import { ListIssuesComponent } from './app-shared/help/list-issues/list-issues.component';
import { HomeComponent } from './app-shared/home/home.component';
import { LanguageInterceptor } from './interceptors/language.interceptor';
import { MaterialModule } from './material-module';
import { TopnavComponent } from './nav-menu/topnav/topnav.component';

//================ claimant app module
import { ClaimantHelpComponent } from './app-claimant/help/help.component';
import { ManageProfileComponent } from './app-claimant/profile/manage-profile/manage-profile.component';

//====================== common module
import { ErrorPageComponent } from './app-shared/error-page/error-page.component';
import { InternalErrorComponent } from './app-shared/error-page/internal-error/internal-error.component';
import { DateonlyPickerComponent } from './common/dateonly-picker/dateonly-picker.component';
import { DetailPageComponent } from './common/detail-page/detail-page.component';
import { FiltersComponent } from './common/filters/filters.component';
import { FormComponent } from './common/form/form.component';
import { InputComponent } from './common/inputs/input.component';
import { TextInputComponent } from './common/inputs/text-input/text-input.component';
import { LoaderComponent } from './common/loader/loader.component';
import { SimpleLoaderComponent } from './common/simple-loader/simple-loader.component';
import { ActionListComponent } from './common/outputs/action-list/action-list.component';
import { CardsComponent } from './common/outputs/cards/cards.component';
import { DetailsActionListComponent } from './common/outputs/details-action-list/details-action-list.component';
import { OutputComponent } from './common/outputs/output/output.component';
import { DateFormatPipe } from './common/pipes/date-format.pipe';
import { DateTimeFormatPipe } from './common/pipes/datetime-format.pipe';
import { ToPrettyAmountNumberPipe } from './common/pipes/toPrettyAmountPipe';
import { ToPrettyAmountNumberPipeMXN } from './common/pipes/toPrettyAmountPipeMXN';
import { TruncatePipe } from './common/pipes/truncate.pipe';
import { SafePipe } from './common/pipes/safe.pipe';
import { SelectDropdownComponent } from './common/reusable-form-components/select-dropdown/select-dropdown.component';
import { TableComponent } from './common/table/table.component';
import { DynamicTreeComponent } from './common/tree/dynamic-tree/dynamic-tree.component';
import { UploaderProgressComponent } from './common/uploader/uploader-progress/uploader-progress.component';
import { UploaderComponent } from './common/uploader/uploader.component';
import { GlobalErrorHandler } from './error-handler';
import { PrivacyComponent } from './privacy/privacy.component';
import { WarningDialogComponent } from './common/dialogs/warning-dialog/warning-dialog.component';
import { TableSettingsDialogComponent } from './common/table/table-settings-dialog/table-settings-dialog.component';
import { MessageModalComponent } from './common/dialogs/message-modal/message-modal.component';

// internal app module
import { DocumentCategoriesComponent } from './app-internal/admin/documents/document-categories.component';
import { EditDocumentCategoryComponent } from './app-internal/admin/documents/edit-document-category/edit-document-category.component';
import { ClaimStagesComponent } from './app-internal/admin/claim-stages/claim-stages.component';
import { EditClaimStageDialogComponent } from './app-internal/admin/claim-stages/edit-claim-stage-dialog/edit-claim-stage-dialog.component';
import { ClaimStageTrackerComponent } from './app-shared/claim-stage-tracker/claim-stage-tracker.component';
import { MoveClaimStageDialogComponent } from './app-shared/claim-stage-tracker/move-claim-stage-dialog/move-claim-stage-dialog.component';
import { ConfirmDialogComponent } from './common/confirm-dialog/confirm-dialog.component';
import { AdvanceAccountsComponent } from './app-internal/output-two/advance-accounts/advance-accounts.component';
import { ContractorsComponent } from './app-internal/contractors/contractors.component';
import { ContractDetailsComponent } from './app-internal/contracts/contract-details/contract-details.component';
import { ContractsComponent } from './app-internal/contracts/contracts.component';
import { GrantDetailsComponent } from './app-internal/grants/grant-details/grant-details.component';
import { GrantsComponent } from './app-internal/grants/grants.component';
import { InvoiceDetailsComponent } from './app-internal/invoices/invoice-details/invoice-details.component';
import { InvoicesComponent } from './app-internal/invoices/invoices.component';
import { MapViewComponent } from './app-internal/map-view/map-view.component';
import { ProjectAgreementsComponent } from './app-internal/output-two/project-agreements/project-agreements.component';
import { WithdrawalApplicationsComponent } from './app-internal/output-two/withdrawal-applications/withdrawal-applications.component';
import { ClaimDetailsComponent } from './app-shared/claims/claim-details/claim-details.component';
import { ClaimTimelineComponent } from './app-shared/claims/claim-details/claim-timeline/claim-timeline.component';
import { ClaimsComponent } from './app-shared/claims/claims.component';
import { CreateClaimComponent } from './app-shared/claims/create-claim/create-claim.component';
import { AddRemarkDialogComponent } from './common/dialogs/add-remark-dialog/add-remark-dialog.component';
import { UserDialogComponent } from './common/dialogs/user-dialog/user-dialog.component';
import { NotificationsComponent } from './notifications/list-notifications/list-notifications.component';
import { UploadEntityDocumentComponent } from './upload-entity-document/upload-entity-document.component';
import { ClaimAuditComponent } from './app-shared/claims/claim-details/claim-audit/claim-audit.component';
import { ClaimRemarkComponent } from './app-shared/claims/claim-details/claim-remark/claim-remark.component';
import { SimplifiedClaimDetailsComponent } from './app-shared/claims/simplified-claim-details/simplified-claim-details.component';
import { AccessDeniedComponent } from './app-shared/error-page/access-denied/access-denied.component';
import { AuthInterceptor } from './auth/auth.interceptor';
import { UpdateDialogComponent } from './common/dialogs/update-dialog/update-dialog.component';
import { AutocompleteDropdownComponent } from './common/reusable-form-components/autocomplete-dropdown/autocomplete-dropdown.component';

// Shared
import { TasksListComponent } from './app-shared/tasks/tasks-list.component';
import { TaskDetailsComponent } from './app-shared/tasks/task-details/task-details.component';
import { ClaimLeadFinanceReportComponent } from './app-shared/claims/claim-details/claim-lead-finance-report/claim-lead-finance-report.component';
import { ClaimLeadLegalReportComponent } from './app-shared/claims/claim-details/claim-lead-legal-report/claim-lead-legal-report.component';
import { ClaimLeadContractsReportComponent } from './app-shared/claims/claim-details/claim-lead-contracts-report/claim-lead-contracts-report.component';
import { ClaimLeadTechnicalReportComponent } from './app-shared/claims/claim-details/claim-lead-technical-report/claim-lead-technical-report.component';
import { GoogleMapComponent } from './common/google-map/google-map.component';
import { EmbeddedDashboardComponent } from './app-internal/summary-dashboard/embedded-dashboard/embedded-dashboard.component';
import { FullPageLoaderComponent } from './common/full-page-loader/full-page-loader.component';
import { CurrencyRatesComponent } from './app-internal/admin/currency-rates/currency-rates.component';
import { CurrencyRateHistoryDialogComponent } from './app-internal/admin/currency-rates/currency-rate-history-dialog/currency-rate-history-dialog.component';
import { CurrencyRateDialogComponent } from './app-internal/admin/currency-rates/currency-rate-dialog/currency-rate-dialog.component';
import { RelatedEntitiesModalComponent } from './app-shared/claims/claim-details/related-entities-modal/related-entities-modal.component';
import { ClaimReplyComponent } from './app-shared/claims/claim-details/claim-remark/claim-reply/claim-reply.component';
import { ClaimDocumentsComponent } from './app-shared/claims/claim-details/claim-documents/claim-documents.component';
import { BulkSubClaimLinkDialogComponent } from './app-shared/claims/claim-details/claim-documents/bulk-subclaim-link-dialog/bulk-subclaim-link-dialog.component';
import { ErrorDialogComponent } from './app-shared/error-page/error-dialog/error-dialog.component';
import { ExpensesComponent } from './app-internal/output-two/expenses/expenses.component';
import { ExpenseDetailsComponent } from './app-internal/output-two/expenses/expense-details/expense-details.component';
import { AdvanceAccountDetailsComponent } from './app-internal/output-two/advance-accounts/advance-account-details/advance-account-details.component';
import { PmoSalariesComponent } from './app-internal/output-two/pmo-salaries/pmo-salaries.component';
import { StaffComponent } from './app-internal/output-two/pmo-salaries/staff/staff.component';
import { StaffContractsComponent } from './app-internal/output-two/pmo-salaries/staff-contracts/staff-contracts.component';
import { PmoSalariesDetailsComponent } from './app-internal/output-two/pmo-salaries/pmo-salaries-details/pmo-salaries-details.component';
import { UserGuideComponent } from './app-shared/help/user-guide/user-guide.component';
import { FullNoteDialogComponent } from './app-shared/claims/claim-details/full-note-dialog/full-note-dialog.component';
import { DriveUploaderComponent } from './common/uploader/drive-uploader/drive-uploader.component';
import { Output1ConsolidatedPlanProgressComponent } from './app-internal/summaries/output1-consolidated-plan-progress/output1-consolidated-plan-progress.component';
import { SubClaimsComponent } from './app-shared/claims/claim-details/subclaims/subclaims.component';

const cookieConfig: NgcCookieConsentConfig = {
  palette: {
    popup: {
      background: '#fff',
      text: '#0d0d0d',
    },
    button: {
      background: "#fec62c",
      text: "#000000",
      border: "transparent"
    }
  },
  theme: 'edgeless',
  type: 'opt-out',
};

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ErrorPageComponent,
    FormComponent,
    UsersComponent,
    TableComponent,
    DynamicTreeComponent,
    AssignRolesComponent,
    LoaderComponent,
    SimpleLoaderComponent,
    TopnavComponent,
    ToPrettyAmountNumberPipe,
    ToPrettyAmountNumberPipeMXN,
    UploaderComponent,
    DriveUploaderComponent,
    UploaderProgressComponent,
    ClaimantHelpComponent,
    ManageProfileComponent,
    UserDialogComponent,
    AddRemarkDialogComponent,
    ErrorLogComponent,
    ListIssuesComponent,
    IssueDetailComponent,
    InternalErrorComponent,
    DateFormatPipe,
    DateTimeFormatPipe,
    TruncatePipe,
    SafePipe,
    PrivacyComponent,
    LinkUserToExternalComponent,
    DateonlyPickerComponent,
    ExternalEntityDetailComponent,
    ListExternalEntitiesComponent,
    TextInputComponent,
    CardsComponent,
    OutputComponent,
    FiltersComponent,
    InputComponent,
    ActionListComponent,
    DetailsActionListComponent,
    AddExternalEntityUserComponent,
    NotificationsComponent,
    GrantsComponent,
    GrantDetailsComponent,
    ContractsComponent,
    ExpensesComponent,
    ExpenseDetailsComponent,
    InvoicesComponent,
    ContractDetailsComponent,
    InvoiceDetailsComponent,
    MapViewComponent,
    ContractorsComponent,
    ClaimsComponent,
    CreateClaimComponent,
    ClaimDetailsComponent,
    ClaimTimelineComponent,
    ProjectAgreementsComponent,
    AdvanceAccountsComponent,
    AdvanceAccountDetailsComponent,
    WithdrawalApplicationsComponent,
    UploadEntityDocumentComponent,
    SelectDropdownComponent,
    ClaimAuditComponent,
    ClaimRemarkComponent,
    DetailPageComponent,
    SimplifiedClaimDetailsComponent,
    AccessDeniedComponent,
    AutocompleteDropdownComponent,
    DetailPageComponent,
    DocumentCategoriesComponent,
    EditDocumentCategoryComponent,
    ClaimStagesComponent,
    EditClaimStageDialogComponent,
    ClaimStageTrackerComponent,
    MoveClaimStageDialogComponent,
    ConfirmDialogComponent,
    TasksListComponent,
    TaskDetailsComponent,
    GoogleMapComponent,
    UpdateDialogComponent,
    ClaimLeadFinanceReportComponent,
    ClaimLeadLegalReportComponent,
    ClaimLeadContractsReportComponent,
    ClaimLeadTechnicalReportComponent,
    EmbeddedDashboardComponent,
    FullPageLoaderComponent,
    CurrencyRatesComponent,
    CurrencyRateHistoryDialogComponent,
    CurrencyRateDialogComponent,
    RelatedEntitiesModalComponent,
    ClaimReplyComponent,
    ClaimDocumentsComponent,
    BulkSubClaimLinkDialogComponent,
    ErrorDialogComponent,
    PmoSalariesComponent,
    StaffComponent,
    StaffContractsComponent,
    PmoSalariesDetailsComponent,
    UserGuideComponent,
    TableSettingsDialogComponent,
    WarningDialogComponent,
    MessageModalComponent,
    FullNoteDialogComponent,
    Output1ConsolidatedPlanProgressComponent,
    SubClaimsComponent,
  ],
  imports: [
    BrowserModule,
    NgcCookieConsentModule.forRoot(cookieConfig),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    DropzoneCdkModule,
    AppRoutingModule,
    MaterialModule,
    MatMomentDateModule,
    NgxMatSelectSearchModule,
    MatStepperModule,
    MatTooltipModule,
    AuthModule.forRoot({
      ...env.auth,
      httpInterceptor: {
        ...env.httpInterceptor,
      },
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    MatToolbarModule,
    MatSidenavModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatMenuModule,
    MatListModule,
    NgChartsModule,
    AngularEditorModule,
    MentionModule,
    GoogleMapsModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    {
      provide: MAT_DATE_LOCALE,
      useValue: 'en-GB',
    },
    {
      provide: MAT_RADIO_DEFAULT_OPTIONS,
      useValue: { color: 'primary' },
    },
    {
      provide: MAT_SELECTSEARCH_DEFAULT_OPTIONS,
      useValue: <MatSelectSearchOptions>{
        placeholderLabel: 'Search',
        noEntriesFoundLabel: 'No options found',
      },
    },
    GlobalErrorHandler,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthHttpInterceptor,
      multi: true,
    },
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false },
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LanguageInterceptor,
      multi: true,
    },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    [HttpClient, provideHttpClient(withInterceptorsFromDi())],
    ToPrettyAmountNumberPipe,
    SafePipe,
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
