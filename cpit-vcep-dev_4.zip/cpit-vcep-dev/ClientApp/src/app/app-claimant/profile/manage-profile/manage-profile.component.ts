import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ExternalUserRequestService } from 'src/app/services/external-user.request.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-manage-profile',
  templateUrl: './manage-profile.component.html',
  styleUrls: ['./manage-profile.component.css'],
})
export class ManageProfileComponent implements OnInit {
  constructor(
    private request: ExternalUserRequestService,
    private router: Router,
    private notification: NotificationService
  ) {}
  form: UntypedFormGroup;
  externalUsers: any[] = [];
  externalUserEmailNotifications: any[] = [];
  selected: any;

  ngOnInit() {
    this.form = new UntypedFormGroup({
      externalUser: new UntypedFormControl(),
      additionalEmail: new UntypedFormArray([]),
    });
    this.getNotificationEmails();
  }

  get additionalEmail(): UntypedFormArray {
    return this.form.get('additionalEmail') as UntypedFormArray;
  }

  get externalUser(): UntypedFormControl {
    return this.form.get('externalUser') as UntypedFormControl;
  }

  addAdditionalEmail() {
    this.additionalEmail.push(
      new UntypedFormGroup({
        email: new UntypedFormControl(''),
      })
    );
  }

  removeRow(item: any) {
    const index = this.additionalEmail.value.findIndex((a: any) => a.email === item.value.email);
    if (index > -1) {
      this.additionalEmail.removeAt(index);
    }
  }
  saveAdditionalEmails() {
    if (this.additionalEmail.status == 'INVALID') {
      alert('Invalid email');
      return;
    }
    var emails = [];
    for (let email of this.additionalEmail.value) {
      let e = email['email'];
      if (e == undefined) {
        alert('Invalid email');
        return;
      }
      e.replace(/ /g, '');
      if (e?.length == 0) {
        alert('Invalid email');
        return;
      }
      emails.push({
        email: e,
        externalUserId: this.externalUser.value,
      });
    }
    this.request.saveAdditionalEmails(emails).subscribe(
      (data) => {
        this.notification.showSuccess('The emails were successfully added.');
      },
      (error) => {
        this.notification.showError('Something went wrong! Please check the correctness of your emails.');
      }
    );
  }
  getExternalUserEmails(externalUserId: any) {
    this.form.controls.additionalEmail = new UntypedFormArray([]);
    for (var a = 0; a < this.externalUserEmailNotifications?.length; a++) {
      if (this.externalUserEmailNotifications[a].externalUserId === externalUserId) {
        this.additionalEmail.push(
          new UntypedFormGroup({
            email: new UntypedFormControl(this.externalUserEmailNotifications[a].email),
            externalUser: new UntypedFormControl(this.externalUserEmailNotifications[a].externalUserId),
          })
        );
      }
    }

    if (this.additionalEmail?.length === 0) {
      this.addAdditionalEmail();
    }
  }
  getNotificationEmails() {
    this.request.getUserExternalUsers().subscribe((data: any) => {
      for (var a = 0; a < data?.length; a++) {
        this.externalUsers.push({
          value: data[a].externalUserId,
          label: data[a].name,
        });
      }
      var externalUserId = data[0].externalUserId;
      this.selected = externalUserId;
      this.request.getNotificationEmails().subscribe((data: any) => {
        this.externalUserEmailNotifications = data;
        this.getExternalUserEmails(externalUserId);
      });
    });
  }
}
