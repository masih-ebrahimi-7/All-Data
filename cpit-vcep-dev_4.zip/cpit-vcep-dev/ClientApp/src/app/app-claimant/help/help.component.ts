import { ViewportScroller } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import AOS from 'aos';
import 'boxicons';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
})
export class ClaimantHelpComponent implements OnInit {
  panelOpenState = false;

  constructor(
    private viewportScroller: ViewportScroller,
    private router: Router
  ) { }

  public onClick(elementId: string): void {
    this.viewportScroller.scrollToAnchor(elementId);
  }

  openHelpdeskPage() {
    this.router.navigate(['/claimant-issues']);
  }

  openUserGuide() {
    this.router.navigate(['/user-guide']);
  }

  ngOnInit(): void {
    AOS.init();
  }

  raiseClaim() {
    this.router.navigate([`/claims/create`]);
  }
}
