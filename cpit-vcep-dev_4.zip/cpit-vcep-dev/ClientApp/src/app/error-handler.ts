import { HttpErrorResponse } from '@angular/common/http';
import { ErrorHandler, Inject, Injectable, Injector } from '@angular/core';
import { ErrorService } from './services/error.service';
import { NotificationService } from './services/notification.service';
import { RequestService } from './services/request.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  previousErrors: string[] = [];
  config: any;
  constructor(private injector: Injector, private requestService: RequestService, @Inject('APP_CONFIG') config: any) {
    this.config = config;
  }

  handleError(error: Error | HttpErrorResponse) {
    const errorService = this.injector.get(ErrorService);
    const notifier = this.injector.get(NotificationService);
    let message;
    let stackTrace: any;
    if (!navigator.onLine) {
      return notifier.showError('No Internet Connection.');
    }
    if (error instanceof HttpErrorResponse) {
      stackTrace = errorService.getStackTrace(error);
      message = errorService.getServerErrorMessage(error);
      if (error.status === 500) {
        notifier.showError('Server error occurred please try again.');
      } else if (error.status === 403) {
        notifier.showError('Permission denied, user is not allowed to view this page.');
      } else if (error.status === 404) {
        notifier.showError('Not found.');
      } 
      else {
        notifier.showError(message);
      }
    } else {
      const currentError = error?.toString();
      if (this.previousErrors.indexOf(currentError) !== -1) {
        return;
      }
      this.previousErrors.push(currentError);
      return this.logError(error);
    }
  }

  logError(error: any) {
    var errorModel = {
      message: error.message,
      code: error.code,
      stack: error.stack,
    };
    this.requestService.logError(errorModel).subscribe(() => {});
  }
}
