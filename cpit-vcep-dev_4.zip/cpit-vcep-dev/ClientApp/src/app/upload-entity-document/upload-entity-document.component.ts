import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UploadEntityDocumentDialog } from './upload-models';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-upload-entity-document',
  templateUrl: './upload-entity-document.component.html',
  styleUrls: []
})

export class UploadEntityDocumentComponent implements OnInit {
  documentCategories: any[]
  subClaims: any[] = []
  claimId: number | null = null
  constructor(
    public dialogRef: MatDialogRef<UploadEntityDocumentComponent>,
    private request: RequestService,
    @Inject(MAT_DIALOG_DATA) public data: UploadEntityDocumentDialog
  ) { }

  projects = new UntypedFormControl();
  user: any;
  filesToUpload: number = 200;

  ngOnInit(): void {
    this.loadCategories();
    this.extractClaimId();
    if (this.claimId) {
      this.loadSubClaims();
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  fileUploadHandler(event: any[]) {
    this.data.output.files = event;
  }

  isUploadButtonDisabled() {
    let isDisabled = false;
    if (!this.data.output.files || !this.data.output.files.length || this.data.output.files?.length > this.filesToUpload) {
      isDisabled = true;
    }
    return isDisabled;
  }

  loadCategories(){
    this.request.getDocumentCategories(1, 9999, '').subscribe((data: any) => {
      this.documentCategories = data.records;
    });
  }

  extractClaimId() {
    if (this.data && this.data.claimId) {
      this.claimId = this.data.claimId;
    }
  }

  loadSubClaims() {
    if (this.claimId) {
      this.request.getSubClaimsByClaimId(this.claimId).subscribe((data: any) => {
        this.subClaims = data;
      });
    }
  }
}
