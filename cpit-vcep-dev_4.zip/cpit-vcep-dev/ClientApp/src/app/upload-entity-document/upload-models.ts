export interface UploadEntityDocumentDialog {
  output: {
    files: any;
    documentName: string;
  };
  claimId?: number;
}

