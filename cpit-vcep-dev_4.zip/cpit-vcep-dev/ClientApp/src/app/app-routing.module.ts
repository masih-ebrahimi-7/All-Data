import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersComponent } from './app-internal/admin/users/users.component';
import { ErrorPageComponent } from './app-shared/error-page/error-page.component';
import { HomeComponent } from './app-shared/home/home.component';

//================ Claimant module
import { ClaimantHelpComponent } from './app-claimant/help/help.component';
import { ManageProfileComponent } from './app-claimant/profile/manage-profile/manage-profile.component';

//================ Internal user module
import { AuthGuard } from '@auth0/auth0-angular';
import { AdvanceAccountsComponent } from './app-internal/output-two/advance-accounts/advance-accounts.component';
import { ContractDetailsComponent } from './app-internal/contracts/contract-details/contract-details.component';
import { ContractsComponent } from './app-internal/contracts/contracts.component';
import { ExternalEntityDetailComponent } from './app-internal/external-entities/external-entity-detail/external-entity-detail.component';
import { ListExternalEntitiesComponent } from './app-internal/external-entities/list-external-entities/list-external-entities.component';
import { GrantDetailsComponent } from './app-internal/grants/grant-details/grant-details.component';
import { GrantsComponent } from './app-internal/grants/grants.component';
import { InvoiceDetailsComponent } from './app-internal/invoices/invoice-details/invoice-details.component';
import { InvoicesComponent } from './app-internal/invoices/invoices.component';
import { MapViewComponent } from './app-internal/map-view/map-view.component';
import { ProjectAgreementsComponent } from './app-internal/output-two/project-agreements/project-agreements.component';
import { WithdrawalApplicationsComponent } from './app-internal/output-two/withdrawal-applications/withdrawal-applications.component';
import { ClaimDetailsComponent } from './app-shared/claims/claim-details/claim-details.component';
import { ClaimsComponent } from './app-shared/claims/claims.component';
import { CreateClaimComponent } from './app-shared/claims/create-claim/create-claim.component';
import { SimplifiedClaimDetailsComponent } from './app-shared/claims/simplified-claim-details/simplified-claim-details.component';
import { AccessDeniedComponent } from './app-shared/error-page/access-denied/access-denied.component';
import { InternalErrorComponent } from './app-shared/error-page/internal-error/internal-error.component';
import { ErrorLogComponent } from './app-shared/help/error-log/error-log.component';
import { IssueDetailComponent } from './app-shared/help/issue-detail/issue-detail.component';
import { ListIssuesComponent } from './app-shared/help/list-issues/list-issues.component';
import { ReleaseNotesComponent } from './app-shared/help/release-notes/release-notes.component';
import { NotificationsComponent } from './notifications/list-notifications/list-notifications.component';
import { PermissionGuard } from './services/permission-guard.service';
import { DocumentCategoriesComponent } from './app-internal/admin/documents/document-categories.component';
import { ClaimStagesComponent } from './app-internal/admin/claim-stages/claim-stages.component';
import { TasksListComponent } from './app-shared/tasks/tasks-list.component';
import { TaskDetailsComponent } from './app-shared/tasks/task-details/task-details.component';
import { EmbeddedDashboardComponent } from './app-internal/summary-dashboard/embedded-dashboard/embedded-dashboard.component';
import { CurrencyRatesComponent } from './app-internal/admin/currency-rates/currency-rates.component';
import { ExpensesComponent } from './app-internal/output-two/expenses/expenses.component';
import { ExpenseDetailsComponent } from './app-internal/output-two/expenses/expense-details/expense-details.component';
import { AdvanceAccountDetailsComponent } from './app-internal/output-two/advance-accounts/advance-account-details/advance-account-details.component';
import { PmoSalariesComponent } from './app-internal/output-two/pmo-salaries/pmo-salaries.component';
import { PmoSalariesDetailsComponent } from './app-internal/output-two/pmo-salaries/pmo-salaries-details/pmo-salaries-details.component';
import { StaffComponent } from './app-internal/output-two/pmo-salaries/staff/staff.component';
import { StaffContractsComponent } from './app-internal/output-two/pmo-salaries/staff-contracts/staff-contracts.component';
import { UserGuideComponent } from './app-shared/help/user-guide/user-guide.component';
import { Output1ConsolidatedPlanProgressComponent } from './app-internal/summaries/output1-consolidated-plan-progress/output1-consolidated-plan-progress.component';

const routes: Routes = [
  { path: '', component: HomeComponent },

    // -------------------- Admin
  { path: 'users', component: UsersComponent, canActivate: [AuthGuard] },
  { path: 'internal-users', component: UsersComponent, canActivate: [AuthGuard] },
  { path: 'external-users', component: UsersComponent, canActivate: [AuthGuard] },
  { path: 'document-categories', component: DocumentCategoriesComponent, canActivate: [AuthGuard] },
  { path: 'currency-rates', component: CurrencyRatesComponent, canActivate: [AuthGuard] },
  { path: 'claim-stages', component: ClaimStagesComponent, canActivate: [AuthGuard] },

  // -------------------- map
  { path: 'data-map', component: MapViewComponent, canActivate: [AuthGuard] },
  
  // -------------------- tasks
  { path: 'my-tasks', component: TasksListComponent, canActivate: [AuthGuard] },
  { path: 'tasks-created', component: TasksListComponent, canActivate: [AuthGuard] },
  { path: 'task/:id', component: TaskDetailsComponent, canActivate: [AuthGuard] },
  
  // -------------------- summary
  // { path: 'output-one/data-summary', component: SummaryOutputOneDashboardComponent, canActivate: [AuthGuard] },
  // { path: 'output-two/data-summary', component: SummaryOutputTwoDashboardComponent, canActivate: [AuthGuard] },
  { path: 'dashboard', component: EmbeddedDashboardComponent, canActivate: [AuthGuard] },
  { path: 'summaries/output1', component: Output1ConsolidatedPlanProgressComponent, canActivate: [AuthGuard] },

  // -------------------- grants
  { path: 'list-grants', component: GrantsComponent, canActivate: [AuthGuard] },
  { path: 'list-energy-grants', component: GrantsComponent, canActivate: [AuthGuard] },
  { path: 'list-transport-grants', component: GrantsComponent, canActivate: [AuthGuard] },
  { path: 'list-health-grants', component: GrantsComponent, canActivate: [AuthGuard] },
  { path: 'list-anr-grants', component: GrantsComponent, canActivate: [AuthGuard] },
  { path: 'grants/:id', component: GrantDetailsComponent, canActivate: [AuthGuard] },

  // -------------------- claims
  { path: 'list-output-one-claims', component: ClaimsComponent, canActivate: [AuthGuard] },
  { path: 'list-output-two-claims', component: ClaimsComponent, canActivate: [AuthGuard] },
  { path: 'claims-clearance', component: ClaimsComponent, canActivate: [AuthGuard] },
  { path: 'claims-rejected', component: ClaimsComponent, canActivate: [AuthGuard] },
  { path: 'claims/create', component: CreateClaimComponent, canActivate: [AuthGuard] },
  {
    path: 'claims/:claimId',
    component: ClaimDetailsComponent,
    canActivate: [PermissionGuard],
    data: { permissions: ['CanViewClaimDetails'] },
  },
  {
    path: 'submission-details/:id',
    component: SimplifiedClaimDetailsComponent,
    canActivate: [PermissionGuard],
    data: { permissions: ['CanViewLimitedClaimDetails', 'CanManageClaimsClearance', 'CanAddDocumentsToClaims', 'CanViewClaimsClearance'] },
  },

  // -------------------- contracts
  { path: 'list-output-one-contracts', component: ContractsComponent, canActivate: [AuthGuard] },
  { path: 'list-output-two-contracts', component: ContractsComponent, canActivate: [AuthGuard] },
  { path: 'contracts/:id', component: ContractDetailsComponent, canActivate: [AuthGuard] },

  // -------------------- advance-accounts
  { path: 'list-advance-accounts', component: AdvanceAccountsComponent, canActivate: [AuthGuard] },
  { path: 'advance-accounts/:id', component: AdvanceAccountDetailsComponent, canActivate: [AuthGuard] },

  // -------------------- PMO Staff salaries
  { path: 'list-salaries', component: PmoSalariesComponent, canActivate: [AuthGuard] },
  { path: 'salaries/:id', component: PmoSalariesDetailsComponent, canActivate: [AuthGuard] },
  { path: 'list-staff', component: StaffComponent, canActivate: [AuthGuard] },
  { path: 'list-staff-contracts', component: StaffContractsComponent, canActivate: [AuthGuard] },

  // -------------------- expenses
  { path: 'list-expenses', component: ExpensesComponent, canActivate: [AuthGuard] },
  { path: 'expenses/:id', component: ExpenseDetailsComponent, canActivate: [AuthGuard] },

  // -------------------- project-agreements
  { path: 'list-project-agreements', component: ProjectAgreementsComponent, canActivate: [AuthGuard] },

  // -------------------- invoices
  { path: 'list-invoices', component: InvoicesComponent, canActivate: [AuthGuard] },
  { path: 'invoices/:id', component: InvoiceDetailsComponent, canActivate: [AuthGuard] },

  // -------------------- withdrawal-applications
  { path: 'list-withdrawal-applications', component: WithdrawalApplicationsComponent, canActivate: [AuthGuard] },

  // -------------------- UNOPS HELP
  { path: 'list-issues', component: ListIssuesComponent, canActivate: [AuthGuard] },
  { path: 'error-log', component: ErrorLogComponent, canActivate: [AuthGuard] },
  { path: 'issue-detail/:helpdeskIssueId', component: IssueDetailComponent, canActivate: [AuthGuard] },
  { path: 'release-notes', component: ReleaseNotesComponent, canActivate: [AuthGuard] },
  { path: 'user-guide', component: UserGuideComponent, canActivate: [AuthGuard] },

  // ------------------- Claimant
  { path: 'list-submissions', component: ClaimsComponent, canActivate: [AuthGuard] },
  { path: 'submission-help', component: ClaimantHelpComponent, canActivate: [AuthGuard] },
  { path: 'claimant-issues', component: ListIssuesComponent, canActivate: [AuthGuard] },
  {
    path: 'claimant-issues-detail/:helpdeskIssueId',
    component: IssueDetailComponent,
    canActivate: [AuthGuard],
  },
  // -------------------
  { path: 'list-external-entities', component: ListExternalEntitiesComponent, canActivate: [AuthGuard] },
  { path: 'list-notifications', component: NotificationsComponent, canActivate: [AuthGuard] },
  { path: 'external-entity-details/:id', component: ExternalEntityDetailComponent, canActivate: [AuthGuard] },
  { path: 'manage-profile', component: ManageProfileComponent, canActivate: [AuthGuard] },
  { path: 'error', component: ErrorPageComponent, canActivate: [AuthGuard] },
  { path: 'internal-error', component: InternalErrorComponent },
  {
    path: 'access-denied',
    component: AccessDeniedComponent,
  },
  { path: '**', component: ErrorPageComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { anchorScrolling: 'enabled' })],
  providers: [AuthGuard],
  exports: [RouterModule],
})
export class AppRoutingModule { }

