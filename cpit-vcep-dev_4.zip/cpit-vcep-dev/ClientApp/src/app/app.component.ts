import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Inject, OnDestroy, OnInit, Output } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AuthService } from '@auth0/auth0-angular';
import { TranslateService } from '@ngx-translate/core';
import AOS from 'aos';
import { BehaviorSubject, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { PermissionsService } from './services/auth/permissions.service';
import { TokenService } from './services/auth/token.service';
import { TaskService } from './services/task.service';
declare const gtag: Function;

export class MenuItem {
  label: string;
  icon?: string;
  subMenu?: MenuItem[] = [];
  dropdownMenuItems?: MenuItem[] = [];
  isOpen?: boolean = false;
  link?: string = '';
  permission?: boolean = false;
  tooltip?: string;
  hidden?: boolean = false;
  isActive?: boolean;
  badge?: any;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements AfterViewInit, OnInit, OnDestroy {
  title = 'app';
  isLoading: boolean = true;
  isExpanded: boolean = true;
  isAuthenticated: boolean = false;
  mediaSub: Subscription;
  deviceXs: boolean;
  currentActiveItem: MenuItem;
  @Output() topMenuItemsChange = new EventEmitter<MenuItem[]>();
  @Output() currentActiveItemChange = new EventEmitter<MenuItem>();
  @Output() isExpandedChange = new EventEmitter<boolean>();

  permissions: any;

  menuItems: MenuItem[] = [];
  topMenuItems?: MenuItem[] = [];

  pendingTasksCount = new BehaviorSubject(0);
  currentPendingTasksCount = this.pendingTasksCount.asObservable();

  pendingClaimsToClearCount = new BehaviorSubject(0);
  currentPendingClaimsToClearCount = this.pendingClaimsToClearCount.asObservable();

  private taskSubscription: Subscription;

  constructor(
    private translateService: TranslateService,
    private router: Router,
    @Inject('APP_CONFIG') public configs: any,
    private tokenService: TokenService,
    private permissionsService: PermissionsService,
    private cd: ChangeDetectorRef,
    public authService: AuthService,
    private taskService: TaskService
  ) {}

  initializeApp() {
    this.translateService.setDefaultLang('en');
    this.translateService.use(localStorage.getItem('lang') || 'en');
    this.permissions = this.permissionsService.get();
    this.isAuthenticated = this.tokenService.loggedIn();
    this.cd.detectChanges();
  }

  toggleExpanded() {
    this.isExpanded = !this.isExpanded;
    this.isExpandedChange.emit(this.isExpanded);
  }

  getMenuTranslations() {
    this.menuItems.forEach((element) => {
      if (element.tooltip != null)
        this.translateService.get(element.tooltip).subscribe((text) => {
          element.tooltip = text;
        });
      element.dropdownMenuItems?.forEach((dropdownElement) => {
        if (dropdownElement.tooltip != null) {
          this.translateService.get(dropdownElement.tooltip).subscribe((text) => {
            dropdownElement.tooltip = text;
          });
        }
      });
    });
  }

  ngOnInit(): void {
    AOS.init();
    this.initializeApp();
    
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe(() => {
      this.isAuthenticated = this.tokenService.loggedIn();
      this.cd.detectChanges();
    });
    
    setTimeout(() => {
      this.cd.detectChanges();
    }, 10);
    this.cd.detectChanges();
    this.taskSubscription = this.taskService.pollPendingTasksCount(15000).subscribe(
      count =>  { 
        this.pendingTasksCount.next(count);
      }
    );
    this.taskSubscription = this.taskService.pollPendingClaimsToClearCount(15000).subscribe(
      count =>  { 
        this.pendingClaimsToClearCount.next(count);
      }
    );
    this.isLoading = false;
  }

  ngOnDestroy(): void {
    if (this.taskSubscription) {
      this.taskSubscription.unsubscribe();
    }
  }

  logOut() {
    this.tokenService.clear();
    this.authService.logout({ logoutParams: { returnTo: window.location.origin } });
  }

  setUpAnalytics() {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: any) => {
      gtag('config', this.configs.googleAnalyticsConfig, {
        page_path: event.urlAfterRedirects,
      });
    });
  }

  onClickMenuItem(item: MenuItem) {
    this.currentActiveItem = item;
    this.currentActiveItem.isActive = true;
    this.topMenuItems = item.subMenu;
    this.topMenuItemsChange.emit(this.topMenuItems);
    this.currentActiveItemChange.emit(this.currentActiveItem);
    
    if (item.subMenu != null) {
      for (var i = 0; i < item.subMenu?.length; i++) {
        if (item.subMenu[i].link != null && item.subMenu[i].permission === true) {
          const targetLink = item.subMenu[i].link;          
          const currentUrl = this.router.url;

          if (!currentUrl || !targetLink) return;

          if (this.removeIdFromRoute(currentUrl) !== this.removeIdFromRoute(targetLink)) {
            this.router.navigate([targetLink]);
          } else {
            this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
              this.router.navigate([targetLink]);
            });
          }
          return;
        }
      }
    }
  }

  showSubmenu(itemEl: HTMLElement) {
    itemEl.classList.toggle('showMenu');
  }

  handleSubmenuClick(item: MenuItem, itemEl: HTMLElement) {
    if (this.isExpanded) {
      item.isOpen = !item.isOpen;
      itemEl.classList.toggle('showMenu');
    } else {
      this.navigateToFirstSubmenuItem(item);
    }
  }

  private navigateToFirstSubmenuItem(item: MenuItem) {
    const firstAvailableItem = item.dropdownMenuItems?.find(subItem => 
      subItem.permission && subItem.subMenu && subItem.subMenu.length > 0
    );
    
    if (firstAvailableItem && firstAvailableItem.subMenu) {
      const firstLink = firstAvailableItem.subMenu.find(linkItem => 
        linkItem.permission && linkItem.link
      );
      if (firstLink && firstLink.link) {
        this.router.navigate([firstLink.link]);
      }
    }
  }

  ngAfterViewInit() {
    this.menuItems = this.getMenu();
    this.menuItems.forEach((item) => (item.isActive = this.isChildActive(item)));
    this.getMenuTranslations();
    this.setUpAnalytics();
    this.cd.detectChanges();
  }

  private isChildActive(menuItem: MenuItem): boolean {
    const currentPath = this.router.url;
    const isCurrentlyActive = this.checkIfMenuItemActive(menuItem, currentPath);
    
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe((navEnd: any) => {
      const path = navEnd.urlAfterRedirects;
      return this.checkIfMenuItemActive(menuItem, path);
    });
    return isCurrentlyActive;
  }


  private checkIfMenuItemActive(menuItem: MenuItem, path: string): boolean {
    if (menuItem.subMenu != null && menuItem.subMenu?.filter((a) => a.link === path)?.length > 0) {
      this.topMenuItems = menuItem.subMenu;
      this.topMenuItemsChange.emit(this.topMenuItems);
      return true;
    }

    for (var j = 0; menuItem.dropdownMenuItems != null && j < menuItem.dropdownMenuItems?.length; j++) {
      var sub = menuItem.dropdownMenuItems[j];

      if (sub.subMenu != null && sub.subMenu?.filter((a) => a.link === path)?.length > 0) {
        this.topMenuItems = sub.subMenu;
        this.topMenuItemsChange.emit(this.topMenuItems);
        return true;
      }
    }
    return false;
  }

  getMenu() {
    return [
      {
        label: 'nav.home',
        tooltip: 'nav.home',
        icon: 'bx bxs-home icon',
        permission: true,
        subMenu: [
          {
            label: 'nav.home',
            permission: true,
            link: '/',
          },
        ],
      },
      {
        label: 'nav.myClaims',
        tooltip: 'nav.myClaims',
        permission: this.permissions.CanAccessAsClaimant,
        icon: 'bx bxs-bank icon',
        subMenu: [
          {
            label: 'nav.myClaims',
            permission: this.permissions.CanAccessAsClaimant,
            link: '/list-submissions',
          },
        ],
      },
      {
        label: 'nav.map',
        icon: 'bx bx-map icon',
        tooltip: 'nav.show-map',
        permission: this.permissions.CanViewDataMap,
        subMenu: [
          {
            label: 'nav.map',
            permission: this.permissions.CanViewDataMap,
            link: '/data-map',
          },
        ],
      },
      {
        label: 'nav.dashboard',
        icon: 'bx bx-chart icon',
        tooltip: 'nav.dashboard',
        permission: this.permissions.CanViewDashboard,
        subMenu: [
          {
            label: 'nav.dashboard',
            permission: this.permissions.CanViewDashboard,
            link: '/dashboard',
          },
        ],
      },
      {
        label: 'Reports',
        icon: 'bx bx-chart icon',
        tooltip: 'Reports and Summaries',
        permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
        subMenu: [
          {
            label: 'Output 1',
            permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
            link: '/summaries/output1',
          },
        ],
      },
      {
        label: 'nav.myTasks',
        icon: 'bx bx-task icon',
        tooltip: 'nav.myTasks',
        badge: this.pendingTasksCount,
        permission: this.permissions.CanViewTasks,
        subMenu: [
          {
            label: 'nav.myTasks',
            permission: this.permissions.CanViewTasks,
            link: '/my-tasks',
          },
          {
            label: 'nav.tasksCreated',
            permission: this.permissions.CanViewTasksCreatedByMe,
            link: '/tasks-created',
          },
        ],
      },
      {
        label: 'nav.claimsClearance',
        icon: 'bx bx-shield-quarter icon',
        tooltip: 'nav.claimsClearance',
        badge: this.pendingClaimsToClearCount,
        permission: this.permissions.CanManageClaimsClearance || this.permissions.CanViewClaimsClearance,
        subMenu: [
          {
            label: 'nav.claimsClearance',
            permission: this.permissions.CanManageClaimsClearance || this.permissions.CanViewClaimsClearance,
            link: '/claims-clearance',
          },
          {
            label: 'nav.rejectedClaims',
            permission: this.permissions.CanManageClaimsClearance || this.permissions.CanViewClaimsClearance,
            link: '/claims-rejected',
          },
        ],
      },
      {
        label: 'nav.grants',
        icon: 'bx bx-data icon',
        tooltip: 'nav.list-grants',
        permission: this.permissions.CanViewGrants,
        subMenu: [
          {
            label: 'nav.grants',
            permission: this.permissions.CanViewGrants,
            link: '/list-grants',
          },
          {
            label: 'nav.energy',
            permission: this.permissions.CanViewGrants,
            link: '/list-energy-grants',
          },
          {
            label: 'nav.transport',
            permission: this.permissions.CanViewGrants,
            link: '/list-transport-grants',
          },
          {
            label: 'nav.health',
            permission: this.permissions.CanViewGrants,
            link: '/list-health-grants',
          },
          {
            label: 'nav.anr',
            permission: this.permissions.CanViewGrants,
            link: '/list-anr-grants',
          },
        ],
      },
      {
        label: 'nav.contracts',
        icon: 'bx bx-hard-hat icon',
        tooltip: 'nav.list-contracts',
        permission: this.permissions.CanViewContracts,
        subMenu: [
          {
            label: 'nav.contracts',
            permission: this.permissions.CanViewContracts,
            link: '/list-output-one-contracts',
          },
        ],
      },
      {
        label: 'nav.outputOne',
        tooltip: 'nav.outputOne',
        permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
        icon: 'bx bxs-bank icon',
        dropdownMenuItems: [
          {
            label: 'nav.claims',
            icon: 'bx bx-layer-plus icon',
            tooltip: 'nav.show-claims',
            permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
            subMenu: [
              {
                label: 'nav.claims',
                permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
                link: '/list-output-one-claims',
              },
            ],
          },
        ],
      },
      {
        label: 'nav.outputTwo',
        tooltip: 'nav.outputTwo',
        permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims || this.permissions.CanViewExpenses || this.permissions.CanManageExpenses || this.permissions.CanViewAdvanceAccounts || this.permissions.CanManageAdvanceAccounts || this.permissions.CanViewSalaries || this.permissions.CanManageSalaries,
        icon: 'bx bx-wallet icon',
        dropdownMenuItems: [
          {
            label: 'nav.claims',
            icon: 'bx bx-layer-plus icon',
            tooltip: 'nav.show-claims',
            permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
            subMenu: [
              {
                label: 'nav.claims',
                permission: this.permissions.CanViewAllClaims || this.permissions.CanViewLimitedClaims,
                link: '/list-output-two-claims',
              },
            ],
          },
          {
            label: 'nav.advance-accounts',
            icon: 'bx bx-money-withdraw icon',
            tooltip: 'nav.list-advance-accounts',
            permission: this.permissions.CanViewAdvanceAccounts || this.permissions.CanManageAdvanceAccounts,
            subMenu: [
              {
                label: 'nav.advance-accounts',
                permission: this.permissions.CanViewAdvanceAccounts || this.permissions.CanManageAdvanceAccounts,
                link: '/list-advance-accounts',
              },
            ],
          },
          {
            label: 'nav.salaries',
            icon: 'bx bx-credit-card icon',
            tooltip: 'nav.list-salaries',
            permission: this.permissions.CanViewSalaries || this.permissions.CanManageSalaries,
            subMenu: [
              {
                label: 'nav.salaries',
                permission: this.permissions.CanViewSalaries || this.permissions.CanManageSalaries,
                link: '/list-salaries',
              },
              {
                label: 'nav.staff',
                permission: this.permissions.CanViewSalaries || this.permissions.CanManageSalaries,
                link: '/list-staff',
              },
              {
                label: 'nav.staff-contracts',
                permission: this.permissions.CanViewSalaries || this.permissions.CanManageSalaries,
                link: '/list-staff-contracts',
              },
            ],
          },
          {
            label: 'nav.expenses',
            icon: 'bx bx-credit-card-front icon',
            tooltip: 'nav.list-expenses',
            permission: this.permissions.CanViewExpenses || this.permissions.CanManageExpenses,
            subMenu: [
              {
                label: 'nav.expenses',
                permission: this.permissions.CanViewExpenses || this.permissions.CanManageExpenses,
                link: '/list-expenses',
              },
            ],
          },
        ],
      },
      {
        label: 'nav.admin',
        icon: 'bx bx-shield-quarter icon',
        tooltip: 'nav.admin',
        permission: this.permissions.CanManageUsers || this.permissions.CanManageDocumentCategories || this.permissions.CanAccessErrorLogs || this.permissions.CanManageCurrencyRates,
        dropdownMenuItems: [
          {
            label: 'nav.manageUsers',
            icon: 'bx bxs-user-detail icon',
            tooltip: 'nav.manageUsers',
            permission: this.permissions.CanManageUsers,
            subMenu: [
              {
                label: 'nav.manageUsers',
                permission: this.permissions.CanManageUsers,
                link: '/users',
              },
              {
                label: 'nav.internalUsers',
                permission: this.permissions.CanManageUsers,
                link: '/internal-users',
              },
              {
                label: 'nav.externalUsers',
                permission: this.permissions.CanManageUsers,
                link: '/external-users',
              },
              {
                label: 'nav.manageExternals',
                permission: this.permissions.CanManageUsers,
                link: '/list-external-entities',
              },
            ]
          },
          {
            label: 'nav.settings',
            icon: 'bx bxs-cog icon',
            tooltip: 'nav.settings',
            permission: this.permissions.CanManageDocumentCategories || this.permissions.CanManageCurrencyRates || this.permissions.CanAccessErrorLogs || this.permissions.CanManageClaimStages,
            subMenu: [
              {
                label: 'nav.documentCategories',
                permission: this.permissions.CanManageDocumentCategories,
                link: '/document-categories',
              },
              {
                label: 'Currency rates',
                permission: this.permissions.CanManageCurrencyRates,
                link: '/currency-rates',
              },
              {
                label: 'Claim Stages',
                permission: this.permissions.CanManageClaimStages,
                link: '/claim-stages',
              },
              {
                label: 'nav.error-log',
                permission: this.permissions.CanAccessErrorLogs,
                link: '/error-log',
              },
            ]
          }
        ]
      },
      {
        label: 'nav.help',
        icon: 'bx bxs-help-circle icon',
        tooltip: 'nav.help',
        permission: this.permissions.CanAccessHelp || this.permissions.CanAccessReleaseNotes,
        subMenu: [
          {
            label: 'nav.list-issues',
            permission: this.permissions.CanAccessHelp,
            link: '/list-issues',
          },
          {
            label: 'nav.releaseNotes',
            permission: this.permissions.CanAccessReleaseNotes,
            link: '/release-notes',
          },
        ],
      },
      {
        label: 'nav.help',
        icon: 'bx bxs-help-circle icon',
        tooltip: 'nav.help',
        permission: this.permissions.CanAccessExternalHelp,
        subMenu: [
          {
            label: 'nav.help',
            permission: this.permissions.CanAccessExternalHelp,
            link: '/submission-help',
          },
        ],
      },
      {
        label: 'nav.user-guide',
        icon: 'bx bxs-book icon',
        tooltip: 'nav.user-guide',
        permission: this.permissions.CanAccessUserGuideAsMoF || this.permissions.CanAccessUserGuideAsDonor || this.permissions.CanAccessUserGuideAsClaimant,
        subMenu: [
          {
            label: 'nav.user-guide',
            permission: this.permissions.CanAccessUserGuideAsMoF || this.permissions.CanAccessUserGuideAsDonor || this.permissions.CanAccessUserGuideAsClaimant,
            link: '/user-guide',
          },
        ],
      },
    ];
  }

  private removeIdFromRoute(route: string): string {
    const segments = route.split('/');
    if (segments.length > 1) {
      const lastSegment = segments[segments.length - 1];
      if (/^[0-9]+$/.test(lastSegment)) {
        return segments.slice(0, -1).join('/');
      }
    }
    return route;
  }
}
