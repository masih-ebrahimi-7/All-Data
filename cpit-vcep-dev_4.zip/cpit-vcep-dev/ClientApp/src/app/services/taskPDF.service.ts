import { Injectable } from '@angular/core';
import htmlToPdfmake from 'html-to-pdfmake';
import * as pdfMake from 'pdfmake/build/pdfmake.min';
import { Action } from 'src/app/common/table/Action';
import { RequestService } from './request.service';

@Injectable({
  providedIn: 'root',
})
export class taskPDFService {
  getAction(id: any): import("src/app/common/table/Action").Action {
    return new Action({
      iconName: 'picture_as_pdf',
      toolTip: 'button.exportToPDF',
      onClick: () => this.downloadAsPDF(
        id,
        true,
      ),
      color: 'danger',
      class: 'icon-small pdf'
    })
  }
  constructor(private request: RequestService) {}
  public getBase64ImageFromURL(url: any) {
    return new Promise((resolve, reject) => {
      var img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');

      img.onload = () => {
        var canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;

        var ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);

        var dataURL = canvas.toDataURL('image/png');

        resolve(dataURL);
      };

      img.onerror = (error) => {
        reject(error);
      };

      img.src = url;
    });
  }

  public async downloadAsPDF(
   taskId: any,
   downloadFile: boolean,
  ) {
    var image = await this.getBase64ImageFromURL('assets/images/unops-logo.png');
    var logo = await this.getBase64ImageFromURL('assets/images/logo.png');

    if (taskId != null) {
      return new Promise<any>((resolve, reject) => {
        var files: any = [];
        this.request.getJiraTaskDetailsById(taskId).subscribe((data: any) => {
            files.push(this.buildPDF(data, image, logo));
          return resolve(files);
        });
      });
    } 
  }

  public async buildPDF(
    task: any,
    image: any,
    logo: any
  ) {
    var htmlPDF = `
    <div style="page-break-after: always;">
    <div>
        <table border="0" cellspacing="0" cellpadding="0" >
        <tbody>
          <tr>
            <td align="center" style="height: 25px; border: 0; border-bottom: 2px solid #000; width:50%"><img src="${image}" width="180" height="26"/></td>
            <td align="right" style="height: 25px; border: 0; border-bottom: 2px solid #000; width:50%; text-align: right;"><h8 style="font-size: 13px; text-transform: uppercase;"><img src="${logo}" width="35"/></h8>
            <div ><h8 style="font-size: 12px; color: #828282">VCEP - Project Monitoring System</h8></div></td>
          </tr>    
        </tbody>
      </table>
    </div>
    <div style="margin-top: 0px; margin-left: 35px;  width: 520px; line-height: 1; font-size: 9px; color: #393d47;">
    <div class="clearfix" style="margin-bottom: 5px;">
      <div>
        <div style="font-size: 12px; margin: 0;"><label><b>Task name: ${task.summary} </b></label></div>
        <div style="font-size: 12px;"><label><b>Task description: ${task.description}</b></label></div>
        <div style="font-size: 12px;"><label><b>Location: ${task.locationName}</b></label></div>
        <div style="font-size: 12px;"><label><b>Project: ${task.projectName}</b></label></div>
      </div>
    </div>
    <table style="margin-top: 8px;" border="0" cellspacing="0" cellpadding="0" >
    <tbody>
      <tr>
        <td colspan="2" align="center" style="font-size: 10px; height: 23px; background-color: #1876d2; vertical-align: middle; border: 2px solid #FFF; text-align: center; color: #FFF;width:*"><b>Task details</b></td>
        <td colspan="2" align="center" style="font-size: 10px; height: 23px; background-color: #1876d2; vertical-align: middle; border: 2px solid #FFF; text-align: center; color: #FFF;"><b>Task creation</b></td>
      </tr>
      <tr>
        <th width="15%" style="font-size: 10px; background-color: #efefef;border: 2px solid #FFF;" align="left">Priority</th>
        <td width="35%" style="font-size: 10px; background-color: #fff;border: 2px solid #FFF;">${task.priority}</td>
        <th width="15%" style="font-size: 10px; background-color: #efefef;border: 2px solid #FFF;" align="left">Created date</th>
        <td width="35%" style="font-size: 10px; background-color: #fff;border: 2px solid #FFF;">${task.createdDate}</td>
      </tr>
      <tr >
        <th style="font-size: 10px; background-color: #efefef;border: 2px solid #FFF;" align="left">Ticket number</th>
        <td style="font-size: 10px; background-color: #fff;border: 2px solid #FFF;">${task.jiraTicketNumber}</td>
        <th style="font-size: 10px; background-color: #efefef;border: 2px solid #FFF;" align="left">Created by</th>
        <td style="font-size: 10px; background-color: #fff;border: 2px solid #FFF;">${task.createdBy}</td>
      </tr>       
    </tbody>
  </table>
  <table style="margin-bottom: 30px; margin-top: 8px;">
  <thead>
    <tr>
      <th style="font-size: 10px; height: 20px; background-color:#515151; color: #FFF;border: 0px;" align="left" colspan="2">Id</th>
      <th style="font-size: 10px; height: 20px; background-color:#515151; color: #FFF;border: 0px; " align="left" colspan="2">Name</th>
      <th style="font-size: 10px; height: 20px; background-color:#515151; color: #FFF;border: 0px; " align="center" colspan="2">Status</th>
      <th style="font-size: 10px; height: 20px; background-color:#515151; color: #FFF;border: 0px;" align="center">Created date</th>
      <th style="font-size: 10px; height: 20px; background-color:#515151; color: #FFF;border: 0px;" align="center" colspan="2">Created by</th>
    </tr>
  </thead>
  <tbody>`;
  task.workflowSteps.forEach((workflowStep: any) => {
    htmlPDF += `<tr>
        <td width="10%" style="border: 2px solid #FFF;background-color: #efefef;" colspan="2">${workflowStep.id}</td>
        <td width="58%" style="border: 2px solid #FFF;" colspan="2">${workflowStep.name}</td>
        <td style="border: 2px solid #FFF;background-color: #efefef;" align="right">${workflowStep.description}</td>
        <td style="border: 2px solid #FFF;" colspan="2" align="right">${workflowStep.createdDate}</td>
        <td style="border: 2px solid #FFF;background-color: #efefef;" colspan="2" align="right">${workflowStep.createdBy}</td>
      </tr>
    <tr>`;
  });
    htmlPDF += `  
      <td style="background-color: #efefef; border: 2px solid #FFF;border-right: 1px solid #FFF; font-size:8px;" colspan="9" >
        <p style="font-size: 9px; word-break: break-word; margin: 0;">
        *This PDF contains a comprehensive export of all Jira and system data related to Task: ${task.id}, extracted for the purpose of providing a single, centralized source of truth for all stakeholders involved. 
        </p>
      </td>
    </tr>
  </tbody>
</table>
  `;
    var html = htmlToPdfmake(htmlPDF, {
      tableAutoSize: true,
    });
    let docDefinition: any = {
      header: '',
      content: [html],
      pageBreakBefore: function (currentNode: any) {
        return currentNode.style && currentNode.style.indexOf('pdf-pagebreak-before') > -1;
      },
    };

    var fullFileName = 'Task_' + task.id;
    var file = pdfMake.createPdf(docDefinition);
    file.download(fullFileName);
    return file;
  }
}
