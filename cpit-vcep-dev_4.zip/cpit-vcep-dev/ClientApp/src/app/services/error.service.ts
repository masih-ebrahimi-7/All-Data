import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  getClientErrorMessage(error: Error): string {
    return error.message ? error.message : error?.toString();
  }

  getServerErrorMessage(error: HttpErrorResponse): string {
    let message = 'Error Occured.';
    if (navigator.onLine) {
      if (error.error) {
        message = error.error.Message ? error.error.Message : message;
      }
    } else {
      message = 'No Internet Connection';
    }
    return message;
  }

  getStackTrace(error: Error) {
    return error.stack ? error.stack : '';
  }
}
