import { EventEmitter, Inject, Injectable, OnInit, Output } from '@angular/core';
import { RequestService } from './request.service';

declare const gapi: any;
declare const google: any;

@Injectable({
  providedIn: 'root'
})
export class GoogleDrivePickerService implements OnInit {
  private clientId;
  private scope = 'https://www.googleapis.com/auth/drive.readonly';
  private pickerApiLoaded = false;
  private oauthToken?: string;
  private googleDriveDefaultFolder: string = "";
  @Output() onFilesSelectedEmitter = new EventEmitter<any>();

  constructor(private request: RequestService, @Inject('APP_CONFIG') config: any) {
    this.clientId = config.clientId;
    this.getDefaultDriveFolderId();
    gapi.load('picker', { 'callback': this.onPickerApiLoad.bind(this) });
  }

  ngOnInit() {

  }

  getDefaultDriveFolderId() {
    this.request.getConfigs().subscribe((response: any) => {
      this.googleDriveDefaultFolder = response.googleDriveDefaultFolder;
    })
  }

  private onPickerApiLoad() {
    this.pickerApiLoaded = true;
  }

  private authenticate() {
    google.accounts.oauth2.initTokenClient({
      client_id: this.clientId,
      scope: this.scope,
      callback: (response: any) => {
        this.oauthToken = response.access_token;
        this.openPicker();
      }
    }).requestAccessToken();
  }

  private createPicker() {
    if (this.pickerApiLoaded && this.oauthToken) {
      const view = new google.picker.DocsView(google.picker.ViewId.DOCS)
      .setIncludeFolders(true)
      .setOwnedByMe(false)
      .setMode(google.picker.DocsViewMode.LIST)
      .setSelectFolderEnabled(false)
      
      if (this.googleDriveDefaultFolder)
        view.setParent(this.googleDriveDefaultFolder);

      const picker = new google.picker.PickerBuilder()
        .enableFeature(google.picker.Feature.NAV_HIDDEN)
        .enableFeature(google.picker.Feature.MULTISELECT_ENABLED)
        .setOAuthToken(this.oauthToken)
        .addView(view)
        .addView(google.picker.ViewId.DOCUMENTS)
        .addView(google.picker.ViewId.PRESENTATIONS)
        .addView(new google.picker.DocsUploadView())
        .setCallback(this.pickerCallback.bind(this))
        .build();
      picker.setVisible(true);
    }
  }

  private pickerCallback(data: any) {
    if (data.action === google.picker.Action.PICKED) {
      var selectedDocuments = data[google.picker.Response.DOCUMENTS];

      this.onFilesSelectedEmitter.emit({processed: false, files: selectedDocuments});
    }
  }

  public openPicker() {
    if (!this.oauthToken)
      gapi.load('auth', { 'callback': this.authenticate.bind(this) });
    else 
      this.createPicker();
  }
}