import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class StateService {
  private readonly subject: BehaviorSubject<any> = new BehaviorSubject({});

  public readonly observable: Observable<any> = this.subject.asObservable();

  public set(newValue: any): void {
    this.subject.next(newValue);
  }
}
