import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { PermissionsService } from './auth/permissions.service';

@Injectable({
  providedIn: 'root',
})
export class PermissionGuard  {
  permissions: any | null;

  constructor(private permissionsService: PermissionsService, private router: Router) {
    this.permissions = this.permissionsService.get();
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    const requiredPermissions = next.data.permissions as string[];

    const permissionsIntersection = requiredPermissions.filter((requiredPermission) =>
      Array.from(Object.keys(this.permissions)).some((permission: any) => permission === requiredPermission)
    );

    if (!permissionsIntersection || !permissionsIntersection?.length) {
      this.router.navigate(['/access-denied']);
    }
    return true;
  }
}
