import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class PermissionsService {
  get() {
    return JSON.parse(localStorage.getItem('permissions') ?? '{}');
  }

  set(permissions: string) {
    localStorage.setItem('permissions', JSON.stringify(permissions));
  }
  isImpersonation() {
    return localStorage.getItem('impersonator') != null && localStorage.getItem('impersonator') != '';
  }
}
