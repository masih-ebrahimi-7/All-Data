import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class UserProfileService {
  get() {
    return {
      email: localStorage.getItem('user email'),
      photo: localStorage.getItem('user photo'),
      externalUserName: localStorage.getItem('externalUser name'),
      institutionName: localStorage.getItem('institution name'),
    };
  }

  set(email: string, photoUrl: string, externalUserName: string = '', institutionName: string = '') {
    localStorage.setItem('user email', email);
    localStorage.setItem('user photo', photoUrl);
    localStorage.setItem('externalUser name', externalUserName);
    localStorage.setItem('institution name', institutionName);
  }
}
