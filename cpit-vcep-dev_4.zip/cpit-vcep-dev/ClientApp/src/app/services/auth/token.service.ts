import { Inject, Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root',
})
export class TokenService {
  iss: any;
  constructor(@Inject('APP_CONFIG') config: any) {
    this.iss = {
      login: 'UNOPS.VCEP',
      signup: 'UNOPS.VCEP',
    };
  }

  set(token: string) {
    localStorage.setItem('token', token);
  }

  get() {
    return localStorage.getItem('token')!;
  }

  isValid() {
    const helper = new JwtHelperService();
    const token = this.get();
    var valid = false;
    if (token) {
      const payload = this.getPayLoad(token);
      const isExpired = helper.isTokenExpired(token);
      if (payload) {
        valid = Object.values(this.iss).indexOf(payload.iss) > -1 && !isExpired ? true : false;
      }
    }
    if (!valid) {
      this.clear();
    }
    return valid;
  }
  clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('permissions');
    localStorage.removeItem('user email');
    localStorage.removeItem('user photo');
    localStorage.removeItem('externalUser name');
    localStorage.removeItem('institution name');
    localStorage.removeItem('impersonator');
  }
  getPayLoad(token: any) {
    var payload = token.split('.')[1];
    payload = JSON.parse(atob(payload));
    return payload;
  }

  loggedIn() {
    return this.isValid();
  }
}
