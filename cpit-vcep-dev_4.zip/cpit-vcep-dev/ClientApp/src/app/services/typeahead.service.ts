import { Injectable } from '@angular/core';
import { map, startWith } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class TypeaheadService {
  constructor() { }
  _filterTypeahead(value: any, collection: any): TypeaheadInput[] {
    const filterValue = value != null ? value.toLowerCase() : '';
    return filterValue === ''
      ? collection
      : collection.filter((option: any) => option.label.toLowerCase().includes(filterValue));
  }

  filterData(input: any, data: any) {
    return input.valueChanges.pipe(
      startWith(''),
      map((value) => this._filterTypeahead(value, data))
    );
  }
}

export interface TypeaheadInput {
  label: string;
  value: string;
  description: string;
}
