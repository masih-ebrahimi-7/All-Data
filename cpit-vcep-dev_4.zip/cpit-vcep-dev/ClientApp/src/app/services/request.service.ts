import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { ExternalAuthDto } from '../app-shared/home/home.component';
import { RemarkType, TaskUserType } from '../models/enums/server-enums';
import { Location } from '../common/google-map/google-map.component';
import { TypeaheadInput } from './typeahead.service';
import { IAssignUserEmailsToIds } from '../common/interfaces';
import { IClaimCreateModel, IClaimEditModel } from '../models/claim.model';
import { IContractRequestModel } from '../models/contract.model';
import { IGrantRequestModel } from '../models/grant.model';
import { ExpenseRequestModel } from '../models/expense.model';
import { IAdvanceAccountCreateRequest } from '../models/advance-account.model';
import { ISalaryBaseModel, IStaffBaseModel, IStaffContractBaseModel } from '../models/staff-salary.model';
import { UserManagementPageType } from '../models/enums/ui-enums';

@Injectable({
  providedIn: 'root',
})
export class RequestService {
  public rootUrl = '/api';
  constructor(private _http: HttpClient) {}

  // config
  getConfigs() {
    return this._http.get(`${this.rootUrl}/configs`);
  }

  getEnum(enumName: any) {
    return this._http.get(`${this.rootUrl}/enum/${enumName}`);
  }

  getEnumValues(enumName: any) {
    return this._http.get(`${this.rootUrl}/enum-value/${enumName}`);
  }

  logError(error: any) {
    return this._http.post(`${this.rootUrl}/error-log/create`, error);
  }

  getErrorLogs(pageIndex: number, pageSize: number) {
    return this._http.get(`${this.rootUrl}/error-logs?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=`);
  }

  // login
  login(externalAuth: ExternalAuthDto) {
    return this._http.post(`${this.rootUrl}/accounts/externallogin`, externalAuth);
  }

  register(externalAuth: ExternalAuthDto) {
    return this._http.post(`${this.rootUrl}/accounts/register`, externalAuth);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  // user management
  getUsers(filterAndPagination: any, userType: UserManagementPageType) {
    return this._http.post(`${this.rootUrl}/users?userType=${userType}`, filterAndPagination);
  }

  assignRoles(userId: string, roles: string[]) {
    return this._http.post(`${this.rootUrl}/users/assign-roles`, {
      userId: userId,
      roles: roles,
    });
  }

  assignExternalUserProjects(externalUser: any) {
    return this._http.post(`${this.rootUrl}/update-external-user`, externalUser);
  }

  createExternalEntityUser(user: any) {
    return this._http.post(`${this.rootUrl}/external-entity-user`, user);
  }

  uploadExternalUsers(formData: FormData) {
    return this._http.post(`${this.rootUrl}/upload-external-users`, formData);
  }

  activateAndAssignUser(userId: string, roles: string[]) {
    return this._http.post(`${this.rootUrl}/users/activate`, {
      userId: userId,
      roles: roles,
    });
  }

  getExternalEntityUser(userId: string) {
    return this._http.get(`${this.rootUrl}/external-entity-user/${userId}`);
  }

  deactivateUser(userId: string) {
    return this._http.get(`${this.rootUrl}/users/deactivate/${userId}`);
  }

  editUser(userId: string, editBodyModel: any) {
    return this._http.post(`${this.rootUrl}/users/edit/${userId}`, editBodyModel);
  }

  getExternalUsers() {
    return this._http.get(`${this.rootUrl}/external-users`);
  }

  getExternalEntitiesForFilter(sector?: number, grantId?: number, contractId?: number): Observable<TypeaheadInput[]> {
    let api = `${this.rootUrl}/external-entities/typeahead?`;
    if (contractId)
      api += `&contractId=${contractId}`;
    if (sector)
      api += `&sector=${sector}`;
    if (grantId)
      api += `&grantId=${grantId}`;
    return this._http.get<TypeaheadInput[]>(api);
  }

  getExternalEntityUsersForFilter(externalEntityId: number): Observable<TypeaheadInput[]> {
    return this._http.get<TypeaheadInput[]>(`${this.rootUrl}/external-entity-users/typeahead/${externalEntityId}`);
  }

  getAllExternalEntities(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/all-external-entities`, filterAndPagination);
  }

  getExternalEntity(id: number) {
    return this._http.get(`${this.rootUrl}/external-entity/${id}`);
  }

  createOrUpdateExternalEntity(model: any) {
    return this._http.post(`${this.rootUrl}/create-or-update-external-entity`, model);
  }

  getSystemRoles() {
    return this._http.get(`${this.rootUrl}/roles`);
  }

  impersonateUser(userId: string) {
    return this._http.get(`${this.rootUrl}/users/impersonate?userId=${userId}`);
  }

  stopImpersonation() {
    return this._http.get(`${this.rootUrl}/users/stop-impersonate`);
  }

  linkUserToExternalEntity(userId: string, externalEntityId: string) {
    return this._http.post(`${this.rootUrl}/users/link-external-entity`, {
      userId: userId,
      externalEntityId: externalEntityId,
    });
  }

  unlinkUserToExternalEntity(userId: string, externalEntityId: string) {
    return this._http.post(`${this.rootUrl}/users/unlink-external-entity`, {
      userId: userId,
      externalEntityId: externalEntityId,
    });
  }

  // jira
  getJiraTaskDetailsById(id: number) {
    return this._http.get(`${this.rootUrl}/jira/task/${id}`);
  }
  getJiraTaskDetailsByKey(id: string) {
    return this._http.get(`${this.rootUrl}/jira/task-by-key/${id}`);
  }

  getIssueWorkflowStepsBykey(key: string) {
    return this._http.get(`${this.rootUrl}/jira/get-issue-workflow-steps-by-key/${key}`);
  }

  getIssueByKey(key: string) {
    return this._http.get(`${this.rootUrl}/jira/get-issue-by-key/${key}`);
  }

  getIssueTypePriorities() {
    return this._http.get(`${this.rootUrl}/jira/issue-types/priorities`);
  }

  createHelpdeskIssueComment(helpdeskIssueComment: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/create-comment`, helpdeskIssueComment);
  }

  createJiraTicketForHelpdeskIssue(helpdeskIssueId: number) {
    return this._http.post(`${this.rootUrl}/jira-tickets/create/${helpdeskIssueId}`, {});
  }

  getLatestJiraStatusForHelpdeskIssue(helpdeskIssueId: number) {
    return this._http.get(`${this.rootUrl}/jira-tickets/sync/${helpdeskIssueId}`, {});
  }

  getLatestJiraStatusForHelpdeskIssues() {
    return this._http.get(`${this.rootUrl}/jira-tickets/sync/`, {});
  }

  getHelpdeskIssue(helpdeskIssueId: string) {
    return this._http.get(`${this.rootUrl}/helpdesk-issue/${helpdeskIssueId}`);
  }

  getHelpdeskIssues(filter: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issues`, filter);
  }

  acknowledgeHelpdeskIssue(helpdeskIssue: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/acknowledge`, helpdeskIssue);
  }

  linkHelpdeskIssueToJiraStatus(helpdeskIssueId: number, jiraIssueKey: string) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/link-to-jira/${helpdeskIssueId}`, {
      jiraIssueKey: jiraIssueKey,
    });
  }

  updateHelpdeskIssue(helpdeskIssue: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/update`, helpdeskIssue);
  }

  createHelpdeskIssue(helpdeskIssue: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/create`, helpdeskIssue);
  }

  getIssueTypes(filter: any) {
    return this._http.get(`${this.rootUrl}/jira/projects/issue-types`, filter);
  }

  getIssueTypeById(jiraIssueId: number) {
    return this._http.get(`${this.rootUrl}/jira-issue-types/${jiraIssueId}`);
  }

  // notifications
  getUserNotifications() {
    return this._http.get(`${this.rootUrl}/user-notifications`);
  }

  markNotificationsAsReadOrUnread(model: any) {
    return this._http.post(`${this.rootUrl}/mark-notifications-read-or-unread`, model);
  }

  searchNotifications(pageIndex: number, pageSize: number, orderBy: string = '', direction: boolean = true, filter: any) {
    return this._http.post(
      `${this.rootUrl}/notifications?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=`,
      filter
    );
  }
  // grants
  getGrants(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/grant`, filterAndPagination);
  }

  createGrant(grant: IGrantRequestModel) {
    return this._http.post(`${this.rootUrl}/grant/create`, grant);
  }

  editGrant(grant: IGrantRequestModel, grantId: number) {
    return this._http.post(`${this.rootUrl}/grant/edit/${grantId}`, grant);
  }

  getGrantsForFilter(sector?: number): Observable<TypeaheadInput[]> {
    let api = `${this.rootUrl}/grants/typeahead`;
    if (sector)
      api += `?sector=${sector}`;
    return this._http.get<TypeaheadInput[]>(api);
  }

  getGrant(grantId: number) {
    return this._http.get(`${this.rootUrl}/grant/${grantId}`);
  }

  // claims
  getClaimAuditLogs(claimId: number, filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/claims/audit?claimId=${claimId}`, filterAndPagination);
  }

  toggleClaimFraudAlert(claimId: number, reason?: string) {
    return this._http.post(`${this.rootUrl}/toggle-claim-fraudulent`, { claimId, reason });
  }

  getClaims(filterAndPagination: any, outputType: string) {
    return this._http.post(`${this.rootUrl}/claims?outputType=${outputType}`, filterAndPagination);
  }

  getClaimantClaims(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/claimant-claims`, filterAndPagination);
  }

  getClaimDocuments(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/documents`, filterAndPagination);
  }

  getClaimDocumentsForFilter(claimId?: number) {
    return this._http.get(`${this.rootUrl}/documents/typeahead/${claimId}`);
  }

  bulkLinkDocumentsToSubClaims(model: any) {
    return this._http.post(`${this.rootUrl}/documents/bulk-link-subclaims`, model);
  }

  getClaimReviewers() {
    return this._http.get(`${this.rootUrl}/claims/reviewers`);
  }

  getClaimStagesForFilter() {
    return this._http.get(`${this.rootUrl}/claim-stages/typeahead`);
  }

  assignUsersToClaims(usersToAssign: IAssignUserEmailsToIds) {
    return this._http.post(`${this.rootUrl}/claims/reviewers`, usersToAssign);
  }

  uploadEntityDocuments(formData: FormData) {
    return this._http.post(`${this.rootUrl}/upload-entity-document`, formData);
  }

  archiveClaimDocument(documentId: number) {
    return this._http.post(`${this.rootUrl}/documents/archive/${documentId}`, {});
  }

  checkExistingFiles(documentModel: any) {
    return this._http.post(`${this.rootUrl}/documents/check-exists`, documentModel);
  }

  getClaim(claimId: number) {
    return this._http.get(`${this.rootUrl}/claims/${claimId}`);
  }

  getFinanceReportStatuses(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-finance-report-statuses/${claimId}`);
  }

  getTechnicalReportStatuses(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-technical-report-statuses/${claimId}`);
  }

  updateTechnicalLeadReport(data: any) {
    return this._http.post(`${this.rootUrl}/claims/edit-technical-report`, data);
  }

  getContractsReportStatuses(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-contracts-report-statuses/${claimId}`);
  }

  getLegalReportStatuses(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-legal-report-statuses/${claimId}`);
  }

  updateContractsLeadReport(data: any) {
    return this._http.post(`${this.rootUrl}/claims/edit-contracts-report`, data);
  }

  updateFinanceLeadReport(data: any) {
    return this._http.post(`${this.rootUrl}/claims/edit-finance-report`, data);
  }

  updateLegalLeadReport(data: any) {
    return this._http.post(`${this.rootUrl}/claims/edit-legal-report`, data);
  }

  getClaimantClaim(claimId: number) {
    return this._http.get(`${this.rootUrl}/claimant-claims/${claimId}`);
  }

  getClaimsByContract(contractId: number) {
    return this._http.get(`${this.rootUrl}/claims/contract/${contractId}`);
  }

  getMoFClaim(claimId: number) {
    return this._http.get(`${this.rootUrl}/mof-claims/${claimId}`);
  }

  getDonorClaim(claimId: number) {
    return this._http.get(`${this.rootUrl}/donor-claims/${claimId}`);
  }

  getClaimRemarks(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-remarks/${claimId}`);
  }

  getExternalClaimRemarks(claimId: number) {
    return this._http.get(`${this.rootUrl}/external-claim-remarks/${claimId}`);
  }

  getClaimSectorLead(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-sector-lead/${claimId}`);
  }
  getClaimWorkflowSteps(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-workflowsteps/${claimId}`);
  }

  getClaimActions(claimId: number) {
    return this._http.get(`${this.rootUrl}/claim-actions/${claimId}`);
  }

  changeClaimStatus(claim: any) {
    return this._http.post(`${this.rootUrl}/change-claim-status`, claim);
  }

  createClaim(claim: IClaimCreateModel) {
    return this._http.post(`${this.rootUrl}/claims/create`, claim);
  }

  createClaimantClaim(claim: IClaimCreateModel) {
    return this._http.post(`${this.rootUrl}/claimant-claims/create`, claim);
  }

  editClaim(claim: IClaimEditModel) {
    return this._http.post(`${this.rootUrl}/claims/edit`, claim);
  }

  editClaimAmounts(claim: IClaimEditModel) {
    return this._http.post(`${this.rootUrl}/claims/edit-amounts`, claim);
  }

  getClaimsStatistics(output: string) {
    return this._http.get(`${this.rootUrl}/claims/statistics?output=${output}`);
  }

  getClaimLocations(claimId: number): Observable<Location[]> {
    return this._http.get<Location[]>(`${this.rootUrl}/claim-locations/${claimId}`);
  }

  addClaimLocation(claimId: number, location: Location): Observable<Location> {
    return this._http.post<Location>(`${this.rootUrl}/claim-locations/${claimId}`, location);
  }

  removeClaimLocation(claimId: number, locId: number): Observable<void> {
    return this._http.delete<void>(`${this.rootUrl}/claim-locations/${claimId}/${locId}`);
  }

  // subclaims
  getSubClaimsByClaimId(claimId: number) {
    return this._http.get(`${this.rootUrl}/sub-claims/claim/${claimId}`);
  }

  getSubClaimById(id: number) {
    return this._http.get(`${this.rootUrl}/sub-claims/${id}`);
  }

  createSubClaim(request: any) {
    return this._http.post(`${this.rootUrl}/sub-claims`, request);
  }

  updateSubClaim(request: any) {
    return this._http.put(`${this.rootUrl}/sub-claims/${request.id}`, request);
  }

  updateSubClaimStatus(request: any) {
    return this._http.patch(`${this.rootUrl}/sub-claims/${request.id}/status`, request);
  }

  deleteSubClaim(id: number) {
    return this._http.delete(`${this.rootUrl}/sub-claims/${id}`);
  }

  getSubClaimSummary(claimId: number) {
    return this._http.get(`${this.rootUrl}/sub-claims/claim/${claimId}/summary`);
  }

  // advance account
  getAdvanceAccounts(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/advance-accounts`, filterAndPagination);
  }

  getAdvanceAccount(id: number) {
    return this._http.get(`${this.rootUrl}/advance-accounts/${id}`);
  }

  createAdvanceAccount(advanceAccount: IAdvanceAccountCreateRequest) {
    return this._http.post(`${this.rootUrl}/advance-accounts/create`, advanceAccount);
  }

  editAdvanceAccount(advanceAccount: IAdvanceAccountCreateRequest, advanceAccountId: number) {
    return this._http.post(`${this.rootUrl}/advance-accounts/edit/${advanceAccountId}`, advanceAccount);
  }


  // project agreement
  getProjectAgreements(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/project-agreements`, filterAndPagination);
  }

  getProjectAgreementsForFilter(): Observable<TypeaheadInput[]> {
    return this._http.get<TypeaheadInput[]>(`${this.rootUrl}/project-agreements/typeahead`);
  }

  getProjectAgreement(id: number) {
    return this._http.get(`${this.rootUrl}/project-agreements/${id}`);
  }

  // invoices
  getInvoices(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/invoice`, filterAndPagination);
  }

  getInvoicesStatistics() {
    return this._http.get(`${this.rootUrl}/invoices/statistics`);
  }

  // withdrawal app
  getWithdrawalApplications(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/withdrawal-applications`, filterAndPagination);
  }

  getWithdrawalApplicationsStatistics() {
    return this._http.get(`${this.rootUrl}/withdrawal-applications/statistics`);
  }

  // contracts
  getContracts(filterAndPagination: any, outputType: string) {
    return this._http.post(`${this.rootUrl}/contract?&outputType=${outputType}`, filterAndPagination);
  }

  getContract(contractId: number) {
    return this._http.get(`${this.rootUrl}/contract/${contractId}`);
  }

  getContractsForFilter(sector?: number, grantId?: number): Observable<TypeaheadInput[]> {
    let api = `${this.rootUrl}/contracts/typeahead?`;
    if (sector)
      api += `&sector=${sector}`;
    if (grantId)
      api += `&grantId=${grantId}`;
    return this._http.get<TypeaheadInput[]>(api);
  }

  createContract(contract: IContractRequestModel) {
    return this._http.post(`${this.rootUrl}/contract/create`, contract);
  }

  editContract(contract: IContractRequestModel, contractId: number) {
    return this._http.post(`${this.rootUrl}/contract/edit/${contractId}`, contract);
  }

  // expenses
  getExpenses(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/expenses`, filterAndPagination);
  }

  getExpense(expenseId: number) {
    return this._http.get(`${this.rootUrl}/expense/${expenseId}`);
  }

  createExpense(expense: ExpenseRequestModel) {
    return this._http.post(`${this.rootUrl}/expenses/create`, expense);
  }

  editExpense(expense: ExpenseRequestModel, expenseId: number) {
    return this._http.post(`${this.rootUrl}/expenses/edit/${expenseId}`, expense);
  }

  // staff
  getAllStaff(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/staff`, filterAndPagination);
  }

  getStaff(staffId: number) {
    return this._http.get(`${this.rootUrl}/staff/${staffId}`);
  }

  createStaff(staff: IStaffBaseModel) {
    return this._http.post(`${this.rootUrl}/staff/create`, staff);
  }

  editStaff(staff: IStaffBaseModel, staffId: number) {
    return this._http.post(`${this.rootUrl}/staff/edit/${staffId}`, staff);
  }

  getStaffForFilter() {
    return this._http.get(`${this.rootUrl}/staff/typeahead`);
  }

  // staff-contract
  getAllStaffContracts(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/staff-contracts`, filterAndPagination);
  }

  getStaffContract(staffContractId: number) {
    return this._http.get(`${this.rootUrl}/staff-contracts/${staffContractId}`);
  }

  createStaffContract(staffContract: IStaffContractBaseModel) {
    return this._http.post(`${this.rootUrl}/staff-contracts/create`, staffContract);
  }

  editStaffContract(staffContract: IStaffContractBaseModel, staffContractId: number) {
    return this._http.post(`${this.rootUrl}/staff-contracts/edit/${staffContractId}`, staffContract);
  }

  getStaffContractsForFilter() {
    return this._http.get(`${this.rootUrl}/staff-contracts/typeahead`);
  }

  // staff salary
  getSalaries(filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/salaries`, filterAndPagination);
  }

  getSalary(salaryId: number) {
    return this._http.get(`${this.rootUrl}/salaries/${salaryId}`);
  }

  createSalary(salary: ISalaryBaseModel) {
    return this._http.post(`${this.rootUrl}/salaries/create`, salary);
  }

  editSalary(salary: ISalaryBaseModel, salaryId: number) {
    return this._http.post(`${this.rootUrl}/salaries/edit/${salaryId}`, salary);
  }

  // currency conversion
  getCurrentCurrencyExchangeRates(pageIndex: number, pageSize: number) {
    return this._http.get(`${this.rootUrl}/currency-conversion-rates?pageIndex=${pageIndex}&pageSize=${pageSize}`);
  }

  showRateHistory(from: string, to: string, pageIndex: number = 1, pageSize: number = 10) {
    return this._http.get(`${this.rootUrl}/currency-conversion-rate-history?fromCurrency=${from}&toCurrency=${to}&pageIndex=${pageIndex}&pageSize=${pageSize}`);
  }

  createOrUpdateConversion(model: any) {
    return this._http.post(`${this.rootUrl}/create-currency-conversion-rate`, model);
  }

  getExternalEntityTypes() {
    return this._http.get(`${this.rootUrl}/external-entity-types`);
  }

  linkEntityToGoogleDriveDocument(googleDriveDocumentModel: any[]) {
    return this._http.post(`${this.rootUrl}/link-entity-to-documents-google-drive`, googleDriveDocumentModel);
  }

  editDocuments(documents: any[]) {
    return this._http.post(`${this.rootUrl}/edit-documents`, documents);
  }

  addRemark(
    entityType: RemarkType,
    entityId: number,
    remarkText: string,
    taggedUsers: string[],
    isTask: boolean,
    assignedTo: string,
    taskUserType: number,
    isExternalCommunication: boolean,
    deadline: Date,
    parentId?: number
  ) {
    return this._http.post(`${this.rootUrl}/remarks`, {
      entityType: entityType,
      entityId: entityId,
      remarkText: remarkText,
      parentId: parentId,
      taggedUsers: taggedUsers,
      isTask: isTask,
      assignedTo: assignedTo,
      taskUserType: taskUserType,
      isExternal: isExternalCommunication,
      deadline: deadline,
    });
  }

  updateRemark(remarkId: number, remarkText: string) {
    return this._http.put(`${this.rootUrl}/remarks/update`, {
      id: remarkId,
      remarkText: remarkText
    });
  }

  deleteRemark(remarkId: number) {
    return this._http.delete(`${this.rootUrl}/remarks/delete/${remarkId}`);
  }

  // // dashboard
  // getAllGrantsStatistics() {
  //   return this._http.get(`${this.rootUrl}/statistics/grants`);
  // }

  getAllContractsStatistics(output: string) {
    return this._http.get(`${this.rootUrl}/statistics/contracts?output=${output}`);
  }

  getAllAdvanceAccountsStatistics(output: string) {
    return this._http.get(`${this.rootUrl}/statistics/advance-accounts?output=${output}`);
  }

  getAllClaimsStatistics(output: string, type?: number, status?: number, sector?: number) {
    return this._http.get(`${this.rootUrl}/statistics/claims?output=${output}`);
  }

  getGenericEntity(entityType: string, id: number) {
    return this._http.get(`${this.rootUrl}/${entityType}/${id}`);
  }

  getEntityAuditLogs(entityName: string, entityId: number, filterAndPagination: any) {
    return this._http.post(`${this.rootUrl}/audit?entityId=${entityId}&entityName=${entityName}`, filterAndPagination);
  }

  getEntityDocuments(filter: any) {
    return this._http.post(`${this.rootUrl}/documents`, filter);
  }

  getDocumentCategories(pageIndex: number, pageSize: number, orderBy: string = '', direction: boolean = true, filter = '')  {
    return filter === ''
      ? this._http.get(`${this.rootUrl}/document-categories?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=${orderBy}&ascending=${direction}`)
      : this._http.get(
          `${this.rootUrl}/document-categories?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=${orderBy}&ascending=${direction}&query=${filter}`
        );
  }
  
  getDocumentCategoriesForFilter() {
    return this._http.get(`${this.rootUrl}/document-categories/typeahead`);
  }

  updateDocumentCategory(model: any) {
    return this._http.post(`${this.rootUrl}/update-document-category`, model);
  }
  
  getMyTasks(filter: any) {
    return this._http.post(`${this.rootUrl}/my-tasks`, filter);
  }
  getMyCreatedTasks(filter: any) {
    return this._http.post(`${this.rootUrl}/my-created-tasks`, filter);
  }
  getTask(taskId: number) {
    return this._http.get(`${this.rootUrl}/task/${taskId}`);
  }
  getTaskAssignableUsers(taskUserType: TaskUserType) {
    return this._http.get(`${this.rootUrl}/task/task-assignable-users?userType=${taskUserType}`);
  }
  getTaskAssignableUsersForEntity(entityId: number, externalUsersOnly: boolean = true, entityType: number = 1) {
    return this._http.get(`${this.rootUrl}/task/task-assignable-users/${entityId}?externalUsersOnly=${externalUsersOnly}&entityType=${entityType}`);
  }
  updateTaskStatus(taskId: number, newStatus: number) {
    return this._http.post(`${this.rootUrl}/task/update-task-status`, {
      id: taskId,
      taskStatus: newStatus,
    });
  }
  reassignTask(taskId: number, assignedTo: string) {
    return this._http.post(`${this.rootUrl}/task/reassign-task`, {
      id: taskId,
      assignedTo: assignedTo,
    });
  }

  getOutput1ConsolidatedPlanProgressStatusReport(request: any): Observable<any> {
    return this._http.post(`${this.rootUrl}/reports/output1-consolidated-plan-progress`, request);
  }

  exportOutput1ConsolidatedPlanProgressStatusReport(request: any): Observable<Blob> {
    return this._http.post(`${this.rootUrl}/reports/output1-consolidated-plan-progress/export`, request, {
      responseType: 'blob'
    });
  }
}
