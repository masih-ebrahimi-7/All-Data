import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { 
  ClaimStageResponseModel, 
  CreateClaimStageRequestModel, 
  EditClaimStageRequestModel,
  ClaimStageHistoryResponseModel,
  MoveClaimStageRequestModel 
} from '../models/claim-stage.models';

@Injectable({
  providedIn: 'root'
})
export class ClaimStageService {
  public apiUrl = '/api/claim-stages';
  constructor(private http: HttpClient) { }

  getAllStages(): Observable<ClaimStageResponseModel[]> {
    return this.http.get<ClaimStageResponseModel[]>(this.apiUrl);
  }

  getActiveStages(): Observable<ClaimStageResponseModel[]> {
    return this.http.get<ClaimStageResponseModel[]>(`${this.apiUrl}/active`);
  }

  getStageById(id: number): Observable<ClaimStageResponseModel> {
    return this.http.get<ClaimStageResponseModel>(`${this.apiUrl}/${id}`);
  }

  createStage(request: CreateClaimStageRequestModel): Observable<ClaimStageResponseModel> {
    return this.http.post<ClaimStageResponseModel>(`${this.apiUrl}/create`, request);
  }

  updateStage(request: EditClaimStageRequestModel): Observable<ClaimStageResponseModel> {
    return this.http.post<ClaimStageResponseModel>(`${this.apiUrl}/edit/${request.id}`, request);
  }

  deleteStage(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getClaimStageHistory(claimId: number): Observable<ClaimStageHistoryResponseModel[]> {
    return this.http.get<ClaimStageHistoryResponseModel[]>(`${this.apiUrl}/${claimId}/history`);
  }

  moveClaimToStage(request: MoveClaimStageRequestModel): Observable<ClaimStageHistoryResponseModel> {
    return this.http.post<ClaimStageHistoryResponseModel>(`${this.apiUrl}/move`, request);
  }

  getCurrentClaimStage(claimId: number): Observable<ClaimStageHistoryResponseModel | null> {
    return this.http.get<ClaimStageHistoryResponseModel | null>(`${this.apiUrl}/${claimId}/current`);
  }
}
