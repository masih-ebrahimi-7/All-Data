import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ExternalAuthDto } from '../app-shared/home/home.component';

@Injectable({
  providedIn: 'root',
})
export class ExternalUserRequestService {
  public rootUrl = '/api';
  constructor(private _http: HttpClient) {}

  login(externalAuth: ExternalAuthDto) {
    return this._http.post(`${this.rootUrl}/accounts/externallogin`, externalAuth);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getConfigs() {
    return this._http.get(`${this.rootUrl}/configs`);
  }

  getInvoices(pageIndex: number, pageSize: number, filter = '', orderBy = '', ascending = true) {
    return filter == ''
      ? this._http.get(
          `${this.rootUrl}/invoices?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=${orderBy}&ascending=${ascending}`
        )
      : this._http.get(
          `${this.rootUrl}/invoices?pageIndex=${pageIndex}&pageSize=${pageSize}&query=${filter}&orderBy=${orderBy}&ascending=${ascending}`
        );
  }

  deleteInvoice(id: string, path: string) {
    return this._http.post(`${this.rootUrl}/delete-invoice`, { Path: path, Id: id });
  }

  saveAdditionalEmails(emails: any) {
    return this._http.post(`${this.rootUrl}/notification-emails`, emails);
  }

  getNotificationEmails() {
    return this._http.get(`${this.rootUrl}/get-notification-emails`);
  }

  getUserExternalUsers() {
    return this._http.get(`${this.rootUrl}/user-external-users`);
  }

  getEnum(enumName: any) {
    return this._http.get(`${this.rootUrl}/enum/${enumName}`);
  }

  getEnumValues(enumName: any) {
    return this._http.get(`${this.rootUrl}/enum-value/${enumName}`);
  }

  getExternalUserHelpdeskIssues(pageIndex: number, pageSize: number, filter: any) {
    return this._http.post(
      `${this.rootUrl}/helpdesk-issues?pageIndex=${pageIndex}&pageSize=${pageSize}&orderBy=`,
      filter
    );
  }

  geExternalUsertHelpdeskIssue(helpdeskIssueId: string) {
    return this._http.get(`${this.rootUrl}/helpdesk-issues/${helpdeskIssueId}`);
  }

  updateExternalEntityUserHelpdeskIssue(helpdeskIssue: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issues/update`, helpdeskIssue);
  }

  createExternalUserHelpdeskIssue(helpdeskIssue: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/create`, helpdeskIssue);
  }

  createExternalUserHelpdeskIssueComment(helpdeskIssueComment: any) {
    return this._http.post(`${this.rootUrl}/helpdesk-issue/${helpdeskIssueComment.helpdeskIssueId}/comments`, helpdeskIssueComment);
  }

}
