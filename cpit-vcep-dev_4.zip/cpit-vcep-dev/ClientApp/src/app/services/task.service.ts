import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { RequestService } from './request.service';
import { TokenService } from './auth/token.service';
import { PermissionsService } from './auth/permissions.service';
import { OutputType } from '../models/enums/ui-enums';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  isLoggedIn: boolean;
  permissions: any | null;

  constructor(private http: HttpClient, 
    private request: RequestService,  
    private tokenService: TokenService,
    private permissionService: PermissionsService) {
    this.isLoggedIn = this.tokenService.loggedIn();
    this.permissions = permissionService.get();
  }
  
  getPendingTasksCount(): Observable<number> {
    return this.request.getMyTasks({
      filter: { }, Statuses: [1, 2, 3] })
      .pipe(map((response: any) => response.totalCount));
  }

  getPendingClaimsToClearCount(): Observable<number> {
    return this.request.getClaims({}, OutputType.AwaitingClearance)
      .pipe(map((response: any) => response.totalCount));
  }

  pollPendingTasksCount(intervalMs: number): Observable<number> {
    if (this.isLoggedIn && this.permissions?.CanViewTasks)
      return timer(0, intervalMs).pipe(
        switchMap(() => this.getPendingTasksCount())
      );
    return of(0);
  }

  pollPendingClaimsToClearCount(intervalMs: number): Observable<number> {
    if (this.isLoggedIn && (this.permissions?.CanViewClaimsClearance || this.permissions?.CanManageClaimsClearance))
      return timer(0, intervalMs).pipe(
        switchMap(() => this.getPendingClaimsToClearCount())
      );
    return of(0);
  }
}
