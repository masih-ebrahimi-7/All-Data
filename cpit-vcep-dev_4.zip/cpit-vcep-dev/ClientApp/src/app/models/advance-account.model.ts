import { IModifiableEntity } from "../common/interfaces";
import { FundSourceType, SectorType } from "./enums/server-enums";
import { IWithdrawalApplicationBase, IWithdrawalApplicationCreateRequest, IWithdrawalApplicationResponse } from "./withdrawal-application.model";

export interface IAdvanceAccountBase {
    accountName: string;
    accountNumber: string;
    grantId?: number | null;
    currencyId: number;
    fundSource: FundSourceType;
    sector: SectorType;
    implementingAgency: string;
    distributionDate: Date;
    latestDisbursementDate?: Date;
    lastDistributionAmount: number;
    unliquidatedAmountUsd: number;
    bankBalanceAccountCurrency: number;
    uncreditedAmount?: number;
    newOtherReceiptsAmount?: number;
    newExpensesPaymentsAmount?: number;
    verifiedExpensesPaymentsAmount?: number;
    rejectedExpensesPaymentsAmount?: number;
  }

  export interface IAdvanceAccountResponse extends IAdvanceAccountBase {
    id: number;
    latestWithdrawalApplication?: IWithdrawalApplicationResponse;
    differenceUsd?: number;
    unreconciledAmountUsd?: number;
    refundableAmount?: number;
  }

  export interface IAdvanceAccountCreateRequest extends IAdvanceAccountBase {
    latestWithdrawalApplication?: IWithdrawalApplicationCreateRequest;
  }

  export interface IAdvanceAccountEditRequest extends IAdvanceAccountCreateRequest {
    id: number;
  }