import { Grant } from './grant.model';
import { IModifiableEntity } from '../common/interfaces';
import { ADBSanctionStatus, AuthorityType, SectorType } from './enums/server-enums';

export interface Expense extends IModifiableEntity {
    reference: string;
    description: string;
    currencyId: string;
    monthlyCost: number;
    numberOfMonths: number;
    pendingClaimsAmount: number;
    grants?: Grant[] | null;
    externalEntityId?: number | null;
    screeningDate?: Date | null;
    dateOfExpenditureStart?: Date | null;
    dateOfExpenditureEnd?: Date | null;
    expenseType: AuthorityType;
    adbSanctionStatus: ADBSanctionStatus;
    nationality?: string;
    remarks?: string;
    sector?: SectorType;
    contractAuthority?: AuthorityType;
    expenditureType?: string;
    contractReference?: string;
    documentUploadUrl?: string;
}

export class ExpenseResponseModel implements Expense {
    pendingClaimsAmount: number;
    id: number;
    reference: string;
    description: string;
    currencyId: string;
    monthlyCost: number;
    numberOfMonths: number;
    pendingClaimsAmountUsd: number;
    monthlyCostUsd: number;
    pendingClaimsUsd: number;
    grants?: Grant[] | null;
    externalEntityId?: number | null;
    screeningDate?: Date | null;
    dateOfExpenditureStart?: Date | null;
    dateOfExpenditureEnd?: Date | null;
    expenseType: AuthorityType;
    expenseTypeLabel: string;
    adbSanctionStatus: ADBSanctionStatus;
    adbSanctionStatusLabel: string;
    createdBy: string;
    grantIds?: number[];
    createdDate: Date;
    lastModifiedBy?: Date | undefined;
    lastModifiedDate?: string | undefined;
    nationality?: string;
    remarks?: string;
    sector?: SectorType;
    contractAuthority?: AuthorityType;
    expenditureType?: string;
    contractReference?: string;
    documentUploadUrl?: string;
}

export class ExpenseRequestModel {
    description: string;
    currencyId: string;
    monthlyCost: number;
    pendingClaimsAmount: number;
    numberOfMonths: number;
    grants?: Grant[] | null;
    externalEntityId?: number | null;
    screeningDate?: string | null;
    dateOfExpenditureStart?: string | null;
    dateOfExpenditureEnd?: string | null;
    expenseType?: AuthorityType = AuthorityType.PMO;
    adbSanctionStatus: ADBSanctionStatus;
    grantIds?: number[];
    nationality?: string;
    remarks?: string;
    sector?: SectorType;
    contractAuthority?: AuthorityType;
    expenditureType?: string;
    contractReference?: string;
    documentUploadUrl?: string;
}

export class ExpenseEditRequestModel extends ExpenseRequestModel{
    id: number;
}