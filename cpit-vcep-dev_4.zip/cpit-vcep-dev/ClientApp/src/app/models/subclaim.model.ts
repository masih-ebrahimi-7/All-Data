export interface ISubClaim {
  id?: number;
  subSeqNo: number;
  referenceCode: string;
  type: SubClaimType;
  typeLabel?: string;
  invoiceIpcDate: Date;
  invoiceIpcNumber: string;
  invoiceIpcDescription?: string;
  currencyId: string;
  currencyCode?: string;
  claimAmount: number;
  claimAmountUsd?: number;
  verifiedAmount?: number;
  verifiedAmountUsd?: number;
  eligibilityStatus?: EligibilityStatus;
  eligibilityStatusLabel?: string;
  remarks?: string;
  claimId: number;
  createdBy?: string;
  createdDate?: Date;
  lastModifiedBy?: string;
  lastModifiedDate?: Date;
  isDeleted?: boolean;
  currencyRate?: number;
}

export interface ICreateSubClaimRequest {
  type: SubClaimType;
  invoiceIpcDate: Date;
  invoiceIpcNumber: string;
  invoiceIpcDescription?: string;
  currencyId: string;
  claimAmount: number;
  verifiedAmount?: number;
  remarks?: string;
  claimId: number;
}

export interface IEditSubClaimRequest {
  id: number;
  type: SubClaimType;
  invoiceIpcDate: Date;
  invoiceIpcNumber: string;
  invoiceIpcDescription?: string;
  currencyId: string;
  claimAmount: number;
  verifiedAmount?: number;
  remarks?: string;
}

export interface IUpdateSubClaimStatusRequest {
  id: number;
  status: EligibilityStatus;
  notes?: string;
}

export interface ISubClaimSummary {
  totalCount: number;
  eligibleCount: number;
  ineligibleCount: number;
  totalClaimAmount: number;
  totalVerifiedAmount: number;
  eligibleAmount: number;
  ineligibleAmount: number;
}

export enum SubClaimType {
  Invoice = 1,
  IPC = 2
}

export enum EligibilityStatus {
  Eligible = 1,
  Ineligible = 2
}

export const SubClaimTypeLabels = {
  [SubClaimType.Invoice]: 'Invoice',
  [SubClaimType.IPC]: 'IPC'
};

export const EligibilityStatusLabels = {
  [EligibilityStatus.Eligible]: 'Eligible',
  [EligibilityStatus.Ineligible]: 'Ineligible'
};

export type SubClaim = ISubClaim;
export type SubClaimRequest = ICreateSubClaimRequest;
export type SubClaimUpdate = IEditSubClaimRequest;
export type SubClaimStatusUpdate = IUpdateSubClaimStatusRequest;
