import { IModifiableEntity } from "../common/interfaces";
import { WithdrawalApplicationType } from "./enums/server-enums";

export interface IWithdrawalApplicationBase {
  withdrawalApplicationNumber: string;
  withdrawalApplicationDate: Date;
  type: WithdrawalApplicationType;
  currencyId: number;
  unliquidatedBalance: number;
  notCreditedAmount: number;
}

export interface IWithdrawalApplicationCreateRequest extends IWithdrawalApplicationBase {
}

export interface IWithdrawalApplicationEditRequest extends IWithdrawalApplicationCreateRequest {
  id: number;
}

export interface IWithdrawalApplicationResponse extends IWithdrawalApplicationBase, IModifiableEntity {
  id: number;
}
