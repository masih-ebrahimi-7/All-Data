import { IModifiableEntity } from "../common/interfaces";
import { StaffType, StaffEmployerType } from "./enums/server-enums";
import { Grant } from "./grant.model";

export interface IStaffBaseModel {
    fullName: string;
    designation: string;
    nationality: string;
    employer: StaffEmployerType;
    accountNumber?: string;
    staffType: StaffType;
}

export interface IStaffResponseModel extends IStaffBaseModel, IModifiableEntity {
    id: number;
    staffTypeLabel: string;
    employerLabel: string;
}

export interface IStaffContractBaseModel {
    reference: string;
    contractStartDate: Date;
    contractEndDate: Date;
    contractCurrencyId: string;
    basicSalary: number;
    allowances?: number;
}

export interface IStaffContractResponseModel extends IStaffContractBaseModel, IModifiableEntity {
    id: number;
    contractCurrencyCode: string;
}

export interface ISalaryBaseModel {
    staffId: number;
    grantId?: number;
    staffContractId: number;
    pendingForJanuary21?: number;
    pendingForFebruary21?: number;
    pendingForMarch21?: number;
    pendingForApril21?: number;
    pendingForMay21?: number;
    pendingForJune21?: number;
    pendingForJuly21?: number;
    pendingForAugust21?: number;
    totalPendingSalary?: number;
    terminationPayment?: number;
    taxDeductible?: number;
    advance?: number;
    contractDocumentUrl?: string;
    timeSheetUrl?: string;
    previousRecord?: string;
    nonPaymentConfirmation: boolean;
    adbSanctionStatus?: number;
    screeningDate?: Date;
    remarks?: string;
}

export interface ISalaryResponseModel extends ISalaryBaseModel, IModifiableEntity {
    id: number;
    reference: string;
    staff?: IStaffResponseModel;
    grant?: Grant;
    staffContract?: IStaffContractResponseModel;
    netAmountPayable?: number;
  }