import { IModifiableEntity } from "../common/interfaces";
import { Contract } from "./contract.model";

export interface IGrantRequestModel {
    name: string;
    reference: string;
    description?: string;
    priority: string;
    sector: string;
}

export interface Grant extends IModifiableEntity {
    reference: string;
    priority: string;
    priorityLabel: string;
    description?: string;
    sector: string;
    sectorLabel: string;
    name: string;
    contracts: Contract[];
}