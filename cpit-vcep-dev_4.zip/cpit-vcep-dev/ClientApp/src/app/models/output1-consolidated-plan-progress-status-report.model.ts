export interface Output1ConsolidatedPlanProgressStatusReportModel {
  claimId: number;
  wbs: string;
  number: number;
  priority: string;
  donor: string;
  grantNumber: string;
  contractNumber: string;
  contractTitle: string;
  claimant: string;
  countryOfRegistration: string;
  claimedAmount: number;
  claimedAmountCurrency: string;
  unopsRecommendation: number;
  unopsRecommendationCurrency: string;
  unopsRecommendationAugust2025USD: number;
  progressPercentageComplete: number;
  stages: ClaimStageProgressModel[];
}

export interface ClaimStageProgressModel {
  stageId: number;
  stageName: string;
  stageDescription: string;
  weightPercentage: number;
  sortOrder: number;
  estimatedDurationWeeks?: number;
  estimatedDeliveryTimeline: string;
  estimatedCompletionDate?: string | null;
  actualCompletionDate?: string | null;
  isCompleted: boolean;
  isCurrentStage: boolean;
  statusLabel: string;
  parentStageId?: number;
  parentStageName?: string;
  hasChildren: boolean;
  children: ClaimStageProgressModel[];
}

export interface Output1ConsolidatedPlanProgressStatusReportRequest {
  pageIndex: number;
  pageSize: number;
  searchTerm?: string;
  priorityFilter?: string;
  donorFilter?: string;
  progressMin?: number;
  progressMax?: number;
}

export interface Output1ConsolidatedPlanProgressStatusReportResponse {
  records: Output1ConsolidatedPlanProgressStatusReportModel[];
  totalCount: number;
}
