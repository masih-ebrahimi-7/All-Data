export interface ClaimStageResponseModel {
  id: number;
  name: string;
  description?: string;
  weightPercentage?: number;
  estimatedDurationWeeks?: number;
  sortOrder: number;
  isActive: boolean;
  parentStageId?: number;
  estimatedDeliveryTimeline?: string;
  createdDate: Date;
  lastModifiedDate?: Date;
  parentStageName?: string;
  children: ClaimStageResponseModel[];
  totalChildrenWeight: number;
  hasChildren: boolean;
}

export interface CreateClaimStageRequestModel {
  name: string;
  description?: string;
  weightPercentage?: number;
  estimatedDurationWeeks?: number;
  sortOrder: number;
  isActive: boolean;
  parentStageId?: number;
  estimatedDeliveryTimeline?: string;
}

export interface EditClaimStageRequestModel {
  id: number;
  name: string;
  description?: string;
  weightPercentage?: number;
  estimatedDurationWeeks?: number;
  sortOrder: number;
  isActive: boolean;
  parentStageId?: number;
  estimatedDeliveryTimeline?: string;
}

export interface ClaimStageHistoryResponseModel {
  id: number;
  claimId: number;
  claimStageId: number;
  stageName: string;
  stageDescription: string;
  stageWeightPercentage?: number;
  stageEstimatedDurationWeeks: number;
  startDate: Date;
  completedDate?: Date;
  estimatedCompletionDate?: Date;
  notes?: string;
  isCurrentStage: boolean;
  movedByUserId?: string;
  movedByUserName?: string;
  createdDate: Date;
  actualDurationDays?: number;
  isOverdue: boolean;
  progressPercentage: number;
}

export interface MoveClaimStageRequestModel {
  claimId: number;
  toStageId: number;
  notes?: string;
  estimatedCompletionDate?: Date;
}
