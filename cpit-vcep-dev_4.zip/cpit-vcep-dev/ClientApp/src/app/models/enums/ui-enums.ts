export enum BulkSubscriptionType {
  Follow,
  UnFollow,
}

export enum OutputType {
  OutputOne = 'output-one',
  OutputTwo = 'output-two',
  AwaitingClearance = 'awaiting-clearance',
  Rejected = 'rejected'
}

export enum BulkNotificationAction {
  MarkAsRead,
  MarkAsUnread,
}

export enum UserManagementPageType {
  All = 0,
  Internal = 1,
  External = 2,
}