import { IModifiableEntity } from "../common/interfaces";
import { Grant } from "./grant.model";

export interface Contract extends IModifiableEntity {
    name: string;
    pcssNumber: string;
    reference: string;
    description?: string;
    contractType: string;
    startDate?: Date;
    endDate?: Date;
    revisedEndDate?: Date;
    fundSource: string;
    amount?: number;
    currencyId: number;
    amountUsd?: number;
    disbursement?: number;
    undisbursedAmount?: number;
    priorityType: string;
    invoices: any[];
    projectAgreementReference?: string;
    projectAgreementId?: number;
    grantIds?: number[];
    grants?: Grant[];
    externalEntityId: number;
    location?: any;
}


export interface IContractRequestModel {
    name: string;
    reference: string;
    description?: string;
    pcssNumber: string;
    fundSource: string;
    startDate?: Date;
    endDate?: Date;
    revisedEndDate?: Date;
    contractType: string;
    priorityType: string;
    amount?: number;
    currencyId: number;
    disbursement?: number;
    undisbursedAmount?: number;
    externalEntityId: number;
    grantIds: number[];
    location: any;
}

export interface IContract {
    externalEntityId: number;
}
