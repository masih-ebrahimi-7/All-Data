import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-privacy',
  templateUrl: './privacy.component.html',
  styleUrls: ['./privacy.component.css'],
})
export class PrivacyComponent implements OnInit {
  policies: any;

  constructor(private translate: TranslateService) {}

  ngOnInit(): void {
    this.policies = [
      {
        title: this.translate.instant('policy.informationCollection'),
        content: this.translate.instant('policy.informationCollectionDescription'),
      },
      {
        title: this.translate.instant('policy.howInformationUsed'),
        content: this.translate.instant('policy.howInformationUsedDescription'),
      },
      {
        title: this.translate.instant('policy.sharingInformation'),
        content: this.translate.instant('policy.sharingInformationDescription'),
      },
      {
        title: this.translate.instant('policy.howInformationSecured'),
        content: this.translate.instant('policy.howInformationSecuredDescription'),
      },
      {
        title: this.translate.instant('policy.informationRetention'),
        content: this.translate.instant('policy.informationRetentionDescription'),
      },
      {
        title: this.translate.instant('policy.informationAccess'),
        content: this.translate.instant('policy.informationAccessDescription'),
      },
      {
        title: this.translate.instant('policy.cookies'),
        content: this.translate.instant('policy.cookiesDescription'),
      },
    ];
  }
}
