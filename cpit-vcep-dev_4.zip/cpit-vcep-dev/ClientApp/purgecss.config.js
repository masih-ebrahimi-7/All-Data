module.exports = {
  content: [
    './dist/**/*.html',
    './dist/**/*.js'
  ],
  css: ['./dist/**/*.css'],
  safelist: [], // Add any selectors you want to always keep
}; 